<!-- file: application/views/is/dashboard.php -->
<style>
    /* Dashboard IS styles - konsisten dengan tema ungu + biru + hitam */
    .dashboard-header {
        background: linear-gradient(135deg, #0f0f1a 0%, #13111f 100%);
        border-radius: 20px;
        padding: 16px 20px;
        margin-bottom: 20px;
        border: 1px solid var(--border);
        display: flex;
        justify-content: space-between;
        align-items: center;
        flex-wrap: wrap;
        gap: 16px;
    }
    
    .dashboard-title h1 { 
        font-size: 20px; 
        font-weight: 700; 
        background: linear-gradient(135deg, var(--purple), var(--cyan), var(--blue));
        -webkit-background-clip: text; 
        background-clip: text; 
        color: transparent;
    }
    
    .dashboard-title .sub { 
        font-size: 10px; 
        color: var(--text-secondary); 
        margin-top: 4px;
    }
    
    /* Desktop Menu */
    .desktop-menu {
        display: flex;
        gap: 12px;
        align-items: center;
        flex-wrap: wrap;
    }
    
    .desktop-menu a {
        color: var(--text-muted);
        text-decoration: none;
        font-size: 13px;
        font-weight: 500;
        padding: 6px 14px;
        border-radius: 40px;
        transition: var(--transition);
    }
    
    .desktop-menu a:hover, .desktop-menu a.active {
        background: var(--purple-glow);
        color: var(--purple);
    }
    
    .stat-cards-dashboard { 
        display: flex; 
        gap: 20px; 
        background: rgba(139, 92, 246, 0.1);
        padding: 6px 16px; 
        border-radius: 60px; 
        border: 1px solid var(--border);
    }
    
    .stat-item-dashboard { text-align: center; padding: 2px 6px; }
    .stat-label-dashboard { font-size: 9px; color: var(--text-muted); }
    .stat-value-dashboard { font-size: 18px; font-weight: 700; background: linear-gradient(135deg, var(--purple), var(--blue)); -webkit-background-clip: text; background-clip: text; color: transparent; }
    
    /* Tabs */
    .tabs-bar-dashboard { display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 12px; margin-bottom: 20px; border-bottom: 1px solid var(--border); padding-bottom: 10px; }
    .tabs-dashboard { display: flex; gap: 6px; flex-wrap: wrap; }
    .tab-btn-dashboard { background: transparent; border: none; padding: 6px 16px; font-size: 12px; font-weight: 600; color: var(--text-muted); cursor: pointer; border-radius: 40px; transition: var(--transition); }
    .tab-btn-dashboard.active { background: linear-gradient(135deg, var(--purple-glow), rgba(59, 130, 246, 0.1)); color: var(--purple); border: 1px solid rgba(139, 92, 246, 0.4); }
    .scout-btn-dashboard { background: linear-gradient(135deg, var(--purple-glow), rgba(6, 182, 212, 0.1)); border: 1px solid var(--purple); padding: 6px 16px; border-radius: 40px; color: var(--purple); font-weight: 600; cursor: pointer; font-size: 12px; transition: var(--transition); }
    .scout-btn-dashboard:hover { background: var(--purple); color: white; }
    
    .tab-content-dashboard { display: none; animation: fadeIn 0.3s ease; }
    .tab-content-dashboard.active { display: block; }
    
    /* Stages Container */
    .stages-scroll-dashboard { overflow-x: auto; overflow-y: visible; margin-bottom: 20px; padding-bottom: 12px; }
    .stages-container-dashboard { display: flex; flex-direction: row; gap: 16px; min-width: min-content; }
    
    /* Warna berbeda untuk setiap stage card */
    .stage-card-dashboard { border-radius: 20px; padding: 16px; width: 340px; flex-shrink: 0; transition: var(--transition); border: 1px solid var(--border); }
    .stage-card-dashboard[data-stage="1"] { background: linear-gradient(135deg, #1a1030, #13111f); border-top: 3px solid var(--purple); }
    .stage-card-dashboard[data-stage="2"] { background: linear-gradient(135deg, #0f1a2e, #13111f); border-top: 3px solid var(--blue); }
    .stage-card-dashboard[data-stage="3"] { background: linear-gradient(135deg, #0a1a1f, #13111f); border-top: 3px solid var(--cyan); }
    .stage-card-dashboard[data-stage="4"] { background: linear-gradient(135deg, #0a1f15, #13111f); border-top: 3px solid var(--green); }
    
    .stage-card-dashboard.completed { opacity: 0.7; }
    .stage-title-dashboard { font-weight: 700; font-size: 14px; margin-bottom: 14px; padding-bottom: 8px; border-bottom: 1px solid var(--border); display: flex; align-items: center; gap: 10px; flex-wrap: wrap; justify-content: space-between; color: var(--text-primary); }
    .stage-count-dashboard { background: var(--bg-elevated); padding: 2px 8px; border-radius: 40px; font-size: 10px; }
    
    /* Items */
    .stage-item-dashboard { background: var(--bg-elevated); border-radius: 14px; padding: 12px; margin-bottom: 10px; cursor: pointer; transition: var(--transition); border: 1px solid transparent; }
    .stage-item-dashboard:hover { border-color: var(--purple); transform: translateX(3px); }
    .stage-item-dashboard strong { display: flex; align-items: center; gap: 8px; margin-bottom: 6px; color: var(--text-primary); font-size: 13px; }
    .item-details-dashboard { display: flex; flex-wrap: wrap; gap: 10px; font-size: 10px; color: var(--text-secondary); margin-bottom: 6px; }
    .badge-dashboard { display: inline-flex; align-items: center; gap: 4px; padding: 2px 8px; border-radius: 20px; font-size: 9px; font-weight: 600; }
    .badge-pending { background: rgba(245, 158, 11, 0.15); color: #f59e0b; }
    .badge-active { background: rgba(16, 185, 129, 0.15); color: #10b981; }
    .badge-approved { background: rgba(139, 92, 246, 0.15); color: #8b5cf6; }
    
    .task-btn-dashboard { margin-top: 14px; width: 100%; padding: 8px; border-radius: 40px; border: none; background: var(--bg-elevated); color: var(--text-secondary); font-weight: 600; cursor: pointer; transition: var(--transition); font-size: 12px; }
    .task-btn-dashboard:hover:not(:disabled) { background: linear-gradient(135deg, var(--purple), var(--blue)); color: white; }
    .task-btn-dashboard:disabled { opacity: 0.5; cursor: not-allowed; }
    
    /* Product item */
    .product-item-dashboard { background: #0f1420; border-radius: 12px; padding: 10px; margin-top: 8px; display: flex; justify-content: space-between; align-items: center; border: 1px solid #2a3346; }
    .product-info-dashboard { flex: 1; }
    .product-name-dashboard { color: #ffffff; font-size: 12px; font-weight: 500; }
    .product-price-dashboard { color: #4ade80; font-size: 11px; margin-top: 3px; }
    .add-product-btn { background: #1e293b; border: 1px dashed #4ade80; border-radius: 12px; padding: 8px; text-align: center; color: #4ade80; cursor: pointer; margin-top: 8px; font-size: 12px; }
    
    /* Recent Orders */
    .recent-section-dashboard { background: var(--bg-card); border-radius: 20px; padding: 16px; border: 1px solid var(--border); overflow-x: auto; margin-top: 20px; }
    .recent-table-dashboard { width: 100%; min-width: 550px; border-collapse: collapse; }
    .recent-table-dashboard th, .recent-table-dashboard td { padding: 8px 6px; text-align: left; border-bottom: 1px solid var(--border); font-size: 11px; color: var(--text-secondary); }
    .recent-table-dashboard th { color: var(--purple); font-weight: 600; }
    
    /* Brands Grid */
    .brands-grid-dashboard { display: flex; flex-direction: column; gap: 16px; }
    .brand-card-dashboard { background: var(--bg-card); border-radius: 20px; padding: 16px; border: 1px solid var(--border); }
    .brand-item-row-dashboard { display: flex; justify-content: space-between; align-items: center; padding: 10px 0; border-bottom: 1px solid var(--border); flex-wrap: wrap; gap: 6px; }
    
    /* Modal */
    .modal-overlay-dashboard { position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.9); backdrop-filter: blur(8px); display: flex; align-items: center; justify-content: center; z-index: 2000; visibility: hidden; opacity: 0; transition: 0.2s; }
    .modal-overlay-dashboard.active { visibility: visible; opacity: 1; }
    .modal-glass-dashboard { background: #111827; border-radius: 28px; width: 95%; max-width: 550px; padding: 24px; border: 1px solid #4ade80; max-height: 85vh; overflow-y: auto; color: #e2f0e8; }
    .modal-header-dashboard { display: flex; justify-content: space-between; align-items: center; margin-bottom: 16px; border-bottom: 1px solid #2a3346; padding-bottom: 10px; }
    .modal-header-dashboard h3 { color: #e2f0e8; font-size: 18px; }
    .modal-close-dashboard { font-size: 26px; cursor: pointer; color: #9aaebe; }
    .modal-body label { color: #bdf2c0; font-weight: 500; display: block; margin-top: 14px; margin-bottom: 5px; font-size: 13px; }
    .modal-body input, .modal-body select, .modal-body textarea { width: 100%; padding: 10px 12px; background: #0f1420; border: 1px solid #2a3346; border-radius: 14px; color: #e2f0e8; font-size: 13px; }
    .modal-body button { background: #4ade80; color: #0a0e17; border: none; padding: 10px 18px; border-radius: 40px; font-weight: 600; cursor: pointer; transition: 0.2s; font-size: 13px; }
    .modal-body button:hover { background: #22c55e; }
    .flex-buttons { display: flex; gap: 10px; margin-top: 16px; }
    .flex-buttons button { flex: 1; }
    
    /* Leaderboard */
    .leaderboard-card-dashboard { background: var(--bg-card); border-radius: 20px; padding: 20px; border: 1px solid var(--border); }
    .leaderboard-item-dashboard { padding: 12px; border-bottom: 1px solid var(--border); display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 8px; }
    
    /* Mobile Bottom Nav */
    .mobile-bottom-nav-dashboard { display: none; position: fixed; bottom: 0; left: 0; right: 0; background: var(--bg-card); border-top: 1px solid var(--border); padding: 6px 12px; justify-content: space-around; z-index: 100; }
    .mobile-nav-item-dashboard { display: flex; flex-direction: column; align-items: center; gap: 2px; color: var(--text-muted); text-decoration: none; font-size: 9px; padding: 6px; border-radius: 40px; }
    .mobile-nav-item-dashboard i { font-size: 16px; }
    .mobile-nav-item-dashboard.active { color: var(--purple); background: var(--purple-glow); }
    
    .text-center { text-align: center; }
    .mt-2 { margin-top: 8px; }
    .mt-3 { margin-top: 12px; }
    .mb-2 { margin-bottom: 8px; }
    
    @media (min-width: 768px) {
        .mobile-bottom-nav-dashboard { display: none; }
        .desktop-menu { display: flex; }
        .stage-card-dashboard { width: 360px; }
    }
    
    @media (max-width: 767px) {
        .mobile-bottom-nav-dashboard { display: flex; }
        body { padding-bottom: 60px; }
        .dashboard-header { flex-direction: column; text-align: center; padding: 14px; }
        .stat-cards-dashboard { justify-content: center; flex-wrap: wrap; gap: 12px; }
        .desktop-menu { display: none; }
        .stage-card-dashboard { width: 300px; padding: 14px; }
        .modal-glass-dashboard { width: 95%; padding: 18px; }
        .dashboard-title h1 { font-size: 18px; }
    }
    /* Tambahkan CSS untuk selected product items */
.selected-product-item {
    transition: all 0.2s ease;
}

.selected-product-item:hover {
    border-color: #4ade80;
}

.commission-input {
    transition: all 0.2s ease;
}

.commission-input:focus {
    outline: none;
    border-color: #4ade80;
    box-shadow: 0 0 5px rgba(74, 222, 128, 0.3);
}

.generate-link-btn {
    transition: all 0.2s ease;
}

.generate-link-btn:hover {
    transform: translateY(-1px);
    box-shadow: 0 2px 8px rgba(74, 222, 128, 0.3);
}

.generated-link-container {
    animation: fadeIn 0.3s ease;
}

.copy-link-btn {
    transition: all 0.2s ease;
}

.copy-link-btn:hover {
    background: #4ade80 !important;
    color: #0a0e17 !important;
}

@keyframes fadeIn {
    from { opacity: 0; transform: translateY(-5px); }
    to { opacity: 1; transform: translateY(0); }
}

.order-status {
    display: inline-block;
    padding: 2px 6px;
    border-radius: 12px;
    font-size: 9px;
    font-weight: 500;
}

.order-status.completed {
    background: rgba(16, 185, 129, 0.15);
    color: #10b981;
}

.order-status.processing {
    background: rgba(245, 158, 11, 0.15);
    color: #f59e0b;
}

.order-status.cancelled {
    background: rgba(239, 68, 68, 0.15);
    color: #ef4444;
}
/* Brand badge style */
.brand-badge {
    background: rgba(74, 222, 128, 0.15);
    padding: 2px 8px;
    border-radius: 20px;
    font-size: 10px;
    color: #4ade80;
    display: inline-flex;
    align-items: center;
    gap: 4px;
}

.brand-badge i {
    font-size: 9px;
}

/* Source badge */
.source-badge-imported {
    color: #fbbf24;
    font-size: 9px;
}

.source-badge-manual {
    color: #4ade80;
    font-size: 9px;
}

/* Creator Status Tab Styles */
.creator-tab-btn.active {
    background: linear-gradient(135deg, var(--purple-glow), rgba(59, 130, 246, 0.1));
    color: var(--purple);
    border: 1px solid rgba(139, 92, 246, 0.4);
}

.creator-tab-btn:hover:not(.active) {
    background: rgba(139, 92, 246, 0.1);
    color: var(--purple);
}

.view-creator-detail:hover {
    background: var(--purple) !important;
    color: white !important;
}

/* Responsive untuk mobile */
@media (max-width: 767px) {
    .creator-list-container table,
    .creator-list-container thead,
    .creator-list-container tbody,
    .creator-list-container th,
    .creator-list-container td,
    .creator-list-container tr {
        display: block;
    }
    
    .creator-list-container thead {
        display: none;
    }
    
    .creator-list-container tr {
        margin-bottom: 12px;
        border: 1px solid var(--border);
        border-radius: 12px;
        padding: 12px;
    }
    
    .creator-list-container td {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 8px 0 !important;
        text-align: left !important;
    }
    
    .creator-list-container td:before {
        content: attr(data-label);
        font-weight: 600;
        color: #9aaebe;
        margin-right: 16px;
    }
}

/* Top Creator Tab Styles */
.leaderboard-card-dashboard {
    transition: transform 0.2s, box-shadow 0.2s;
}

.leaderboard-card-dashboard:hover {
    transform: translateY(-2px);
    box-shadow: 0 8px 25px rgba(0,0,0,0.3);
}

.period-btn.active {
    background: linear-gradient(135deg, var(--purple-glow), rgba(59, 130, 246, 0.1));
    color: var(--purple);
    border-color: rgba(139, 92, 246, 0.4);
}

.period-btn:hover:not(.active) {
    background: rgba(139, 92, 246, 0.1);
    border-color: var(--purple);
}

/* Responsive */
@media (max-width: 768px) {
    #tabLeaderboardDashboard > div:first-of-type {
        flex-direction: column;
        align-items: flex-start;
    }
    
    #tabLeaderboardDashboard > div:not(:first-of-type) {
        grid-template-columns: 1fr !important;
    }
    
    .leaderboard-item-dashboard {
        flex-wrap: wrap;
    }
    
    .leaderboard-item-dashboard > div:last-child {
        width: 100%;
        text-align: left;
        margin-top: 8px;
        padding-left: 48px;
    }
}

/* Icon SV dan LV styles */
.icon-sv {
    display: inline-flex;
    align-items: center;
    gap: 3px;
    background: linear-gradient(135deg, #8b5cf6, #a855f7);
    padding: 2px 8px;
    border-radius: 20px;
    font-size: 9px;
    font-weight: 600;
    color: white;
    box-shadow: 0 0 8px rgba(139, 92, 246, 0.5);
}

.icon-lv {
    display: inline-flex;
    align-items: center;
    gap: 3px;
    background: linear-gradient(135deg, #f97316, #ea580c);
    padding: 2px 8px;
    border-radius: 20px;
    font-size: 9px;
    font-weight: 600;
    color: white;
    box-shadow: 0 0 8px rgba(249, 115, 22, 0.5);
}

.icon-sv i, .icon-lv i {
    font-size: 8px;
}


/* ===== IS Dashboard BA-style polish - header/footer untouched ===== */
:root{
    --is-border: rgba(112,136,185,.18);
    --is-muted: var(--muted,#8e9bb6);
    --is-muted-2: var(--muted-2,#b7c1d6);
    --is-purple: var(--purple,#7c3cff);
    --is-blue:#3b82f6;
    --is-cyan:#10dff0;
    --is-green:#10b981;
}
.dashboard{padding:18px 28px 32px;max-width:1920px;margin:0 auto;}
.desktop-menu-with-stats{height:auto !important;min-height:76px;display:flex !important;align-items:center;justify-content:space-between;gap:18px;padding:10px 28px !important;border-bottom:1px solid rgba(112,136,185,.16);background:rgba(3,9,20,.28);overflow-x:visible !important;}
.desktop-menu-links{display:flex;align-items:center;gap:8px;flex-wrap:wrap;min-width:0;}
.desktop-menu-with-stats a{display:inline-flex;align-items:center;gap:8px;height:36px;padding:0 14px;border-radius:10px;color:var(--is-muted);font-size:13px;font-weight:800;white-space:nowrap;border:1px solid transparent;text-decoration:none;}
.desktop-menu-with-stats a:hover,.desktop-menu-with-stats a.active{background:linear-gradient(135deg,rgba(124,60,255,.28),rgba(124,60,255,.12));border-color:rgba(124,60,255,.24);color:#fff;box-shadow:none;}
.menu-stats-dashboard{display:flex !important;grid-template-columns:none !important;gap:10px !important;margin-left:auto;padding:0 !important;border:0 !important;border-radius:0 !important;background:transparent !important;flex:0 0 auto;}
.menu-stats-dashboard .stat-item-dashboard{position:relative;overflow:hidden;width:190px;min-height:54px !important;padding:9px 12px 9px 52px !important;text-align:left !important;border-radius:14px !important;border:1px solid var(--is-border) !important;background:linear-gradient(160deg,rgba(20,27,54,.84),rgba(7,14,30,.88)) !important;box-shadow:inset 0 1px 0 rgba(255,255,255,.04);}
.menu-stats-dashboard .stat-item-dashboard:before{content:"";position:absolute;left:12px;top:50%;width:32px;height:32px;transform:translateY(-50%);border-radius:50%;display:grid;place-items:center;color:#fff;font-family:"Font Awesome 6 Free";font-weight:900;font-size:13px;box-shadow:0 0 18px rgba(124,60,255,.22);}
.menu-stats-dashboard .stat-gmv:before{content:"\f201";background:linear-gradient(135deg,#7c3cff,#c02cff);}
.menu-stats-dashboard .stat-orders:before{content:"\f291";background:linear-gradient(135deg,#10dff0,#3b82f6);}
.menu-stats-dashboard .stat-active:before{content:"\f0e7";background:linear-gradient(135deg,#10b981,#39f08a);}
.menu-stats-dashboard .stat-label-dashboard{font-size:10px !important;font-weight:800;color:var(--is-muted-2) !important;text-transform:none;}
.menu-stats-dashboard .stat-value-dashboard{margin-top:3px !important;font-size:17px !important;line-height:1;color:#fff !important;background:none !important;-webkit-background-clip:initial !important;background-clip:initial !important;white-space:nowrap;}
.menu-stats-dashboard .stat-active .stat-value-dashboard{font-size:14px !important;}
.menu-stats-dashboard .stat-active .stat-value-dashboard i{color:var(--is-green);font-size:7px;margin-right:5px;}
.menu-stats-dashboard .stat-caption-dashboard{margin-top:3px;font-size:9px;color:var(--is-muted);font-weight:700;}
.dashboard-header-hidden{display:none !important;}
.tabs-bar-dashboard{display:grid !important;grid-template-columns:minmax(330px,460px) auto;gap:16px !important;align-items:center;margin:0 0 18px !important;padding:14px 18px !important;border:1px solid var(--is-border) !important;border-radius:18px;background:linear-gradient(160deg,rgba(9,17,34,.72),rgba(4,10,22,.86));}
.tabs-dashboard{display:flex;gap:8px;padding:0;border:1px solid rgba(112,136,185,.14);border-radius:12px;background:rgba(4,10,22,.38);overflow:hidden;}
.tab-btn-dashboard{display:inline-flex;align-items:center;justify-content:center;gap:8px;height:42px;padding:0 22px !important;border-radius:10px !important;color:var(--is-muted-2) !important;font-size:13px !important;}
.tab-btn-dashboard.active{color:#fff !important;background:linear-gradient(135deg,#6226d8,#7c3cff) !important;border:0 !important;}
.scout-btn-dashboard{justify-self:end;height:42px;min-width:170px;padding:0 20px !important;border-radius:999px !important;color:#d18aff !important;border:1px solid rgba(209,138,255,.86) !important;background:rgba(124,60,255,.08) !important;}
.scout-btn-dashboard:hover{background:#7c3cff !important;color:#fff !important;}
.stages-scroll-dashboard{padding:16px;margin-bottom:18px;border:1px solid var(--is-border);border-radius:20px;background:linear-gradient(160deg,rgba(9,17,34,.72),rgba(4,10,22,.86));overflow-x:auto;}
.stages-container-dashboard{display:grid !important;grid-template-columns:repeat(4,minmax(250px,1fr));gap:16px !important;width:100%;min-width:1180px !important;}
.stage-card-dashboard{width:auto !important;min-width:0 !important;height:520px !important;padding:16px !important;border-radius:18px !important;overflow:hidden !important;display:flex !important;flex-direction:column !important;border:1px solid var(--is-border) !important;background:linear-gradient(160deg,rgba(13,23,46,.90),rgba(6,12,25,.92)) !important;box-shadow:inset 0 1px 0 rgba(255,255,255,.04);}
.stage-card-dashboard[data-stage="1"]{border-top:2px solid var(--is-purple) !important;background:linear-gradient(160deg,rgba(31,20,55,.86),rgba(7,14,30,.92)) !important;}
.stage-card-dashboard[data-stage="2"]{border-top:2px solid var(--is-blue) !important;background:linear-gradient(160deg,rgba(13,30,62,.82),rgba(7,14,30,.92)) !important;}
.stage-card-dashboard[data-stage="3"]{border-top:2px solid var(--is-cyan) !important;background:linear-gradient(160deg,rgba(6,42,50,.78),rgba(7,14,30,.92)) !important;}
.stage-card-dashboard[data-stage="4"]{border-top:2px solid var(--is-green) !important;background:linear-gradient(160deg,rgba(9,46,34,.78),rgba(7,14,30,.92)) !important;}
.stage-title-dashboard{flex:0 0 auto !important;min-height:32px;margin-bottom:10px !important;padding-bottom:0 !important;border-bottom:0 !important;font-size:15px !important;letter-spacing:-.02em;flex-wrap:nowrap !important;}
.stage-title-dashboard span:first-child{display:flex;align-items:center;gap:8px;min-width:0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
.stage-count-dashboard{padding:5px 10px !important;border:1px solid rgba(255,255,255,.10);background:rgba(3,9,20,.38) !important;font-size:12px !important;color:#fff;}
.stage-card-dashboard input[type="text"]{width:100% !important;height:40px !important;padding:0 14px !important;color:#fff !important;background:rgba(255,255,255,.055) !important;border:1px solid rgba(255,255,255,.08) !important;border-radius:11px !important;outline:none;}
.stage-card-dashboard input[type="text"]::placeholder{color:rgba(183,193,214,.72);}
.stage-card-dashboard > div[style*="padding: 8px 12px"]{padding:0 0 12px !important;}
#scoutingContainerDashboard,#linkSwappingContainerDashboard,#sendingSampleContainerDashboard,#monitoringContainerDashboard{flex:1 1 auto !important;min-height:0 !important;overflow-y:auto !important;padding:0 4px 0 0 !important;scrollbar-width:thin;scrollbar-color:rgba(255,255,255,.22) transparent;}
#scoutingContainerDashboard::-webkit-scrollbar,#linkSwappingContainerDashboard::-webkit-scrollbar,#sendingSampleContainerDashboard::-webkit-scrollbar,#monitoringContainerDashboard::-webkit-scrollbar{width:5px;}
#scoutingContainerDashboard::-webkit-scrollbar-thumb,#linkSwappingContainerDashboard::-webkit-scrollbar-thumb,#sendingSampleContainerDashboard::-webkit-scrollbar-thumb,#monitoringContainerDashboard::-webkit-scrollbar-thumb{background:rgba(255,255,255,.22);border-radius:999px;}
.stage-item-dashboard{padding:12px !important;margin-bottom:8px !important;border-radius:13px !important;border:1px solid rgba(112,136,185,.14) !important;background:rgba(9,17,34,.56) !important;}
.stage-item-dashboard:hover{transform:none !important;border-color:rgba(124,60,255,.42) !important;background:rgba(16,29,55,.74) !important;}
.stage-item-dashboard strong{font-size:12px !important;line-height:1.25 !important;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
.item-details-dashboard{font-size:9.5px !important;line-height:1.4 !important;gap:5px 9px !important;color:var(--is-muted-2) !important;}
.badge-dashboard{font-size:8.5px !important;padding:4px 8px !important;font-weight:900;text-transform:uppercase;}
.task-btn-dashboard{height:42px !important;margin-top:10px !important;border-radius:12px !important;border:1px solid rgba(124,60,255,.26) !important;background:rgba(124,60,255,.10) !important;color:#c084fc !important;}
.task-btn-dashboard:hover:not(:disabled){background:linear-gradient(135deg,#6226d8,#7c3cff) !important;color:#fff !important;}
.brand-card-dashboard,.leaderboard-card-dashboard,.recent-section-dashboard,#tabLeaderboardDashboard > div[style*="background"]{border-radius:20px !important;border:1px solid var(--is-border) !important;background:linear-gradient(160deg,rgba(9,17,34,.74),rgba(4,10,22,.88)) !important;}
@media(max-width:1500px){.desktop-menu-with-stats{align-items:flex-start;flex-direction:column;}.menu-stats-dashboard{width:100%;margin-left:0;}.menu-stats-dashboard .stat-item-dashboard{flex:1;width:auto;}}
@media(max-width:1200px){.tabs-bar-dashboard{grid-template-columns:1fr !important;}.scout-btn-dashboard{justify-self:stretch;width:100%;}.stages-container-dashboard{display:flex !important;min-width:min-content !important;}.stage-card-dashboard{flex:0 0 310px !important;width:310px !important;min-width:310px !important;}}
@media(max-width:767px){.dashboard{padding:16px 14px 76px !important;}.desktop-menu-with-stats{display:none !important;}.mobile-menu-bar{display:flex;overflow-x:auto;gap:8px;padding:10px 14px;}.menu-stats-dashboard{display:none !important;}.tabs-bar-dashboard{padding:12px !important;}.tabs-dashboard{width:100%;overflow-x:auto;}.tab-btn-dashboard{flex:1;min-width:max-content;padding:0 14px !important;}.stage-card-dashboard{flex:0 0 294px !important;width:294px !important;min-width:294px !important;}}
.mobile-menu-bar{
    display:none !important;
}

@media(max-width:767px){
    .desktop-menu{
        display:none !important;
    }

    .mobile-menu-bar{
        display:flex !important;
        overflow-x:auto;
        gap:8px;
        padding:10px 14px;
    }
}


.assign-modal-table {
    width: 100%;
    border-collapse: collapse;
    font-size: 12px;
}

.assign-modal-table thead th {
    padding: 10px 12px;
    text-align: left;
    font-size: 10px;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    color: #8b5cf6;
    background: #1a1f2e;
    border-bottom: 2px solid #2a3346;
    position: sticky;
    top: 0;
    z-index: 10;
}

.assign-modal-table tbody td {
    padding: 10px 12px;
    border-bottom: 1px solid #1e293b;
    vertical-align: middle;
}

.assign-modal-table tbody tr {
    transition: background 0.15s ease;
}

.assign-modal-table tbody tr:hover {
    background: rgba(139, 92, 246, 0.05);
}

.assign-modal-table tbody tr:last-child td {
    border-bottom: none;
}

/* Kolom dengan lebar tetap */
.assign-modal-table .col-product { width: 40%; }
.assign-modal-table .col-sales { width: 8%; text-align: center; }
.assign-modal-table .col-commission { width: 12%; text-align: center; }
.assign-modal-table .col-status { width: 18%; text-align: center; }
.assign-modal-table .col-action { width: 22%; text-align: center; }

/* Product cell dengan gambar */
.product-cell {
    display: flex;
    align-items: center;
    gap: 10px;
}

.product-cell .product-thumb {
    width: 36px;
    height: 36px;
    border-radius: 6px;
    background: #1e293b;
    display: flex;
    align-items: center;
    justify-content: center;
    flex-shrink: 0;
    overflow: hidden;
}

.product-cell .product-thumb img {
    width: 100%;
    height: 100%;
    object-fit: cover;
}

.product-cell .product-thumb i {
    font-size: 14px;
    color: #6b7280;
}

.product-cell .product-info {
    min-width: 0;
}

.product-cell .product-name {
    font-weight: 500;
    color: #e2f0e8;
    font-size: 12px;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
}

.product-cell .product-meta {
    font-size: 10px;
    color: #6b7280;
    margin-top: 2px;
}

.product-cell .product-meta .shop-name {
    color: #8b5cf6;
}

.product-cell .product-meta .campaign-id {
    color: #4ade80;
}

/* Badge Status */
.status-badge {
    display: inline-flex;
    align-items: center;
    gap: 4px;
    padding: 3px 10px;
    border-radius: 20px;
    font-size: 10px;
    font-weight: 600;
}

.status-badge.ready {
    background: rgba(74, 222, 128, 0.15);
    color: #4ade80;
}

.status-badge.assigned {
    background: rgba(139, 92, 246, 0.15);
    color: #8b5cf6;
}

.status-badge.nolink {
    background: rgba(239, 68, 68, 0.15);
    color: #ef4444;
}

/* Tombol Action */
.btn-action {
    padding: 4px 14px;
    border-radius: 16px;
    font-size: 10px;
    font-weight: 600;
    border: none;
    cursor: pointer;
    transition: all 0.2s ease;
    white-space: nowrap;
}

.btn-action.assign {
    background: #8b5cf6;
    color: white;
}

.btn-action.assign:hover:not(:disabled) {
    background: #7c3aed;
    transform: scale(1.02);
}

.btn-action.assign:disabled {
    opacity: 0.5;
    cursor: not-allowed;
}

.btn-action.copy {
    background: transparent;
    color: #4ade80;
    border: 1px solid #4ade80;
}

.btn-action.copy:hover {
    background: #4ade80;
    color: #0a0e17;
}

.btn-action.ask-bd {
    color: #6b7280;
    font-size: 9px;
    cursor: default;
}

/* Summary Bar */
.summary-bar {
    display: flex;
    gap: 20px;
    padding: 10px 14px;
    background: rgba(139, 92, 246, 0.08);
    border-radius: 8px;
    margin-bottom: 12px;
    flex-wrap: wrap;
    border: 1px solid rgba(139, 92, 246, 0.1);
}

.summary-bar .item {
    display: flex;
    align-items: center;
    gap: 6px;
    font-size: 11px;
    color: #9aaebe;
}

.summary-bar .item .value {
    font-weight: 600;
    color: #e2f0e8;
}

.summary-bar .item .value.green { color: #4ade80; }
.summary-bar .item .value.gold { color: #fbbf24; }
.summary-bar .item .value.purple { color: #8b5cf6; }

/* Container scroll */
.table-scroll {
    max-height: 380px;
    overflow-y: auto;
    border-radius: 8px;
    border: 1px solid #1e293b;
}

.table-scroll::-webkit-scrollbar {
    width: 4px;
}

.table-scroll::-webkit-scrollbar-track {
    background: #0f1420;
}

.table-scroll::-webkit-scrollbar-thumb {
    background: #4ade80;
    border-radius: 4px;
}
</style>

<!-- Desktop Menu -->
<div class="desktop-menu desktop-menu-with-stats">
    <div class="desktop-menu-links">
        <a href="<?= base_url('is/dashboard') ?>" class="active"><i class="fas fa-tachometer-alt"></i> Dashboard</a>
        <a href="<?= base_url('is/creators') ?>"><i class="fas fa-users"></i> Creators</a>
        <a href="<?= base_url('is/performance') ?>"><i class="fas fa-chart-line"></i> Performance</a>
        <a href="<?= base_url('performance') ?>"><i class="fas fa-chart-line"></i> Performance Creator</a>
        <a href="<?= base_url('is/team_performance') ?>"><i class="fas fa-users"></i> Team Performance</a>
        <a href="<?= base_url('analytics/bd') ?>"><i class="fas fa-chart-line"></i> Analytics</a>
        <a href="<?= base_url($this->session->userdata('role') == 'IS' ? 'is/target_plan_dashboard' : 'bd/target_plan_dashboard') ?>"><i class="fas fa-bullseye"></i> Target Plan</a>
    </div>

    <div class="stat-cards-dashboard menu-stats-dashboard">
        <div class="stat-item-dashboard stat-gmv">
            <div class="stat-label-dashboard">Total GMV</div>
            <div class="stat-value-dashboard">Rp <?= number_format($total_gmv ?? 0, 0, ',', '.') ?></div>
            <div class="stat-caption-dashboard">Hari ini</div>
        </div>
        <div class="stat-item-dashboard stat-orders">
            <div class="stat-label-dashboard">Total Orders</div>
            <div class="stat-value-dashboard"><?= number_format($total_orders ?? 0) ?></div>
            <div class="stat-caption-dashboard">Semua order</div>
        </div>
        <div class="stat-item-dashboard stat-active">
            <div class="stat-label-dashboard">Status</div>
            <div class="stat-value-dashboard"><i class="fas fa-circle"></i> LIVE</div>
            <div class="stat-caption-dashboard">Realtime API</div>
        </div>
    </div>
</div>

<!-- Mobile Menu Bar -->
<div class="mobile-menu-bar">
    <a href="<?= base_url('is/dashboard') ?>" class="active"><i class="fas fa-tachometer-alt"></i> Dashboard</a>
    <a href="<?= base_url('is/creators') ?>"><i class="fas fa-users"></i> Creators</a>
    <a href="<?= base_url('is/performance') ?>"><i class="fas fa-chart-line"></i> Performance</a>
    <a href="<?= base_url('analytics/bd') ?>"><i class="fas fa-chart-line"></i> Analytics</a>
    
</div>

<div class="dashboard">
    <!-- Dashboard Header moved into desktop menu -->
    <div class="dashboard-header dashboard-header-hidden" aria-hidden="true"></div>

    <!-- Tabs -->
    <div class="tabs-bar-dashboard">
        <div class="tabs-dashboard">
            <button class="tab-btn-dashboard active" data-tab="tabTaskDashboard"><i class="fas fa-clipboard-list"></i> Task</button>
            <button class="tab-btn-dashboard" data-tab="tabCreatorsDashboard"><i class="fas fa-users"></i> Creator Status</button>
            <button class="tab-btn-dashboard" data-tab="tabLeaderboardDashboard"><i class="fas fa-trophy"></i> Top Creator</button>
        </div>
        
        <button class="scout-btn-dashboard" id="addCreatorBtnDashboard"><i class="fas fa-plus-circle"></i> Tambah Creator</button>
    </div>

  
 <!-- TAB TASK - 4 STAGE dengan SCROLL dan SEARCH -->
<div id="tabTaskDashboard" class="tab-content-dashboard active">
    <div class="stages-scroll-dashboard">
        <div class="stages-container-dashboard">
           
           <!-- TASK 1: SCOUTING - UNGU -->
<!-- TASK 1: SCOUTING - UNGU -->
<div class="stage-card-dashboard" data-stage="1" style="display: flex; flex-direction: column; height: 500px;">
    <div class="stage-title-dashboard" style="flex-shrink: 0;">
        <span><i class="fas fa-search"></i> 1. SCOUTING (Cari Creator)</span>
        <span class="stage-count-dashboard" id="scoutingCountDashboard"><?= count($scouting_items ?? []) ?></span>
    </div>
    
    <!-- Search input -->
    <div style="flex-shrink: 0; padding: 8px 12px;">
        <input type="text" id="searchScoutingDashboard" placeholder=" Cari creator atau brand..." style="width: 100%; padding: 6px 10px; border: 1px solid #ddd; border-radius: 6px; font-size: 12px; background: #1a1f2e; color: white;">
    </div>
    
    <!-- Scrollable container -->
    <div id="scoutingContainerDashboard" style="flex: 1; overflow-y: auto; padding: 0 8px;">
        <?php if (!empty($scouting_items)): ?>
            <?php foreach ($scouting_items as $item): ?>
            <div class="stage-item-dashboard scouting-item-dashboard" 
                 data-creator-id="<?= $item->id ?>" 
                 data-creator-name="<?= htmlspecialchars($item->username) ?>"
                 data-creator-phone="<?= htmlspecialchars($item->phone ?? '') ?>"
                 data-searchable="<?= strtolower(htmlspecialchars($item->username . ' ' . ($item->shop_name ?? '') . ' ' . ($item->brand_name ?? ''))) ?>">
                
                <strong><i class="fab fa-tiktok"></i> <?= htmlspecialchars($item->username) ?></strong>
                
                <!-- TAMPILAN SHOP/BRAND NAME -->
                <div class="item-details-dashboard" style="margin-top: 4px;">
                    <?php if ($is_supervisor && isset($item->is_username)): ?>
                    <span><i class="fas fa-user-tie"></i> IS:  <?php if ($item->is_id == 1): ?>
                    <span style="color: #4ade80; font-weight: 600;">Toopai</span>
                <?php else: ?>
                    <?= htmlspecialchars($item->is_username ?? '-') ?>
                <?php endif; ?></span>
                    <?php endif; ?>
                    
                    <!-- SHOP NAME / BRAND -->
                    <?php if (!empty($item->shop_name) || !empty($item->brand_name)): ?>
                    <span class="brand-badge" style="background: rgba(74,222,128,0.15); padding: 2px 8px; border-radius: 20px;">
                        <i class="fas fa-store"></i> <?= htmlspecialchars($item->shop_name ?: $item->brand_name) ?>
                    </span>
                    <?php else: ?>
                    <span style="color: #9aaebe; font-size: 10px;">
                        <i class="fas fa-store"></i> Belum ada brand
                    </span>
                    <?php endif; ?>
                </div>
                
                <div class="item-details-dashboard">
                    <!-- WhatsApp dengan tombol Resync -->
                    <span id="phoneDisplay_<?= $item->id ?>">
                        <i class="fab fa-whatsapp"></i> 
                        <?php if (!empty($item->phone)): ?>
                            <?= htmlspecialchars($item->phone) ?>
                        <?php else: ?>
                            <span style="color: #ef4444;">Tidak ada</span>
                        <?php endif; ?>
                    </span>
                    <span><i class="fas fa-tag"></i> <?= $item->category ?? '-' ?></span>
                </div>
                
                <!-- GMV 28 HARI -->
                <?php if (!empty($item->imported_gmv) && $item->imported_gmv > 0): ?>
                <div class="item-details-dashboard" style="margin-top: 4px;">
                    <span style="color: #fbbf24; font-size: 11px;">
                        <i class="fas fa-chart-line"></i> GMV 28H: Rp <?= number_format($item->imported_gmv, 0, ',', '.') ?>
                    </span>
                </div>
                <?php endif; ?>
                
                <!-- SUMBER DATA DAN TANGGAL INPUT + TOMBOL RESYNC -->
                <div class="item-details-dashboard" style="font-size: 9px; margin-top: 4px; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 4px;">
                    <div>
                        <?php if (isset($item->source) && $item->source == 'imported'): ?>
                        <span style="color: #fbbf24;">
                            <i class="fas fa-file-import"></i> Imported
                        </span>
                        <?php else: ?>
                        <span style="color: #4ade80;">
                            <i class="fas fa-user-plus"></i> Manual
                        </span>
                        <?php endif; ?>
                    </div>
                    <div style="color: #9aaebe; font-size: 9px;">
                        <i class="fas fa-calendar-alt"></i> 
                        <?= !empty($item->created_at) ? date('d/m/Y H:i', strtotime($item->created_at)) : '-' ?>
                    </div>
                    <!-- TOMBOL RESYNC WA - hanya muncul jika tidak ada nomor -->
                    <?php if (empty($item->phone)): ?>
                    <button class="resync-wa-btn" 
                            data-creator-id="<?= $item->id ?>" 
                            data-creator-name="<?= htmlspecialchars($item->username) ?>"
                            style="background: #fbbf24; color: #0a0e17; border: none; padding: 2px 10px; border-radius: 12px; cursor: pointer; font-size: 9px; font-weight: 600;">
                        <i class="fas fa-sync-alt"></i> Resync WA
                    </button>
                    <?php endif; ?>
                </div>
                
                <span class="badge-dashboard badge-pending" style="margin-top: 6px;">
                    <i class="fas fa-clock"></i> <?= $item->status ?>
                </span>
            </div>
            <?php endforeach; ?>
        <?php else: ?>
            <div class="stage-item-dashboard">
                <strong><i class="fas fa-info-circle"></i> Belum ada creator</strong>
                <div class="item-details-dashboard">Klik "Tambah Creator" atau "Import Excel" untuk mulai</div>
            </div>
        <?php endif; ?>
    </div>
    
    <!-- Button group -->
    <div style="flex-shrink: 0; display: flex; gap: 8px; margin-top: 8px;">
        <button class="task-btn-dashboard" id="addCreatorQuickBtnDashboard" style="flex: 1;">
            <i class="fas fa-plus-circle"></i> Tambah Creator
        </button>
        <button class="task-btn-dashboard" id="importCreatorBtnDashboard" style="flex: 1; background: linear-gradient(135deg, #8b5cf6, #3b82f6);">
            <i class="fas fa-file-upload"></i> Import Excel
        </button>
    </div>
</div>





            <!-- TASK 2: LINK SWAPPING - BIRU -->
            <div class="stage-card-dashboard" data-stage="2" style="display: flex; flex-direction: column; height: 500px;">
                <div class="stage-title-dashboard" style="flex-shrink: 0;">
                    <span><i class="fas fa-link"></i> 2. LINK SWAPPING</span>
                    <span class="stage-count-dashboard" id="linkCountDashboard">0</span>
                </div>
                
                <!-- Search input untuk Task 2 -->
                <div style="flex-shrink: 0; padding: 8px 12px;">
                    <input type="text" id="searchLinkSwappingDashboard" placeholder=" Cari creator..." style="width: 100%; padding: 6px 10px; border: 1px solid #ddd; border-radius: 6px; font-size: 12px; background: #1a1f2e; color: white;">
                </div>
                
                <!-- Scrollable container -->
                <div id="linkSwappingContainerDashboard" style="flex: 1; overflow-y: auto; padding: 0 8px;">
                    <div class="stage-item-dashboard"><strong>Loading...</strong><div class="item-details-dashboard">Memuat data creator</div></div>
                </div>
                
                <button class="task-btn-dashboard" id="refreshTask2BtnDashboard" style="flex-shrink: 0; margin-top: 8px;"><i class="fas fa-sync-alt"></i> Refresh</button>
            </div>

            <!-- TASK 3: SENDING SAMPLE - CYAN -->
            <div class="stage-card-dashboard" data-stage="3" style="display: flex; flex-direction: column; height: 500px;">
                <div class="stage-title-dashboard" style="flex-shrink: 0;">
                    <span><i class="fas fa-box"></i> 3. KIRIM SAMPLE</span>
                    <span class="stage-count-dashboard" id="sampleCountDashboard"><?= count($sending_sample_items) ?></span>
                </div>
                
                <!-- Search input untuk Task 3 -->
                <div style="flex-shrink: 0; padding: 8px 12px;">
                    <input type="text" id="searchSampleDashboard" placeholder=" Cari creator..." style="width: 100%; padding: 6px 10px; border: 1px solid #ddd; border-radius: 6px; font-size: 12px; background: #1a1f2e; color: white;">
                </div>
                
                <!-- Scrollable container -->
               <div id="sendingSampleContainerDashboard" style="flex: 1; overflow-y: auto; padding: 0 8px;">
    <?php if (!empty($sending_sample_items)): ?>
        <?php foreach ($sending_sample_items as $item): ?>
        <div class="stage-item-dashboard sample-item-dashboard" data-creator-id="<?= $item->id ?>" data-creator-name="<?= htmlspecialchars($item->username) ?>" data-creator-phone="<?= htmlspecialchars($item->phone ?? '') ?>" data-creator-category="<?= htmlspecialchars($item->category ?? '') ?>" data-searchable="<?= strtolower(htmlspecialchars($item->username)) ?>">
            <strong><i class="fab fa-tiktok"></i> <?= htmlspecialchars($item->username) ?></strong>
            <div class="item-details-dashboard">
                <?php if ($is_supervisor && isset($item->is_username)): ?>
                <span><i class="fas fa-user-tie"></i> IS: <?= htmlspecialchars($item->is_username) ?></span>
                <?php endif; ?>
                <span><i class="fab fa-whatsapp"></i> <?= $item->phone ?? '-' ?></span>
                <span><i class="fas fa-tag"></i> <?= $item->category ?? '-' ?></span>
            </div>
            <div class="item-details-dashboard"><i class="fas fa-box"></i> 
                <?php if ($item->status == 'LINK_SENT'): ?>
                Menunggu konfirmasi sample
                <?php else: ?>
                Sample sudah dikirim
                <?php endif; ?>
            </div>
            <span class="badge-dashboard badge-pending">
                <i class="fas fa-clock"></i> <?= $item->status ?>
            </span>
        </div>
        <?php endforeach; ?>
    <?php else: ?>
        <div class="stage-item-dashboard">
            <strong><i class="fas fa-info-circle"></i> Belum ada creator di tahap pengiriman sample</strong>
            <div class="item-details-dashboard">Creator akan auto-pindah ke monitoring jika ada order</div>
        </div>
    <?php endif; ?>
</div>
                
                <button class="task-btn-dashboard" data-action="sample" style="flex-shrink: 0; margin-top: 8px;"><i class="fas fa-truck"></i> Request & Lacak Sample</button>
            </div>

            <!-- TASK 4: MONITORING - Hijau -->
            <div class="stage-card-dashboard" data-stage="4" style="display: flex; flex-direction: column; height: 500px;">
                <div class="stage-title-dashboard" style="flex-shrink: 0;">
                    <span><i class="fas fa-chart-line"></i> 4. MONITORING</span>
                    <span class="stage-count-dashboard" id="monitoringCountDashboard"><?= count($monitoring_items) ?></span>
                </div>
                
                <!-- Search input untuk Task 4 -->
                <div style="flex-shrink: 0; padding: 8px 12px;">
                    <input type="text" id="searchMonitoringDashboard" placeholder=" Cari creator..." style="width: 100%; padding: 6px 10px; border: 1px solid #ddd; border-radius: 6px; font-size: 12px; background: #1a1f2e; color: white;">
                </div>
                
                <!-- Scrollable container -->
                <div id="monitoringContainerDashboard" style="flex: 1; overflow-y: auto; padding: 0 8px;">
    <?php if (!empty($monitoring_items)): ?>
        <?php foreach ($monitoring_items as $item): ?>
        <div class="stage-item-dashboard monitor-item-dashboard" data-creator-id="<?= $item->id ?>" data-creator-name="<?= htmlspecialchars($item->username) ?>" data-searchable="<?= strtolower(htmlspecialchars($item->username)) ?>">
            <strong><i class="fab fa-tiktok"></i> <?= htmlspecialchars($item->username) ?></strong>
            <div class="item-details-dashboard">
                <?php if ($is_supervisor && isset($item->is_username)): ?>
                <span><i class="fas fa-user-tie"></i> IS: <?= htmlspecialchars($item->is_username) ?></span>
                <?php endif; ?>
                <span><i class="fas fa-money-bill-wave"></i> GMV: Rp <?= number_format($item->total_gmv ?? 0, 0, ',', '.') ?></span>
                <span><i class="fas fa-chart-line"></i> ROAS: <?= $item->roas ?? 0 ?>x</span>
            </div>
            <div class="item-details-dashboard">
                <span><i class="fas fa-shopping-cart"></i> Orders: <?= number_format($item->total_orders ?? 0) ?></span>
                <span><i class="fas fa-tag"></i> <?= $item->category ?? '-' ?></span>
            </div>
            <span class="badge-dashboard badge-active">
                <i class="fas fa-check-circle"></i> ACTIVE
                <?php if ($item->auto_activated_at): ?>
                <span class="auto-badge" style="background: #4ade80; color: #0a0e17; font-size: 8px; padding: 2px 6px; border-radius: 10px; margin-left: 6px;">
                    <i class="fas fa-robot"></i> Auto
                </span>
                <?php endif; ?>
            </span>
        </div>
        <?php endforeach; ?>
        <!-- Summary card untuk monitoring -->
        <div style="margin-top: 12px; padding: 12px; background: #0f1420; border-radius: 14px;">
            <div style="display: flex; justify-content: space-between;">
                <span style="color: var(--text-muted); font-size:11px;">Total GMV (All Time):</span>
                <span style="color: #4ade80; font-size:12px;">Rp <?= number_format($monitoring_stats['total_gmv'] ?? 0, 0, ',', '.') ?></span>
            </div>
            <div style="display: flex; justify-content: space-between; margin-top: 6px;">
                <span style="color: var(--text-muted); font-size:11px;">Total Estimated Commission:</span>
                <span style="color: #fbbf24; font-size:12px;">Rp <?= number_format($monitoring_stats['total_estimated_commission'] ?? 0, 0, ',', '.') ?></span>
            </div>
        </div>
    <?php else: ?>
        <div class="stage-item-dashboard">
            <strong><i class="fas fa-info-circle"></i> Belum ada creator aktif</strong>
            <div class="item-details-dashboard">Creator akan muncul setelah sample dikirim atau auto-move karena order</div>
        </div>
    <?php endif; ?>
</div>
                <button class="task-btn-dashboard" data-action="monitor" style="flex-shrink: 0; margin-top: 8px;"><i class="fas fa-chart-simple"></i> Lihat Laporan</button>
            </div>
        </div>
    </div>
</div>
    <!-- TAB CREATOR STATUS -->
<div id="tabCreatorsDashboard" class="tab-content-dashboard">
    <!-- Summary Cards -->
    <div style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 16px; margin-bottom: 24px;">
        <div style="background: linear-gradient(135deg, #1a1030, #13111f); border-radius: 16px; padding: 16px; border: 1px solid var(--border);">
            <div style="display: flex; align-items: center; gap: 12px;">
                <div style="background: rgba(74,222,128,0.15); width: 48px; height: 48px; border-radius: 50%; display: flex; align-items: center; justify-content: center;">
                    <i class="fas fa-users" style="color: #4ade80; font-size: 24px;"></i>
                </div>
                <div>
                    <div style="color: #9aaebe; font-size: 11px;">TOTAL CREATOR</div>
                    <div style="color: #e2f0e8; font-size: 24px; font-weight: 700;"><?= $total_creators ?? 0 ?></div>
                </div>
            </div>
        </div>
        
        <div style="background: linear-gradient(135deg, #0f1a2e, #13111f); border-radius: 16px; padding: 16px; border: 1px solid var(--border);">
            <div style="display: flex; align-items: center; gap: 12px;">
                <div style="background: rgba(16,185,129,0.15); width: 48px; height: 48px; border-radius: 50%; display: flex; align-items: center; justify-content: center;">
                    <i class="fas fa-check-circle" style="color: #10b981; font-size: 24px;"></i>
                </div>
                <div>
                    <div style="color: #9aaebe; font-size: 11px;">CREATOR AKTIF</div>
                    <div style="color: #e2f0e8; font-size: 24px; font-weight: 700;"><?= count($active_creators ?? []) ?></div>
                </div>
            </div>
        </div>
        
        <div style="background: linear-gradient(135deg, #0a1a1f, #13111f); border-radius: 16px; padding: 16px; border: 1px solid var(--border);">
            <div style="display: flex; align-items: center; gap: 12px;">
                <div style="background: rgba(139,92,246,0.15); width: 48px; height: 48px; border-radius: 50%; display: flex; align-items: center; justify-content: center;">
                    <i class="fas fa-clock" style="color: #8b5cf6; font-size: 24px;"></i>
                </div>
                <div>
                    <div style="color: #9aaebe; font-size: 11px;">TOTAL GMV (HARI INI)</div>
                    <div style="color: #e2f0e8; font-size: 24px; font-weight: 700;">Rp <?= number_format($total_gmv ?? 0, 0, ',', '.') ?></div>
                </div>
            </div>
        </div>
        
        <div style="background: linear-gradient(135deg, #0a1f15, #13111f); border-radius: 16px; padding: 16px; border: 1px solid var(--border);">
            <div style="display: flex; align-items: center; gap: 12px;">
                <div style="background: rgba(245,158,11,0.15); width: 48px; height: 48px; border-radius: 50%; display: flex; align-items: center; justify-content: center;">
                    <i class="fas fa-chart-line" style="color: #f59e0b; font-size: 24px;"></i>
                </div>
                <!--<div>-->
                <!--    <div style="color: #9aaebe; font-size: 11px;">EST. COMMISSION</div>-->
                <!--    <div style="color: #e2f0e8; font-size: 24px; font-weight: 700;">Rp <?= number_format($total_estimated_commission ?? 0, 0, ',', '.') ?></div>-->
                <!--</div>-->
            </div>
        </div>
    </div>
    
    <!-- Tabs for Creator Categories -->
    <div style="display: flex; gap: 8px; margin-bottom: 20px; border-bottom: 1px solid var(--border); padding-bottom: 12px;">
        <button class="creator-tab-btn active" data-creator-tab="active" style="background: transparent; border: none; padding: 8px 20px; font-size: 13px; font-weight: 600; color: var(--text-muted); cursor: pointer; border-radius: 40px; transition: all 0.2s;">
            <i class="fas fa-check-circle"></i> Aktif
            <span style="background: rgba(16,185,129,0.2); padding: 2px 8px; border-radius: 20px; margin-left: 6px;"><?= count($active_creators ?? []) ?></span>
        </button>
        <button class="creator-tab-btn" data-creator-tab="pending" style="background: transparent; border: none; padding: 8px 20px; font-size: 13px; font-weight: 600; color: var(--text-muted); cursor: pointer; border-radius: 40px; transition: all 0.2s;">
            <i class="fas fa-clock"></i> Pending
            <span style="background: rgba(245,158,11,0.2); padding: 2px 8px; border-radius: 20px; margin-left: 6px;"><?= count($inactive_creators ?? []) ?></span>
        </button>
    </div>
    
    <!-- Active Creators List -->
    <div id="activeCreatorsList" class="creator-list-container" style="display: block;">
        <div style="background: var(--bg-card); border-radius: 20px; border: 1px solid var(--border); overflow: hidden;">
            <div style="background: linear-gradient(135deg, #1a1030, #13111f); padding: 12px 16px; border-bottom: 1px solid var(--border);">
                <h4 style="margin: 0; color: #4ade80; font-size: 14px;"><i class="fas fa-check-circle"></i> Daftar Creator Aktif</h4>
            </div>
            <?php if (!empty($active_creators)): ?>
                <div style="overflow-x: auto;">
                    <table style="width: 100%; border-collapse: collapse; font-size: 12px;">
                        <thead>
                            <tr style="background: #0f1420; border-bottom: 1px solid var(--border);">
                                <th style="padding: 12px 16px; text-align: left; color: #9aaebe;">Username</th>
                                <th style="padding: 12px 16px; text-align: left; color: #9aaebe;">Kategori</th>
                                <th style="padding: 12px 16px; text-align: right; color: #9aaebe;">GMV Today</th>
                                <th style="padding: 12px 16px; text-align: right; color: #9aaebe;">Status</th>
                                <th style="padding: 12px 16px; text-align: center; color: #9aaebe;">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($active_creators as $c): ?>
                            <tr style="border-bottom: 1px solid var(--border); transition: background 0.2s;" onmouseover="this.style.background='rgba(139,92,246,0.1)'" onmouseout="this.style.background='transparent'">
                                <td style="padding: 12px 16px;">
                                    <div style="display: flex; align-items: center; gap: 10px;">
                                        <i class="fab fa-tiktok" style="color: #4ade80; font-size: 16px;"></i>
                                        <strong style="color: var(--text-primary);">@<?= htmlspecialchars($c->username) ?></strong>
                                    </div>
                                </td>
                                <td style="padding: 12px 16px;">
                                    <span style="background: rgba(139,92,246,0.15); padding: 4px 12px; border-radius: 20px; font-size: 11px; color: #8b5cf6;">
                                        <?= htmlspecialchars($c->category ?? '-') ?>
                                    </span>
                                </td>
                                <td style="padding: 12px 16px; text-align: right;">
                                    <span style="color: #4ade80; font-weight: 600;">
                                        Rp <?= number_format($c->today_gmv ?? 0, 0, ',', '.') ?>
                                    </span>
                                </td>
                                <td style="padding: 12px 16px; text-align: right;">
                                    <span class="badge-dashboard badge-active">
                                        <i class="fas fa-check-circle"></i> AKTIF
                                    </span>
                                </td>
                                <td style="padding: 12px 16px; text-align: center;">
                                    <button class="view-creator-detail" data-creator-id="<?= $c->id ?>" style="background: #1e293b; border: none; padding: 4px 12px; border-radius: 20px; color: #9aaebe; cursor: pointer; font-size: 11px;">
                                        <i class="fas fa-eye"></i> Detail
                                    </button>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <div style="text-align: center; padding: 40px; color: #9aaebe;">
                    <i class="fas fa-users" style="font-size: 48px; margin-bottom: 16px; display: block; opacity: 0.5;"></i>
                    <p>Belum ada creator aktif</p>
                </div>
            <?php endif; ?>
        </div>
    </div>
    
    <!-- Pending Creators List -->
    <div id="pendingCreatorsList" class="creator-list-container" style="display: none;">
        <div style="background: var(--bg-card); border-radius: 20px; border: 1px solid var(--border); overflow: hidden;">
            <div style="background: linear-gradient(135deg, #0a1a1f, #13111f); padding: 12px 16px; border-bottom: 1px solid var(--border);">
                <h4 style="margin: 0; color: #f59e0b; font-size: 14px;"><i class="fas fa-clock"></i> Daftar Creator Pending</h4>
            </div>
            <?php if (!empty($inactive_creators)): ?>
                <div style="overflow-x: auto;">
                    <table style="width: 100%; border-collapse: collapse; font-size: 12px;">
                        <thead>
                            <tr style="background: #0f1420; border-bottom: 1px solid var(--border);">
                                <th style="padding: 12px 16px; text-align: left; color: #9aaebe;">Username</th>
                                <th style="padding: 12px 16px; text-align: left; color: #9aaebe;">Kategori</th>
                                <th style="padding: 12px 16px; text-align: left; color: #9aaebe;">WhatsApp</th>
                                <th style="padding: 12px 16px; text-align: left; color: #9aaebe;">Status</th>
                                <th style="padding: 12px 16px; text-align: center; color: #9aaebe;">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($inactive_creators as $c): ?>
                            <tr style="border-bottom: 1px solid var(--border); transition: background 0.2s;" onmouseover="this.style.background='rgba(139,92,246,0.1)'" onmouseout="this.style.background='transparent'">
                                <td style="padding: 12px 16px;">
                                    <div style="display: flex; align-items: center; gap: 10px;">
                                        <i class="fab fa-tiktok" style="color: #f59e0b; font-size: 16px;"></i>
                                        <strong style="color: var(--text-primary);">@<?= htmlspecialchars($c->username) ?></strong>
                                    </div>
                                </td>
                                <td style="padding: 12px 16px;">
                                    <span style="background: rgba(139,92,246,0.15); padding: 4px 12px; border-radius: 20px; font-size: 11px; color: #8b5cf6;">
                                        <?= htmlspecialchars($c->category ?? '-') ?>
                                    </span>
                                </td>
                                <td style="padding: 12px 16px;">
                                    <?php if (!empty($c->phone)): ?>
                                        <span style="color: #4ade80; font-size: 11px;">
                                            <i class="fab fa-whatsapp"></i> <?= htmlspecialchars($c->phone) ?>
                                        </span>
                                    <?php else: ?>
                                        <span style="color: #ef4444; font-size: 11px;">
                                            <i class="fas fa-times-circle"></i> Belum ada WA
                                        </span>
                                    <?php endif; ?>
                                </td>
                                <td style="padding: 12px 16px;">
                                    <span class="badge-dashboard badge-pending">
                                        <i class="fas fa-clock"></i> <?= $c->status ?? 'PENDING' ?>
                                    </span>
                                </td>
                                <td style="padding: 12px 16px; text-align: center;">
                                    <button class="view-creator-detail" data-creator-id="<?= $c->id ?>" style="background: #1e293b; border: none; padding: 4px 12px; border-radius: 20px; color: #9aaebe; cursor: pointer; font-size: 11px;">
                                        <i class="fas fa-eye"></i> Detail
                                    </button>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <div style="text-align: center; padding: 40px; color: #9aaebe;">
                    <i class="fas fa-check-circle" style="font-size: 48px; margin-bottom: 16px; display: block; opacity: 0.5; color: #4ade80;"></i>
                    <p>Semua creator sudah diapprove! </p>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>
    <!-- TAB TOP CREATOR LEADERBOARD -->
    <!-- TAB TOP CREATOR LEADERBOARD -->
<div id="tabLeaderboardDashboard" class="tab-content-dashboard">
    <!-- Filter Periode -->
    <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 16px; margin-bottom: 24px;">
        <h3 style="color: var(--text-primary); font-size: 16px; margin: 0;">
            <i class="fas fa-trophy" style="color: var(--purple);"></i> Top Performing Creators
        </h3>
        <div style="display: flex; gap: 8px;">
            <button class="period-btn active" data-period="today" style="background: transparent; border: 1px solid var(--border); padding: 6px 16px; border-radius: 40px; font-size: 12px; color: var(--text-muted); cursor: pointer; transition: all 0.2s;">
                <i class="fas fa-calendar-day"></i> Hari Ini
            </button>
            <button class="period-btn" data-period="week" style="background: transparent; border: 1px solid var(--border); padding: 6px 16px; border-radius: 40px; font-size: 12px; color: var(--text-muted); cursor: pointer; transition: all 0.2s;">
                <i class="fas fa-calendar-week"></i> 7 Hari
            </button>
            <button class="period-btn" data-period="month" style="background: transparent; border: 1px solid var(--border); padding: 6px 16px; border-radius: 40px; font-size: 12px; color: var(--text-muted); cursor: pointer; transition: all 0.2s;">
                <i class="fas fa-calendar-alt"></i> 30 Hari
            </button>
        </div>
    </div>
    
    <!-- Leaderboard Grid -->
    <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 20px;">
        <!-- Top Creator berdasarkan GMV -->
        <div class="leaderboard-card-dashboard" style="background: linear-gradient(135deg, #1a1030, #13111f); border-radius: 20px; padding: 20px; border: 1px solid var(--border);">
            <div style="display: flex; align-items: center; gap: 12px; margin-bottom: 20px; padding-bottom: 12px; border-bottom: 1px solid var(--border);">
                <div style="background: rgba(74,222,128,0.15); width: 40px; height: 40px; border-radius: 50%; display: flex; align-items: center; justify-content: center;">
                    <i class="fas fa-chart-line" style="color: #4ade80; font-size: 20px;"></i>
                </div>
                <div>
                    <h4 style="margin: 0; color: var(--text-primary); font-size: 14px;">Top GMV Creator</h4>
                    <p style="margin: 0; color: var(--text-muted); font-size: 10px;">Berdasarkan total GMV</p>
                </div>
            </div>
            
            <div id="topGmvCreatorsList">
                <?php if (!empty($top_creators)): ?>
                    <?php $rank = 1; foreach ($top_creators as $c): ?>
                    <div class="leaderboard-item-dashboard" style="display: flex; align-items: center; gap: 12px; padding: 12px; border-bottom: 1px solid var(--border); transition: background 0.2s; border-radius: 12px;" onmouseover="this.style.background='rgba(139,92,246,0.1)'" onmouseout="this.style.background='transparent'">
                        <div style="width: 36px; text-align: center;">
                            <?php if ($rank == 1): ?>
                                <span style="background: linear-gradient(135deg, #fbbf24, #f59e0b); color: #0a0e17; width: 28px; height: 28px; display: flex; align-items: center; justify-content: center; border-radius: 50%; font-weight: 700; font-size: 12px;">1</span>
                            <?php elseif ($rank == 2): ?>
                                <span style="background: linear-gradient(135deg, #94a3b8, #64748b); color: white; width: 28px; height: 28px; display: flex; align-items: center; justify-content: center; border-radius: 50%; font-weight: 700; font-size: 12px;">2</span>
                            <?php elseif ($rank == 3): ?>
                                <span style="background: linear-gradient(135deg, #cd7e56, #b45309); color: white; width: 28px; height: 28px; display: flex; align-items: center; justify-content: center; border-radius: 50%; font-weight: 700; font-size: 12px;">3</span>
                            <?php else: ?>
                                <span style="color: var(--text-muted); font-size: 12px; font-weight: 600;"><?= $rank ?></span>
                            <?php endif; ?>
                        </div>
                        <div style="flex: 1;">
                            <div style="display: flex; align-items: center; gap: 8px; flex-wrap: wrap;">
                                <strong style="color: var(--text-primary); font-size: 13px;">@<?= htmlspecialchars($c->creator_username ?? $c->username ?? '-') ?></strong>
                                <?php if ($is_supervisor && isset($c->is_username)): ?>
                                <span style="background: rgba(139,92,246,0.15); padding: 2px 8px; border-radius: 20px; font-size: 9px; color: #8b5cf6;">
                                    <i class="fas fa-user-tie"></i> <?= htmlspecialchars($c->is_username) ?>
                                </span>
                                <?php endif; ?>
                            </div>
                            <div style="display: flex; gap: 16px; margin-top: 4px; flex-wrap: wrap;">
                                <span style="font-size: 10px; color: var(--text-muted);">
                                    <i class="fas fa-tag"></i> <?= htmlspecialchars($c->category ?? '-') ?>
                                </span>
                                <span style="font-size: 10px; color: var(--text-muted);">
                                    <i class="fas fa-box"></i> <?= number_format($c->total_orders ?? 0) ?> orders
                                </span>
                            </div>
                        </div>
                        <div style="text-align: right;">
                            <div style="color: #4ade80; font-weight: 700; font-size: 14px;">
                                Rp <?= number_format($c->total_gmv ?? 0, 0, ',', '.') ?>
                            </div>
                            <div style="font-size: 9px; color: var(--text-muted);">
                                <?= $c->engagement_rate ?? 0 ?>% ER
                            </div>
                        </div>
                    </div>
                    <?php $rank++; endforeach; ?>
                <?php else: ?>
                    <div style="text-align: center; padding: 40px; color: var(--text-muted);">
                        <i class="fas fa-chart-line" style="font-size: 48px; margin-bottom: 16px; display: block; opacity: 0.5;"></i>
                        <p>Belum ada data creator</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
        
        <!-- Top Creator berdasarkan Engagement -->
        <div class="leaderboard-card-dashboard" style="background: linear-gradient(135deg, #0f1a2e, #13111f); border-radius: 20px; padding: 20px; border: 1px solid var(--border);">
            <div style="display: flex; align-items: center; gap: 12px; margin-bottom: 20px; padding-bottom: 12px; border-bottom: 1px solid var(--border);">
                <div style="background: rgba(139,92,246,0.15); width: 40px; height: 40px; border-radius: 50%; display: flex; align-items: center; justify-content: center;">
                    <i class="fas fa-heart" style="color: #8b5cf6; font-size: 20px;"></i>
                </div>
                <div>
                    <h4 style="margin: 0; color: var(--text-primary); font-size: 14px;">Top Engagement Creator</h4>
                    <p style="margin: 0; color: var(--text-muted); font-size: 10px;">Berdasarkan engagement rate</p>
                </div>
            </div>
            
            <div id="topEngagementCreatorsList">
                <?php 
                // Sort by engagement rate
                $sorted_by_engagement = $top_creators ?? [];
                usort($sorted_by_engagement, function($a, $b) {
                    return ($b->engagement_rate ?? 0) <=> ($a->engagement_rate ?? 0);
                });
                ?>
                <?php if (!empty($sorted_by_engagement)): ?>
                    <?php $rank = 1; foreach (array_slice($sorted_by_engagement, 0, 5) as $c): ?>
                    <div class="leaderboard-item-dashboard" style="display: flex; align-items: center; gap: 12px; padding: 12px; border-bottom: 1px solid var(--border); transition: background 0.2s; border-radius: 12px;" onmouseover="this.style.background='rgba(139,92,246,0.1)'" onmouseout="this.style.background='transparent'">
                        <div style="width: 36px; text-align: center;">
                            <?php if ($rank == 1): ?>
                                <span style="background: linear-gradient(135deg, #fbbf24, #f59e0b); color: #0a0e17; width: 28px; height: 28px; display: flex; align-items: center; justify-content: center; border-radius: 50%; font-weight: 700; font-size: 12px;">1</span>
                            <?php elseif ($rank == 2): ?>
                                <span style="background: linear-gradient(135deg, #94a3b8, #64748b); color: white; width: 28px; height: 28px; display: flex; align-items: center; justify-content: center; border-radius: 50%; font-weight: 700; font-size: 12px;">2</span>
                            <?php elseif ($rank == 3): ?>
                                <span style="background: linear-gradient(135deg, #cd7e56, #b45309); color: white; width: 28px; height: 28px; display: flex; align-items: center; justify-content: center; border-radius: 50%; font-weight: 700; font-size: 12px;">3</span>
                            <?php else: ?>
                                <span style="color: var(--text-muted); font-size: 12px; font-weight: 600;"><?= $rank ?></span>
                            <?php endif; ?>
                        </div>
                        <div style="flex: 1;">
                            <strong style="color: var(--text-primary); font-size: 13px;">@<?= htmlspecialchars($c->creator_username ?? $c->username ?? '-') ?></strong>
                            <div style="display: flex; gap: 16px; margin-top: 4px;">
                                <span style="font-size: 10px; color: var(--text-muted);">
                                    <i class="fas fa-tag"></i> <?= htmlspecialchars($c->category ?? '-') ?>
                                </span>
                            </div>
                        </div>
                        <div style="text-align: right;">
                            <div style="color: #8b5cf6; font-weight: 700; font-size: 14px;">
                                <?= number_format($c->engagement_rate ?? 0, 1) ?>%
                            </div>
                            <div style="font-size: 9px; color: var(--text-muted);">
                                GMV: Rp <?= number_format($c->total_gmv ?? 0, 0, ',', '.') ?>
                            </div>
                        </div>
                    </div>
                    <?php $rank++; endforeach; ?>
                <?php else: ?>
                    <div style="text-align: center; padding: 40px; color: var(--text-muted);">
                        <i class="fas fa-heart" style="font-size: 48px; margin-bottom: 16px; display: block; opacity: 0.5;"></i>
                        <p>Belum ada data engagement</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <!-- Recent Activity -->
    <div style="margin-top: 20px; background: var(--bg-card); border-radius: 20px; padding: 20px; border: 1px solid var(--border);">
        <div style="display: flex; align-items: center; gap: 12px; margin-bottom: 20px; padding-bottom: 12px; border-bottom: 1px solid var(--border);">
            <div style="background: rgba(245,158,11,0.15); width: 40px; height: 40px; border-radius: 50%; display: flex; align-items: center; justify-content: center;">
                <i class="fas fa-clock" style="color: #f59e0b; font-size: 20px;"></i>
            </div>
            <div>
                <h4 style="margin: 0; color: var(--text-primary); font-size: 14px;">Recent Activity</h4>
                <p style="margin: 0; color: var(--text-muted); font-size: 10px;">Top creator terbaru minggu ini</p>
            </div>
        </div>
        
        <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap: 12px;">
            <?php if (!empty($top_creators)): ?>
                <?php foreach (array_slice($top_creators, 0, 4) as $c): ?>
                <div style="display: flex; align-items: center; gap: 12px; padding: 10px; background: #0f1420; border-radius: 12px;">
                                    <div style="width: 40px; height: 40px; background: linear-gradient(135deg, var(--purple), var(--blue)); border-radius: 50%; display: flex; align-items: center; justify-content: center;">
                        <i class="fab fa-tiktok" style="color: white; font-size: 18px;"></i>
                    </div>
                    <div style="flex: 1;">
                        <div style="color: var(--text-primary); font-size: 13px; font-weight: 500;">@<?= htmlspecialchars($c->creator_username ?? $c->username ?? '-') ?></div>
                        <div style="font-size: 10px; color: var(--text-muted);"><?= htmlspecialchars($c->category ?? '-') ?></div>
                    </div>
                    <div style="text-align: right;">
                        <div style="color: #4ade80; font-size: 12px; font-weight: 600;">
                            Rp <?= number_format($c->total_gmv ?? 0, 0, ',', '.') ?>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            <?php else: ?>
                <div style="text-align: center; padding: 30px; color: var(--text-muted); grid-column: 1 / -1;">
                    <p>Belum ada aktivitas</p>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>



</div>

<!-- Modal -->
<div id="taskModalDashboard" class="modal-overlay-dashboard">
    <div class="modal-glass-dashboard">
        <div class="modal-header-dashboard">
            <h3 id="modalTitleDashboard"><i class="fas fa-tasks"></i> Task</h3>
            <span class="modal-close-dashboard" id="closeTaskModalDashboard">&times;</span>
        </div>
        <div class="modal-body" id="modalBodyDashboard"></div>
    </div>
</div>


<!-- Modal Import Creator -->
<div id="importModalDashboard" class="modal-overlay-dashboard">
    <div class="modal-glass-dashboard" style="max-width: 900px;">
        <div class="modal-header-dashboard">
            <h3 id="importModalTitle"><i class="fas fa-file-upload"></i> Import Creator dari Excel</h3>
            <span class="modal-close-dashboard" id="closeImportModal">&times;</span>
        </div>
        <div class="modal-body" id="importModalBody">
            <!-- Step 1: Pilih Brand & Upload File -->
            <div id="importStep1">
                <div style="background: rgba(74,222,128,0.1); border-radius: 14px; padding: 12px; margin-bottom: 16px;">
                    <p style="color: #4ade80; font-size: 12px;"><i class="fas fa-info-circle"></i> Support file: Excel (.xlsx, .xls) atau CSV</p>
                    <p style="color: #9aaebe; font-size: 11px;">Format yang didukung: FastMoss atau Kalodata export</p>
                </div>
                
                <!--  Pilihan Brand -->
                <label><i class="fas fa-store"></i> Pilih Brand <span style="color:#ef4444;">*</span></label>
                <select id="importBrandSelect" style="width: 100%; padding: 10px; background: #0f1420; border: 1px solid #2a3346; border-radius: 12px; color: #e2f0e8; margin-bottom: 16px;">
                    <option value="">-- Pilih Brand --</option>
                    <?php 
                    // Ambil brand dari database
                    $brands = $this->db->select('id, name, shop_name')->where('status', 'ACTIVE')->order_by('name', 'ASC')->get('brands')->result();
                    foreach ($brands as $brand): 
                    ?>
                    <option value="<?= $brand->id ?>" data-shop-name="<?= htmlspecialchars($brand->shop_name ?: $brand->name) ?>">
                        <?= htmlspecialchars($brand->name) ?> <?= $brand->shop_name ? '(Shop: ' . htmlspecialchars($brand->shop_name) . ')' : '' ?>
                    </option>
                    <?php endforeach; ?>
                </select>
                
                <label><i class="fas fa-file-excel"></i> Pilih File</label>
                <input type="file" id="importFileInput" accept=".xlsx,.xls,.csv" style="width: 100%; padding: 10px; background: #0f1420; border: 1px solid #2a3346; border-radius: 12px; color: #e2f0e8;">
                
                <!--  Mapping Kolom (Opsional) -->
                <div style="margin-top: 16px;">
                    <label><i class="fas fa-columns"></i> Mapping Kolom (Opsional)</label>
                    <div style="background: #0f1420; border-radius: 12px; padding: 12px; margin-top: 8px;">
                        <p style="color: #9aaebe; font-size: 11px; margin-bottom: 8px;">Jika file memiliki struktur berbeda, sesuaikan mapping berikut:</p>
                     
<div style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px;">
    <div>
        <select id="colMappingUsername" style="width:100%; padding:6px; background:#1e293b; border-radius:8px; color:#e2f0e8;">
            <option value="1">Handle</option>
            <option value="0">Kolom 0</option>
            <option value="1">Kolom 1</option>
            <option value="2">Kolom 2</option>
            <option value="3">Kolom 3</option>
            <option value="4">Kolom 4</option>
            <option value="5">Kolom 5</option>
            <option value="6">Kolom 6</option>
            <option value="7">Kolom 7</option>
        </select>
        <span style="font-size:10px; color:#9aaebe;">Kolom Username</span>
    </div>
    <div>
        <select id="colMappingFullname" style="width:100%; padding:6px; background:#1e293b; border-radius:8px; color:#e2f0e8;">
            <option value="0">Nickname</option>
            <option value="0">Kolom 0</option>
            <option value="1">Kolom 1</option>
            <option value="2">Kolom 2</option>
        </select>
        <span style="font-size:10px; color:#9aaebe;">Kolom Nama</span>
    </div>
    <div>
        <select id="colMappingCategory" style="width:100%; padding:6px; background:#1e293b; border-radius:8px; color:#e2f0e8;">
            <option value="3">Kategori (FastMoss kolom3)</option>
            <option value="-1">Tidak Ada</option>
            <option value="0">Kolom 0</option>
            <option value="1">Kolom 1</option>
            <option value="2">Kolom 2</option>
            <option value="3">Kolom 3</option>
        </select>
        <span style="font-size:10px; color:#9aaebe;">Kolom Kategori</span>
    </div>
    <div>
        <select id="colMappingGmv" style="width:100%; padding:6px; background:#1e293b; border-radius:8px; color:#e2f0e8;">
            <option value="8">Revenue(Rp)</option>
            <option value="-1">Tidak Ada</option>
            <option value="4">Kolom 4</option>
            <option value="5">Kolom 5</option>
            <option value="8">Kolom 8</option>
        </select>
        <span style="font-size:10px; color:#9aaebe;">Kolom GMV</span>
    </div>
    <div>
        <select id="colMappingFollowers" style="width:100%; padding:6px; background:#1e293b; border-radius:8px; color:#e2f0e8;">
            <option value="6">Followers</option>
            <option value="-1">Tidak Ada</option>
            <option value="3">Kolom 3</option>
            <option value="6">Kolom 6</option>
        </select>
        <span style="font-size:10px; color:#9aaebe;">Kolom Followers</span>
    </div>
    <div>
        <select id="colMappingEmail" style="width:100%; padding:6px; background:#1e293b; border-radius:8px; color:#e2f0e8;">
            <option value="12">Email</option>
            <option value="-1">Tidak Ada</option>
            <option value="12">Kolom 12</option>
            <option value="18">Kolom 18</option>
        </select>
        <span style="font-size:10px; color:#9aaebe;">Kolom Email</span>
    </div>
    <div>
        <select id="colMappingPhone" style="width:100%; padding:6px; background:#1e293b; border-radius:8px; color:#e2f0e8;">
            <option value="13">whatsapp</option>
            <option value="-1">Tidak Ada</option>
            <option value="13">Kolom 13</option>
            <option value="23">Kolom 23</option>
        </select>
        <span style="font-size:10px; color:#9aaebe;">Kolom WhatsApp/Phone</span>
    </div>
</div>
                    </div>
                </div>
                
                <div style="margin-top: 16px;">
                    <label><i class="fas fa-check-circle"></i> Opsi Duplikat</label>
                    <div style="display: flex; gap: 16px; margin-top: 8px;">
                        <label style="display: flex; align-items: center; gap: 8px;">
                            <input type="radio" name="duplicate_action" value="skip" checked> Lewati creator yang sudah ada
                        </label>
                        <label style="display: flex; align-items: center; gap: 8px;">
                            <input type="radio" name="duplicate_action" value="update"> Update creator yang sudah ada
                        </label>
                    </div>
                </div>
                
                <div class="flex-buttons" style="margin-top: 20px;">
                    <button id="previewImportBtn" style="background: #4ade80; color: #0a0e17;"><i class="fas fa-eye"></i> Preview Data</button>
                    <button id="cancelImportBtn" style="background: #1e293b;">Batal</button>
                </div>
            </div>
            
            <!-- Step 2: Preview & Confirm -->
            <div id="importStep2" style="display: none;">
                <div id="previewBrandInfo" style="background: rgba(74,222,128,0.1); border-radius: 14px; padding: 12px; margin-bottom: 16px;"></div>
                <div id="previewStats" style="background: rgba(74,222,128,0.1); border-radius: 14px; padding: 12px; margin-bottom: 16px;"></div>
                <div id="previewErrors" style="background: rgba(239,68,68,0.1); border-radius: 14px; padding: 12px; margin-bottom: 16px; display: none; max-height: 150px; overflow-y: auto;"></div>
                <label><i class="fas fa-table"></i> Preview Data (10 baris pertama)</label>
                <div id="previewTable" style="max-height: 300px; overflow-y: auto; background: #0f1420; border-radius: 12px; padding: 8px; margin-bottom: 16px;"></div>
                <div class="flex-buttons">
                    <button id="confirmImportBtn" style="background: #4ade80; color: #0a0e17;"><i class="fas fa-save"></i> Konfirmasi Import</button>
                    <button id="backToUploadBtn" style="background: #1e293b;">Kembali</button>
                </div>
            </div>
            
            <!-- Step 3: Result -->
            <div id="importStep3" style="display: none;">
                <div id="importResult" style="text-align: center; padding: 20px;"></div>
                <div class="flex-buttons" style="margin-top: 20px;">
                    <button id="closeImportResultBtn" style="background: #4ade80; color: #0a0e17;">Tutup</button>
                </div>
            </div>
        </div>
    </div>
</div>


<!-- Mobile Bottom Navigation -->
<div class="mobile-bottom-nav-dashboard">
    <a href="#" class="mobile-nav-item-dashboard active" data-tab="tabTaskDashboard"><i class="fas fa-tasks"></i><span>Task</span></a>
    <a href="#" class="mobile-nav-item-dashboard" data-tab="tabCreatorsDashboard"><i class="fas fa-users"></i><span>Creators</span></a>
    <a href="#" class="mobile-nav-item-dashboard" data-tab="tabLeaderboardDashboard"><i class="fas fa-trophy"></i><span>Top</span></a>
</div>



<script>
// ========== DATA ==========
const baseUrlIS = '<?= base_url() ?>';

// ========== HELPER FUNCTIONS ==========
function escapeHtml(str) {
    if (!str) return '';
    return String(str).replace(/[&<>]/g, function(m) {
        if (m === '&') return '&amp;';
        if (m === '<') return '&lt;';
        if (m === '>') return '&gt;';
        return m;
    });
}

function formatNumber(num) {
    if (num === undefined || num === null) return '0';
    const n = parseFloat(num);
    return isNaN(n) ? '0' : n.toLocaleString('id-ID', { 
        minimumFractionDigits: 0,  //  TANPA DESIMAL
        maximumFractionDigits: 0   //  TANPA DESIMAL
    });
}

function formatNumberShort(num) {
    if (num === undefined || num === null) return '0';
    if (num >= 1000000) return (num / 1000000).toFixed(1) + 'M';
    if (num >= 1000) return (num / 1000).toFixed(1) + 'K';
    return num.toString();
}

function showToastGlobal(message, type = 'success') {
    let toast = document.getElementById('globalToast');
    if (!toast) {
        toast = document.createElement('div');
        toast.id = 'globalToast';
        toast.style.cssText = `
            position: fixed;
            bottom: 20px;
            right: 20px;
            background: ${type === 'success' ? '#10b981' : '#ef4444'};
            color: white;
            padding: 12px 20px;
            border-radius: 12px;
            font-size: 13px;
            z-index: 9999;
            animation: slideIn 0.3s ease;
            box-shadow: 0 4px 12px rgba(0,0,0,0.3);
        `;
        document.body.appendChild(toast);
        
        if (!document.querySelector('#toastStyle')) {
            const style = document.createElement('style');
            style.id = 'toastStyle';
            style.textContent = `
                @keyframes slideIn {
                    from { transform: translateX(100%); opacity: 0; }
                    to { transform: translateX(0); opacity: 1; }
                }
                @keyframes slideOut {
                    from { transform: translateX(0); opacity: 1; }
                    to { transform: translateX(100%); opacity: 0; }
                }
            `;
            document.head.appendChild(style);
        }
    }
    
    toast.textContent = message;
    toast.style.background = type === 'success' ? '#10b981' : (type === 'error' ? '#ef4444' : '#f59e0b');
    toast.style.display = 'block';
    
    setTimeout(() => {
        toast.style.animation = 'slideOut 0.3s ease';
        setTimeout(() => {
            toast.style.display = 'none';
            toast.style.animation = 'slideIn 0.3s ease';
        }, 300);
    }, 3000);
}

// ========== MODAL ==========
function closeModalIS() { 
    document.getElementById('taskModalDashboard')?.classList.remove('active'); 
}
function openModalIS() { 
    document.getElementById('taskModalDashboard')?.classList.add('active'); 
}

// ========== TAMBAH CREATOR (MANUAL - LAMA, TETAP DIKEEP) ==========
function showAddCreatorModalIS() {
    const modalTitle = document.getElementById('modalTitleDashboard');
    const modalBody = document.getElementById('modalBodyDashboard');
    modalTitle.innerHTML = '<i class="fas fa-user-plus"></i> Tambah Creator Baru';
    modalBody.innerHTML = `
        <div style="background:rgba(74,222,128,0.1); border-radius:14px; padding:12px; margin-bottom:16px;">
            <p style="color:#4ade80; font-size:12px;"><i class="fas fa-info-circle"></i> Masukkan data creator TikTok</p>
        </div>
        <label><i class="fab fa-tiktok"></i> Username TikTok *</label>
        <input type="text" id="creatorUsernameIS" placeholder="@username_tiktok">
        <label><i class="fas fa-user"></i> Nama Lengkap</label>
        <input type="text" id="creatorNameIS">
        <label><i class="fab fa-whatsapp"></i> WhatsApp</label>
        <input type="tel" id="creatorPhoneIS" placeholder="+62 812 3456 7890">
        <label><i class="fas fa-envelope"></i> Email</label>
        <input type="email" id="creatorEmailIS">
        <label><i class="fas fa-tag"></i> Kategori</label>
        <select id="creatorCategoryIS">
            <option value="Beauty"> Beauty</option>
            <option value="Fashion"> Fashion</option>
            <option value="Tech">Tech</option>
            <option value="Lifestyle"> Lifestyle</option>
            <option value="Gaming">Gaming</option>
            <option value="Food">Food</option>
        </select>
        <button id="saveCreatorBtnIS" style="margin-top:16px; width:100%;"><i class="fas fa-save"></i> Simpan Creator</button>
    `;
    openModalIS();
    
    document.getElementById('saveCreatorBtnIS').addEventListener('click', async () => {
        const username = document.getElementById('creatorUsernameIS').value.trim();
        if (!username) { showToastGlobal('Username harus diisi', 'error'); return; }
        const btn = document.getElementById('saveCreatorBtnIS');
        btn.disabled = true; btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Menyimpan...';
        
        const response = await fetch(baseUrlIS + 'is/add_creator', { 
            method: 'POST', 
            body: new URLSearchParams({
                username: username.replace('@', ''),
                full_name: document.getElementById('creatorNameIS').value,
                phone: document.getElementById('creatorPhoneIS').value,
                email: document.getElementById('creatorEmailIS').value,
                category: document.getElementById('creatorCategoryIS').value
            })
        });
        const result = await response.json();
        if (result.success) {
            closeModalIS();
            showToastGlobal(` Creator @${username} berhasil ditambahkan!`);
            setTimeout(() => location.reload(), 1500);
        } else {
            showToastGlobal(result.message || 'Gagal menambah creator', 'error');
            btn.disabled = false;
            btn.innerHTML = '<i class="fas fa-save"></i> Simpan Creator';
        }
    });
}

// ========== SEARCH CREATOR FROM API (FITUR BARU) ==========
let searchResults = [];
let searchPageToken = null;
let searchKeyword = '';
let isLoadingMore = false;

function showSearchCreatorModal() {
    const modalTitle = document.getElementById('modalTitleDashboard');
    const modalBody = document.getElementById('modalBodyDashboard');
    
    modalTitle.innerHTML = '<i class="fab fa-tiktok"></i> Cari Creator dari TikTok Shop';
    modalBody.innerHTML = `
        <div style="background:rgba(74,222,128,0.1); border-radius:14px; padding:12px; margin-bottom:16px;">
            <p style="color:#4ade80; font-size:12px;"><i class="fas fa-search"></i> Cari creator di TikTok Affiliate Marketplace</p>
            <p style="color:#9aaebe; font-size:10px;">Masukkan username TikTok untuk mencari data creator secara realtime</p>
        </div>
        
        <div style="display:flex; gap:10px; margin-bottom:16px;">
            <input type="text" id="searchCreatorKeyword" placeholder="Cari creator... (contoh: jefreestar, beautycreator)" 
                   style="flex:1; padding:12px; background:#0f1420; border:1px solid #2a3346; border-radius:12px; color:#e2f0e8;">
            <button id="searchCreatorBtn" style="background:#4ade80; color:#0a0e17; padding:0 20px; border-radius:12px;">
                <i class="fas fa-search"></i> Cari
            </button>
        </div>
        
        <div id="searchResultsContainer" style="max-height:400px; overflow-y:auto; background:#0f1420; border-radius:12px; padding:8px;">
            <div style="text-align:center; padding:40px; color:#9aaebe;">
                <i class="fas fa-search" style="font-size:32px; margin-bottom:12px; display:block;"></i>
                <p>Masukkan keyword dan klik Cari untuk mencari creator</p>
            </div>
        </div>
        
        <div id="searchPagination" style="display:none; margin-top:12px; text-align:center;">
            <button id="loadMoreResults" class="btn-secondary" style="background:#1e293b; color:#4ade80; border:1px solid #4ade80; padding:6px 16px; border-radius:20px; cursor:pointer;">
                <i class="fas fa-chevron-down"></i> Load More
            </button>
        </div>
        
        <div class="flex-buttons" style="margin-top:16px;">
            <button id="closeSearchModalBtn" style="background:#1e293b;">Tutup</button>
        </div>
    `;
    openModalIS();
    
    // Search button event
    const searchBtn = document.getElementById('searchCreatorBtn');
    if (searchBtn) {
        const newSearchBtn = searchBtn.cloneNode(true);
        searchBtn.parentNode.replaceChild(newSearchBtn, searchBtn);
        
        newSearchBtn.addEventListener('click', async () => {
            const keyword = document.getElementById('searchCreatorKeyword').value.trim();
            if (!keyword) {
                showToastGlobal('Masukkan keyword pencarian', 'error');
                return;
            }
            
            searchKeyword = keyword;
            searchPageToken = null;
            await performSearch();
        });
    }
    
    // Enter key event
    const searchInput = document.getElementById('searchCreatorKeyword');
    if (searchInput) {
        searchInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                document.getElementById('searchCreatorBtn')?.click();
            }
        });
    }
    
    // Close button
    const closeBtn = document.getElementById('closeSearchModalBtn');
    if (closeBtn) {
        const newCloseBtn = closeBtn.cloneNode(true);
        closeBtn.parentNode.replaceChild(newCloseBtn, closeBtn);
        newCloseBtn.addEventListener('click', closeModalIS);
    }
}

async function performSearch(append = false) {
    const keyword = searchKeyword;
    const container = document.getElementById('searchResultsContainer');
    const loadMoreContainer = document.getElementById('searchPagination');
    
    if (!append) {
        container.innerHTML = '<div style="text-align:center; padding:40px;"><i class="fas fa-spinner fa-pulse"></i> Searching creators...</div>';
    } else {
        isLoadingMore = true;
        const loadMoreBtn = document.getElementById('loadMoreResults');
        if (loadMoreBtn) {
            loadMoreBtn.innerHTML = '<i class="fas fa-spinner fa-pulse"></i> Loading...';
            loadMoreBtn.disabled = true;
        }
    }
    
    try {
        const response = await fetch(baseUrlIS + 'is/search_creators_by_is', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: new URLSearchParams({
                keyword: keyword,
                page_token: searchPageToken || ''
            })
        });
        
        const result = await response.json();
        console.log('Search result:', result);
        
        if (result.success && result.creators && result.creators.length > 0) {
            if (!append) {
                searchResults = [];
                container.innerHTML = '';
            }
            
            searchResults = [...searchResults, ...result.creators];
            
            // Render results
            result.creators.forEach(creator => {
                const followerFormatted = formatNumberShort(creator.follower_count);
                const gmvUsd = parseFloat(creator.gmv || 0);
                const gmvIdr = Math.round(gmvUsd * 16000);
                const gmvFormatted = gmvUsd > 0 
                    ? `Rp ${formatNumber(gmvIdr)}`
                    : (creator.gmv_formatted || 'Rp 0');
                const avatarHtml = creator.avatar_url && creator.avatar_url !== ''
                    ? `<img src="${escapeHtml(creator.avatar_url)}" style="width:100%; height:100%; object-fit:cover;" onerror="this.src=''; this.onerror=null; this.parentElement.innerHTML='<i class=\\'fab fa-tiktok\\' style=\\'font-size:28px; color:#4ade80;\\'></i>'">` 
                    : '<i class="fab fa-tiktok" style="font-size:28px; color:#4ade80;"></i>';
                
                //  Bangun icon SV/LV dengan class CSS
                let contentIconsHtml = '';
                const liveCount = creator.live_count || creator.avg_live_uv || 0;
                const videoCount = creator.video_count || creator.avg_video_views || 0;
                
                // SV untuk Live (Streaming Video) - NEON PURPLE, ICON PLAY
                if (liveCount > 0) {
                    contentIconsHtml += `<span class="icon-lv" style="margin-left:4px;">
                        <i class="fas fa-camera"></i> LV
                    </span>`;
                }
                // LV untuk Video - NEON ORANGE, ICON CAMERA DECODER
                if (videoCount > 0) {
                     contentIconsHtml += `<span class="icon-sv">
                        <i class="fas fa-play"></i> SV
                    </span>`;
                   
                }
                
                //  BUAT CARD UNTUK SETIAP CREATOR
                const cardHtml = `
                <div class="search-result-item" style="background:#0f1420; border-radius:12px; padding:12px; margin-bottom:10px; border:1px solid #2a3346; transition:all 0.2s; cursor:pointer;" 
                     data-creator='${JSON.stringify(creator).replace(/'/g, "&#39;")}'
                     onmouseover="this.style.borderColor='#4ade80'" 
                     onmouseout="this.style.borderColor='#2a3346'">
                    <div style="display:flex; gap:12px;">
                        <div style="width:50px; height:50px; border-radius:50%; overflow:hidden; background:#1e293b; flex-shrink:0; display:flex; align-items:center; justify-content:center;">
                            ${avatarHtml}
                        </div>
                        <div style="flex:1;">
                            <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:6px;">
                                <div>
                                    <div style="display:flex; align-items:center; flex-wrap:wrap; gap:6px;">
                                        <strong style="color:#e2f0e8; font-size:13px;">${escapeHtml(creator.nickname || creator.username)}</strong>
                                        ${contentIconsHtml}
                                    </div>
                                    <div style="color:#9aaebe; font-size:10px; margin-top:2px;">@${escapeHtml(creator.username)}</div>
                                </div>
                                <div style="text-align:right;">
                                    <div style="color:#4ade80; font-size:12px; font-weight:600;">${gmvFormatted}</div>
                                    <div style="color:#9aaebe; font-size:9px;">GMV 28 hari</div>
                                </div>
                            </div>
                            <div style="display:flex; gap:12px; margin-top:6px; flex-wrap:wrap;">
                                <span style="color:#4ade80; font-size:10px;">
                                    <i class="fas fa-users"></i> ${followerFormatted}
                                </span>
                                <span style="color:#8b5cf6; font-size:10px;">
                                    <i class="fas fa-chart-line"></i> Avg View: ${formatNumberShort(creator.avg_video_views || 0)}
                                </span>
                                ${creator.avg_live_uv > 0 ? `
                                <span style="color:#f59e0b; font-size:10px;">
                                    <i class="fas fa-video"></i> Avg Live: ${formatNumberShort(creator.avg_live_uv)}
                                </span>
                                ` : ''}
                                <span style="color:#9aaebe; font-size:9px;">
                                    <i class="fas fa-tag"></i> ${escapeHtml(creator.category || 'Lifestyle')}
                                </span>
                            </div>
                        </div>
                        <div style="display:flex; flex-direction:column; gap:6px; flex-shrink:0;">
                            <button class="select-creator-btn" style="background:#4ade80; color:#0a0e17; border:none; padding:4px 12px; border-radius:16px; cursor:pointer; font-size:10px; font-weight:600; white-space:nowrap;">
                                <i class="fas fa-plus"></i> Pilih
                            </button>
                            <button class="detail-creator-btn" data-creator-open-id="${escapeHtml(creator.creator_open_id || '')}" 
                                    style="background:#1e293b; color:#8b5cf6; border:1px solid #8b5cf6; padding:4px 12px; border-radius:16px; cursor:pointer; font-size:10px; white-space:nowrap;">
                                <i class="fas fa-info-circle"></i> Detail
                            </button>
                        </div>
                    </div>
                </div>`;
                
                container.innerHTML += cardHtml;
            });
            
            // ... (rest of event listeners same as before)
            
            //  ATTACH EVENT LISTENER KE TOMBOL DETAIL
            document.querySelectorAll('.detail-creator-btn').forEach(btn => {
                const newBtn = btn.cloneNode(true);
                btn.parentNode.replaceChild(newBtn, btn);
                
                newBtn.addEventListener('click', (e) => {
                    e.stopPropagation();
                    const creatorOpenId = newBtn.getAttribute('data-creator-open-id');
                    console.log('Detail button clicked, creator_open_id:', creatorOpenId);
                    
                    if (creatorOpenId && creatorOpenId !== '') {
                        showCreatorPerformanceDetail(creatorOpenId);
                    } else {
                        showToastGlobal('Creator Open ID tidak tersedia untuk creator ini', 'warning');
                    }
                });
            });
            
            //  ATTACH EVENT LISTENER KE TOMBOL PILIH
            document.querySelectorAll('.select-creator-btn').forEach(btn => {
                const newBtn = btn.cloneNode(true);
                btn.parentNode.replaceChild(newBtn, btn);
                
                newBtn.addEventListener('click', (e) => {
                    e.stopPropagation();
                    const parent = newBtn.closest('.search-result-item');
                    const creatorData = JSON.parse(parent.getAttribute('data-creator'));
                    console.log('Select button clicked:', creatorData);
                    showAddCreatorFromSearchForm(creatorData);
                });
            });
            
            // Update pagination
            if (result.next_page_token) {
                searchPageToken = result.next_page_token;
                loadMoreContainer.style.display = 'block';
                
                let loadMoreBtn = document.getElementById('loadMoreResults');
                if (loadMoreBtn) {
                    const newLoadMoreBtn = loadMoreBtn.cloneNode(true);
                    loadMoreBtn.parentNode.replaceChild(newLoadMoreBtn, loadMoreBtn);
                    
                    newLoadMoreBtn.innerHTML = '<i class="fas fa-chevron-down"></i> Load More';
                    newLoadMoreBtn.disabled = false;
                    isLoadingMore = false;
                    
                    newLoadMoreBtn.addEventListener('click', async () => {
                        if (!isLoadingMore && searchPageToken) {
                            await performSearch(true);
                        }
                    });
                }
            } else {
                searchPageToken = null;
                if (searchResults.length > 0) {
                    loadMoreContainer.style.display = 'block';
                    let loadMoreBtn = document.getElementById('loadMoreResults');
                    if (loadMoreBtn) {
                        const newLoadMoreBtn = loadMoreBtn.cloneNode(true);
                        loadMoreBtn.parentNode.replaceChild(newLoadMoreBtn, loadMoreBtn);
                        newLoadMoreBtn.innerHTML = '<i class="fas fa-check"></i> No more results';
                        newLoadMoreBtn.disabled = true;
                    }
                } else {
                    loadMoreContainer.style.display = 'none';
                }
            }
            
        } else {
            container.innerHTML = `
                <div style="text-align:center; padding:40px; color:#ef4444;">
                    <i class="fas fa-exclamation-triangle" style="font-size:32px; margin-bottom:12px; display:block;"></i>
                    <p>${result.message || 'Tidak ditemukan creator'}</p>
                    <small style="color:#9aaebe;">Coba dengan keyword lain</small>
                </div>
            `;
            loadMoreContainer.style.display = 'none';
        }
        
    } catch (error) {
        console.error('Search error:', error);
        container.innerHTML = `
            <div style="text-align:center; padding:40px; color:#ef4444;">
                <i class="fas fa-exclamation-triangle" style="font-size:32px; margin-bottom:12px; display:block;"></i>
                <p>Error: ${error.message}</p>
                <button id="retrySearchBtn" class="btn-primary" style="margin-top:12px; background:#4ade80; color:#0a0e17; border:none; padding:8px 16px; border-radius:20px; cursor:pointer;">Coba Lagi</button>
            </div>
        `;
        const retryBtn = document.getElementById('retrySearchBtn');
        if (retryBtn) {
            retryBtn.addEventListener('click', () => performSearch());
        }
        loadMoreContainer.style.display = 'none';
    }
}
async function showAddCreatorFromSearchForm(creator) {
    console.log('Opening add creator form with data:', creator);
    
    const modalTitle = document.getElementById('modalTitleDashboard');
    const modalBody = document.getElementById('modalBodyDashboard');
    
    // Tampilkan loading
    modalTitle.innerHTML = '<i class="fas fa-spinner fa-pulse"></i> Memuat data kontak...';
    modalBody.innerHTML = `
        <div style="text-align:center; padding:40px;">
            <i class="fas fa-spinner fa-pulse fa-2x" style="color:#8b5cf6;"></i>
            <p style="margin-top:12px;">AI Toopai sedang mencari kontak WhatsApp & Email creator</p>
            <p style="font-size:11px; color:#9aaebe;">Mohon tunggu sebentar</p>
        </div>
    `;
    openModalIS();
    
    // FETCH KONTAK DARI CRAWLER
    let contactData = { whatsapp: '', email: '', display_name: '' };
    let contactFound = false;
    
    try {
        const contactResult = await fetchCreatorContact(creator.username);
        if (contactResult.success && contactResult.whatsapp) {
            contactData.whatsapp = contactResult.whatsapp;
            contactData.email = contactResult.email || '';
            contactData.display_name = contactResult.display_name || creator.nickname;
            contactFound = true;
            console.log('Contact found via crawler:', contactData);
        } else {
            console.log('No contact found via crawler, using manual input');
        }
    } catch (error) {
        console.error('Error fetching contact:', error);
    }
    
    // Format data
    const followerFormatted = formatNumberShort(creator.follower_count);
    const followerRaw = creator.follower_count || 0;
    const gmvUsd = parseFloat(creator.gmv || 0);
    const gmvIdr = Math.round(gmvUsd * 16000);
    const gmvFormatted = 'Rp ' + formatNumber(gmvIdr);
    const gmvRaw = gmvIdr;
    
    // �9�7 CEK APAKAH CREATOR SUDAH ADA DI DATABASE - AMBIL JUGA CA INFO
    let existingCreator = null;
    let existingStatusHtml = '';
    let caInfoHtml = '';
    
    try {
        const checkResponse = await fetch(baseUrlIS + 'is/check_creator_exists', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: new URLSearchParams({ username: creator.username })
        });
        const checkResult = await checkResponse.json();
        if (checkResult.exists) {
            existingCreator = checkResult.creator;
            const createdDate = existingCreator.created_at ? new Date(existingCreator.created_at).toLocaleDateString('id-ID') : '-';
            const createdTime = existingCreator.created_at ? new Date(existingCreator.created_at).toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' }) : '-';
            
            // �9�7 AMBIL INFO CA (Creator Acquisition) - user yang punya creator ini
            let caName = '-';
            let caUsername = '-';
            if (existingCreator.is_id) {
                const caUser = await fetch(baseUrlIS + 'is/get_user/' + existingCreator.is_id);
                const caResult = await caUser.json();
                if (caResult.success && caResult.user) {
                    caName = caResult.user.full_name || caResult.user.username || '-';
                    caUsername = caResult.user.username || '-';
                }
            }
            
            existingStatusHtml = `
                <div style="background:rgba(251,191,36,0.15); border-radius:12px; padding:10px; margin-bottom:16px; border-left:3px solid #fbbf24;">
                    <div style="color:#fbbf24; font-size:12px; margin-bottom:4px;">
                        <i class="fas fa-exclamation-triangle"></i> Creator sudah ada di database!
                    </div>
                    <div style="display:grid; grid-template-columns:1fr 1fr; gap:4px 16px; font-size:11px; color:#9aaebe; margin-top:4px;">
                        <div><i class="fas fa-calendar-alt"></i> Tanggal input: ${createdDate} ${createdTime}</div>
                        <div><i class="fas fa-tag"></i> Status: ${existingCreator.status || '-'}</div>
                        <div><i class="fab fa-whatsapp"></i> WhatsApp: ${existingCreator.phone || '-'}</div>
                        <div><i class="fas fa-user-tie"></i> CA: <span style="color:#8b5cf6; font-weight:500;">${caName}</span> (@${caUsername})</div>
                    </div>
                </div>
            `;
        }
    } catch (error) {
        console.error('Error checking existing creator:', error);
    }
    
    // Avatar HTML
    const avatarHtml = creator.avatar_url && creator.avatar_url !== ''
        ? `<img src="${escapeHtml(creator.avatar_url)}" style="width:100%; height:100%; object-fit:cover;" onerror="this.src=''; this.onerror=null; this.parentElement.innerHTML='<i class=\\'fab fa-tiktok\\' style=\\'font-size:40px; color:#4ade80;\\'></i>'">` 
        : '<i class="fab fa-tiktok" style="font-size:40px; color:#4ade80;"></i>';
    
    // Tampilkan form dengan data yang sudah didapat
    modalTitle.innerHTML = '<i class="fas fa-user-plus"></i> Tambah Creator dari Hasil Pencarian';
    modalBody.innerHTML = `
        <div style="background:rgba(74,222,128,0.1); border-radius:14px; padding:12px; margin-bottom:16px;">
            <div style="display:flex; gap:16px; align-items:center;">
                <div style="width:70px; height:70px; border-radius:50%; overflow:hidden; background:#1e293b; display:flex; align-items:center; justify-content:center;">
                    ${avatarHtml}
                </div>
                <div>
                    <div style="color:#e2f0e8; font-weight:600; font-size:16px;">${escapeHtml(creator.nickname || creator.username)}</div>
                    <div style="color:#4ade80; font-size:12px;">@${escapeHtml(creator.username)}</div>
                    ${contactFound ? '<div style="color:#4ade80; font-size:10px; margin-top:4px;"><i class="fas fa-check-circle"></i> Kontak otomatis ditemukan!</div>' : '<div style="color:#fbbf24; font-size:10px; margin-top:4px;"><i class="fas fa-info-circle"></i> Kontak tidak ditemukan, silakan isi manual</div>'}
                </div>
            </div>
        </div>
        
        ${existingStatusHtml}
        
        <div style="display:grid; grid-template-columns:1fr 1fr; gap:12px; margin-bottom:16px;">
            <div style="background:#0f1420; border-radius:10px; padding:8px; text-align:center;">
                <div style="color:#9aaebe; font-size:10px;"><i class="fas fa-users"></i> Followers</div>
                <div style="color:#4ade80; font-size:14px; font-weight:600;">${followerFormatted}</div>
            </div>
            <div style="background:#0f1420; border-radius:10px; padding:8px; text-align:center;">
                <div style="color:#9aaebe; font-size:10px;"><i class="fas fa-chart-line"></i> GMV 28 Hari</div>
                <div style="color:#fbbf24; font-size:14px; font-weight:600;">${gmvFormatted}</div>
            </div>
        </div>
        
        <label><i class="fab fa-tiktok"></i> Username *</label>
        <input type="text" id="creatorUsernameIS" value="${escapeHtml(creator.username)}" ${existingCreator ? 'readonly' : ''} style="background:#1a1f2e; color:#9aaebe; width:100%; padding:10px; border-radius:10px; border:1px solid #2a3346;">
        
        <label><i class="fas fa-user"></i> Nama Lengkap</label>
        <input type="text" id="creatorNameIS" value="${escapeHtml(contactData.display_name || creator.nickname || existingCreator?.full_name || '')}" placeholder="Nama lengkap creator" style="width:100%; padding:10px; background:#0f1420; border:1px solid #2a3346; border-radius:10px; color:#e2f0e8;">
        
        <label><i class="fab fa-whatsapp"></i> WhatsApp <span id="whatsappStatus" style="font-size:10px; color:${contactData.whatsapp ? '#4ade80' : '#fbbf24'}; margin-left:8px;">${contactData.whatsapp ? '(Auto-ditemukan)' : (existingCreator?.phone ? '(Sudah ada)' : '(Kosong - isi manual)')}</span></label>
        <div style="display:flex; gap:8px; align-items:center;">
            <input type="tel" id="creatorPhoneIS" value="${escapeHtml(contactData.whatsapp || existingCreator?.phone || '')}" placeholder="+62 812 3456 7890" style="flex:1; padding:10px; background:#0f1420; border:1px solid #2a3346; border-radius:10px; color:#e2f0e8;">
            <button type="button" id="refreshContactBtn" style="background:#8b5cf6; color:white; border:none; padding:8px 12px; border-radius:10px; cursor:pointer; font-size:11px;" title="Cari ulang kontak">
                <i class="fas fa-sync-alt"></i>
            </button>
        </div>
        
        <label><i class="fas fa-envelope"></i> Email <span id="emailStatus" style="font-size:10px; color:${contactData.email ? '#4ade80' : '#fbbf24'}; margin-left:8px;">${contactData.email ? '(Auto-ditemukan)' : '(Kosong)'}</span></label>
        <input type="email" id="creatorEmailIS" value="${escapeHtml(contactData.email || existingCreator?.email || '')}" placeholder="Email creator" style="width:100%; padding:10px; background:#0f1420; border:1px solid #2a3346; border-radius:10px; color:#e2f0e8;">
        
        <label><i class="fas fa-tag"></i> Kategori</label>
        <select id="creatorCategoryIS" style="width:100%; padding:10px; background:#0f1420; border:1px solid #2a3346; border-radius:10px; color:#e2f0e8;">
            <option value="Beauty" ${creator.category === 'Beauty' ? 'selected' : (existingCreator?.category === 'Beauty' ? 'selected' : '')}> Beauty</option>
            <option value="Fashion" ${creator.category === 'Fashion' ? 'selected' : (existingCreator?.category === 'Fashion' ? 'selected' : '')}> Fashion</option>
            <option value="Tech" ${creator.category === 'Tech' ? 'selected' : (existingCreator?.category === 'Tech' ? 'selected' : '')}> Tech</option>
            <option value="Lifestyle" ${creator.category === 'Lifestyle' ? 'selected' : (existingCreator?.category === 'Lifestyle' ? 'selected' : '')}> Lifestyle</option>
            <option value="Gaming" ${creator.category === 'Gaming' ? 'selected' : (existingCreator?.category === 'Gaming' ? 'selected' : '')}> Gaming</option>
            <option value="Food" ${creator.category === 'Food' ? 'selected' : (existingCreator?.category === 'Food' ? 'selected' : '')}> Food</option>
            <option value="Sports" ${creator.category === 'Sports' ? 'selected' : (existingCreator?.category === 'Sports' ? 'selected' : '')}> Sports</option>
            <option value="Home & Living" ${creator.category === 'Home & Living' ? 'selected' : (existingCreator?.category === 'Home & Living' ? 'selected' : '')}> Home & Living</option>
            <option value="Health" ${creator.category === 'Health' ? 'selected' : (existingCreator?.category === 'Health' ? 'selected' : '')}> Health</option>
            <option value="Skincare" ${creator.category === 'Skincare' ? 'selected' : (existingCreator?.category === 'Skincare' ? 'selected' : '')}> Skincare</option>
            <option value="Makeup" ${creator.category === 'Makeup' ? 'selected' : (existingCreator?.category === 'Makeup' ? 'selected' : '')}> Makeup</option>
        </select>
        
        <!-- Hidden fields untuk data API -->
        <input type="hidden" id="creatorAvatarUrl" value="${escapeHtml(creator.avatar_url || '')}">
        <input type="hidden" id="creatorFollowerCount" value="${followerRaw}">
        <input type="hidden" id="creatorGmv" value="${gmvRaw}">
        
        <div class="flex-buttons" style="margin-top:20px;">
            <button id="saveCreatorFromSearchBtn" style="background:#4ade80; color:#0a0e17; flex:1;"><i class="fas fa-save"></i> ${existingCreator ? 'Update Creator' : 'Simpan Creator'}</button>
            <button id="cancelCreatorFromSearchBtn" style="background:#1e293b; flex:1;">Batal</button>
        </div>
    `;
    
    //  EVENT: Refresh Contact Button
    document.getElementById('refreshContactBtn')?.addEventListener('click', async () => {
        const refreshBtn = document.getElementById('refreshContactBtn');
        const originalText = refreshBtn.innerHTML;
        refreshBtn.disabled = true;
        refreshBtn.innerHTML = '<i class="fas fa-spinner fa-pulse"></i>';
        
        showToastGlobal('Mencari ulang kontak creator...', 'info');
        
        try {
            const contactResult = await fetchCreatorContact(creator.username);
            
            if (contactResult.success && contactResult.whatsapp) {
                document.getElementById('creatorPhoneIS').value = contactResult.whatsapp;
                document.getElementById('creatorEmailIS').value = contactResult.email || '';
                document.getElementById('whatsappStatus').innerHTML = '(Auto-ditemukan)';
                document.getElementById('whatsappStatus').style.color = '#4ade80';
                document.getElementById('emailStatus').innerHTML = contactResult.email ? '(Auto-ditemukan)' : '(Kosong)';
                document.getElementById('emailStatus').style.color = contactResult.email ? '#4ade80' : '#fbbf24';
                
                if (!document.getElementById('creatorNameIS').value || document.getElementById('creatorNameIS').value === '') {
                    document.getElementById('creatorNameIS').value = contactResult.display_name || creator.nickname || '';
                }
                
                showToastGlobal(`Kontak ditemukan! WhatsApp: ${contactResult.whatsapp}`, 'success');
            } else {
                showToastGlobal('Kontak tidak ditemukan, silakan isi manual', 'warning');
                document.getElementById('whatsappStatus').innerHTML = '(Tidak ditemukan - isi manual)';
                document.getElementById('whatsappStatus').style.color = '#ef4444';
            }
        } catch (error) {
            showToastGlobal('Gagal mencari kontak: ' + error.message, 'error');
        } finally {
            refreshBtn.disabled = false;
            refreshBtn.innerHTML = originalText;
        }
    });
    
    // Save button event
    const saveBtn = document.getElementById('saveCreatorFromSearchBtn');
    if (saveBtn) {
        const newSaveBtn = saveBtn.cloneNode(true);
        saveBtn.parentNode.replaceChild(newSaveBtn, saveBtn);
        
        newSaveBtn.addEventListener('click', async () => {
            const username = document.getElementById('creatorUsernameIS').value.trim();
            if (!username) { 
                showToastGlobal('Username harus diisi', 'error'); 
                return; 
            }
            
            const btn = newSaveBtn;
            btn.disabled = true; 
            btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Menyimpan...';
            
            const formData = new URLSearchParams({
                username: username.replace('@', ''),
                full_name: document.getElementById('creatorNameIS').value,
                phone: document.getElementById('creatorPhoneIS').value,
                email: document.getElementById('creatorEmailIS').value,
                category: document.getElementById('creatorCategoryIS').value,
                avatar_url: document.getElementById('creatorAvatarUrl').value,
                follower_count: document.getElementById('creatorFollowerCount').value,
                gmv: document.getElementById('creatorGmv').value
            });
            
            try {
                const response = await fetch(baseUrlIS + 'is/add_creator', { 
                    method: 'POST', 
                    body: formData
                });
                const result = await response.json();
                
                if (result.success) {
                    closeModalIS();
                    showToastGlobal(` Creator @${username} berhasil ditambahkan!`);
                    setTimeout(() => location.reload(), 1500);
                } else {
                    showToastGlobal(result.message || 'Gagal menambah creator', 'error');
                    btn.disabled = false;
                    btn.innerHTML = '<i class="fas fa-save"></i> Simpan Creator';
                }
            } catch (error) {
                console.error('Save error:', error);
                showToastGlobal('Error: ' + error.message, 'error');
                btn.disabled = false;
                btn.innerHTML = '<i class="fas fa-save"></i> Simpan Creator';
            }
        });
    }
    
    // Cancel button event
    const cancelBtn = document.getElementById('cancelCreatorFromSearchBtn');
    if (cancelBtn) {
        const newCancelBtn = cancelBtn.cloneNode(true);
        cancelBtn.parentNode.replaceChild(newCancelBtn, cancelBtn);
        newCancelBtn.addEventListener('click', closeModalIS);
    }
}

// ========== CEK KONTAK CREATOR DARI CRAWLER ==========
async function fetchCreatorContact(username) {
    try {
        console.log('Fetching contact for username:', username);
        
        const response = await fetch(baseUrlIS + 'creator_crawler/cek/' + encodeURIComponent(username), {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json'
            }
        });
        
        const result = await response.json();
        console.log('Contact result:', result);
        
        if (result.success && result.status === 'FOUND') {
            return {
                success: true,
                whatsapp: result.whatsapp || '',
                email: result.email || '',
                display_name: result.display_name || '',
                status: result.status
            };
        } else {
            return {
                success: false,
                whatsapp: '',
                email: '',
                display_name: '',
                status: result.status || 'NOT_FOUND',
                message: result.message || 'Kontak tidak ditemukan'
            };
        }
    } catch (error) {
        console.error('Error fetching contact:', error);
        return {
            success: false,
            whatsapp: '',
            email: '',
            display_name: '',
            error: error.message
        };
    }
}
// ========== UPDATE BUTTON TAMBAH CREATOR (GABUNGAN) ==========
function updateAddCreatorButtons() {
    // Tombol di tab - BUKA SEARCH MODAL
    const addBtn = document.getElementById('addCreatorBtnDashboard');
    if (addBtn) {
        const newAddBtn = addBtn.cloneNode(true);
        addBtn.parentNode.replaceChild(newAddBtn, addBtn);
        newAddBtn.addEventListener('click', function(e) {
            e.preventDefault();
            e.stopPropagation();
            console.log('Add Creator button clicked - opening search modal');
            showSearchCreatorModal();
        });
    }
    
    // Tombol quick di Task 1 - BUKA SEARCH MODAL
    const quickBtn = document.getElementById('addCreatorQuickBtnDashboard');
    if (quickBtn) {
        const newQuickBtn = quickBtn.cloneNode(true);
        quickBtn.parentNode.replaceChild(newQuickBtn, quickBtn);
        newQuickBtn.addEventListener('click', function(e) {
            e.preventDefault();
            e.stopPropagation();
            console.log('Quick Add Creator button clicked - opening search modal');
            showSearchCreatorModal();
        });
    }
}

// ========== TASK 1: KLIK BOX SCOUTING ==========
async function showCreatorDetailIS(creatorId) {
    console.log('Fetching creator detail for ID:', creatorId);
    
    document.getElementById('modalTitleDashboard').innerHTML = `<i class="fab fa-tiktok"></i> Loading...`;
    document.getElementById('modalBodyDashboard').innerHTML = `
        <div style="text-align:center; padding:40px;">
            <i class="fas fa-spinner fa-pulse fa-2x" style="color:#4ade80;"></i>
            <p style="margin-top:12px;">Memuat data creator...</p>
        </div>
    `;
    openModalIS();
    
    try {
        const response = await fetch(baseUrlIS + 'is/get_creator_detail', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: new URLSearchParams({ creator_id: creatorId })
        });
        
        const result = await response.json();
        console.log('API Response:', result);
        
        if (!result.success) {
            document.getElementById('modalBodyDashboard').innerHTML = `
                <div style="text-align:center; padding:40px;">
                    <i class="fas fa-exclamation-triangle fa-2x" style="color:#ef4444;"></i>
                    <p style="margin-top:12px;">${result.message || 'Gagal mengambil detail creator'}</p>
                    <button class="btn-submit" onclick="closeModalIS()" style="margin-top:16px;">Tutup</button>
                </div>
            `;
            return;
        }
        
        const creator = result.data;
        const createdDate = creator.created_at ? new Date(creator.created_at).toLocaleDateString('id-ID') : '-';
        const approvedDate = creator.approved_at ? new Date(creator.approved_at).toLocaleDateString('id-ID') : 'Belum';
        const hasPhone = creator.phone && creator.phone !== '' && creator.phone !== '-';
        
        let statusBadge = '';
        if (creator.status === 'ACTIVE') {
            statusBadge = '<span class="badge-dashboard badge-active"><i class="fas fa-check-circle"></i> ACTIVE</span>';
        } else if (creator.status === 'PENDING') {
            statusBadge = '<span class="badge-dashboard badge-pending"><i class="fas fa-clock"></i> PENDING</span>';
        } else if (creator.status === 'REJECTED') {
            statusBadge = '<span class="badge-dashboard" style="background:rgba(239,68,68,0.15); color:#ef4444;"><i class="fas fa-times-circle"></i> REJECTED</span>';
        } else {
            statusBadge = `<span class="badge-dashboard badge-pending"><i class="fas fa-clock"></i> ${creator.status}</span>`;
        }
        
        const phoneWarning = !hasPhone && creator.status === 'PENDING' ? `
            <div style="background: rgba(239,68,68,0.15); border-radius: 12px; padding: 10px; margin-bottom: 16px; border-left: 3px solid #ef4444;">
                <div style="color: #fbbf24; font-size: 12px; font-weight: 500; margin-bottom: 5px;">
                    <i class="fas fa-exclamation-triangle"></i> Nomor WhatsApp tidak tersedia!
                </div>
                <div style="color: #9aaebe; font-size: 11px;">
                    Silakan update nomor WhatsApp creator sebelum approve.
                </div>
            </div>
        ` : '';
        
        let campaignsHtml = '';
        if (creator.campaigns && creator.campaigns.length > 0) {
            campaignsHtml = `
                <div style="margin-top:16px;">
                    <label style="color:#9aaebe; font-size:12px; margin-bottom:8px; display:block;">
                        <i class="fas fa-bullhorn"></i> Campaign yang Diikuti
                    </label>
                    <div style="background:#0f1420; border-radius:12px; padding:8px; max-height:150px; overflow-y:auto;">
                        ${creator.campaigns.map(camp => `
                            <div style="display:flex; justify-content:space-between; padding:8px; border-bottom:1px solid #2a3346;">
                                <div style="color:#e2f0e8; font-size:12px;">${escapeHtml(camp.campaign_name || camp.campaign_id)}</div>
                                <div style="color:#fbbf24; font-size:11px;">${camp.commission_rate}%</div>
                            </div>
                        `).join('')}
                    </div>
                </div>
            `;
        }
        
        let whatsappHtml = '';
        if (creator.whatsapp_logs && creator.whatsapp_logs.length > 0) {
            whatsappHtml = `
                <div style="margin-top:16px;">
                    <label style="color:#9aaebe; font-size:12px; margin-bottom:8px; display:block;">
                        <i class="fab fa-whatsapp"></i> Riwayat WhatsApp
                    </label>
                    <div style="background:#0f1420; border-radius:12px; padding:8px; max-height:120px; overflow-y:auto;">
                        ${creator.whatsapp_logs.map(log => `
                            <div style="font-size:10px; color:#9aaebe; padding:4px 0; border-bottom:1px solid #2a3346;">
                                <i class="fas fa-paper-plane"></i> ${log.sent_at ? new Date(log.sent_at).toLocaleString() : '-'}
                                <div style="color:#e2f0e8; margin-top:2px;">${escapeHtml(log.message.substring(0, 100))}${log.message.length > 100 ? '...' : ''}</div>
                            </div>
                        `).join('')}
                    </div>
                </div>
            `;
        }
        
        document.getElementById('modalTitleDashboard').innerHTML = `<i class="fab fa-tiktok"></i> Detail Creator: @${escapeHtml(creator.username)}`;
        document.getElementById('modalBodyDashboard').innerHTML = `
            <div style="background:rgba(74,222,128,0.1); border-radius:14px; padding:14px; margin-bottom:16px;">
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 12px;">
                    <div>
                        <div style="color:#9aaebe; font-size:11px;">Username</div>
                        <div style="color:#ffffff; font-size:14px; font-weight:500; display: flex; align-items: center; gap: 8px;">
                            @${escapeHtml(creator.username)}
                            <button id="checkTiktokBtnIS" style="background: transparent; border: 1px solid #4ade80; border-radius: 20px; padding: 2px 10px; font-size: 10px; color: #4ade80; cursor: pointer;">
                                <i class="fab fa-tiktok"></i> Cek Profil
                            </button>
                        </div>
                    </div>
                    <div>
                        <div style="color:#9aaebe; font-size:11px;">Nama Lengkap</div>
                        <div style="color:#ffffff; font-size:14px;">${escapeHtml(creator.full_name || '-')}</div>
                    </div>
                    <div>
                        <div style="color:#9aaebe; font-size:11px;">Kategori</div>
                        <div style="color:#ffffff; font-size:14px;">${escapeHtml(creator.category || '-')}</div>
                    </div>
                    <div>
                        <div style="color:#9aaebe; font-size:11px;">Status</div>
                        <div>${statusBadge}</div>
                    </div>
                    <div>
                        <div style="color:#9aaebe; font-size:11px;"><i class="fab fa-whatsapp"></i> WhatsApp</div>
                        <div style="color:${hasPhone ? '#4ade80' : '#ef4444'}; font-size:14px;">
                            ${hasPhone ? escapeHtml(creator.phone) : '<i class="fas fa-times-circle"></i> Tidak tersedia'}
                        </div>
                    </div>
                    <div>
                        <div style="color:#9aaebe; font-size:11px;"><i class="fas fa-envelope"></i> Email</div>
                        <div style="color:#ffffff; font-size:14px;">${escapeHtml(creator.email || '-')}</div>
                    </div>
                    <div>
                        <div style="color:#9aaebe; font-size:11px;">Tanggal Daftar</div>
                        <div style="color:#ffffff; font-size:12px;">${createdDate}</div>
                    </div>
                    <div>
                        <div style="color:#9aaebe; font-size:11px;">Tanggal Approve</div>
                        <div style="color:#ffffff; font-size:12px;">${approvedDate}</div>
                    </div>
                </div>
            </div>
            
            ${phoneWarning}
            ${campaignsHtml}
            ${whatsappHtml}
            
            <div class="flex-buttons" style="margin-top:20px;">
                ${creator.status === 'PENDING' ? `
                 <button id="editCreatorBtnIS" style="background:#8b5cf6; color:white;">
            <i class="fas fa-edit"></i> Edit Data
        </button>
                    <button id="approveCreatorBtnIS" style="background:#4ade80; color:#0a0e17;">
                        <i class="fas fa-check-circle"></i> Approve Creator
                    </button>
                    <button id="updatePhoneBtnIS" style="background:#fbbf24; color:#0a0e17;">
                        <i class="fab fa-whatsapp"></i> Update WhatsApp
                    </button>
                    <button id="rejectCreatorBtnIS" style="background:#1e293b; border:1px solid #ef4444; color:#ef4444;">
                        <i class="fas fa-times-circle"></i> Tolak
                    </button>
                ` : ''}
                <button id="closeDetailBtnIS" style="background:#1e293b;">Tutup</button>
            </div>
        `;
        const editBtn = document.getElementById('editCreatorBtnIS');
if (editBtn) {
    editBtn.addEventListener('click', () => {
        showEditCreatorModalIS(creatorId, creator);
    });
}

        const checkTiktokBtn = document.getElementById('checkTiktokBtnIS');
        if (checkTiktokBtn) {
            checkTiktokBtn.addEventListener('click', (e) => {
                e.preventDefault();
                e.stopPropagation();
                window.open(`https://www.tiktok.com/@${creator.username}`, '_blank');
            });
        }
        
        const updatePhoneBtn = document.getElementById('updatePhoneBtnIS');
        if (updatePhoneBtn) {
            updatePhoneBtn.addEventListener('click', () => {
                showUpdatePhoneModalIS(creatorId, creator.username, creator.phone);
            });
        }
        
        const approveBtn = document.getElementById('approveCreatorBtnIS');
        if (approveBtn) {
            approveBtn.addEventListener('click', async () => {
                if (!hasPhone) {
                    showToastGlobal('Silakan update nomor WhatsApp creator terlebih dahulu sebelum approve!', 'error');
                    showUpdatePhoneModalIS(creatorId, creator.username, null);
                    return;
                }
                
                const btn = approveBtn;
                btn.disabled = true;
                btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Approving...';
                
                const approveRes = await fetch(baseUrlIS + 'is/approve_creator', {
                    method: 'POST',
                    body: new URLSearchParams({ creator_id: creatorId })
                });
                const approveResult = await approveRes.json();
                
                if (approveResult.success) {
                    closeModalIS();
                    showToastGlobal(` @${creator.username} approved! Kini dapat diassign campaign di Task 2.`, 'success');
                    setTimeout(() => location.reload(), 1500);
                } else {
                    showToastGlobal(approveResult.message || 'Gagal approve', 'error');
                    btn.disabled = false;
                    btn.innerHTML = '<i class="fas fa-check-circle"></i> Approve Creator';
                }
            });
        }
        
        const rejectBtn = document.getElementById('rejectCreatorBtnIS');
        if (rejectBtn) {
            rejectBtn.addEventListener('click', async () => {
                if (confirm(`Tolak creator @${creator.username}?`)) {
                    await fetch(baseUrlIS + 'is/update_creator_status', {
                        method: 'POST',
                        body: new URLSearchParams({ creator_id: creatorId, status: 'REJECTED' })
                    });
                    closeModalIS();
                    showToastGlobal(`@${creator.username} ditolak`, 'warning');
                    setTimeout(() => location.reload(), 1500);
                }
            });
        }
        
        document.getElementById('closeDetailBtnIS')?.addEventListener('click', closeModalIS);
        
    } catch (error) {
        console.error('Error:', error);
        document.getElementById('modalBodyDashboard').innerHTML = `
            <div style="text-align:center; padding:40px;">
                <i class="fas fa-exclamation-triangle fa-2x" style="color:#ef4444;"></i>
                <p style="margin-top:12px;">Network error: ${error.message}</p>
                <button class="btn-submit" onclick="closeModalIS()" style="margin-top:16px;">Tutup</button>
            </div>
        `;
    }
}

function showUpdatePhoneModalIS(creatorId, creatorUsername, currentPhone) {
    const modalTitle = document.getElementById('modalTitleDashboard');
    const modalBody = document.getElementById('modalBodyDashboard');
    
    modalTitle.innerHTML = `<i class="fab fa-whatsapp"></i> Update WhatsApp - @${escapeHtml(creatorUsername)}`;
    modalBody.innerHTML = `
        <div style="background:rgba(74,222,128,0.1); border-radius:14px; padding:12px; margin-bottom:16px;">
            <p style="color:#4ade80; font-size:12px;"><i class="fas fa-info-circle"></i> Nomor WhatsApp diperlukan untuk mengirim link afiliasi dan sample</p>
        </div>
        
        <label><i class="fab fa-whatsapp"></i> Nomor WhatsApp</label>
        <input type="tel" id="updatePhoneNumber" placeholder="+62 812 3456 7890" value="${escapeHtml(currentPhone || '')}" style="width:100%; padding:10px; background:#0f1420; border:1px solid #2a3346; border-radius:12px; color:#e2f0e8; margin-bottom:16px;">
        <div style="font-size:11px; color:#9aaebe; margin-bottom:16px;">
            <i class="fas fa-info-circle"></i> Format: +628123456789 atau 08123456789
        </div>
        
        <div class="flex-buttons">
            <button id="savePhoneBtn" style="background:#4ade80; color:#0a0e17;"><i class="fas fa-save"></i> Simpan</button>
            <button id="cancelPhoneBtn" style="background:#1e293b;">Batal</button>
        </div>
    `;
    openModalIS();
    
    document.getElementById('savePhoneBtn').addEventListener('click', async () => {
        let phone = document.getElementById('updatePhoneNumber').value.trim();
        
        if (!phone) {
            showToastGlobal('Nomor WhatsApp tidak boleh kosong', 'error');
            return;
        }
        
        phone = phone.replace(/[^0-9+]/g, '');
        if (phone.startsWith('0')) {
            phone = '62' + phone.substring(1);
        } else if (phone.startsWith('+')) {
            phone = phone.substring(1);
        }
        
        if (phone.length < 10) {
            showToastGlobal('Nomor WhatsApp tidak valid (minimal 10 digit)', 'error');
            return;
        }
        
        const btn = document.getElementById('savePhoneBtn');
        btn.disabled = true;
        btn.innerHTML = '<i class="fas fa-spinner fa-pulse"></i> Menyimpan...';
        
        try {
            const response = await fetch(baseUrlIS + 'is/update_creator_phone', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: new URLSearchParams({
                    creator_id: creatorId,
                    phone: phone
                })
            });
            const result = await response.json();
            
            if (result.success) {
                showToastGlobal('Nomor WhatsApp berhasil diupdate!', 'success');
                closeModalIS();
                showCreatorDetailIS(creatorId);
            } else {
                showToastGlobal(result.message || 'Gagal update nomor', 'error');
                btn.disabled = false;
                btn.innerHTML = '<i class="fas fa-save"></i> Simpan';
            }
        } catch (error) {
            showToastGlobal('Error: ' + error.message, 'error');
            btn.disabled = false;
            btn.innerHTML = '<i class="fas fa-save"></i> Simpan';
        }
    });
    
    document.getElementById('cancelPhoneBtn').addEventListener('click', () => {
        closeModalIS();
        showCreatorDetailIS(creatorId);
    });
}
// ========== MODAL EDIT CREATOR (TASK 1) ==========
function showEditCreatorModalIS(creatorId, creatorData) {
    const modalTitle = document.getElementById('modalTitleDashboard');
    const modalBody = document.getElementById('modalBodyDashboard');
    
    modalTitle.innerHTML = `<i class="fas fa-edit"></i> Edit Creator: @${escapeHtml(creatorData.username)}`;
    modalBody.innerHTML = `
        <div style="background:rgba(139,92,246,0.1); border-radius:14px; padding:12px; margin-bottom:16px;">
            <p style="color:#8b5cf6; font-size:12px;"><i class="fas fa-info-circle"></i> Edit data creator. Field yang dikosongkan tidak akan diubah.</p>
        </div>
        
        <label><i class="fab fa-tiktok"></i> Username</label>
        <input type="text" value="@${escapeHtml(creatorData.username)}" readonly style="background:#1a1f2e; color:#9aaebe; width:100%; padding:10px; border-radius:10px; border:1px solid #2a3346;">
        
        <label><i class="fas fa-user"></i> Nama Lengkap</label>
        <input type="text" id="editFullName" value="${escapeHtml(creatorData.full_name || '')}" placeholder="Nama lengkap" style="width:100%; padding:10px; background:#0f1420; border:1px solid #2a3346; border-radius:10px; color:#e2f0e8;">
        
        <label><i class="fab fa-whatsapp"></i> WhatsApp</label>
        <input type="tel" id="editPhone" value="${escapeHtml(creatorData.phone || '')}" placeholder="+62 812 3456 7890" style="width:100%; padding:10px; background:#0f1420; border:1px solid #2a3346; border-radius:10px; color:#e2f0e8;">
        
        <label><i class="fas fa-envelope"></i> Email</label>
        <input type="email" id="editEmail" value="${escapeHtml(creatorData.email || '')}" placeholder="Email" style="width:100%; padding:10px; background:#0f1420; border:1px solid #2a3346; border-radius:10px; color:#e2f0e8;">
        
        <label><i class="fas fa-tag"></i> Kategori</label>
        <select id="editCategory" style="width:100%; padding:10px; background:#0f1420; border:1px solid #2a3346; border-radius:10px; color:#e2f0e8;">
            <option value="Beauty" ${creatorData.category === 'Beauty' ? 'selected' : ''}> Beauty</option>
            <option value="Fashion" ${creatorData.category === 'Fashion' ? 'selected' : ''}> Fashion</option>
            <option value="Tech" ${creatorData.category === 'Tech' ? 'selected' : ''}> Tech</option>
            <option value="Lifestyle" ${creatorData.category === 'Lifestyle' ? 'selected' : ''}> Lifestyle</option>
            <option value="Gaming" ${creatorData.category === 'Gaming' ? 'selected' : ''}> Gaming</option>
            <option value="Food" ${creatorData.category === 'Food' ? 'selected' : ''}> Food</option>
            <option value="Sports" ${creatorData.category === 'Sports' ? 'selected' : ''}> Sports</option>
            <option value="Home & Living" ${creatorData.category === 'Home & Living' ? 'selected' : ''}> Home & Living</option>
            <option value="Health" ${creatorData.category === 'Health' ? 'selected' : ''}> Health</option>
            <option value="FnB" ${creatorData.category === 'FnB' ? 'selected' : ''}> FnB</option>
            <option value="Skincare" ${creatorData.category === 'Skincare' ? 'selected' : ''}> Skincare</option>
            <option value="Makeup" ${creatorData.category === 'Makeup' ? 'selected' : ''}> Makeup</option>
        </select>
        
        <label><i class="fas fa-user-tag"></i> Nama Penerima Sample</label>
        <input type="text" id="editPenerima" value="${escapeHtml(creatorData.penerima || '')}" placeholder="Nama penerima" style="width:100%; padding:10px; background:#0f1420; border:1px solid #2a3346; border-radius:10px; color:#e2f0e8;">
        
        <label><i class="fas fa-map-marker-alt"></i> Alamat Pengiriman</label>
        <textarea id="editAlamat" rows="2" placeholder="Alamat lengkap..." style="width:100%; padding:10px; background:#0f1420; border:1px solid #2a3346; border-radius:10px; color:#e2f0e8;">${escapeHtml(creatorData.alamat || '')}</textarea>
        
        <label><i class="fas fa-sticky-note"></i> Catatan</label>
        <textarea id="editNotes" rows="2" placeholder="Catatan tentang creator ini..." style="width:100%; padding:10px; background:#0f1420; border:1px solid #2a3346; border-radius:10px; color:#e2f0e8;">${escapeHtml(creatorData.notes || '')}</textarea>
        
        <div style="background:#0f1420; border-radius:10px; padding:10px; margin-top:16px;">
            <div style="display:grid; grid-template-columns:1fr 1fr; gap:8px; font-size:10px; color:#9aaebe;">
                <div>Status: <span style="color:#fbbf24;">${escapeHtml(creatorData.status || '-')}</span></div>
                <div>Source: <span style="color:#8b5cf6;">${escapeHtml(creatorData.source || '-')}</span></div>
                <div>Created: ${new Date(creatorData.created_at).toLocaleDateString('id-ID')}</div>
                <div>Updated: ${new Date(creatorData.updated_at).toLocaleDateString('id-ID')}</div>
            </div>
        </div>
        
        <div class="flex-buttons" style="margin-top:20px;">
            <button id="saveEditBtn" style="background:#4ade80; color:#0a0e17; flex:1;"><i class="fas fa-save"></i> Simpan Perubahan</button>
            <button id="cancelEditBtn" style="background:#1e293b; flex:1;">Batal</button>
        </div>
    `;
    openModalIS();
    
    // Save button
    document.getElementById('saveEditBtn').addEventListener('click', async () => {
        const btn = document.getElementById('saveEditBtn');
        btn.disabled = true;
        btn.innerHTML = '<i class="fas fa-spinner fa-pulse"></i> Menyimpan...';
        
        const updateData = new URLSearchParams();
       const newUsername = document.getElementById('editUsername').value.trim().replace('@', '');
    const oldUsername = creatorData.username || '';
    
    //  KONFIRMASI KALAU USERNAME BERUBAH
    if (newUsername !== oldUsername && newUsername !== '') {
        if (!confirm(` Username akan diubah dari @${oldUsername} menjadi @${newUsername}.\n\nData order, link, dan performa akan ikut terupdate.\n\nLanjutkan?`)) {
            return;
        }
    }
        
        const fullName = document.getElementById('editFullName').value.trim();
        const phone = document.getElementById('editPhone').value.trim();
        const email = document.getElementById('editEmail').value.trim();
        const category = document.getElementById('editCategory').value;
        const penerima = document.getElementById('editPenerima').value.trim();
        const alamat = document.getElementById('editAlamat').value.trim();
        const notes = document.getElementById('editNotes').value.trim();
        
        if (fullName !== (creatorData.full_name || '')) updateData.append('full_name', fullName);
        if (phone !== (creatorData.phone || '')) updateData.append('phone', phone);
        if (email !== (creatorData.email || '')) updateData.append('email', email);
        if (category !== (creatorData.category || '')) updateData.append('category', category);
        if (penerima !== (creatorData.penerima || '')) updateData.append('penerima', penerima);
        if (alamat !== (creatorData.alamat || '')) updateData.append('alamat', alamat);
        if (notes !== (creatorData.notes || '')) updateData.append('notes', notes);
        
        try {
            const response = await fetch(baseUrlIS + 'is/update_creator_data', {
                method: 'POST',
                body: updateData
            });
            const result = await response.json();
            
            if (result.success) {
                closeModalIS();
                showToastGlobal('Data creator berhasil diupdate!', 'success');
                setTimeout(() => location.reload(), 1500);
            } else {
                showToastGlobal(result.message || 'Gagal update', 'error');
                btn.disabled = false;
                btn.innerHTML = '<i class="fas fa-save"></i> Simpan Perubahan';
            }
        } catch (error) {
            showToastGlobal('Error: ' + error.message, 'error');
            btn.disabled = false;
            btn.innerHTML = '<i class="fas fa-save"></i> Simpan Perubahan';
        }
    });
    
    // Cancel button
    document.getElementById('cancelEditBtn').addEventListener('click', () => {
        closeModalIS();
        showCreatorDetailIS(creatorId);
    });
}
document.querySelectorAll('.scouting-item-dashboard').forEach(item => {
    item.addEventListener('click', () => {
        const creatorId = item.getAttribute('data-creator-id');
        showCreatorDetailIS(creatorId);
    });
});
/**
 * Extract phone number from bio text
 */
function extractPhoneFromBio(bio) {
    if (!bio) return '';
    
    // Pola nomor Indonesia
    const patterns = [
        /(\+?62[-\s]?8[1-9][0-9]{1,3}[-\s]?[0-9]{3,4}[-\s]?[0-9]{3,4})/i,  // +62 812-3456-7890
        /(08[1-9][0-9]{1,3}[-\s]?[0-9]{3,4}[-\s]?[0-9]{3,4})/i,             // 0812-3456-7890
        /(08[1-9][0-9]{8,11})/i,                                              // 081234567890
        /(\+62[0-9]{9,13})/i,                                                 // +6281234567890
    ];
    
    for (const pattern of patterns) {
        const match = bio.match(pattern);
        if (match) {
            // Bersihkan nomor
            let phone = match[1].replace(/[-\s]/g, '');
            return phone;
        }
    }
    
    return '';
}
// ========== SHOW CREATOR PERFORMANCE DETAIL ==========
async function showCreatorPerformanceDetail(creatorOpenId) {
    if (!creatorOpenId) {
        showToastGlobal('Creator Open ID tidak tersedia', 'error');
        return;
    }
    
    const modalTitle = document.getElementById('modalTitleDashboard');
    const modalBody = document.getElementById('modalBodyDashboard');
    
    modalTitle.innerHTML = '<i class="fas fa-chart-line"></i> Loading Performance...';
    modalBody.innerHTML = `
        <div style="text-align:center; padding:40px;">
            <i class="fas fa-spinner fa-pulse fa-2x" style="color:#8b5cf6;"></i>
            <p style="margin-top:12px; color:#e2f0e8;">Mengambil data performa creator...</p>
        </div>
    `;
    openModalIS();
    
    try {
        const response = await fetch(baseUrlIS + 'is/get_creator_performance_detail', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: new URLSearchParams({ creator_open_id: creatorOpenId })
        });
        
        const result = await response.json();
        
        if (!result.success) {
            modalBody.innerHTML = `
                <div style="text-align:center; padding:40px; color:#ef4444;">
                    <i class="fas fa-exclamation-triangle" style="font-size:48px; margin-bottom:16px; display:block;"></i>
                    <p style="font-size:14px;">${result.message || 'Gagal mengambil data performa'}</p>
                    <button onclick="closeModalIS()" style="margin-top:16px; background:#1e293b; color:#e2f0e8; border:1px solid #2a3346; padding:8px 20px; border-radius:8px; cursor:pointer;">Tutup</button>
                </div>
            `;
            return;
        }
        
        const c = result.data;
        
        // Parse semua data dari API
        const nickname = c.nickname || c.username || 'Unknown';
        const username = c.username || '';
        const avatarUrl = c.avatar_url || '';
        const bio = c.bio || c.bio_description || '';
        const followerCount = c.follower_count || 0;
        const region = c.selection_region || '';
        
        //  AMBIL GMV DARI API (dalam USD) dan KONVERSI KE RUPIAH
        const gmvUsd = parseFloat(c.gmv || 0);
        const exchangeRate = 16000;
        const gmvIdr = Math.round(gmvUsd * exchangeRate);
        const gmvFormatted = gmvUsd > 0 ? 'Rp ' + formatNumber(gmvIdr) : 'Rp 0';
        const gmvUsdFormatted = gmvUsd > 0 ? '$ ' + gmvUsd.toFixed(2) : '$ 0';
        const gmvRange = c.gmv_range?.formatted_range || '';
        const unitsSold = c.units_sold || 0;
        
        //  DEFINE gmvValue untuk digunakan di select button
        const gmvValue = gmvUsd;  //  FIX: definisikan variabel
        
        // Content
        const liveCount = c.ec_live_count || 0;
        const videoCount = c.ec_video_count || 0;
        const avgLiveViews = c.avg_ec_live_view_count || 0;
        const avgVideoViews = c.avg_ec_video_play_count || 0;
        
        // Engagement
        const videoEngRate = parseFloat(c.ec_video_engagement_rate || 0) / 100;
        const liveEngRate = parseFloat(c.ec_live_engagement_rate || 0) / 100;
        const avgCommission = parseFloat(c.avg_commission_rate || 0) / 100;
        const postRate = c.post_rate || '0';
        const rating = c.rating || '0';
        const pps = c.pps || '0';
        
        // Live interaction
        const avgLiveLikes = c.avg_ec_live_like_count || 0;
        const avgLiveComments = c.avg_ec_live_comment_count || 0;
        const avgLiveShares = c.avg_ec_live_share_count || 0;
        
        // Promoted products
        const promotedProducts = c.promoted_product_num || 0;
        const brandCollab = c.brand_collaboration_count || 0;
        
        // Content distribution
        const contentDist = c.content_gmv_distribution || [];
        
        // Follower demographics
        const followerAge = c.follower_age || [];
        const followerGender = c.follower_gender || [];
        
        let contentIconsHtml = '';
        if (liveCount > 0) {
            contentIconsHtml += `<span style="display:inline-flex; align-items:center; gap:4px; background:rgba(139,92,246,0.15); padding:2px 8px; border-radius:20px; font-size:10px; color:#8b5cf6; margin-left:8px;">
                <i class="fas fa-play-circle"></i> LV
            </span>`;
        }
        if (videoCount > 0) {
            contentIconsHtml += `<span style="display:inline-flex; align-items:center; gap:4px; background:rgba(245,158,11,0.15); padding:2px 8px; border-radius:20px; font-size:10px; color:#f59e0b; margin-left:8px;">
                <i class="fas fa-video"></i> SV
            </span>`;
        }
        
        // RENDER MODAL
        modalTitle.innerHTML = `<i class="fas fa-chart-line"></i> Performance: @${escapeHtml(username)}`;
        
        let html = '';
        
        // HEADER
        html += `
        <div style="background:rgba(139,92,246,0.1); border-radius:14px; padding:14px; margin-bottom:16px; display:flex; gap:16px; align-items:center;">
            <div style="width:70px; height:70px; border-radius:50%; overflow:hidden; background:#1e293b; flex-shrink:0; display:flex; align-items:center; justify-content:center;">
                ${avatarUrl ? `<img src="${escapeHtml(avatarUrl)}" style="width:100%; height:100%; object-fit:cover;" onerror="this.style.display='none'; this.parentElement.innerHTML='<i class=\\'fas fa-user\\' style=\\'font-size:32px; color:#8b5cf6;\\'></i>'">` : '<i class="fas fa-user" style="font-size:32px; color:#8b5cf6;"></i>'}
            </div>
            <div>
                <div style="display:flex; align-items:center; flex-wrap:wrap; gap:4px;">
                    <div style="color:#e2f0e8; font-weight:600; font-size:16px;">${escapeHtml(nickname)}</div>
                    ${contentIconsHtml}
                </div>
                <div style="color:#8b5cf6; font-size:12px; margin-top:2px;">@${escapeHtml(username)}</div>
                <div style="color:#9aaebe; font-size:11px; margin-top:4px;">
                    ${escapeHtml(region || 'N/A')} | ${formatNumberShort(followerCount)} followers
                </div>
                ${bio ? `<div style="color:#9aaebe; font-size:10px; margin-top:4px; max-height:40px; overflow:hidden;">${escapeHtml(bio.substring(0, 150))}</div>` : ''}
            </div>
        </div>`;
        
        // GMV CARD
        html += `
        <div style="background:rgba(74,222,128,0.1); border-radius:14px; padding:14px; margin-bottom:12px; text-align:center;">
            <div style="color:#9aaebe; font-size:11px; margin-bottom:4px;">Est. GMV</div>
            <div style="color:#4ade80; font-size:28px; font-weight:700;">${gmvFormatted}</div>
            ${gmvRange ? `<div style="color:#9aaebe; font-size:10px; margin-top:4px;">Range: ${escapeHtml(gmvRange)}</div>` : ''}
        </div>`;
        
        // CONTENT & ENGAGEMENT
        html += `
        <div style="display:grid; grid-template-columns:1fr 1fr; gap:12px; margin-bottom:12px;">
            <div style="background:#0f1420; border-radius:14px; padding:14px;">
                <h4 style="color:#e2f0e8; margin:0 0 12px 0; font-size:14px;">Content</h4>
                <div style="display:grid; gap:8px;">
                    <div style="display:flex; justify-content:space-between;"><span style="color:#9aaebe; font-size:12px;">Items Sold</span><span style="color:#fbbf24; font-size:12px; font-weight:600;">${formatNumberShort(unitsSold)}</span></div>
                    <div style="display:flex; justify-content:space-between;"><span style="color:#9aaebe; font-size:12px;">Live Count</span><span style="color:#f59e0b; font-size:12px; font-weight:600;">${liveCount}</span></div>
                    <div style="display:flex; justify-content:space-between;"><span style="color:#9aaebe; font-size:12px;">Video Count</span><span style="color:#ef4444; font-size:12px; font-weight:600;">${videoCount}</span></div>
                    <div style="display:flex; justify-content:space-between;"><span style="color:#9aaebe; font-size:12px;">Avg Live Views</span><span style="color:#e2f0e8; font-size:12px;">${formatNumberShort(avgLiveViews)}</span></div>
                    <div style="display:flex; justify-content:space-between;"><span style="color:#9aaebe; font-size:12px;">Avg Video Views</span><span style="color:#e2f0e8; font-size:12px;">${formatNumberShort(avgVideoViews)}</span></div>
                    <div style="display:flex; justify-content:space-between;"><span style="color:#9aaebe; font-size:12px;">Products Promoted</span><span style="color:#e2f0e8; font-size:12px;">${promotedProducts}</span></div>
                </div>
            </div>
            
            <div style="background:#0f1420; border-radius:14px; padding:14px;">
                <h4 style="color:#e2f0e8; margin:0 0 12px 0; font-size:14px;">Engagement</h4>
                <div style="display:grid; gap:8px;">
                    <div style="display:flex; justify-content:space-between;"><span style="color:#9aaebe; font-size:12px;">Live Eng. Rate</span><span style="color:#4ade80; font-size:12px; font-weight:600;">${liveEngRate.toFixed(1)}%</span></div>
                    <div style="display:flex; justify-content:space-between;"><span style="color:#9aaebe; font-size:12px;">Video Eng. Rate</span><span style="color:#4ade80; font-size:12px; font-weight:600;">${videoEngRate.toFixed(1)}%</span></div>
                    <div style="display:flex; justify-content:space-between;"><span style="color:#9aaebe; font-size:12px;">Avg Commission</span><span style="color:#fbbf24; font-size:12px; font-weight:600;">${avgCommission.toFixed(1)}%</span></div>
                    <div style="display:flex; justify-content:space-between;"><span style="color:#9aaebe; font-size:12px;">Post Rate</span><span style="color:#e2f0e8; font-size:12px;">${postRate}%</span></div>
                    <div style="display:flex; justify-content:space-between;"><span style="color:#9aaebe; font-size:12px;">Rating / PPS</span><span style="color:#fbbf24; font-size:12px;">${rating} / ${pps}</span></div>
                </div>
            </div>
        </div>`;
        
        // LIVE INTERACTION
        if (avgLiveLikes > 0 || avgLiveComments > 0) {
            html += `
            <div style="background:#0f1420; border-radius:14px; padding:14px; margin-bottom:12px;">
                <h4 style="color:#e2f0e8; margin:0 0 12px 0; font-size:14px;">Live Interaction (Avg)</h4>
                <div style="display:grid; grid-template-columns:repeat(3,1fr); gap:10px; text-align:center;">
                    <div style="background:#1e293b; border-radius:10px; padding:10px;">
                        <div style="color:#ef4444; font-size:16px; font-weight:700;">${formatNumberShort(avgLiveLikes)}</div>
                        <div style="color:#9aaebe; font-size:10px;">Likes</div>
                    </div>
                    <div style="background:#1e293b; border-radius:10px; padding:10px;">
                        <div style="color:#4ade80; font-size:16px; font-weight:700;">${formatNumberShort(avgLiveComments)}</div>
                        <div style="color:#9aaebe; font-size:10px;">Comments</div>
                    </div>
                    <div style="background:#1e293b; border-radius:10px; padding:10px;">
                        <div style="color:#f59e0b; font-size:16px; font-weight:700;">${formatNumberShort(avgLiveShares)}</div>
                        <div style="color:#9aaebe; font-size:10px;">Shares</div>
                    </div>
                </div>
            </div>`;
        }
        
        // BRAND COLLABORATION
        html += `
        <div style="background:#0f1420; border-radius:14px; padding:14px; margin-bottom:12px;">
            <h4 style="color:#e2f0e8; margin:0 0 12px 0; font-size:14px;">Brand Collaboration</h4>
            <div style="display:flex; gap:20px; justify-content:center;">
                <div style="text-align:center;">
                    <div style="color:#8b5cf6; font-size:24px; font-weight:700;">${brandCollab}</div>
                    <div style="color:#9aaebe; font-size:10px;">Brands</div>
                </div>
                <div style="text-align:center;">
                    <div style="color:#4ade80; font-size:24px; font-weight:700;">${promotedProducts}</div>
                    <div style="color:#9aaebe; font-size:10px;">Products</div>
                </div>
                <div style="text-align:center;">
                    <div style="color:#fbbf24; font-size:24px; font-weight:700;">${formatNumberShort(unitsSold)}</div>
                    <div style="color:#9aaebe; font-size:10px;">Units Sold</div>
                </div>
            </div>
        </div>`;
        
        // GMV DISTRIBUTION
        if (contentDist.length > 0) {
            html += `
            <div style="background:#0f1420; border-radius:14px; padding:14px; margin-bottom:12px;">
                <h4 style="color:#e2f0e8; margin:0 0 8px 0; font-size:14px;">GMV Distribution</h4>
                <div style="display:flex; gap:8px; flex-wrap:wrap;">
                    ${contentDist.map(d => {
                        const pct = (parseFloat(d.value) * 100).toFixed(1);
                        const typeLabel = d.content_type === 'live_gmv' ? 'Live' : (d.content_type === 'video_gmv' ? 'Video' : 'Showcase');
                        const barColor = d.content_type === 'live_gmv' ? '#f59e0b' : (d.content_type === 'video_gmv' ? '#ef4444' : '#4ade80');
                        return `<div style="flex:1; min-width:100px; text-align:center;">
                            <div style="color:#9aaebe; font-size:10px;">${typeLabel}</div>
                            <div style="background:#1e293b; border-radius:6px; height:6px; margin:4px 0; overflow:hidden;">
                                <div style="background:${barColor}; height:100%; width:${pct}%;"></div>
                            </div>
                            <div style="color:#e2f0e8; font-size:12px; font-weight:600;">${pct}%</div>
                        </div>`;
                    }).join('')}
                </div>
            </div>`;
        }
        
        // FOLLOWER DEMOGRAPHICS
        if (followerAge.length > 0 || followerGender.length > 0) {
            html += `
            <div style="background:#0f1420; border-radius:14px; padding:14px; margin-bottom:12px;">
                <h4 style="color:#e2f0e8; margin:0 0 8px 0; font-size:14px;">Follower Demographics</h4>`;
            
            if (followerAge.length > 0) {
                html += `<div style="margin-bottom:8px;">
                    <span style="color:#9aaebe; font-size:11px;">Age: </span>
                    ${followerAge.map(a => `<span style="background:#1e293b; padding:2px 8px; border-radius:10px; font-size:10px; color:#e2f0e8;">${a.key}: ${(parseFloat(a.value)*100).toFixed(1)}%</span>`).join(' ')}
                </div>`;
            }
            
            if (followerGender.length > 0) {
                html += `<div>
                    <span style="color:#9aaebe; font-size:11px;">Gender: </span>
                    ${followerGender.map(g => `<span style="background:#1e293b; padding:2px 8px; border-radius:10px; font-size:10px; color:#e2f0e8;">${g.key}: ${(parseFloat(g.value)*100).toFixed(1)}%</span>`).join(' ')}
                </div>`;
            }
            
            html += `</div>`;
        }
        
        // BUTTONS
        html += `
        <div class="flex-buttons" style="margin-top:16px; gap:12px;">
            <button id="selectFromPerfBtn" style="background:#4ade80; color:#0a0e17; flex:1; padding:12px; border:none; border-radius:12px; cursor:pointer; font-weight:600; font-size:13px;">
                <i class="fas fa-plus"></i> Pilih Creator Ini
            </button>
            <button id="backToSearchBtn" style="background:#1e293b; color:#e2f0e8; flex:1; padding:12px; border:1px solid #2a3346; border-radius:12px; cursor:pointer; font-size:13px;">
                <i class="fas fa-arrow-left"></i> Kembali ke Pencarian
            </button>
        </div>`;
        
        modalBody.innerHTML = html;
        
        // EVENT: Pilih Creator
        const selectBtn = document.getElementById('selectFromPerfBtn');
        if (selectBtn) {
            selectBtn.addEventListener('click', () => {
                const extractedPhone = extractPhoneFromBio(bio);
                
                const creatorData = {
                    username: username,
                    nickname: nickname,
                    avatar_url: avatarUrl,
                    follower_count: followerCount,
                    gmv: gmvValue,  //  SEKARANG gmvValue SUDAH TERDEFINISI
                    gmv_formatted: gmvFormatted,
                    category: 'Lifestyle',
                    avg_video_views: avgVideoViews,
                    avg_live_uv: avgLiveViews,
                    creator_open_id: creatorOpenId,
                    phone: extractedPhone,
                    email: ''
                };
                
                closeModalIS();
                showAddCreatorFromSearchForm(creatorData);
            });
        }
        
        // BACK TO SEARCH
        const backBtn = document.getElementById('backToSearchBtn');
        if (backBtn) {
            backBtn.addEventListener('click', () => {
                closeModalIS();
                setTimeout(() => {
                    showSearchCreatorModal();
                    const searchInput = document.getElementById('searchCreatorKeyword');
                    if (searchInput && searchKeyword) {
                        searchInput.value = searchKeyword;
                    }
                    if (searchResults.length > 0) {
                        const container = document.getElementById('searchResultsContainer');
                        if (container) {
                            renderSearchResults(searchResults);
                        }
                    }
                }, 300);
            });
        }
        
    } catch (error) {
        console.error('Error in showCreatorPerformanceDetail:', error);
        modalBody.innerHTML = `
            <div style="text-align:center; padding:40px; color:#ef4444;">
                <i class="fas fa-exclamation-triangle" style="font-size:48px; margin-bottom:16px; display:block;"></i>
                <p style="font-size:14px;">Error: ${error.message}</p>
                <button onclick="closeModalIS()" style="margin-top:16px; background:#1e293b; color:#e2f0e8; border:1px solid #2a3346; padding:8px 20px; border-radius:8px; cursor:pointer;">Tutup</button>
            </div>
        `;
    }
}


function renderSearchResults(results) {
    const container = document.getElementById('searchResultsContainer');
    if (!container) return;
    
    container.innerHTML = '';
    
    results.forEach(creator => {
        const followerFormatted = formatNumberShort(creator.follower_count);
        const gmvUsd = parseFloat(creator.gmv || 0);
        const gmvIdr = Math.round(gmvUsd * 16000);
        const gmvFormatted = gmvUsd > 0 
            ? `Rp ${formatNumber(gmvIdr)}`
            : (creator.gmv_formatted || 'Rp 0');
        const avatarHtml = creator.avatar_url && creator.avatar_url !== ''
            ? `<img src="${escapeHtml(creator.avatar_url)}" style="width:100%; height:100%; object-fit:cover;" onerror="this.onerror=null; this.parentElement.innerHTML='<i class=\\'fab fa-tiktok\\' style=\\'font-size:28px; color:#4ade80;\\'></i>'">` 
            : '<i class="fab fa-tiktok" style="font-size:28px; color:#4ade80;"></i>';
        
        // Format tanggal (jika ada created_at dari database)
        const createdDate = creator.created_at ? new Date(creator.created_at).toLocaleDateString('id-ID') : '';
        const createdTime = creator.created_at ? new Date(creator.created_at).toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' }) : '';
        
        const cardHtml = `
            <div class="search-result-item" style="background:#0f1420; border-radius:12px; padding:12px; margin-bottom:10px; border:1px solid #2a3346; transition:all 0.2s; cursor:pointer;" 
                 data-creator='${JSON.stringify(creator).replace(/'/g, "&#39;")}'
                 onmouseover="this.style.borderColor='#4ade80'" 
                 onmouseout="this.style.borderColor='#2a3346'">
                <div style="display:flex; gap:12px;">
                    <div style="width:60px; height:60px; border-radius:50%; overflow:hidden; background:#1e293b; flex-shrink:0; display:flex; align-items:center; justify-content:center;">
                        ${avatarHtml}
                    </div>
                    <div style="flex:1;">
                        <div style="display:flex; justify-content:space-between;">
                            <div>
                                <strong>${escapeHtml(creator.nickname || creator.username)}</strong>
                                <div style="color:#9aaebe; font-size:11px;">@${escapeHtml(creator.username)}</div>
                            </div>
                            <div style="text-align:right;">
                                <div style="color:#fbbf24;">${gmvFormatted}</div>
                                <div style="font-size:10px;">GMV 28 hari</div>
                            </div>
                        </div>
                        <div style="display:flex; gap:16px; margin-top:8px; flex-wrap:wrap;">
                            <span><i class="fas fa-users"></i> ${followerFormatted}</span>
                            <span>${escapeHtml(creator.category || 'Lifestyle')}</span>
                            ${createdDate ? `<span style="color:#4ade80; font-size:10px;"><i class="fas fa-calendar-alt"></i> Input: ${createdDate} ${createdTime}</span>` : ''}
                        </div>
                    </div>
                    <div style="display:flex; flex-direction:column; gap:6px;">
                        <button class="select-creator-btn" style="background:#4ade80; color:#0a0e17; border:none; padding:6px 16px; border-radius:20px; cursor:pointer; font-size:11px;">
                            <i class="fas fa-plus"></i> Pilih
                        </button>
                        <button class="detail-creator-btn" data-creator-open-id="${escapeHtml(creator.creator_open_id || '')}" 
                                style="background:#1e293b; color:#8b5cf6; border:1px solid #8b5cf6; padding:6px 16px; border-radius:20px; cursor:pointer; font-size:11px;">
                            <i class="fas fa-info-circle"></i> Detail
                        </button>
                    </div>
                </div>
            </div>
        `;
        container.innerHTML += cardHtml;
    });
    
    // Re-attach event listeners
    document.querySelectorAll('.select-creator-btn').forEach(btn => {
        const newBtn = btn.cloneNode(true);
        btn.parentNode.replaceChild(newBtn, btn);
        newBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            const parent = newBtn.closest('.search-result-item');
            const creatorData = JSON.parse(parent.getAttribute('data-creator'));
            showAddCreatorFromSearchForm(creatorData);
        });
    });
    
    document.querySelectorAll('.detail-creator-btn').forEach(btn => {
        const newBtn = btn.cloneNode(true);
        btn.parentNode.replaceChild(newBtn, btn);
        newBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            const creatorOpenId = newBtn.getAttribute('data-creator-open-id');
            if (creatorOpenId) showCreatorPerformanceDetail(creatorOpenId);
        });
    });
}
// ========== TASK 2: LINK SWAPPING ==========
let selectedProductsIS = [];
let currentCreatorId = null;
let currentCreatorName = null;
let currentCreatorCategory = null;
let currentCreatorPhone = null;
let currentCampaignId = null;

// ========== TASK 2: LINK SWAPPING (REWRITE) ==========
async function loadTask2CreatorsIS() {
    console.log('�9�4 Loading Task 2: LINK SWAPPING...');
    
    const container = document.getElementById('linkSwappingContainerDashboard');
    const countSpan = document.getElementById('linkCountDashboard');
    
    if (!container) {
        console.error('Container linkSwappingContainerDashboard not found');
        return;
    }
    
    try {
        // �9�7 AMBIL CREATOR DENGAN STATUS LINK_SWAPPING
        const response = await fetch(baseUrlIS + 'is/get_creators_by_status', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: new URLSearchParams({ status: 'LINK_SWAPPING' })
        });
        
        const result = await response.json();
        console.log('Task 2 result:', result);
        
        if (result.success && result.data && result.data.length > 0) {
            // �9�7 Filter: hanya yang belum auto_activated
            const filtered = result.data.filter(c => !c.auto_activated_at);
            
            if (countSpan) countSpan.innerText = filtered.length;
            
            if (filtered.length === 0) {
                container.innerHTML = `
                    <div class="stage-item-dashboard">
                        <strong><i class="fas fa-info-circle"></i> Belum ada creator siap assign link</strong>
                        <div class="item-details-dashboard">Creator akan muncul setelah di-approve di Task 1</div>
                    </div>
                `;
                return;
            }
            
            let html = '';
            filtered.forEach(creator => {
                const phoneDisplay = creator.phone 
                    ? `<span style="color:#4ade80;"><i class="fab fa-whatsapp"></i> ${creator.phone}</span>` 
                    : '<span style="color:#ef4444;"><i class="fab fa-whatsapp"></i> No WA</span>';
                
                const isName = creator.is_full_name || creator.is_username || '-';
                const isDisplay = isName !== '-' ? `<span style="color:#8b5cf6; font-size:9px;"><i class="fas fa-user-tie"></i> ${escapeHtml(isName)}</span>` : '';
                
                html += `
                <div class="stage-item-dashboard link-item-dashboard" 
                     data-creator-id="${creator.id}" 
                     data-creator-name="${escapeHtml(creator.username)}"
                     data-creator-phone="${escapeHtml(creator.phone || '')}"
                     data-creator-category="${escapeHtml(creator.category || '')}"
                     style="cursor:pointer;">
                    <div style="display:flex; justify-content:space-between; align-items:center;">
                        <strong><i class="fab fa-tiktok"></i> ${escapeHtml(creator.username)}</strong>
                        <div style="display:flex; gap:6px; align-items:center;">
                            ${isDisplay}
                            ${!creator.phone ? `
                            <button class="update-phone-quick-btn" data-creator-id="${creator.id}" 
                                style="background:#fbbf24; color:#0a0e17; border:none; padding:2px 8px; border-radius:10px; cursor:pointer; font-size:9px;">
                                <i class="fas fa-edit"></i> WA
                            </button>` : ''}
                            <span class="badge-dashboard badge-approved" style="background:rgba(139,92,246,0.15); color:#8b5cf6;">
                                <i class="fas fa-link"></i> LINK_SWAPPING
                            </span>
                        </div>
                    </div>
                    <div class="item-details-dashboard">
                        ${phoneDisplay}
                        <span><i class="fas fa-tag"></i> ${escapeHtml(creator.category || '-')}</span>
                    </div>
                    <div class="item-details-dashboard">
                        <i class="fas fa-link"></i> Siap diberikan link afiliasi
                        <span style="font-size:9px; color:#9aaebe; margin-left:8px;"> Click untuk assign</span>
                    </div>
                </div>`;
            });
            
            container.innerHTML = html;
            
            // �9�7 EVENT: Update WA
            document.querySelectorAll('.update-phone-quick-btn').forEach(btn => {
                btn.addEventListener('click', (e) => {
                    e.stopPropagation();
                    const cid = btn.getAttribute('data-creator-id');
                    const cname = btn.closest('.link-item-dashboard')?.getAttribute('data-creator-name');
                    showQuickEditPhoneModal(cid, cname, '');
                });
            });
            
            // �9�7 EVENT: Buka Assign Link
            document.querySelectorAll('.link-item-dashboard').forEach(item => {
                const newItem = item.cloneNode(true);
                item.parentNode.replaceChild(newItem, item);
                
                newItem.addEventListener('click', function(e) {
                    if (e.target.closest('.update-phone-quick-btn')) return;
                    
                    const creatorId = this.getAttribute('data-creator-id');
                    const creatorName = this.getAttribute('data-creator-name');
                    const creatorPhone = this.getAttribute('data-creator-phone') || '';
                    
                    console.log('�9�7�1�5 Task 2 clicked:', { creatorId, creatorName, creatorPhone });
                    
                    if (!creatorPhone || creatorPhone === '') {
                        showToastGlobal(`Creator @${creatorName} belum memiliki nomor WhatsApp!`, 'error');
                        return;
                    }
                    
                    // �9�7 PANGGIL openAssignLinkModal
                    openAssignLinkModal(creatorId, creatorName);
                });
            });
            
        } else {
            if (countSpan) countSpan.innerText = '0';
            container.innerHTML = `
                <div class="stage-item-dashboard">
                    <strong><i class="fas fa-info-circle"></i> Belum ada creator siap assign link</strong>
                    <div class="item-details-dashboard">Creator akan muncul setelah di-approve di Task 1</div>
                </div>
            `;
        }
        
    } catch (error) {
        console.error('Error loadTask2CreatorsIS:', error);
        container.innerHTML = `
            <div class="stage-item-dashboard" style="color:#ef4444;">
                <strong><i class="fas fa-exclamation-triangle"></i> Error loading data: ${error.message}</strong>
            </div>
        `;
    }
}




// ========== MODAL ASSIGN LINK ==========
async function showLinkAssignmentModal(creatorId, creatorName, creatorCategory, creatorPhone) {
    selectedProductsIS = [];
    currentCreatorId = creatorId;
    currentCreatorName = creatorName;
    currentCreatorCategory = creatorCategory;
    currentCreatorPhone = creatorPhone;
    currentCampaignId = null;
    
    document.getElementById('modalTitleDashboard').innerHTML = `<i class="fas fa-link"></i> Assign Link - @${escapeHtml(creatorName)}`;
    document.getElementById('modalBodyDashboard').innerHTML = `
        <div style="background:rgba(74,222,128,0.1); border-radius:14px; padding:12px; margin-bottom:16px;">
            <div style="display:grid; grid-template-columns:1fr 1fr; gap:8px;">
                <div>
                    <span style="color:#9aaebe; font-size:10px;">Creator</span><br>
                    <span style="color:#e2f0e8; font-size:13px; font-weight:600;">@${escapeHtml(creatorName)}</span>
                </div>
                <div>
                    <span style="color:#9aaebe; font-size:10px;">Kategori</span><br>
                    <span style="color:#e2f0e8; font-size:13px;">${escapeHtml(creatorCategory || 'Semua')}</span>
                </div>
                <div>
                    <span style="color:#9aaebe; font-size:10px;"><i class="fab fa-whatsapp"></i> WA</span><br>
                    <span style="color:#4ade80; font-size:13px;">${escapeHtml(creatorPhone)}</span>
                    <button id="editPhoneInModal" style="background:transparent; border:none; color:#fbbf24; cursor:pointer; font-size:9px; margin-left:4px;">
                        <i class="fas fa-edit"></i>
                    </button>
                </div>
                <div>
                    <span style="color:#9aaebe; font-size:10px;">Handler</span><br>
                    <span style="color:#8b5cf6; font-size:13px; font-weight:500;">
                        <i class="fas fa-user"></i> <?= $this->session->userdata('full_name') ?? 'IS User' ?>
                    </span>
                </div>
            </div>
        </div>
        
        <!-- STEP 1: Pilih Campaign -->
        <div id="step1Container">
            <label style="color:#e2f0e8; font-weight:500;"><i class="fas fa-bullhorn"></i> Pilih Campaign</label>
            <select id="campaignSelectIS" style="width:100%; padding:10px; background:#0f1420; border:1px solid #2a3346; border-radius:12px; color:#e2f0e8; margin-bottom:12px;">
                <option value="">-- Pilih Campaign --</option>
                <?php foreach ($campaigns as $camp): ?>
                <option value="<?= $camp->campaign_id ?>"><?= htmlspecialchars($camp->campaign_name) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        
        <!-- STEP 2: Pilih Produk -->
        <div id="step2Container" style="display:none;">
            <label style="color:#e2f0e8; font-weight:500;"><i class="fas fa-search"></i> Cari Produk</label>
            <input type="text" id="productSearchInput" placeholder="Ketik nama produk..." 
                style="width:100%; padding:10px; background:#0f1420; border:1px solid #2a3346; border-radius:12px; color:#e2f0e8; margin-bottom:12px;">
            
            <div id="campaignProductsList" style="max-height:300px; overflow-y:auto; background:#0f1420; border-radius:12px; padding:8px;">
                <div style="text-align:center; padding:20px; color:#9aaebe;">Pilih campaign terlebih dahulu</div>
            </div>
        </div>
        
        <!-- STEP 3: Review & Kirim -->
        <div id="step3Container" style="display:none; margin-top:12px;">
            <div style="background:#0f1420; border-radius:12px; padding:12px; margin-bottom:12px;">
                <div style="display:flex; justify-content:space-between; margin-bottom:8px;">
                    <span style="color:#9aaebe; font-size:11px;">Produk Dipilih</span>
                    <span id="selectedCount" style="color:#4ade80; font-size:11px; font-weight:600;">0</span>
                </div>
                <div id="selectedProductsPreview" style="max-height:150px; overflow-y:auto;"></div>
            </div>
            
            <!-- Tampilkan link yang akan diambil dari database -->
            <div id="linksPreviewContainer" style="background:rgba(74,222,128,0.1); border-radius:12px; padding:10px; margin-bottom:12px; display:none;">
                <p style="color:#4ade80; font-size:11px; margin-bottom:8px;">
                    <i class="fas fa-database"></i> Link dari Database (BD Affiliate Links):
                </p>
                <div id="linksPreviewList" style="max-height:200px; overflow-y:auto;"></div>
            </div>
            
            <div style="background:rgba(74,222,128,0.1); border-radius:12px; padding:10px; margin-bottom:12px;">
                <p style="color:#4ade80; font-size:11px;">
                    <i class="fas fa-info-circle"></i> Link akan dikirim via WhatsApp ke: <b>${creatorPhone}</b>
                </p>
                <p style="color:#9aaebe; font-size:10px;">
                    <i class="fas fa-user"></i> Handler: <b><?= $this->session->userdata('full_name') ?? 'IS User' ?></b>
                </p>
            </div>
            
            <button id="confirmAndSendBtn" style="width:100%; background:#25D366; color:white; border:none; padding:12px; border-radius:12px; cursor:pointer; font-weight:600; font-size:13px;">
                <i class="fab fa-whatsapp"></i> Konfirmasi & Kirim WA
            </button>
        </div>
        
        <div class="flex-buttons" style="margin-top:12px;">
            <button id="cancelLinkBtn" style="background:#1e293b; flex:1;">Batal</button>
        </div>
    `;
    openModalIS();
    
    // STEP 1  STEP 2
    document.getElementById('campaignSelectIS').addEventListener('change', async (e) => {
        currentCampaignId = e.target.value;
        if (!currentCampaignId) {
            document.getElementById('step2Container').style.display = 'none';
            document.getElementById('step3Container').style.display = 'none';
            return;
        }
        document.getElementById('step2Container').style.display = 'block';
        document.getElementById('step3Container').style.display = 'none';
        selectedProductsIS = [];
        await loadProductsForLink(currentCampaignId, currentCreatorCategory);
    });
    
    // Search produk
    document.getElementById('productSearchInput').addEventListener('keyup', (e) => {
        const search = e.target.value.toLowerCase();
        document.querySelectorAll('#campaignProductsList .product-item-card').forEach(item => {
            const name = item.getAttribute('data-product-name')?.toLowerCase() || '';
            item.style.display = name.includes(search) ? '' : 'none';
        });
    });
    
    // Edit phone
    document.getElementById('editPhoneInModal')?.addEventListener('click', () => {
        showQuickEditPhoneModal(creatorId, creatorName, creatorPhone);
    });
    
    // CONFIRM & SEND
    document.getElementById('confirmAndSendBtn')?.addEventListener('click', async () => {
        if (selectedProductsIS.length === 0) {
            showToastGlobal('Pilih minimal 1 produk', 'error');
            return;
        }
        
        const btn = document.getElementById('confirmAndSendBtn');
        btn.disabled = true;
        btn.innerHTML = '<i class="fas fa-spinner fa-pulse"></i> Mengirim...';
        
        // Simpan link
        const saveRes = await fetch(baseUrlIS + 'is/send_affiliate_links_bulk', {
            method: 'POST',
            body: new URLSearchParams({
                creator_id: creatorId,
                campaign_id: currentCampaignId,
                products: JSON.stringify(selectedProductsIS)
            })
        });
        const saveData = await saveRes.json();
        
        // Kirim WhatsApp
        if (saveData.success && saveData.generated.length > 0 && currentCreatorPhone) {
            const campaignName = document.getElementById('campaignSelectIS')?.selectedOptions[0]?.text || 'Campaign';
            let message = `Halo @${currentCreatorName}! \n\n`;
            message += `Link afiliasi untuk campaign *${campaignName}*:\n\n`;
            
            saveData.generated.forEach((p, i) => {
                message += `${i+1}. *${p.product_name}*\n`;
                message += `   Komisi: ${p.commission_rate}%\n`;
                message += `   Link: ${p.link}\n\n`;
            });
            
            message += `\n Selamat berpromosi! \n\n`;
            message += `Dikirim oleh: ${saveData.generated[0]?.created_by || 'Toopai Team'}`;
            
            let phone = currentCreatorPhone.replace(/[^0-9+]/g, '');
            if (phone.startsWith('0')) phone = '62' + phone.substring(1);
            else if (phone.startsWith('+')) phone = phone.substring(1);
            
            window.open(`https://wa.me/${phone}?text=${encodeURIComponent(message)}`, '_blank');
        }
        
        let statusMsg = saveData.message || 'Link berhasil dikirim!';
        if (saveData.failed && saveData.failed.length > 0) {
            statusMsg += `  Link untuk: ${saveData.failed.join(', ')} belum tersedia.`;
        }
        showToastGlobal(statusMsg, saveData.failed.length > 0 ? 'warning' : 'success');
        setTimeout(() => { closeModalIS(); location.reload(); }, 2000);
    });
    
    document.getElementById('cancelLinkBtn').addEventListener('click', closeModalIS);
}


// ========== LOAD PRODUCTS FOR LINK ==========
async function loadProductsForLink(campaignId, creatorCategory) {
    const container = document.getElementById('campaignProductsList');
    if (!container) return;
    
    container.innerHTML = '<div style="text-align:center; padding:20px;"><i class="fas fa-spinner fa-pulse"></i> Loading products...</div>';
    
    try {
        //  AMBIL DARI DATABASE: bd_affiliate_links + affiliate_products
        const response = await fetch(baseUrlIS + 'is/get_available_products_for_link', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: new URLSearchParams({ 
                campaign_id: campaignId,
                creator_category: creatorCategory || ''
            })
        });
        const data = await response.json();
        
        console.log('Products from DB:', data);
        
        if (data.success && data.products && data.products.length > 0) {
            let html = '';
            
            for (const product of data.products) {
                const hasLink = true; // Karena dari bd_affiliate_links pasti ada link
                const bdLink = product.affiliate_link || '';
                const bdCommission = product.commission_rate || (product.open_commission_rate ? product.open_commission_rate + 1 : 10);
                const isSelected = selectedProductsIS.some(p => p.product_id === product.product_id);
                const productImage = product.image_url || '';
                const hasImage = productImage && productImage !== '';
                
                html += `
                <div class="product-item-card" data-product-id="${product.product_id}" 
                     data-product-name="${escapeHtml(product.product_name || '')}"
                     style="display:flex; justify-content:space-between; align-items:center; padding:10px; border-bottom:1px solid #2a3346; background:${isSelected ? '#0a2e1a' : '#0f1420'}; border-radius:8px; margin-bottom:6px;">
                    <div style="display:flex; gap:10px; flex:1;">
                        <div style="width:50px; height:50px; background:#1e293b; border-radius:8px; display:flex; align-items:center; justify-content:center; overflow:hidden; flex-shrink:0;">
                            ${hasImage ? `<img src="${escapeHtml(productImage)}" style="width:100%; height:100%; object-fit:cover;" onerror="this.src=''; this.onerror=null; this.parentElement.innerHTML='<i class=\\'fas fa-box\\' style=\\'color:#4ade80;\\'></i>'">` : '<i class="fas fa-box" style="color:#4ade80;"></i>'}
                        </div>
                        <div style="flex:1;">
                            <div style="color:#e2f0e8; font-size:12px;">${escapeHtml((product.product_name || '').substring(0, 60))}</div>
                            <div style="display:flex; gap:8px; margin-top:4px; flex-wrap:wrap;">
                                <span style="color:#4ade80; font-size:10px;">Rp ${formatNumber(product.price)}</span>
                                <span style="color:#fbbf24; font-size:10px;">Komisi: ${bdCommission}%</span>
                                <span style="color:#4ade80; font-size:10px;"><i class="fas fa-check-circle"></i> Link tersedia</span>
                            </div>
                            ${product.shop_name ? `<div style="color:#9aaebe; font-size:9px; margin-top:2px;"><i class="fas fa-store"></i> ${escapeHtml(product.shop_name)}</div>` : ''}
                            <div style="color:#8b5cf6; font-size:9px; margin-top:2px; word-break:break-all;"><i class="fas fa-link"></i> ${escapeHtml(bdLink.substring(0, 50))}...</div>
                        </div>
                    </div>
                    <div>
                        <button class="copy-link-quick-btn" data-link="${escapeHtml(bdLink)}" 
                                style="background:#1e293b; color:#4ade80; border:1px solid #4ade80; padding:4px 10px; border-radius:20px; cursor:pointer; font-size:10px; margin-right:6px;">
                            <i class="fas fa-copy"></i> Copy
                        </button>
                        <button class="toggle-product-btn" data-product='${JSON.stringify({
                            product_id: product.product_id,
                            product_name: product.product_name,
                            commission_rate: bdCommission,
                            affiliate_link: bdLink,
                            has_link: true
                        })}'
                        style="background:${isSelected ? '#ef4444' : '#4ade80'}; color:white; border:none; padding:6px 12px; border-radius:20px; cursor:pointer; font-size:10px;">
                            ${isSelected ? 'Hapus' : '+ Pilih'}
                        </button>
                    </div>
                </div>`;
            }
            
            container.innerHTML = html || '<div style="text-align:center; padding:20px; color:#9aaebe;">Tidak ada produk yang tersedia untuk campaign ini (link dari BD belum ada)</div>';
            
            // Toggle product
            document.querySelectorAll('.toggle-product-btn').forEach(btn => {
                btn.addEventListener('click', () => {
                    const productData = JSON.parse(btn.getAttribute('data-product'));
                    if (!productData.has_link) {
                        showToastGlobal(`Link untuk "${productData.product_name}" belum tersedia.`, 'warning');
                        return;
                    }
                    
                    const idx = selectedProductsIS.findIndex(p => p.product_id === productData.product_id);
                    
                    if (idx !== -1) {
                        selectedProductsIS.splice(idx, 1);
                    } else {
                        selectedProductsIS.push({
                            product_id: productData.product_id,
                            product_name: productData.product_name,
                            commission_rate: productData.commission_rate,
                            affiliate_link: productData.affiliate_link
                        });
                    }
                    updateSelectedPreview();
                    loadProductsForLink(campaignId, creatorCategory);
                });
            });
            
            // Copy link button
            document.querySelectorAll('.copy-link-quick-btn').forEach(btn => {
                btn.addEventListener('click', (e) => {
                    e.stopPropagation();
                    const link = btn.getAttribute('data-link');
                    navigator.clipboard.writeText(link);
                    showToastGlobal('Link copied!', 'success');
                });
            });
        } else {
            container.innerHTML = `
                <div style="text-align:center; padding:40px; color:#ef4444;">
                    <i class="fas fa-exclamation-triangle" style="font-size:32px; margin-bottom:12px; display:block;"></i>
                    <p>${data.message || 'Tidak ada produk yang tersedia untuk campaign ini'}</p>
                    <p style="font-size:10px; color:#9aaebe; margin-top:8px;">Pastikan BD/BA sudah generate link afiliasi untuk campaign ini</p>
                </div>
            `;
        }
    } catch (error) {
        console.error('Error:', error);
        container.innerHTML = '<div style="text-align:center; padding:20px; color:#ef4444;">Error loading products</div>';
    }
}

function updateSelectedPreview() {
    const countSpan = document.getElementById('selectedCount');
    const preview = document.getElementById('selectedProductsPreview');
    const step3 = document.getElementById('step3Container');
    const linksPreviewContainer = document.getElementById('linksPreviewContainer');
    const linksPreviewList = document.getElementById('linksPreviewList');
    
    if (countSpan) countSpan.innerText = selectedProductsIS.length;
    if (step3) step3.style.display = selectedProductsIS.length > 0 ? 'block' : 'none';
    
    // Preview produk yang dipilih
    if (preview) {
        preview.innerHTML = selectedProductsIS.map((p, i) => `
            <div style="display:flex; justify-content:space-between; align-items:center; padding:6px 0; border-bottom:1px solid #2a3346; font-size:10px;">
                <span style="color:#e2f0e8;">${i+1}. ${escapeHtml(p.product_name || '').substring(0, 40)}</span>
                <div>
                    <span style="color:#fbbf24;">${p.commission_rate}%</span>
                    <button class="copy-single-link-btn" data-link="${escapeHtml(p.affiliate_link)}" data-product="${escapeHtml(p.product_name)}"
                            style="background:#1e293b; color:#4ade80; border:1px solid #4ade80; padding:2px 8px; border-radius:12px; cursor:pointer; font-size:9px; margin-left:8px;">
                        <i class="fas fa-copy"></i> Copy Link
                    </button>
                </div>
            </div>
        `).join('');
        
        // Event copy single link
        document.querySelectorAll('.copy-single-link-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                e.stopPropagation();
                const link = btn.getAttribute('data-link');
                const product = btn.getAttribute('data-product');
                navigator.clipboard.writeText(link);
                showToastGlobal(`Link untuk "${product}" dicopy!`, 'success');
            });
        });
    }
    
    // Tampilkan semua link yang akan dikirim
    if (linksPreviewList && selectedProductsIS.length > 0) {
        linksPreviewContainer.style.display = 'block';
        linksPreviewList.innerHTML = selectedProductsIS.map((p, i) => `
            <div style="display:flex; justify-content:space-between; align-items:center; padding:6px; border-bottom:1px solid #2a3346;">
                <div style="flex:1;">
                    <span style="color:#e2f0e8; font-size:11px;">${i+1}. ${escapeHtml(p.product_name)}</span>
                    <div style="color:#9aaebe; font-size:9px; word-break:break-all;">${escapeHtml(p.affiliate_link)}</div>
                </div>
                <button class="copy-link-preview-btn" data-link="${escapeHtml(p.affiliate_link)}" 
                        style="background:#1e293b; color:#4ade80; border:1px solid #4ade80; padding:4px 10px; border-radius:20px; cursor:pointer; font-size:9px; margin-left:8px;">
                    <i class="fas fa-copy"></i> Copy
                </button>
            </div>
        `).join('');
        
        document.querySelectorAll('.copy-link-preview-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                e.stopPropagation();
                const link = btn.getAttribute('data-link');
                navigator.clipboard.writeText(link);
                showToastGlobal('Link dicopy!', 'success');
            });
        });
    } else if (linksPreviewContainer) {
        linksPreviewContainer.style.display = 'none';
    }
}

async function showCampaignSelectionModalIS(creatorId, creatorName, creatorCategory, creatorPhone) {
    currentCreatorId = creatorId;
    currentCreatorName = creatorName;
    currentCreatorCategory = creatorCategory;
    currentCreatorPhone = creatorPhone;
    selectedProductsIS = [];
    
    document.getElementById('modalTitleDashboard').innerHTML = `<i class="fas fa-bullhorn"></i> Assign Campaign - ${creatorName}`;
    document.getElementById('modalBodyDashboard').innerHTML = `
        <div style="background:rgba(74,222,128,0.1); border-radius:14px; padding:12px; margin-bottom:16px;">
            <p style="color:#4ade80;"><i class="fas fa-info-circle"></i> Kategori Creator: ${creatorCategory || 'Semua'}</p>
            <p style="color:#4ade80;"><i class="fab fa-whatsapp"></i> WhatsApp: ${creatorPhone}</p>
            <p style="color:#9aaebe; font-size:11px;">Pilih campaign, pilih produk, atur komisi, lalu generate link</p>
        </div>
        
        <div id="step1Container">
            <label>Pilih Campaign</label>
            <select id="campaignSelectIS" style="width:100%; padding:10px; background:#0f1420; border:1px solid #2a3346; border-radius:12px; color:#e2f0e8;">
                <option value="">-- Pilih Campaign --</option>
                <?php foreach ($campaigns as $camp): ?>
                <option value="<?= $camp->campaign_id ?>"><?= htmlspecialchars($camp->campaign_name) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        
        <div id="step2Container" style="display:none; margin-top:16px;">
            <label><i class="fas fa-box"></i> Pilih Produk</label>
            <div id="campaignProductsList" style="max-height:300px; overflow-y:auto; background:#0f1420; border-radius:12px; padding:8px;">
                <div class="loading">Pilih campaign terlebih dahulu...</div>
            </div>
        </div>
        
        <div id="step3Container" style="display:none; margin-top:16px;">
            <label><i class="fas fa-sliders-h"></i> Atur Komisi & Generate Link</label>
            <div id="selectedProductsWithCommission" style="background:#0f1420; border-radius:12px; padding:8px; max-height:350px; overflow-y:auto;"></div>
        </div>
        
        <div id="step4Container" style="display:none; margin-top:16px;">
            <div style="background:rgba(74,222,128,0.1); border-radius:12px; padding:12px; margin-bottom:12px;">
                <p style="color:#4ade80; font-size:12px;"><i class="fas fa-check-circle"></i> 
                    <span id="generatedCount">0</span> dari <span id="totalProductsCount">0</span> link telah digenerate
                </p>
                <p style="color:#25D366; font-size:11px; margin-top:8px;">
                    <i class="fab fa-whatsapp"></i> Akan dikirim ke: ${creatorPhone}
                </p>
            </div>
            <div class="flex-buttons">
                <button id="saveAndSendWABtn" style="background:#25D366; color:white;"><i class="fab fa-whatsapp"></i> Save & Kirim WA</button>
                <button id="backToEditBtn" style="background:#1e293b;">Kembali Edit</button>
            </div>
        </div>
        
        <div class="flex-buttons" style="margin-top:16px;">
            <button id="cancelStepBtnIS" style="background:#1e293b;">Batal</button>
        </div>
    `;
    openModalIS();
    
    const campaignSelect = document.getElementById('campaignSelectIS');
    const step2Container = document.getElementById('step2Container');
    const step3Container = document.getElementById('step3Container');
    const step4Container = document.getElementById('step4Container');
    
    campaignSelect.addEventListener('change', async () => {
        currentCampaignId = campaignSelect.value;
        if (!currentCampaignId) {
            step2Container.style.display = 'none';
            step3Container.style.display = 'none';
            step4Container.style.display = 'none';
            return;
        }
        
        step2Container.style.display = 'block';
        step3Container.style.display = 'none';
        step4Container.style.display = 'none';
        selectedProductsIS = [];
        
        await loadAvailableProducts(currentCampaignId, currentCreatorCategory);
    });
    
    document.getElementById('backToEditBtn')?.addEventListener('click', () => {
        step3Container.style.display = 'block';
        step4Container.style.display = 'none';
    });
    
    document.getElementById('saveAndSendWABtn')?.addEventListener('click', async () => {
        const notGenerated = selectedProductsIS.filter(p => p.status !== 'generated');
        if (notGenerated.length > 0) {
            showToastGlobal(`Generate link terlebih dahulu untuk: ${notGenerated.map(p => p.product_name).join(', ')}`, 'error');
            return;
        }
        
        let phone = currentCreatorPhone || '';
        if (!phone || phone === '') {
            showToastGlobal('Creator tidak memiliki nomor WhatsApp!', 'error');
            return;
        }
        
        const saveBtn = document.getElementById('saveAndSendWABtn');
        saveBtn.disabled = true;
        saveBtn.innerHTML = '<i class="fas fa-spinner fa-pulse"></i> Menyimpan & Mengirim WA...';
        
        await fetch(baseUrlIS + 'is/update_creator_status', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: new URLSearchParams({ creator_id: currentCreatorId, status: 'LINK_SENT' })
        });
        
        const campaignName = campaignSelect.options[campaignSelect.selectedIndex]?.text || 'Campaign';
        
        let message = `Halo @${currentCreatorName}! \n\n`;
        message += `Terima kasih telah bergabung dengan Toopai. Berikut adalah link afiliasi untuk campaign yang sudah kita sepakati:\n\n`;
        message += ` *Campaign:* ${campaignName}\n\n`;
        message += `*Link Afiliasi:*\n`;
        
        selectedProductsIS.forEach((product, idx) => {
            message += `${idx + 1}. *${product.product_name}* (Komisi: ${product.custom_commission}%)\n`;
            message += `   ${product.generated_link}\n\n`;
        });
        
        message += `\n8 *Tips Sukses:*\n`;
        message += `Promosikan produk dengan konten yang menarik\n`;
        message += `Gunakan hashtag yang relevan\n`;
        message += `Pantau performa link di dashboard Anda\n\n`;
        message += `Semangat berpromosi! \n\nBest regards,\nToopai Team `;
        
        phone = phone.replace(/[^0-9+]/g, '');
        if (phone.startsWith('0')) phone = '62' + phone.substring(1);
        else if (phone.startsWith('+')) phone = phone.substring(1);
        
        const whatsappUrl = `https://wa.me/${phone}?text=${encodeURIComponent(message)}`;
        window.open(whatsappUrl, '_blank');
        
        showToastGlobal('Link berhasil disimpan! WhatsApp akan terbuka.', 'success');
        
        saveBtn.disabled = false;
        saveBtn.innerHTML = '<i class="fab fa-whatsapp"></i> Save & Kirim WA';
        
        setTimeout(() => {
            closeModalIS();
            location.reload();
        }, 3000);
    });
    
    document.getElementById('cancelStepBtnIS').addEventListener('click', closeModalIS);
}

async function loadAvailableProducts(campaignId, creatorCategory) {
    const container = document.getElementById('campaignProductsList');
    if (!container) return;
    
    container.innerHTML = '<div class="loading"><i class="fas fa-spinner fa-pulse"></i> Loading products...</div>';
    
    try {
        const response = await fetch(baseUrlIS + 'is/get_campaign_products', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: new URLSearchParams({ 
                campaign_id: campaignId,
                creator_category: creatorCategory || ''
            })
        });
        const data = await response.json();
        
        console.log('API Response:', data);
        
        if (data.success && data.products && data.products.length > 0) {
            let html = '';
            data.products.forEach(product => {
                const isSelected = selectedProductsIS.some(p => p.product_id === product.product_id);
                const recommendedCommission = (product.commission_rate / 100) + 2;
                const productImage = product.image_url || '';
                const hasImage = productImage && productImage !== '';
                
                html += `
                    <div class="product-item-dashboard" data-product-id="${product.product_id}" style="display:flex; justify-content:space-between; align-items:center; padding:12px; border-bottom:1px solid #2a3346; background:#0f1420; margin-bottom:8px; border-radius:12px; transition:all 0.2s;">
                        <div style="width:60px; height:60px; background:#1e293b; border-radius:10px; display:flex; align-items:center; justify-content:center; overflow:hidden; flex-shrink:0;">
                            ${hasImage ? `<img src="${escapeHtml(productImage)}" alt="${escapeHtml(product.product_name)}" style="width:100%; height:100%; object-fit:cover;" onerror="this.src=''; this.onerror=null; this.parentElement.innerHTML='<i class=\\'fas fa-box fa-2x\\' style=\\'color:#4ade80;\\'></i>'">` : '<i class="fas fa-box fa-2x" style="color:#4ade80;"></i>'}
                        </div>
                        <div style="flex:1; margin-left:12px;">
                            <div style="color:#e2f0e8; font-size:13px; font-weight:500; margin-bottom:4px;">${escapeHtml(product.product_name || 'No Name')}</div>
                            <div style="display:flex; gap:16px; flex-wrap:wrap; margin-bottom:4px;">
                                <span style="color:#4ade80; font-size:12px;"> Rp ${formatNumber(product.price)}</span>
                                <span style="color:#fbbf24; font-size:11px;"> Open Plan: ${product.commission_rate / 100}%</span>
                                <span style="color:#9aaebe; font-size:10px;"> Rekomendasi: ${recommendedCommission}% (+2%)</span>
                            </div>
                            ${product.shop_name ? `<div style="color:#9aaebe; font-size:10px;"><i class="fas fa-store"></i> Shop: ${escapeHtml(product.shop_name)}</div>` : ''}
                        </div>
                        <button class="select-product-btn" 
                                data-product='${JSON.stringify({
                                    product_id: product.product_id,
                                    product_name: product.product_name,
                                    product_image: productImage,
                                    open_commission: product.commission_rate,
                                    recommended_commission: recommendedCommission
                                })}'
                                style="background:${isSelected ? '#4ade80' : '#1e293b'}; border:none; color:white; padding:8px 16px; border-radius:20px; cursor:pointer; font-size:12px; font-weight:500; transition:all 0.2s;">
                            ${isSelected ? ' Terpilih' : '+ Pilih'}
                        </button>
                    </div>
                `;
            });
            container.innerHTML = html;
            
            document.querySelectorAll('.select-product-btn').forEach(btn => {
                btn.addEventListener('click', () => {
                    const productData = JSON.parse(btn.getAttribute('data-product'));
                    const existingIndex = selectedProductsIS.findIndex(p => p.product_id === productData.product_id);
                    
                    if (existingIndex !== -1) {
                        selectedProductsIS.splice(existingIndex, 1);
                        btn.innerHTML = '+ Pilih';
                        btn.style.background = '#1e293b';
                        showToastGlobal(`Produk "${productData.product_name}" dihapus`, 'info');
                    } else {
                        selectedProductsIS.push({
                            product_id: productData.product_id,
                            product_name: productData.product_name,
                            product_image: productData.product_image,
                            open_commission: productData.open_commission,
                            custom_commission: productData.recommended_commission,
                            status: 'pending',
                            generated_link: null
                        });
                        btn.innerHTML = ' Terpilih';
                        btn.style.background = '#4ade80';
                        showToastGlobal(`Produk "${productData.product_name}" ditambahkan`, 'success');
                    }
                    renderSelectedProductsWithCommission();
                });
            });
        } else {
            container.innerHTML = `<div style="text-align:center; padding:40px; color:#9aaebe;">
                <i class="fas fa-box-open" style="font-size:48px; margin-bottom:16px; display:block;"></i>
                <p>Tidak ada produk yang tersedia untuk campaign ini.</p>
                <small style="font-size:11px;">Coba pilih campaign lain atau tunggu produk ditambahkan.</small>
            </div>`;
        }
    } catch (error) {
        console.error('Error:', error);
        container.innerHTML = `<div style="text-align:center; padding:40px; color:#ef4444;">
            <i class="fas fa-exclamation-triangle" style="font-size:48px; margin-bottom:16px; display:block;"></i>
            <p>Error loading products: ${error.message}</p>
            <button class="btn-retry" onclick="loadAvailableProducts('${campaignId}', '${creatorCategory}')" style="margin-top:12px;">Coba Lagi</button>
        </div>`;
    }
}

function renderSelectedProductsWithCommission() {
    const container = document.getElementById('selectedProductsWithCommission');
    const step3Container = document.getElementById('step3Container');
    const step4Container = document.getElementById('step4Container');
    
    if (selectedProductsIS.length === 0) {
        if (step3Container) step3Container.style.display = 'none';
        if (step4Container) step4Container.style.display = 'none';
        return;
    }
    
    if (step3Container) step3Container.style.display = 'block';
    if (step4Container) step4Container.style.display = 'none';
    
    let html = '';
    selectedProductsIS.forEach((product, idx) => {
        const recommended = (product.open_commission / 100) + 2;
        const isGenerated = product.status === 'generated';
        const hasLinkFromBD = product.has_bd_link === true;
        let borderColor = '#2a3346';
        if (isGenerated) borderColor = '#4ade80';
        else if (hasLinkFromBD) borderColor = '#fbbf24';
        
        html += `
            <div class="selected-product-item" style="background:#0f1420; border-radius:10px; padding:12px; margin-bottom:10px; border:1px solid ${borderColor};">
                <div style="display:flex; justify-content:space-between; align-items:flex-start;">
                    <div style="flex:1;">
                        <div style="color:#e2f0e8; font-size:13px; font-weight:500;">${escapeHtml(product.product_name)}</div>
                        <div style="color:#fbbf24; font-size:11px; margin-top:4px;">Open Plan: ${product.open_commission / 100}%</div>
                        <div style="color:#9aaebe; font-size:10px;"> Rekomendasi: ${recommended}% (+2%)</div>
                        ${hasLinkFromBD && !isGenerated ? `<div style="color:#fbbf24; font-size:10px; margin-top:4px;"><i class="fas fa-database"></i> Link tersedia dari BD, klik "Ambil Link"</div>` : ''}
                    </div>
                    <button class="remove-product-btn" data-idx="${idx}" style="background:transparent; border:none; color:#ef4444; cursor:pointer; font-size:16px;">
                        <i class="fas fa-trash-alt"></i>
                    </button>
                </div>
                <div style="margin-top:10px;">
                    <label style="color:#9aaebe; font-size:11px;">Set Komisi Manual (%):</label>
                    <input type="number" class="commission-input" data-idx="${idx}" value="${product.custom_commission || recommended}" 
                           step="0.5" min="1" max="50" ${isGenerated ? 'disabled' : ''}
                           style="width:100%; margin-top:5px; padding:8px; background:#1e293b; border:1px solid ${borderColor}; border-radius:8px; color:#e2f0e8;">
                    <div class="commission-status" id="commissionStatus-${idx}" style="font-size:10px; margin-top:4px; color:${isGenerated ? '#4ade80' : (hasLinkFromBD ? '#fbbf24' : '#fbbf24')};">
                        ${isGenerated ? ' Link sudah digenerate' : (hasLinkFromBD ? ' Link tersedia dari BD, klik "Ambil Link"' : ' Belum digenerate')}
                    </div>
                </div>
                ${!isGenerated ? `
                <button class="generate-link-btn" data-idx="${idx}" style="width:100%; margin-top:10px; background:${hasLinkFromBD ? '#fbbf24' : '#4ade80'}; border:none; color:#0a0e17; padding:8px; border-radius:20px; cursor:pointer; font-weight:600; font-size:12px;">
                    <i class="fas fa-${hasLinkFromBD ? 'download' : 'link'}"></i> ${hasLinkFromBD ? 'Ambil Link dari BD' : 'Generate Link'}
                </button>
                ` : `
                <div style="margin-top:10px; background:#0a0e1a; padding:10px; border-radius:8px;">
                    <div style="font-size:11px; color:#4ade80; word-break:break-all;">
                        <strong>Link Afiliasi:</strong><br>
                        ${product.generated_link}
                    </div>
                    <button class="copy-link-btn" data-link="${product.generated_link}" style="margin-top:8px; background:#1e293b; border:none; color:#4ade80; padding:4px 12px; border-radius:12px; cursor:pointer; font-size:10px;">
                        <i class="fas fa-copy"></i> Copy Link
                    </button>
                </div>
                `}
            </div>
        `;
    });
    container.innerHTML = html;
    
    document.querySelectorAll('.remove-product-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            const idx = parseInt(btn.getAttribute('data-idx'));
            selectedProductsIS.splice(idx, 1);
            renderSelectedProductsWithCommission();
            if (currentCampaignId) {
                loadAvailableProducts(currentCampaignId, currentCreatorCategory);
            }
            updateStep4Visibility();
        });
    });
    
    document.querySelectorAll('.commission-input').forEach(input => {
        input.addEventListener('change', (e) => {
            const idx = parseInt(input.getAttribute('data-idx'));
            const newCommission = parseFloat(input.value);
            if (!isNaN(newCommission) && newCommission > 0) {
                selectedProductsIS[idx].custom_commission = newCommission;
                selectedProductsIS[idx].status = 'pending';
                selectedProductsIS[idx].generated_link = null;
                const statusDiv = document.getElementById(`commissionStatus-${idx}`);
                if (statusDiv) {
                    statusDiv.innerHTML = ' Komisi diubah, klik Generate/Ambil Link';
                    statusDiv.style.color = '#fbbf24';
                }
                renderSelectedProductsWithCommission();
            }
        });
    });
    
    document.querySelectorAll('.generate-link-btn').forEach(btn => {
        btn.addEventListener('click', async () => {
            const idx = parseInt(btn.getAttribute('data-idx'));
            const product = selectedProductsIS[idx];
            const commission = product.custom_commission;
            const statusDiv = document.getElementById(`commissionStatus-${idx}`);
            const genBtn = btn;
            
            if (!commission || commission <= 0) {
                showToastGlobal('Masukkan komisi terlebih dahulu', 'error');
                return;
            }
            
            genBtn.disabled = true;
            genBtn.innerHTML = '<i class="fas fa-spinner fa-pulse"></i> Checking...';
            if (statusDiv) {
                statusDiv.innerHTML = ' Mengecek ketersediaan link...';
                statusDiv.style.color = '#4ade80';
            }
            
            try {
                const checkResponse = await fetch(baseUrlIS + 'is/get_bd_affiliate_link', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                    body: new URLSearchParams({
                        product_id: product.product_id,
                        campaign_id: currentCampaignId
                    })
                });
                const checkData = await checkResponse.json();
                
                if (checkData.has_link) {
                    product.generated_link = checkData.link;
                    product.commission_rate = checkData.commission_rate;
                    product.status = 'generated';
                    product.has_bd_link = true;
                    
                    if (statusDiv) {
                        statusDiv.innerHTML = ' Link berhasil diambil dari BD!';
                        statusDiv.style.color = '#4ade80';
                    }
                    showToastGlobal(`Link untuk ${product.product_name} berhasil diambil dari BD!`, 'success');
                    
                    await fetch(baseUrlIS + 'is/save_bd_affiliate_link', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                        body: new URLSearchParams({
                            creator_id: currentCreatorId,
                            campaign_id: currentCampaignId,
                            product_id: product.product_id,
                            product_name: product.product_name,
                            affiliate_link: checkData.link,
                            commission_rate: checkData.commission_rate
                        })
                    });
                    
                    renderSelectedProductsWithCommission();
                    updateStep4Visibility();
                } else {
                    const canGenerate = await checkCanGenerateLink();
                    
                    if (canGenerate) {
                        if (statusDiv) statusDiv.innerHTML = ' Generating link...';
                        
                        const generateResponse = await fetch(baseUrlIS + 'is/generate_creator_affiliate_link', {
                            method: 'POST',
                            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                            body: new URLSearchParams({
                                creator_id: currentCreatorId,
                                campaign_id: currentCampaignId,
                                product_id: product.product_id,
                                product_name: product.product_name,
                                commission_rate: commission
                            })
                        });
                        const generateData = await generateResponse.json();
                        
                        if (generateData.success) {
                            product.generated_link = generateData.link;
                            product.status = 'generated';
                            if (statusDiv) {
                                statusDiv.innerHTML = ' Link berhasil digenerate!';
                                statusDiv.style.color = '#4ade80';
                            }
                            showToastGlobal(`Link untuk ${product.product_name} berhasil digenerate!`, 'success');
                            renderSelectedProductsWithCommission();
                            updateStep4Visibility();
                        } else {
                            if (statusDiv) {
                                statusDiv.innerHTML = ` Gagal: ${generateData.message}`;
                                statusDiv.style.color = '#ef4444';
                            }
                            showToastGlobal(generateData.message, 'error');
                            genBtn.disabled = false;
                            genBtn.innerHTML = '<i class="fas fa-link"></i> Generate Link';
                        }
                    } else {
                        if (statusDiv) {
                            statusDiv.innerHTML = ' Link belum tersedia. Silakan minta BD generate link terlebih dahulu.';
                            statusDiv.style.color = '#ef4444';
                        }
                        showToastGlobal(`Link untuk ${product.product_name} belum tersedia. Silakan minta BD generate link.`, 'error');
                        genBtn.disabled = false;
                        genBtn.innerHTML = '<i class="fas fa-link"></i> Generate Link (Butuh BD)';
                    }
                }
            } catch (error) {
                console.error('Error:', error);
                if (statusDiv) {
                    statusDiv.innerHTML = ` Error: ${error.message}`;
                    statusDiv.style.color = '#ef4444';
                }
                showToastGlobal('Network error', 'error');
                genBtn.disabled = false;
                genBtn.innerHTML = '<i class="fas fa-link"></i> Generate Link';
            }
        });
    });
    
    document.querySelectorAll('.copy-link-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            const link = btn.getAttribute('data-link');
            navigator.clipboard.writeText(link);
            showToastGlobal('Link copied!', 'success');
        });
    });
}

function updateStep4Visibility() {
    const step4Container = document.getElementById('step4Container');
    const generatedCountSpan = document.getElementById('generatedCount');
    const totalCountSpan = document.getElementById('totalProductsCount');
    
    if (!step4Container) return;
    
    const generatedCount = selectedProductsIS.filter(p => p.status === 'generated').length;
    const totalCount = selectedProductsIS.length;
    
    if (generatedCountSpan) generatedCountSpan.innerText = generatedCount;
    if (totalCountSpan) totalCountSpan.innerText = totalCount;
    
    if (totalCount > 0 && generatedCount === totalCount) {
        step4Container.style.display = 'block';
    } else {
        step4Container.style.display = 'none';
    }
}

async function checkCanGenerateLink() {
    const response = await fetch(baseUrlIS + 'is/can_generate_link');
    const data = await response.json();
    return data.can_generate;
}

async function showProductModalIS(creatorId, creatorName, campaignId, campaignName) {
    const canGenerate = await checkCanGenerateLink();
    
    document.getElementById('modalTitleDashboard').innerHTML = `<i class="fas fa-box"></i> Tambah Produk - ${creatorName}`;
    document.getElementById('modalBodyDashboard').innerHTML = `
        <div style="background:rgba(74,222,128,0.1); border-radius:14px; padding:12px; margin-bottom:16px;">
            <p style="color:#4ade80;"><i class="fas fa-bullhorn"></i> Campaign: ${escapeHtml(campaignName)}</p>
            ${!canGenerate ? '<p style="color:#fbbf24; font-size:11px; margin-top:6px;"><i class="fas fa-info-circle"></i>  Link afiliasi akan diambil dari database (digenerate oleh BA/BD). Jika link belum tersedia, silakan minta BA/BD generate link terlebih dahulu.</p>' : ''}
            <p style="color:#9aaebe; font-size:11px; margin-top:6px;"><i class="fab fa-whatsapp"></i> Nomor WhatsApp Creator: ${currentCreatorPhone || '-'}</p>
        </div>
        
        <label>Daftar Produk yang Dipilih</label>
        <div id="productsListIS" style="max-height:200px; overflow-y:auto; background:#0f1420; border-radius:12px; padding:8px; margin-bottom:12px;">
            <div class="loading">Belum ada produk dipilih</div>
        </div>
        
        <div class="add-product-btn" id="addProductBtnIS" style="text-align:center; padding:10px; background:#1e293b; border:1px dashed #4ade80; border-radius:12px; color:#4ade80; cursor:pointer;">
            <i class="fas fa-plus"></i> Tambah Produk
        </div>
        
        <label style="margin-top:16px;">Pesan WhatsApp untuk Creator</label>
        <textarea id="whatsappMessageIS" rows="4" style="width:100%; padding:10px; background:#0f1420; border:1px solid #2a3346; border-radius:12px; color:#e2f0e8; font-size:12px;">Halo! Terima kasih telah bergabung dengan Toopai. Berikut adalah link afiliasi untuk produk yang dapat Anda promosikan. Selamat bekerja sama! </textarea>
        
        <div class="flex-buttons" style="margin-top:16px;">
            <button id="generateAndSendBtnIS" style="background:#4ade80; color:#0a0e17; padding:12px;"><i class="fas fa-link"></i> ${canGenerate ? 'Generate Link & Kirim WA' : 'Ambil Link & Kirim WA'}</button>
            <button id="backToCampaignBtnIS" style="background:#1e293b; color:#cbd5e6; padding:12px;">Kembali</button>
        </div>
    `;
    openModalIS();
    
    renderProductsListIS();
    
    document.getElementById('addProductBtnIS').addEventListener('click', () => {
        showAddProductModalIS(creatorId, creatorName, campaignId, campaignName);
    });
    
    document.getElementById('generateAndSendBtnIS').addEventListener('click', async () => {
        if (selectedProductsIS.length === 0) { 
            showToastGlobal('Tambah minimal 1 produk', 'error'); 
            return; 
        }
        
        const btn = document.getElementById('generateAndSendBtnIS');
        btn.disabled = true;
        btn.innerHTML = '<i class="fas fa-spinner fa-pulse"></i> Processing...';
        
        const response = await fetch(baseUrlIS + 'is/send_affiliate_links_bulk', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: new URLSearchParams({
                creator_id: creatorId,
                campaign_id: campaignId,
                products: JSON.stringify(selectedProductsIS)
            })
        });
        
        const result = await response.json();
        
        if (result.success && result.generated.length > 0) {
            const message = document.getElementById('whatsappMessageIS').value;
            let phone = currentCreatorPhone || '';
            
            if (phone) {
                let linksText = '';
                result.generated.forEach(l => {
                    if (l.source === 'BD') {
                        linksText += ` *${l.product_name}* (Link dari ${l.created_by || 'BD'} - Komisi: ${l.commission_rate}%)\n   ${l.link}\n\n`;
                    } else {
                        linksText += ` *${l.product_name}* (Komisi: ${l.commission_rate}%)\n   ${l.link}\n\n`;
                    }
                });
                
                phone = phone.replace(/[^0-9+]/g, '');
                if (phone.startsWith('0')) phone = '62' + phone.substring(1);
                else if (phone.startsWith('+')) phone = phone.substring(1);
                
                const whatsappUrl = `https://wa.me/${phone}?text=${encodeURIComponent(message + '\n\n' + linksText)}`;
                window.open(whatsappUrl, '_blank');
            }
            
            if (!result.can_generate) {
                showToastGlobal(result.generated.length + ' link berhasil diambil dari BD! ' + (result.failed.length > 0 ? result.failed.length + ' produk gagal karena link belum tersedia.' : ''), result.failed.length > 0 ? 'warning' : 'success');
            } else {
                showToastGlobal(result.generated.length + ' link berhasil digenerate!', 'success');
            }
            
            closeModalIS();
            setTimeout(() => location.reload(), 2000);
        } else if (result.failed && result.failed.length > 0) {
            showToastGlobal('Link untuk produk berikut tidak tersedia: ' + result.failed.join(', ') + '. Silakan minta BA/BD generate link terlebih dahulu.', 'error');
            btn.disabled = false;
            btn.innerHTML = '<i class="fas fa-link"></i> Proses Link';
        } else {
            showToastGlobal(result.message || 'Gagal memproses link', 'error');
            btn.disabled = false;
            btn.innerHTML = '<i class="fas fa-link"></i> Proses Link';
        }
    });
    
    document.getElementById('backToCampaignBtnIS').addEventListener('click', () => {
        showCampaignSelectionModalIS(creatorId, creatorName, currentCreatorCategory, currentCreatorPhone);
    });
}

function renderProductsListIS() {
    const container = document.getElementById('productsListIS');
    if (!container) return;
    
    if (selectedProductsIS.length === 0) {
        container.innerHTML = '<div style="text-align:center; padding:20px; color:#9aaebe;">Belum ada produk dipilih. Klik "Tambah Produk" untuk memilih produk.</div>';
        return;
    }
    
    let html = '';
    selectedProductsIS.forEach((product, idx) => {
        html += `
            <div style="display:flex; justify-content:space-between; align-items:center; padding:10px; background:#0f1420; border-radius:8px; margin-bottom:8px; border:1px solid #2a3346;">
                <div style="flex:1;">
                    <div style="color:#e2f0e8; font-size:13px; font-weight:500;">${escapeHtml(product.product_name)}</div>
                    <div style="color:#fbbf24; font-size:11px;">Komisi: ${product.custom_commission || product.commission_rate || 10}%</div>
                </div>
                <button class="remove-product-item" data-idx="${idx}" style="background:transparent; border:none; color:#ef4444; cursor:pointer; font-size:16px;">
                    <i class="fas fa-trash-alt"></i>
                </button>
            </div>
        `;
    });
    container.innerHTML = html;
    
    document.querySelectorAll('.remove-product-item').forEach(btn => {
        btn.addEventListener('click', () => {
            const idx = parseInt(btn.getAttribute('data-idx'));
            selectedProductsIS.splice(idx, 1);
            renderProductsListIS();
            renderSelectedProductsWithCommission();
        });
    });
}

function showAddProductModalIS(creatorId, creatorName, campaignId, campaignName) {
    document.getElementById('modalTitleDashboard').innerHTML = `<i class="fas fa-plus"></i> Tambah Produk - ${creatorName}`;
    document.getElementById('modalBodyDashboard').innerHTML = `
        <div style="background:rgba(74,222,128,0.1); border-radius:14px; padding:12px; margin-bottom:16px;">
            <p style="color:#4ade80;"><i class="fas fa-info-circle"></i> Pilih produk dari campaign: ${escapeHtml(campaignName)}</p>
            <p style="color:#9aaebe; font-size:11px;">Pilih produk, komisi akan otomatis +2% dari open plan</p>
        </div>
        
        <label>Pilih Produk</label>
        <div id="addProductList" style="max-height:300px; overflow-y:auto; background:#0f1420; border-radius:12px; padding:8px;">
            <div class="loading"><i class="fas fa-spinner fa-pulse"></i> Loading products...</div>
        </div>
        
        <div class="flex-buttons" style="margin-top:16px;">
            <button id="backToProductBtnIS" style="background:#1e293b;">Kembali</button>
        </div>
    `;
    openModalIS();
    
    loadAvailableProductsForAdd(campaignId, creatorName, campaignName);
    
    document.getElementById('backToProductBtnIS').addEventListener('click', () => {
        showProductModalIS(creatorId, creatorName, campaignId, campaignName);
    });
}

async function loadAvailableProductsForAdd(campaignId, creatorName, campaignName) {
    const container = document.getElementById('addProductList');
    container.innerHTML = '<div class="loading"><i class="fas fa-spinner fa-pulse"></i> Loading products...</div>';
    
    try {
        const response = await fetch(baseUrlIS + 'is/get_campaign_products', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: new URLSearchParams({ 
                campaign_id: campaignId,
                creator_category: currentCreatorCategory || ''
            })
        });
        const data = await response.json();
        
        if (data.success && data.products && data.products.length > 0) {
            let html = '';
            data.products.forEach(product => {
                const isAlreadySelected = selectedProductsIS.some(p => p.product_id === product.product_id);
                if (isAlreadySelected) return;
                
                const recommendedCommission = (product.commission_rate / 100) + 2;
                
                html += `
                    <div style="display:flex; justify-content:space-between; align-items:center; padding:12px; border-bottom:1px solid #2a3346; background:#0f1420; margin-bottom:5px; border-radius:8px;">
                        <div style="flex:1;">
                            <div style="color:#e2f0e8; font-size:13px; font-weight:500;">${escapeHtml(product.product_name || 'No Name')}</div>
                            <div style="color:#4ade80; font-size:12px;">Rp ${formatNumber(product.price)}</div>
                            <div style="color:#fbbf24; font-size:11px;">Open Plan: ${product.commission_rate / 100}%</div>
                            <div style="color:#9aaebe; font-size:10px;">Rekomendasi: ${recommendedCommission}% (+2%)</div>
                        </div>
                        <button class="add-this-product-btn" 
                                data-product-id="${product.product_id}"
                                data-product-name="${escapeHtml(product.product_name)}"
                                data-open-commission="${product.commission_rate}"
                                data-recommended-commission="${recommendedCommission}"
                                style="background:#4ade80; border:none; color:#0a0e17; padding:6px 14px; border-radius:20px; cursor:pointer; font-size:11px; font-weight:500;">
                            + Tambah
                        </button>
                    </div>
                `;
            });
            container.innerHTML = html;
            
            document.querySelectorAll('.add-this-product-btn').forEach(btn => {
                btn.addEventListener('click', () => {
                    const productId = btn.getAttribute('data-product-id');
                    const productName = btn.getAttribute('data-product-name');
                    const openCommission = parseFloat(btn.getAttribute('data-open-commission'));
                    const recommendedCommission = parseFloat(btn.getAttribute('data-recommended-commission'));
                    
                    selectedProductsIS.push({
                        product_id: productId,
                        product_name: productName,
                        open_commission: openCommission,
                        custom_commission: recommendedCommission,
                        commission_rate: recommendedCommission,
                        status: 'pending',
                        generated_link: null
                    });
                    
                    showToastGlobal(`Produk "${productName}" ditambahkan!`, 'success');
                    showProductModalIS(creatorId, creatorName, campaignId, campaignName);
                });
            });
        } else {
            container.innerHTML = '<div style="text-align:center; padding:30px; color:#9aaebe;">Tidak ada produk yang tersedia untuk campaign ini.</div>';
        }
    } catch (error) {
        console.error('Error:', error);
        container.innerHTML = '<div style="text-align:center; padding:30px; color:#ef4444;">Error loading products</div>';
    }
}


// ========== TASK 3: LOAD CREATORS ==========
async function loadTask3CreatorsIS() {
    const response = await fetch(baseUrlIS + 'is/get_creators_by_status', {
        method: 'POST', 
        body: new URLSearchParams({ status: 'LINK_SENT' })
    });
    const result = await response.json();
    const container = document.getElementById('sendingSampleContainerDashboard');
    const countSpan = document.getElementById('sampleCountDashboard');
    
    if (result.success && result.data.length > 0) {
        // �9�7 Filter hanya yang belum auto_activated
        const filteredCreators = result.data.filter(c => !c.auto_activated_at);
        
        if (countSpan) countSpan.innerText = filteredCreators.length;
        let html = '';
        filteredCreators.forEach(creator => {
            const hasPhone = creator.phone && creator.phone !== '' && creator.phone !== '-';
            const phoneDisplay = hasPhone 
                ? `<span style="color:#4ade80;"><i class="fab fa-whatsapp"></i> ${creator.phone}</span>` 
                : `<span style="color:#ef4444;"><i class="fab fa-whatsapp"></i> No WA</span>`;
            
            // �9�7 NAMA PETUGAS IS
            const isName = creator.is_full_name || creator.is_username || '-';
            const isDisplay = isName !== '-' ? `<span style="color:#8b5cf6; font-size:9px;"><i class="fas fa-user-tie"></i> ${escapeHtml(isName)}</span>` : '';
            
            html += `
            <div class="stage-item-dashboard sample-item-dashboard" 
                 data-creator-id="${creator.id}" 
                 data-creator-name="${escapeHtml(creator.username)}"
                 data-creator-phone="${escapeHtml(creator.phone || '')}"
                 data-creator-category="${escapeHtml(creator.category || '')}">
                <div style="display:flex; justify-content:space-between; align-items:center;">
                    <strong><i class="fab fa-tiktok"></i> ${escapeHtml(creator.username)}</strong>
                    <div style="display:flex; gap:6px; align-items:center;">
                        ${isDisplay}
                        <span class="badge-dashboard badge-pending"><i class="fas fa-clock"></i> ${creator.status}</span>
                    </div>
                </div>
                <div class="item-details-dashboard">
                    ${phoneDisplay}
                    ${!hasPhone ? `
                    <button class="edit-wa-task3-btn" data-creator-id="${creator.id}" data-creator-name="${escapeHtml(creator.username)}"
                        style="background:#fbbf24; color:#0a0e17; border:none; padding:2px 8px; border-radius:10px; cursor:pointer; font-size:9px; margin-left:8px;">
                        <i class="fas fa-edit"></i> Tambah WA
                    </button>` : ''}
                    <span><i class="fas fa-tag"></i> ${escapeHtml(creator.category || '-')}</span>
                </div>
                <div class="item-details-dashboard"><i class="fas fa-box"></i> Menunggu konfirmasi sample</div>
            </div>`;
        });
        container.innerHTML = html || '<div class="stage-item-dashboard">Semua creator sudah naik ke monitoring</div>';
        
        // Event: Edit WA di Task 3
        document.querySelectorAll('.edit-wa-task3-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                e.stopPropagation();
                const cid = btn.getAttribute('data-creator-id');
                const cname = btn.getAttribute('data-creator-name');
                showQuickEditPhoneModal(cid, cname, '');
            });
        });
        
        // Event: Buka Sample Modal
        document.querySelectorAll('.sample-item-dashboard').forEach(item => {
            item.addEventListener('click', () => {
                const creatorId = item.getAttribute('data-creator-id');
                const creatorName = item.getAttribute('data-creator-name');
                const creatorPhone = item.getAttribute('data-creator-phone');
                const creatorCategory = item.getAttribute('data-creator-category');
                showSampleRequestModalIS(creatorId, creatorName, creatorCategory, creatorPhone);
            });
        });
    } else {
        if (countSpan) countSpan.innerText = '0';
        container.innerHTML = '<div class="stage-item-dashboard"><strong><i class="fas fa-info-circle"></i> Belum ada creator di tahap pengiriman sample</strong></div>';
    }
}


// ========== TASK 3: SHOW SAMPLE REQUEST MODAL (REWRITE - NO METHOD OPTION) ========== //
async function showSampleRequestModalIS(creatorId, creatorName, creatorCategory, creatorPhone) {
    currentSampleCreatorId = creatorId;
    currentSampleCreatorName = creatorName;
    currentSampleCreatorCategory = creatorCategory;
    currentSampleCreatorPhone = creatorPhone;
    currentSelectedProducts = [];
    
    const modalTitle = document.getElementById('modalTitleDashboard');
    const modalBody = document.getElementById('modalBodyDashboard');
    
    modalTitle.innerHTML = `<i class="fas fa-box"></i> Kirim Sample - @${escapeHtml(creatorName)}`;
    modalBody.innerHTML = `
        <div style="background:rgba(74,222,128,0.1); border-radius:14px; padding:12px; margin-bottom:16px;">
            <div style="display:grid; grid-template-columns:1fr 1fr; gap:8px;">
                <div>
                    <span style="color:#9aaebe; font-size:10px;">Creator</span><br>
                    <span style="color:#e2f0e8; font-size:14px; font-weight:600;">@${escapeHtml(creatorName)}</span>
                </div>
                <div>
                    <span style="color:#9aaebe; font-size:10px;">Kategori</span><br>
                    <span style="color:#e2f0e8; font-size:13px;">${escapeHtml(creatorCategory || 'Semua')}</span>
                </div>
                <div>
                    <span style="color:#9aaebe; font-size:10px;"><i class="fab fa-whatsapp"></i> WhatsApp</span><br>
                    <span style="color:${creatorPhone ? '#4ade80' : '#ef4444'}; font-size:13px;">${escapeHtml(creatorPhone || 'Tidak ada')}</span>
                </div>
                <div>
                    <span style="color:#9aaebe; font-size:10px;">Status</span><br>
                    <span class="badge-dashboard badge-pending">LINK_SENT</span>
                </div>
            </div>
        </div>
        
        <!-- === PILIHAN KIRIM SAMPLE === -->
        <div style="background:#0f1420; border-radius:14px; padding:14px; margin-bottom:16px;">
            <h4 style="color:#e2f0e8; margin:0 0 12px 0; font-size:13px;">
                <i class="fas fa-question-circle"></i> Apakah akan mengirim sample?
            </h4>
            <div style="display:flex; gap:16px; flex-wrap:wrap;">
                <label style="display:flex; align-items:center; gap:8px; cursor:pointer;">
                    <input type="radio" name="send_sample_radio" value="yes" checked style="width:18px; height:18px; accent-color:#4ade80;">
                    <span style="color:#e2f0e8;">Ya, Kirim Sample</span>
                </label>
                <label style="display:flex; align-items:center; gap:8px; cursor:pointer;">
                    <input type="radio" name="send_sample_radio" value="no" style="width:18px; height:18px; accent-color:#f59e0b;">
                    <span style="color:#e2f0e8;">Tidak, Langsung ke Monitoring</span>
                </label>
            </div>
            <p style="color:#9aaebe; font-size:10px; margin-top:8px;">
                <i class="fas fa-info-circle"></i> Jika pilih "Tidak", creator akan langsung pindah ke Task 4 (Monitoring)
            </p>
        </div>
        
        <!-- === LIST PRODUK (GROUPING BY BRAND) === -->
        <div id="productsSampleList" style="background:#0f1420; border-radius:14px; padding:14px; margin-bottom:16px; display:block;">
            <h4 style="color:#e2f0e8; margin:0 0 12px 0; font-size:13px;">
                <i class="fas fa-box"></i> Pilih Produk untuk Sample
                <span style="font-size:10px; color:#9aaebe; font-weight:normal; margin-left:8px;">(isi varian & catatan)</span>
            </h4>
            <div id="sampleProductsContainer" style="max-height:400px; overflow-y:auto;">
                <div style="text-align:center; padding:20px;">
                    <i class="fas fa-spinner fa-pulse"></i> Loading produk...
                </div>
            </div>
        </div>
        
        <!-- Buttons -->
        <div class="flex-buttons" style="margin-top:12px; gap:12px;">
            <button id="confirmSampleBtn" style="background:#4ade80; color:#0a0e17; flex:1; padding:12px; border:none; border-radius:12px; cursor:pointer; font-weight:600;">
                <i class="fas fa-paper-plane"></i> Konfirmasi
            </button>
            <button id="cancelSampleBtn" style="background:#1e293b; color:#e2f0e8; flex:1; padding:12px; border:1px solid #2a3346; border-radius:12px; cursor:pointer;">
                Batal
            </button>
        </div>
    `;
    openModalIS();
    
    // �9�7 EVENT: Toggle produk list berdasarkan pilihan kirim sample
    const radioYes = document.querySelector('input[name="send_sample_radio"][value="yes"]');
    const radioNo = document.querySelector('input[name="send_sample_radio"][value="no"]');
    const productsList = document.getElementById('productsSampleList');
    
    if (radioYes && radioNo) {
        radioYes.addEventListener('change', function() {
            if (this.checked) {
                productsList.style.display = 'block';
            }
        });
        radioNo.addEventListener('change', function() {
            if (this.checked) {
                productsList.style.display = 'none';
            }
        });
    }
    
    // �9�7 LOAD PRODUK (GROUPING BY BRAND)
    await loadProductsForSampleNew(creatorId);
    
    // �9�7 BUTTON CANCEL
    document.getElementById('cancelSampleBtn')?.addEventListener('click', closeModalIS);
    
    // �9�7 BUTTON CONFIRM
  document.getElementById('confirmSampleBtn')?.addEventListener('click', async () => {
    const sendSample = document.querySelector('input[name="send_sample_radio"]:checked')?.value;
    
    // Jika pilih "Tidak" (langsung ke monitoring)
    if (sendSample === 'no') {
        const btn = document.getElementById('confirmSampleBtn');
        btn.disabled = true;
        btn.innerHTML = '<i class="fas fa-spinner fa-pulse"></i> Memproses...';
        
        try {
            const response = await fetch(baseUrlIS + 'is/update_creator_status', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: new URLSearchParams({
                    creator_id: creatorId,
                    status: 'ACTIVE'
                })
            });
            const result = await response.json();
            
            if (result.success) {
                showToastGlobal(`Creator @${creatorName} langsung ke Monitoring!`, 'success');
                closeModalIS();
                setTimeout(() => location.reload(), 1500);
            } else {
                showToastGlobal(result.message || 'Gagal update status', 'error');
                btn.disabled = false;
                btn.innerHTML = '<i class="fas fa-paper-plane"></i> Konfirmasi';
            }
        } catch (error) {
            showToastGlobal('Error: ' + error.message, 'error');
            btn.disabled = false;
            btn.innerHTML = '<i class="fas fa-paper-plane"></i> Konfirmasi';
        }
        return;
    }
    
    // === KIRIM SAMPLE ===
    const selectedProducts = [];
    document.querySelectorAll('.sample-product-checkbox:checked').forEach(cb => {
        const parent = cb.closest('.sample-product-item');
        const varian = parent?.querySelector('.sample-varian-input')?.value || '';
        const notes = parent?.querySelector('.sample-notes-input')?.value || '';
        
        selectedProducts.push({
            product_id: cb.getAttribute('data-product-id'),
            product_name: cb.getAttribute('data-product-name'),
            campaign_id: cb.getAttribute('data-campaign-id'),
            commission_rate: cb.getAttribute('data-commission'),
            varian: varian,
            product_notes: notes
        });
    });
    
    if (selectedProducts.length === 0) {
        showToastGlobal('Pilih minimal 1 produk untuk sample', 'error');
        return;
    }
    
    const btn = document.getElementById('confirmSampleBtn');
    btn.disabled = true;
    btn.innerHTML = '<i class="fas fa-spinner fa-pulse"></i> Memproses...';
    
    try {
        console.log('Sending products:', selectedProducts);
        
        const response = await fetch(baseUrlIS + 'is/confirm_sample_with_details', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: new URLSearchParams({
                creator_id: creatorId,
                products: JSON.stringify(selectedProducts)
            })
        });
        
        // �9�7 CEK RESPONSE
        if (!response.ok) {
            const text = await response.text();
            console.error('Response error:', text);
            throw new Error('HTTP ' + response.status + ' - ' + text.substring(0, 200));
        }
        
        const result = await response.json();
        console.log('Confirm result:', result);
        
        if (result.success) {
            showToastGlobal(`Sample request untuk ${selectedProducts.length} produk berhasil!`, 'success');
            
            // �9�7 Generate print out
            const printResponse = await fetch(baseUrlIS + 'is/generate_sample_printout', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: new URLSearchParams({
                    creator_id: creatorId,
                    brand_groups: JSON.stringify(result.brand_groups || [])
                })
            });
            
            if (!printResponse.ok) {
                throw new Error('Printout generation failed');
            }
            
            const printResult = await printResponse.json();
            
            if (printResult.success) {
                closeModalIS();
                window.open(baseUrlIS + 'is/view_sample_printout', '_blank');
                setTimeout(() => location.reload(), 2000);
            } else {
                showToastGlobal('Gagal generate print out', 'error');
                btn.disabled = false;
                btn.innerHTML = '<i class="fas fa-paper-plane"></i> Konfirmasi';
            }
        } else {
            showToastGlobal(result.message || 'Gagal konfirmasi sample', 'error');
            btn.disabled = false;
            btn.innerHTML = '<i class="fas fa-paper-plane"></i> Konfirmasi';
        }
    } catch (error) {
        console.error('Confirm error:', error);
        showToastGlobal('Error: ' + error.message, 'error');
        btn.disabled = false;
        btn.innerHTML = '<i class="fas fa-paper-plane"></i> Konfirmasi';
    }
});
}


// ========== LOAD BRAND INFO WITH SAMPLE TYPE ==========
async function loadBrandInfoWithSampleType(creatorId) {
    const container = document.getElementById('brandInfoContent');
    if (!container) {
        console.error('brandInfoContent element not found');
        return;
    }
    
    console.log('Loading brand info for creator:', creatorId);
    
    try {
        const response = await fetch(baseUrlIS + 'is/get_creator_shipping_address', {
            method: 'POST',
            headers: { 
                'Content-Type': 'application/x-www-form-urlencoded',
                'X-Requested-With': 'XMLHttpRequest'
            },
            body: new URLSearchParams({ creator_id: creatorId })
        });
        
        // �9�7 CEK RESPONSE STATUS
        if (!response.ok) {
            const text = await response.text();
            console.error('Response error:', text);
            throw new Error('HTTP ' + response.status);
        }
        
        const result = await response.json();
        console.log('Brand info response:', result);
        
        if (!result.success) {
            container.innerHTML = `
                <div style="color:#fbbf24; font-size:12px; padding:8px; background:rgba(251,191,36,0.1); border-radius:8px;">
                    <i class="fas fa-exclamation-triangle"></i> ${result.message || 'Data brand belum lengkap'}
                </div>
            `;
            return;
        }
        
        if (result.success && result.creator) {
            const c = result.creator;
            
            // �9�7 SAMPLE TYPE BADGE
            let sampleTypeBadge = '';
            if (c.sample_type === 'auto') {
                sampleTypeBadge = `<span style="background:rgba(139,92,246,0.2); color:#8b5cf6; padding:2px 10px; border-radius:20px; font-size:10px;">
                    <i class="fas fa-robot"></i> Auto (System TikTok)
                </span>`;
            } else {
                sampleTypeBadge = `<span style="background:rgba(74,222,128,0.2); color:#4ade80; padding:2px 10px; border-radius:20px; font-size:10px;">
                    <i class="fas fa-box"></i> Manual
                </span>`;
            }
            
            container.innerHTML = `
                <div style="display:grid; grid-template-columns:1fr 1fr; gap:6px 12px;">
                    <div>
                        <span style="color:#9aaebe; font-size:10px;">Brand</span>
                        <div style="color:#e2f0e8; font-size:13px; font-weight:500;">
                            ${escapeHtml(c.brand_name || '-')}
                            ${c.brand_shop_name ? `<span style="font-size:11px; color:#9aaebe; font-weight:normal;">(${escapeHtml(c.brand_shop_name)})</span>` : ''}
                        </div>
                    </div>
                    <div>
                        <span style="color:#9aaebe; font-size:10px;">Sample Type</span>
                        <div style="margin-top:2px;">${sampleTypeBadge}</div>
                    </div>
                    <div>
                        <span style="color:#9aaebe; font-size:10px;">Penerima</span>
                        <div style="color:#e2f0e8; font-size:12px; font-weight:500;">${escapeHtml(c.penerima || c.full_name || '-')}</div>
                    </div>
                    <div>
                        <span style="color:#9aaebe; font-size:10px;">WhatsApp</span>
                        <div style="color:#4ade80; font-size:12px;">${escapeHtml(c.phone || '-')}</div>
                    </div>
                    <div style="grid-column: 1 / -1;">
                        <span style="color:#9aaebe; font-size:10px;">Alamat Brand</span>
                        <div style="color:#e2f0e8; font-size:11px; background:#0a0e17; padding:6px 10px; border-radius:8px; margin-top:4px; border-left:2px solid #8b5cf6;">
                            ${escapeHtml(c.brand_address || 'Alamat brand tidak tersedia')}
                        </div>
                    </div>
                    <div style="grid-column: 1 / -1;">
                        <span style="color:#9aaebe; font-size:10px;">Alamat Creator (Tujuan)</span>
                        <div style="color:#e2f0e8; font-size:11px; background:#0a0e17; padding:6px 10px; border-radius:8px; margin-top:4px; border-left:2px solid #4ade80;">
                            ${escapeHtml(c.alamat || 'Belum diisi')}
                        </div>
                    </div>
                    ${c.brand_whatsapp ? `
                    <div>
                        <span style="color:#9aaebe; font-size:10px;">WhatsApp Brand</span>
                        <div style="color:#4ade80; font-size:12px;">${escapeHtml(c.brand_whatsapp)}</div>
                    </div>` : ''}
                    ${c.brand_email ? `
                    <div>
                        <span style="color:#9aaebe; font-size:10px;">Email Brand</span>
                        <div style="color:#e2f0e8; font-size:12px;">${escapeHtml(c.brand_email)}</div>
                    </div>` : ''}
                </div>
            `;
        } else {
            container.innerHTML = `
                <div style="color:#fbbf24; font-size:12px; padding:8px; background:rgba(251,191,36,0.1); border-radius:8px;">
                    <i class="fas fa-exclamation-triangle"></i> Data brand/creator belum lengkap
                </div>
            `;
        }
    } catch (error) {
        console.error('Error loading brand info:', error);
        container.innerHTML = `
            <div style="color:#ef4444; font-size:12px; padding:8px; background:rgba(239,68,68,0.1); border-radius:8px;">
                <i class="fas fa-exclamation-circle"></i> Error loading brand info: ${error.message}
            </div>
        `;
    }
}


// ========== LOAD BRAND INFO FOR CREATOR ==========
async function loadBrandInfoForCreator(creatorId) {
    const container = document.getElementById('brandInfoContent');
    if (!container) return;
    
    try {
        const response = await fetch(baseUrlIS + 'is/get_creator_shipping_address', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: new URLSearchParams({ creator_id: creatorId })
        });
        const result = await response.json();
        
        if (result.success && result.creator) {
            const c = result.creator;
            container.innerHTML = `
                <div style="display:grid; grid-template-columns:1fr 1fr; gap:6px 12px;">
                    <div>
                        <span style="color:#9aaebe; font-size:10px;">Penerima</span>
                        <div style="color:#e2f0e8; font-size:12px; font-weight:500;">${escapeHtml(c.penerima || c.full_name)}</div>
                    </div>
                    <div>
                        <span style="color:#9aaebe; font-size:10px;">WhatsApp</span>
                        <div style="color:#4ade80; font-size:12px;">${escapeHtml(c.phone || '-')}</div>
                    </div>
                    <div style="grid-column: 1 / -1;">
                        <span style="color:#9aaebe; font-size:10px;">Alamat Pengiriman</span>
                        <div style="color:#e2f0e8; font-size:12px; background:#0a0e17; padding:8px; border-radius:8px; margin-top:4px;">
                            ${escapeHtml(c.alamat || 'Belum diisi')}
                        </div>
                    </div>
                </div>
            `;
        } else {
            container.innerHTML = `
                <div style="color:#fbbf24; font-size:12px;">
                    <i class="fas fa-exclamation-triangle"></i> Data alamat creator belum lengkap
                </div>
            `;
        }
    } catch (error) {
        container.innerHTML = `<div style="color:#ef4444;">Error loading brand info</div>`;
    }
}

// ========== LOAD PRODUCTS FOR SAMPLE (NEW WITH VARIAN & NOTES) ==========
async function loadProductsForSampleNew(creatorId) {
    const container = document.getElementById('sampleProductsContainer');
    if (!container) return;
    
    container.innerHTML = '<div style="text-align:center; padding:20px;"><i class="fas fa-spinner fa-pulse"></i> Loading produk...</div>';
    
    try {
        const response = await fetch(baseUrlIS + 'is/get_sample_products', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: new URLSearchParams({ creator_id: creatorId })
        });
        
        if (!response.ok) {
            const text = await response.text();
            console.error('Response error:', text);
            throw new Error('HTTP ' + response.status);
        }
        
        const result = await response.json();
        console.log('Sample products with brands:', result);
        
        if (!result.success || !result.brands || result.brands.length === 0) {
            container.innerHTML = `
                <div style="text-align:center; padding:20px; color:#ef4444;">
                    <i class="fas fa-exclamation-triangle"></i>
                    <p>${result.message || 'Belum ada produk untuk creator ini'}</p>
                    <p style="font-size:10px;">Silakan assign campaign terlebih dahulu di Task 2</p>
                </div>
            `;
            return;
        }
        
        let html = '';
        
        // �9�7 LOOP PER BRAND
        result.brands.forEach((brand, brandIndex) => {
            const brandName = brand.brand_name || 'Brand Tidak Diketahui';
            const brandShopName = brand.brand_shop_name || '';
            const sampleType = brand.sample_type || 'manual';
            const brandWhatsapp = brand.brand_whatsapp || '';
            const brandAddress = brand.brand_address || '';
            
            // Sample type badge
            let sampleTypeBadge = '';
            if (sampleType === 'auto') {
                sampleTypeBadge = `<span style="background:rgba(139,92,246,0.2); color:#8b5cf6; padding:2px 8px; border-radius:12px; font-size:9px;">
                    <i class="fas fa-robot"></i> Auto
                </span>`;
            } else {
                sampleTypeBadge = `<span style="background:rgba(74,222,128,0.2); color:#4ade80; padding:2px 8px; border-radius:12px; font-size:9px;">
                    <i class="fas fa-box"></i> Manual
                </span>`;
            }
            
            html += `
            <div style="background:#0f1420; border-radius:12px; padding:12px; margin-bottom:16px; border:1px solid #2a3346;">
                <!-- Brand Header -->
                <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:12px; padding-bottom:8px; border-bottom:1px solid #2a3346;">
                    <div>
                        <div style="color:#e2f0e8; font-size:14px; font-weight:600;">
                            <i class="fas fa-store" style="color:#8b5cf6;"></i>
                            ${escapeHtml(brandName)}
                            ${brandShopName ? `<span style="font-size:11px; color:#9aaebe; font-weight:normal;">(${escapeHtml(brandShopName)})</span>` : ''}
                        </div>
                        <div style="display:flex; gap:8px; margin-top:4px; flex-wrap:wrap;">
                            <span style="font-size:10px; color:#9aaebe;">${brand.products.length} produk</span>
                            ${sampleTypeBadge}
                            ${brandWhatsapp ? `<span style="font-size:9px; color:#4ade80;"><i class="fab fa-whatsapp"></i> ${escapeHtml(brandWhatsapp)}</span>` : ''}
                        </div>
                        ${brandAddress ? `<div style="font-size:9px; color:#9aaebe; margin-top:2px;"><i class="fas fa-map-marker-alt"></i> ${escapeHtml(brandAddress)}</div>` : ''}
                    </div>
                    <label style="display:flex; align-items:center; gap:6px; font-size:11px; color:#9aaebe; cursor:pointer;">
                        <input type="checkbox" class="select-all-brand" data-brand-index="${brandIndex}" 
                               style="width:16px; height:16px; accent-color:#4ade80; cursor:pointer;">
                        Pilih Semua
                    </label>
                </div>
                
                <!-- Products List -->
                <div style="display:flex; flex-direction:column; gap:8px;">
            `;
            
            brand.products.forEach((product, productIndex) => {
                const productName = product.product_name || `Product ID: ${product.product_id}`;
                const commissionRate = product.commission_rate || 0;
                const campaignId = product.campaign_id || '';
                const campaignName = product.campaign_name || '';
                
                html += `
                <div class="sample-product-item" data-brand-index="${brandIndex}" data-product-index="${productIndex}"
                     style="background:#1a1f2e; border-radius:10px; padding:10px 12px; border:1px solid #2a3346; transition:all 0.2s;">
                    <div style="display:flex; gap:12px; align-items:flex-start;">
                        <input type="checkbox" class="sample-product-checkbox" 
                               data-brand-index="${brandIndex}"
                               data-product-id="${product.product_id}"
                               data-product-name="${escapeHtml(productName)}"
                               data-campaign-id="${escapeHtml(campaignId)}"
                               data-commission="${commissionRate}"
                               style="width:18px; height:18px; cursor:pointer; accent-color:#4ade80; margin-top:3px;">
                        <div style="flex:1;">
                            <div style="color:#e2f0e8; font-size:12px; font-weight:500;">
                                <i class="fas fa-box" style="color:#4ade80; margin-right:6px;"></i>
                                ${escapeHtml(productName.substring(0, 60))}
                                <span style="font-size:10px; color:#fbbf24; margin-left:8px;">${commissionRate}%</span>
                            </div>
                            ${campaignName ? `<div style="color:#8b5cf6; font-size:10px;"><i class="fas fa-bullhorn"></i> ${escapeHtml(campaignName)}</div>` : ''}
                        </div>
                    </div>
                    
                    <!-- Varian & Catatan -->
                    <div class="sample-detail-fields" style="display:none; margin-top:8px; padding-top:8px; border-top:1px dashed #2a3346;">
                        <div style="display:grid; grid-template-columns:1fr 1fr; gap:8px;">
                            <div>
                                <label style="color:#9aaebe; font-size:9px; display:block; margin-bottom:3px;">
                                    <i class="fas fa-palette"></i> Varian
                                </label>
                                <input type="text" class="sample-varian-input" 
                                       placeholder="Ukuran, Warna, 100ml..."
                                       style="width:100%; padding:6px 10px; background:#0f1420; border:1px solid #2a3346; border-radius:8px; color:#e2f0e8; font-size:11px;">
                            </div>
                            <div>
                                <label style="color:#9aaebe; font-size:9px; display:block; margin-bottom:3px;">
                                    <i class="fas fa-sticky-note"></i> Catatan
                                </label>
                                <input type="text" class="sample-notes-input" 
                                       placeholder="Catatan produk ini..."
                                       style="width:100%; padding:6px 10px; background:#0f1420; border:1px solid #2a3346; border-radius:8px; color:#e2f0e8; font-size:11px;">
                            </div>
                        </div>
                    </div>
                </div>`;
            });
            
            html += `
                </div>
            </div>`;
        });
        
        container.innerHTML = html;
        
        // �9�7 EVENT: Toggle detail fields
        document.querySelectorAll('.sample-product-checkbox').forEach(cb => {
            cb.addEventListener('change', function() {
                const parent = this.closest('.sample-product-item');
                const detailFields = parent?.querySelector('.sample-detail-fields');
                if (detailFields) {
                    detailFields.style.display = this.checked ? 'block' : 'none';
                    if (!this.checked) {
                        const varianInput = parent.querySelector('.sample-varian-input');
                        const notesInput = parent.querySelector('.sample-notes-input');
                        if (varianInput) varianInput.value = '';
                        if (notesInput) notesInput.value = '';
                    }
                }
                updateSelectAllState();
            });
        });
        
        // �9�7 EVENT: Select All per Brand
        document.querySelectorAll('.select-all-brand').forEach(btn => {
            btn.addEventListener('change', function() {
                const brandIndex = this.getAttribute('data-brand-index');
                const checkboxes = document.querySelectorAll(`.sample-product-checkbox[data-brand-index="${brandIndex}"]`);
                checkboxes.forEach(cb => {
                    cb.checked = this.checked;
                    cb.dispatchEvent(new Event('change'));
                });
            });
        });
        
        function updateSelectAllState() {
            document.querySelectorAll('.select-all-brand').forEach(btn => {
                const brandIndex = btn.getAttribute('data-brand-index');
                const checkboxes = document.querySelectorAll(`.sample-product-checkbox[data-brand-index="${brandIndex}"]`);
                const checked = document.querySelectorAll(`.sample-product-checkbox[data-brand-index="${brandIndex}"]:checked`);
                btn.checked = checkboxes.length > 0 && checked.length === checkboxes.length;
            });
        }
        
    } catch (error) {
        console.error('Error loading products:', error);
        container.innerHTML = `
            <div style="text-align:center; padding:20px; color:#ef4444;">
                <i class="fas fa-exclamation-triangle"></i>
                <p>Error loading products: ${error.message}</p>
                <button onclick="location.reload()" style="margin-top:12px; background:#4ade80; color:#0a0e17; padding:8px 20px; border:none; border-radius:12px; cursor:pointer;">Refresh</button>
            </div>
        `;
    }
}


//  LOAD PRODUK UNTUK SAMPLE
async function loadProductsForSample(creatorId, creatorCategory) {
    const container = document.getElementById('sampleProductsContainer');
    if (!container) return;
    
    container.innerHTML = '<div style="text-align:center; padding:20px;"><i class="fas fa-spinner fa-pulse"></i> Loading produk...</div>';
    
    try {
        // Ambil affiliate links creator
        const linksRes = await fetch(baseUrlIS + 'is/get_creator_affiliate_links', {
            method: 'POST',
            body: new URLSearchParams({ creator_id: creatorId })
        });
        const linksResult = await linksRes.json();
        const links = linksResult.links || [];
        
        if (links.length === 0) {
            container.innerHTML = `
                <div style="text-align:center; padding:20px; color:#ef4444;">
                    <i class="fas fa-exclamation-triangle"></i>
                    <p>Belum ada link afiliasi untuk creator ini</p>
                    <p style="font-size:10px;">Silakan assign campaign terlebih dahulu di Task 2</p>
                </div>
            `;
            return;
        }
        
        let html = '';
        links.forEach(link => {
            const productName = link.product_name || `Product ID: ${link.product_id}`;
            html += `
                <label style="display:flex; align-items:center; gap:12px; padding:12px; background:#0f1420; border-radius:12px; margin-bottom:8px; cursor:pointer; border:1px solid #2a3346; transition:all 0.2s;"
                       onmouseover="this.style.borderColor='#4ade80'"
                       onmouseout="this.style.borderColor='#2a3346'">
                    <input type="checkbox" class="sample-product-checkbox" 
                           data-product-id="${link.product_id}"
                           data-product-name="${escapeHtml(productName)}"
                           data-campaign-id="${link.campaign_id}"
                           style="width:18px; height:18px; cursor:pointer; accent-color:#4ade80;">
                    <div style="flex:1;">
                        <div style="color:#e2f0e8; font-size:13px; font-weight:500;">
                            <i class="fas fa-box" style="color:#4ade80; margin-right:8px;"></i>
                            ${escapeHtml(productName.substring(0, 60))}
                        </div>
                        <div style="display:flex; gap:12px; margin-top:4px; flex-wrap:wrap;">
                            <span style="color:#fbbf24; font-size:10px;"><i class="fas fa-percent"></i> Komisi: ${link.commission_rate}%</span>
                            <span style="color:#8b5cf6; font-size:10px;"><i class="fas fa-bullhorn"></i> Campaign: ${escapeHtml(link.campaign_name || '-')}</span>
                        </div>
                    </div>
                    <div style="color:#4ade80;">
                        <i class="fas fa-chevron-right"></i>
                    </div>
                </label>
            `;
        });
        
        container.innerHTML = html;
        
    } catch (error) {
        console.error('Error loading products:', error);
        container.innerHTML = `
            <div style="text-align:center; padding:20px; color:#ef4444;">
                <i class="fas fa-exclamation-triangle"></i>
                <p>Error loading products: ${error.message}</p>
            </div>
        `;
    }
}

// ========== LOAD REKOMENDASI PRODUK ==========
async function loadRecommendedProducts(creatorCategory) {
    const container = document.getElementById('recommendedProducts');
    if (!container) return;
    
    try {
        // Ambil campaign yang aktif
        const response = await fetch(baseUrlIS + 'is/get_campaign_products', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: new URLSearchParams({ 
                campaign_id: '',  // Semua campaign
                creator_category: creatorCategory || ''
            })
        });
        const data = await response.json();
        
        if (data.success && data.products && data.products.length > 0) {
            let html = '';
            data.products.slice(0, 5).forEach(product => {
                html += `
                <div style="display:flex; justify-content:space-between; align-items:center; padding:10px; border-bottom:1px solid #2a3346;">
                    <div style="flex:1;">
                        <div style="color:#e2f0e8; font-size:12px;">${escapeHtml(product.product_name || 'Unknown').substring(0, 50)}</div>
                        <div style="display:flex; gap:8px; margin-top:4px;">
                            <span style="color:#4ade80; font-size:10px;">Rp ${formatNumber(product.price)}</span>
                            <span style="color:#fbbf24; font-size:10px;">${product.commission_rate / 100}%</span>
                        </div>
                    </div>
                    <button class="sample-recommend-btn" data-product-id="${product.product_id}" 
                        data-product-name="${escapeHtml(product.product_name || '')}"
                        style="background:#4ade80; color:#0a0e17; border:none; padding:6px 12px; border-radius:20px; cursor:pointer; font-size:10px; white-space:nowrap;">
                        <i class="fas fa-box"></i> Sample
                    </button>
                </div>`;
            });
            container.innerHTML = html;
            
            // Attach event listeners
            document.querySelectorAll('.sample-recommend-btn').forEach(btn => {
                btn.addEventListener('click', () => {
                    const productName = btn.getAttribute('data-product-name');
                    showToastGlobal(`Produk "${productName}" ditambahkan ke sample!`, 'success');
                    btn.style.background = '#fbbf24';
                    btn.innerHTML = '<i class="fas fa-check"></i> Dipilih';
                    btn.setAttribute('data-selected', 'true');
                });
            });
        } else {
            container.innerHTML = '<div style="text-align:center; padding:20px; color:#9aaebe;">Tidak ada produk tersedia</div>';
        }
    } catch (error) {
        container.innerHTML = '<div style="text-align:center; padding:20px; color:#ef4444;">Error loading produk</div>';
    }
}

function renderSampleProductsList(links) {
    if (!links || links.length === 0) {
        return '<div style="text-align:center; padding:20px; color:#9aaebe;"><i class="fas fa-box-open" style="font-size:32px; margin-bottom:10px; display:block;"></i>Belum ada link afiliasi yang digenerate untuk creator ini</div>';
    }
    
    let html = '';
    links.forEach((link) => {
        let productName = link.product_name || `Product ID: ${link.product_id}`;
        const commissionRate = parseFloat(link.commission_rate || 0).toFixed(2);
        const campaignName = link.campaign_name || '';
        
        html += `
            <label style="display:flex; align-items:center; gap:12px; padding:12px; background:#0f1420; border-radius:12px; margin-bottom:8px; cursor:pointer; border:1px solid #2a3346;" 
                   onmouseover="this.style.borderColor='#4ade80'" 
                   onmouseout="this.style.borderColor='#2a3346'">
                <input type="radio" name="sample_product" value="${link.product_id}" 
                       data-product-name="${escapeHtml(productName)}" 
                       data-commission="${commissionRate}"
                       style="width:18px; height:18px; cursor:pointer;">
                <div style="flex:1;">
                    <div style="color:#e2f0e8; font-size:13px; font-weight:500;">
                        <i class="fas fa-box" style="color:#4ade80; margin-right:8px;"></i>
                        ${escapeHtml(productName)}
                    </div>
                    <div style="display:flex; gap:16px; margin-top:6px; flex-wrap:wrap;">
                        <span style="color:#fbbf24; font-size:11px;"><i class="fas fa-percent"></i> Komisi: ${commissionRate}%</span>
                        ${campaignName ? `<span style="color:#9aaebe; font-size:11px;"><i class="fas fa-bullhorn"></i> ${escapeHtml(campaignName)}</span>` : ''}
                        <span style="color:#9aaebe; font-size:11px;"><i class="fas fa-calendar"></i> Dibuat: ${formatDate(link.created_at)}</span>
                    </div>
                </div>
                <div style="color:#4ade80;"><i class="fas fa-chevron-right"></i></div>
            </label>
        `;
    });
    return html;
}

function formatDate(dateString) {
    if (!dateString) return '-';
    const date = new Date(dateString);
    return date.toLocaleDateString('id-ID');
}



// ========== TASK 4: MONITORING (REWRITE) ==========
async function loadTask4CreatorsIS() {
    const response = await fetch(baseUrlIS + 'is/get_creators_by_status', {
        method: 'POST', 
        body: new URLSearchParams({ status: 'ACTIVE' })
    });
    const result = await response.json();
    const container = document.getElementById('monitoringContainerDashboard');
    const countSpan = document.getElementById('monitoringCountDashboard');
    
    if (result.success && result.data.length > 0) {
        // Filter yang punya order atau auto_activated
        const monitoringCreators = [];
        
        for (const creator of result.data) {
            const perfRes = await fetch(baseUrlIS + 'is/get_creator_realtime_performance', {
                method: 'POST',
                body: new URLSearchParams({ creator_id: creator.id, days: 30 })
            });
            const perfData = await perfRes.json();
            
            if (perfData.success && perfData.summary.total_orders > 0) {
                monitoringCreators.push({
                    ...creator,
                    total_gmv: perfData.summary.total_gmv,
                    total_orders: perfData.summary.total_orders,
                    total_commission: perfData.summary.total_estimated_commission,
                    roas: perfData.summary.total_gmv > 0 && perfData.summary.total_estimated_commission > 0 
                        ? (perfData.summary.total_gmv / perfData.summary.total_estimated_commission).toFixed(1) 
                        : 0
                });
            }
        }
        
        // Sort by GMV
        monitoringCreators.sort((a, b) => b.total_gmv - a.total_gmv);
        
        if (countSpan) countSpan.innerText = monitoringCreators.length;
        let html = '';
        
        monitoringCreators.forEach((creator, index) => {
            const medal = index === 0 ? '1' : (index === 1 ? '2' : (index === 2 ? '3' : ''));
        
            const hasPhone = creator.phone && creator.phone !== '' && creator.phone !== '-';
            const phoneDisplay = hasPhone 
                ? `<span style="color:#4ade80;"><i class="fab fa-whatsapp"></i> ${creator.phone}</span>` 
                : `<span style="color:#ef4444;"><i class="fab fa-whatsapp"></i> No WA</span>`;
            
            // �9�7 NAMA PETUGAS IS
            const isName = creator.is_full_name || creator.is_username || '-';
            const isDisplay = isName !== '-' ? `<span style="color:#8b5cf6; font-size:9px;"><i class="fas fa-user-tie"></i> ${escapeHtml(isName)}</span>` : '';
            
            html += `
<div class="stage-item-dashboard monitor-item-dashboard" 
     data-creator-id="${creator.id}" 
     data-creator-name="${escapeHtml(creator.username)}">
    <div style="display:flex; justify-content:space-between; align-items:center;">
        <strong>${medal} <i class="fab fa-tiktok"></i> ${escapeHtml(creator.username)}</strong>
        <div style="display:flex; gap:6px; align-items:center;">
            ${isDisplay}
            <span class="badge-dashboard badge-active"><i class="fas fa-check-circle"></i> ACTIVE</span>
        </div>
    </div>
    <div class="item-details-dashboard">
        <span><i class="fas fa-money-bill-wave"></i> GMV: Rp ${formatNumber(creator.total_gmv)}</span>
        <span><i class="fas fa-chart-line"></i> ROAS: ${creator.roas}x</span>
        <span><i class="fas fa-shopping-cart"></i> Orders: ${creator.total_orders}</span>
    </div>
    <div class="item-details-dashboard">
        <span><i class="fas fa-tag"></i> ${escapeHtml(creator.category || '-')}</span>
        ${phoneDisplay}
        ${!hasPhone ? `
        <button class="edit-wa-task4-btn" data-creator-id="${creator.id}" data-creator-name="${escapeHtml(creator.username)}"
            style="background:#fbbf24; color:#0a0e17; border:none; padding:2px 8px; border-radius:10px; cursor:pointer; font-size:9px; margin-left:8px;">
            <i class="fas fa-edit"></i> Tambah WA
        </button>` : ''}
    </div>
    <div style="margin-top:8px; display:flex; gap:6px;">
        <button class="view-monitoring-detail-btn" data-creator-id="${creator.id}"
            style="background:#8b5cf6; color:white; border:none; padding:4px 12px; border-radius:20px; cursor:pointer; font-size:10px;">
            <i class="fas fa-eye"></i> Detail
        </button>
        <button class="add-product-monitor-btn" data-creator-id="${creator.id}"
            data-creator-name="${escapeHtml(creator.username)}"
            data-creator-category="${escapeHtml(creator.category || '')}"
            data-creator-phone="${escapeHtml(creator.phone || '')}"
            style="background:#4ade80; color:#0a0e17; border:none; padding:4px 12px; border-radius:20px; cursor:pointer; font-size:10px;">
            <i class="fas fa-plus"></i> Tambah Product
        </button>
    </div>
</div>`;
        });
        
        container.innerHTML = html || '<div class="stage-item-dashboard">Belum ada creator dengan penjualan</div>';
        
        // Event: Detail Monitoring
        document.querySelectorAll('.view-monitoring-detail-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                e.stopPropagation();
                const creatorId = btn.getAttribute('data-creator-id');
                showMonitoringDetailModal(creatorId);
            });
        });

        // Event: Edit WA
        document.querySelectorAll('.edit-wa-task4-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                e.stopPropagation();
                const cid = btn.getAttribute('data-creator-id');
                const cname = btn.getAttribute('data-creator-name');
                showQuickEditPhoneModal(cid, cname, '');
            });
        });
        
        // Event: Tambah Product
        document.querySelectorAll('.add-product-monitor-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                e.stopPropagation();
                const creatorId = btn.getAttribute('data-creator-id');
                const creatorName = btn.getAttribute('data-creator-name');
                const creatorCategory = btn.getAttribute('data-creator-category');
                const creatorPhone = btn.getAttribute('data-creator-phone');
                
                currentCreatorId = creatorId;
                currentCreatorName = creatorName;
                currentCreatorCategory = creatorCategory;
                currentCreatorPhone = creatorPhone;
                
                showLinkAssignmentModal(creatorId, creatorName, creatorCategory, creatorPhone);
            });
        });
    } else {
        if (countSpan) countSpan.innerText = '0';
        container.innerHTML = '<div class="stage-item-dashboard"><strong><i class="fas fa-info-circle"></i> Belum ada creator aktif</strong></div>';
    }
}
// ========== MODAL MONITORING DETAIL ==========
async function showMonitoringDetailModal(creatorId) {
    document.getElementById('modalTitleDashboard').innerHTML = '<i class="fas fa-chart-line"></i> Loading...';
    document.getElementById('modalBodyDashboard').innerHTML = `
        <div style="text-align:center; padding:40px;">
            <i class="fas fa-spinner fa-pulse fa-2x" style="color:#8b5cf6;"></i>
        </div>
    `;
    openModalIS();
    
    try {
        const response = await fetch(baseUrlIS + 'is/get_monitoring_detail', {
            method: 'POST',
            body: new URLSearchParams({ creator_id: creatorId })
        });
        const result = await response.json();
        
        if (!result.success) {
            document.getElementById('modalBodyDashboard').innerHTML = `
                <div style="text-align:center; padding:40px; color:#ef4444;">
                    <p>${result.message || 'Gagal memuat data'}</p>
                    <button onclick="closeModalIS()" style="margin-top:12px; background:#1e293b; color:#e2f0e8; padding:8px 16px; border-radius:8px; border:1px solid #2a3346; cursor:pointer;">Tutup</button>
                </div>
            `;
            return;
        }
        
        const c = result.creator;
        const perf = result.performance;
        const links = result.links || [];
        const contents = result.contents || [];
        const daily = result.daily_performance || [];
        
        document.getElementById('modalTitleDashboard').innerHTML = `<i class="fas fa-chart-line"></i> Monitoring: @${escapeHtml(c.username)}`;
        
        let html = '';
        
        // ========== HEADER ==========
        html += `
        <div style="background:rgba(139,92,246,0.1); border-radius:14px; padding:14px; margin-bottom:16px;">
            <div style="display:grid; grid-template-columns:1fr 1fr; gap:12px;">
                <div>
                    <div style="color:#9aaebe; font-size:10px;">Creator</div>
                    <div style="color:#e2f0e8; font-size:15px; font-weight:600;">@${escapeHtml(c.username)}</div>
                </div>
                <div>
                    <div style="color:#9aaebe; font-size:10px;">Kategori</div>
                    <div style="color:#e2f0e8; font-size:13px;">${escapeHtml(c.category || '-')}</div>
                </div>
                <div>
                    <div style="color:#9aaebe; font-size:10px;">Status</div>
                    <span class="badge-dashboard badge-active">ACTIVE</span>
                </div>
                <div>
                    <div style="color:#9aaebe; font-size:10px;">WhatsApp</div>
                    <div style="color:${c.phone ? '#4ade80' : '#ef4444'}; font-size:13px;">${escapeHtml(c.phone || 'Tidak ada')}</div>
                </div>
            </div>
        </div>`;
        
        // ========== PERFORMANCE ==========
        html += `
        <div style="background:#0f1420; border-radius:14px; padding:14px; margin-bottom:12px;">
            <h4 style="color:#e2f0e8; margin:0 0 12px 0; font-size:13px;"><i class="fas fa-chart-bar"></i> Performance (30 Hari)</h4>
            <div style="display:grid; grid-template-columns:repeat(4,1fr); gap:8px; text-align:center;">
                <div style="background:#1e293b; border-radius:10px; padding:10px;">
                    <div style="color:#4ade80; font-size:16px; font-weight:700;">Rp ${formatNumber(perf.total_gmv)}</div>
                    <div style="color:#9aaebe; font-size:9px;">Total GMV</div>
                </div>
                <div style="background:#1e293b; border-radius:10px; padding:10px;">
                    <div style="color:#fbbf24; font-size:16px; font-weight:700;">${perf.total_orders}</div>
                    <div style="color:#9aaebe; font-size:9px;">Orders</div>
                </div>
                <div style="background:#1e293b; border-radius:10px; padding:10px;">
                    <div style="color:#8b5cf6; font-size:16px; font-weight:700;">${perf.roas}x</div>
                    <div style="color:#9aaebe; font-size:9px;">ROAS</div>
                </div>
                <div style="background:#1e293b; border-radius:10px; padding:10px;">
                    <div style="color:#f59e0b; font-size:16px; font-weight:700;">Rp ${formatNumber(perf.total_commission)}</div>
                    <div style="color:#9aaebe; font-size:9px;">Commission</div>
                </div>
            </div>
            ${perf.last_order ? `
            <div style="margin-top:8px; display:flex; justify-content:space-between; font-size:10px; color:#9aaebe;">
                <span>First Order: ${new Date(perf.first_order).toLocaleDateString('id-ID')}</span>
                <span>Last Order: ${new Date(perf.last_order).toLocaleDateString('id-ID')}</span>
            </div>` : ''}
        </div>`;
        
        // ========== VIDEOS / CONTENT ==========
        if (contents.length > 0) {
            html += `
            <div style="background:#0f1420; border-radius:14px; padding:14px; margin-bottom:12px;">
                <h4 style="color:#e2f0e8; margin:0 0 12px 0; font-size:13px;"><i class="fab fa-tiktok"></i> Konten Creator</h4>
                <div style="display:flex; gap:8px; overflow-x:auto; padding-bottom:8px;">`;
            
            contents.forEach(c => {
                const videoUrl = c.linked_tiktok_video || c.source_url || '#';
                html += `
                <a href="${videoUrl}" target="_blank" style="text-decoration:none; flex-shrink:0; width:140px;">
                    <div style="background:#1e293b; border-radius:10px; overflow:hidden; border:1px solid #2a3346;">
                        <div style="height:80px; background:#111827; display:flex; align-items:center; justify-content:center;">
                            ${c.cover_img_url 
                                ? `<img src="${escapeHtml(c.cover_img_url)}" style="width:100%; height:100%; object-fit:cover;" onerror="this.style.display='none'">`
                                : '<i class="fab fa-tiktok" style="font-size:32px; color:#8b5cf6;"></i>'}
                        </div>
                        <div style="padding:6px;">
                            <div style="color:#e2f0e8; font-size:10px;"> ${formatNumberShort(c.view_count)}</div>
                            <div style="color:#9aaebe; font-size:9px;"> ${formatNumberShort(c.like_count)} |  ${formatNumberShort(c.comment_count)}</div>
                            <div style="color:#4ade80; font-size:9px;"> ${c.paid_order_count} orders</div>
                        </div>
                    </div>
                </a>`;
            });
            
            html += `</div></div>`;
        }
        
        // ========== ACTIVE LINKS ==========
        if (links.length > 0) {
            html += `
            <div style="background:#0f1420; border-radius:14px; padding:14px; margin-bottom:12px;">
                <h4 style="color:#e2f0e8; margin:0 0 12px 0; font-size:13px;"><i class="fas fa-link"></i> Active Links (${links.length})</h4>
                <div style="max-height:200px; overflow-y:auto;">`;
            
            links.forEach(link => {
                html += `
                <div style="display:flex; justify-content:space-between; padding:8px; border-bottom:1px solid #2a3346; font-size:10px;">
                    <div style="flex:1;">
                        <div style="color:#e2f0e8;">${escapeHtml((link.product_name || '').substring(0, 40))}</div>
                        <div style="display:flex; gap:8px; margin-top:2px;">
                            <span style="color:#4ade80;">GMV: Rp ${formatNumber(link.link_gmv || 0)}</span>
                            <span style="color:#9aaebe;">Orders: ${link.link_orders || 0}</span>
                            <span style="color:#fbbf24;">${link.commission_rate}%</span>
                        </div>
                        ${link.handler_name ? `<div style="color:#8b5cf6; font-size:8px; margin-top:2px;"><i class="fas fa-user"></i> Handler: ${escapeHtml(link.handler_name)}</div>` : ''}
                    </div>
                    <a href="${link.affiliate_link || '#'}" target="_blank" style="color:#8b5cf6; font-size:9px;">
                        <i class="fas fa-external-link-alt"></i>
                    </a>
                </div>`;
            });
            
            html += `</div></div>`;
        }
        
        // ========== TAMBAH PRODUCT BUTTON ==========
        html += `
        <button id="addProductFromMonitoringBtn" style="width:100%; background:#4ade80; color:#0a0e17; border:none; padding:12px; border-radius:12px; cursor:pointer; font-weight:600; font-size:13px; margin-top:12px;">
            <i class="fas fa-plus"></i> Tambah Product Baru untuk Creator Ini
        </button>
        
        <button id="closeMonitoringBtn" style="width:100%; background:#1e293b; color:#e2f0e8; border:1px solid #2a3346; padding:10px; border-radius:12px; cursor:pointer; font-size:12px; margin-top:8px;">
            Tutup
        </button>`;
        
        document.getElementById('modalBodyDashboard').innerHTML = html;
        
        // Event: Tambah Product
        document.getElementById('addProductFromMonitoringBtn')?.addEventListener('click', () => {
            closeModalIS();
            // Buka modal assign link (Task 2 style)
            setTimeout(() => {
                currentCreatorId = c.id;
                currentCreatorName = c.username;
                currentCreatorCategory = c.category || '';
                currentCreatorPhone = c.phone || '';
                showLinkAssignmentModal(c.id, c.username, c.category || '', c.phone || '');
            }, 300);
        });
        
        document.getElementById('closeMonitoringBtn')?.addEventListener('click', closeModalIS);
        
    } catch (error) {
        document.getElementById('modalBodyDashboard').innerHTML = `
            <div style="text-align:center; padding:40px; color:#ef4444;">
                <p>Error: ${error.message}</p>
                <button onclick="closeModalIS()" style="margin-top:12px;">Tutup</button>
            </div>
        `;
    }
}

async function showCreatorPerformanceModalIS(creatorId, creatorName) {
    const response = await fetch(baseUrlIS + 'is/get_creator_realtime_performance', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: new URLSearchParams({ creator_id: creatorId, days: 30 })
    });
    const result = await response.json();
    
    if (!result.success) {
        showToastGlobal('Gagal mengambil data performa', 'error');
        return;
    }
    
    document.getElementById('modalTitleDashboard').innerHTML = `<i class="fas fa-chart-line"></i> Performance - ${creatorName}`;
    document.getElementById('modalBodyDashboard').innerHTML = `
        <div style="background:rgba(74,222,128,0.1); border-radius:14px; padding:14px; margin-bottom:16px;">
            <div style="display:grid; grid-template-columns:1fr 1fr; gap:12px;">
                <div><div style="color:#9aaebe; font-size:11px;">Total GMV</div><div style="color:#4ade80; font-size:18px; font-weight:700;">Rp ${formatNumber(result.summary.total_gmv)}</div></div>
                <div><div style="color:#9aaebe; font-size:11px;">Total Orders</div><div style="color:#4ade80; font-size:18px; font-weight:700;">${result.summary.total_orders}</div></div>
                <div><div style="color:#9aaebe; font-size:11px;">Estimated Commission</div><div style="color:#fbbf24; font-size:14px; font-weight:600;">Rp ${formatNumber(result.summary.total_estimated_commission)}</div></div>
                <div><div style="color:#9aaebe; font-size:11px;">Completed Orders</div><div style="color:#10b981; font-size:14px; font-weight:600;">${result.summary.completed_orders || 0}</div></div>
            </div>
        </div>
        <div style="margin-bottom:16px;">
            <label><i class="fas fa-chart-simple"></i> Campaign Breakdown</label>
            <div style="background:#0f1420; border-radius:12px; padding:8px;">${renderCampaignBreakdown(result.campaign_breakdown || [])}</div>
        </div>
        <div><label><i class="fas fa-history"></i> Recent Orders (30 hari)</label><div style="max-height:250px; overflow-y:auto; background:#0f1420; border-radius:12px; padding:8px;">${renderRecentOrders(result.recent_orders || [])}</div></div>
        <div class="flex-buttons" style="margin-top:16px;"><button id="closePerfBtn" style="background:#1e293b;">Tutup</button></div>
    `;
    openModalIS();
    document.getElementById('closePerfBtn').addEventListener('click', closeModalIS);
}

function renderCampaignBreakdown(campaigns) {
    if (!campaigns || campaigns.length === 0) return '<div style="text-align:center; padding:20px; color:#9aaebe;">Belum ada data campaign</div>';
    let html = '';
    campaigns.forEach(camp => {
        html += `<div style="display:flex; justify-content:space-between; padding:8px; border-bottom:1px solid #2a3346;"><div style="color:#e2f0e8; font-size:12px;">${escapeHtml(camp.campaign_name || camp.campaign_id)}</div><div style="color:#4ade80; font-size:12px;">Rp ${formatNumber(camp.gmv)}</div></div>`;
    });
    return html;
}

function renderRecentOrders(orders) {
    if (!orders || orders.length === 0) return '<div style="text-align:center; padding:20px; color:#9aaebe;">Belum ada pesanan</div>';
    let html = '<table style="width:100%; font-size:11px;"><thead><tr><th>Tanggal</th><th>Produk</th><th>GMV</th><th>Status</th></tr></thead><tbody>';
    orders.forEach(order => {
        html += `<tr style="border-bottom:1px solid #2a3346;"><td style="padding:6px;">${order.order_date || '-'}</td><td style="padding:6px;">${escapeHtml(order.product_name || '-').substring(0, 30)}</td><td style="padding:6px; color:#4ade80;">Rp ${formatNumber(order.gmv)}</td><td style="padding:6px;"><span class="order-status ${order.order_status?.toLowerCase()}">${order.order_status || '-'}</span></td></tr>`;
    });
    html += '</tbody></table>';
    return html;
}

// ========== TAB SWITCHING ==========
document.querySelectorAll('.tab-btn-dashboard').forEach(btn => {
    btn.addEventListener('click', () => {
        const tabId = btn.getAttribute('data-tab');
        document.querySelectorAll('.tab-content-dashboard').forEach(c => c.classList.remove('active'));
        document.querySelectorAll('.tab-btn-dashboard').forEach(b => b.classList.remove('active'));
        document.getElementById(tabId).classList.add('active');
        btn.classList.add('active');
        document.querySelectorAll('.mobile-nav-item-dashboard').forEach(nav => {
            if (nav.getAttribute('data-tab') === tabId) nav.classList.add('active');
            else nav.classList.remove('active');
        });
    });
});

document.querySelectorAll('.mobile-nav-item-dashboard').forEach(item => {
    item.addEventListener('click', (e) => {
        e.preventDefault();
        const tabId = item.getAttribute('data-tab');
        document.querySelector(`.tab-btn-dashboard[data-tab="${tabId}"]`)?.click();
    });
});

document.getElementById('closeTaskModalDashboard').addEventListener('click', closeModalIS);
document.getElementById('taskModalDashboard').addEventListener('click', (e) => {
    if (e.target === document.getElementById('taskModalDashboard')) closeModalIS();
});

// ========== FUNGSI SEARCH UNTUK SETIAP TASK ==========
function initSearchTask(searchInputId, containerId, itemClass) {
    const searchInput = document.getElementById(searchInputId);
    if (!searchInput) return;
    
    searchInput.addEventListener('keyup', function() {
        const searchTerm = this.value.toLowerCase();
        const container = document.getElementById(containerId);
        if (!container) return;
        
        const items = container.querySelectorAll(itemClass);
        let visibleCount = 0;
        
        items.forEach(function(item) {
            const searchable = item.getAttribute('data-searchable') || '';
            if (searchable.indexOf(searchTerm) > -1) {
                item.style.display = '';
                visibleCount++;
            } else {
                item.style.display = 'none';
            }
        });
        
        let countSpan = null;
        if (searchInputId === 'searchScoutingDashboard') countSpan = document.getElementById('scoutingCountDashboard');
        else if (searchInputId === 'searchLinkSwappingDashboard') countSpan = document.getElementById('linkCountDashboard');
        else if (searchInputId === 'searchSampleDashboard') countSpan = document.getElementById('sampleCountDashboard');
        else if (searchInputId === 'searchMonitoringDashboard') countSpan = document.getElementById('monitoringCountDashboard');
        
        if (countSpan) countSpan.innerText = visibleCount;
        
        const noResultDiv = container.querySelector('.no-search-result');
        if (visibleCount === 0 && searchTerm !== '') {
            if (!noResultDiv) {
                const noResult = document.createElement('div');
                noResult.className = 'stage-item-dashboard no-search-result';
                noResult.setAttribute('data-no-result', 'true');
                noResult.innerHTML = '<strong><i class="fas fa-search"></i> Tidak ada yang cocok</strong><div class="item-details-dashboard">Coba kata kunci lain (username atau brand)</div>';
                container.appendChild(noResult);
            }
        } else {
            if (noResultDiv) noResultDiv.remove();
        }
    });
}
// ========== QUICK EDIT PHONE MODAL ==========
function showQuickEditPhoneModal(creatorId, creatorName, currentPhone) {
    const modalTitle = document.getElementById('modalTitleDashboard');
    const modalBody = document.getElementById('modalBodyDashboard');
    
    modalTitle.innerHTML = `<i class="fab fa-whatsapp"></i> Update WhatsApp - @${escapeHtml(creatorName)}`;
    modalBody.innerHTML = `
        <div style="background:rgba(251,191,36,0.1); border-radius:14px; padding:12px; margin-bottom:16px; border-left:3px solid #fbbf24;">
            <p style="color:#fbbf24; font-size:12px;"><i class="fas fa-exclamation-triangle"></i> Nomor WhatsApp diperlukan untuk mengirim link & sample</p>
        </div>
        
        <label><i class="fab fa-whatsapp"></i> Nomor WhatsApp</label>
        <input type="tel" id="quickEditPhone" placeholder="+62 812 3456 7890" value="${escapeHtml(currentPhone || '')}" 
            style="width:100%; padding:12px; background:#0f1420; border:2px solid #fbbf24; border-radius:12px; color:#e2f0e8; font-size:14px; margin-bottom:12px;">
        <div style="font-size:11px; color:#9aaebe; margin-bottom:16px;">
            <i class="fas fa-info-circle"></i> Format: +628123456789 atau 08123456789
        </div>
        
        <div class="flex-buttons">
            <button id="saveQuickPhoneBtn" style="background:#4ade80; color:#0a0e17; flex:1; padding:12px; border:none; border-radius:12px; cursor:pointer; font-weight:600;">
                <i class="fas fa-save"></i> Simpan
            </button>
            <button id="cancelQuickPhoneBtn" style="background:#1e293b; flex:1; padding:12px; border:1px solid #2a3346; border-radius:12px; cursor:pointer;">
                Batal
            </button>
        </div>
    `;
    openModalIS();
    
    document.getElementById('saveQuickPhoneBtn').addEventListener('click', async () => {
        let phone = document.getElementById('quickEditPhone').value.trim();
        
        if (!phone) {
            showToastGlobal('Nomor WhatsApp tidak boleh kosong', 'error');
            return;
        }
        
        const btn = document.getElementById('saveQuickPhoneBtn');
        btn.disabled = true;
        btn.innerHTML = '<i class="fas fa-spinner fa-pulse"></i> Menyimpan...';
        
        try {
            const response = await fetch(baseUrlIS + 'is/update_creator_phone', {
                method: 'POST',
                body: new URLSearchParams({ creator_id: creatorId, phone: phone })
            });
            const result = await response.json();
            
            if (result.success) {
                closeModalIS();
                showToastGlobal(`WhatsApp @${creatorName} berhasil diupdate!`, 'success');
                setTimeout(() => location.reload(), 1500);
            } else {
                showToastGlobal(result.message || 'Gagal update', 'error');
                btn.disabled = false;
                btn.innerHTML = '<i class="fas fa-save"></i> Simpan';
            }
        } catch (error) {
            showToastGlobal('Error: ' + error.message, 'error');
            btn.disabled = false;
            btn.innerHTML = '<i class="fas fa-save"></i> Simpan';
        }
    });
    
    document.getElementById('cancelQuickPhoneBtn').addEventListener('click', closeModalIS);
}
function initAllSearches() {
    setTimeout(() => {
        // �9�7 TASK 1: SCOUTING - hanya PENDING
        const scoutingInput = document.getElementById('searchScoutingDashboard');
        if (scoutingInput) {
            initDatabaseSearch('searchScoutingDashboard', 'scoutingContainerDashboard', 'scouting');
        }
        
        // �9�7 TASK 2: LINK SWAPPING - hanya ACTIVE (belum punya order/auto activated)
        const linkInput = document.getElementById('searchLinkSwappingDashboard');
        if (linkInput) {
            initDatabaseSearch('searchLinkSwappingDashboard', 'linkSwappingContainerDashboard', 'link_swapping');
        }
        
        // �9�7 TASK 3: SAMPLE - hanya LINK_SENT atau SAMPLE_SENT
        const sampleInput = document.getElementById('searchSampleDashboard');
        if (sampleInput) {
            initDatabaseSearch('searchSampleDashboard', 'sendingSampleContainerDashboard', 'sample');
        }
        
        // �9�7 TASK 4: MONITORING - hanya ACTIVE yang sudah auto activated atau punya order
        const monitoringInput = document.getElementById('searchMonitoringDashboard');
        if (monitoringInput) {
            initDatabaseSearch('searchMonitoringDashboard', 'monitoringContainerDashboard', 'monitoring');
        }
    }, 1000);
}
const originalLoadTask2 = loadTask2CreatorsIS;
loadTask2CreatorsIS = async function() {
    await originalLoadTask2();
    setTimeout(() => {
        document.querySelectorAll('#linkSwappingContainerDashboard .link-item-dashboard').forEach(item => {
            const name = item.getAttribute('data-creator-name') || '';
            item.setAttribute('data-searchable', name.toLowerCase());
        });
        initSearchTask('searchLinkSwappingDashboard', 'linkSwappingContainerDashboard', '.link-item-dashboard');
    }, 500);
};

const originalLoadTask3 = loadTask3CreatorsIS;
loadTask3CreatorsIS = async function() {
    await originalLoadTask3();
    setTimeout(() => {
        document.querySelectorAll('#sendingSampleContainerDashboard .sample-item-dashboard').forEach(item => {
            const name = item.getAttribute('data-creator-name') || '';
            item.setAttribute('data-searchable', name.toLowerCase());
        });
        initSearchTask('searchSampleDashboard', 'sendingSampleContainerDashboard', '.sample-item-dashboard');
    }, 500);
};

const originalLoadTask4 = loadTask4CreatorsIS;
loadTask4CreatorsIS = async function() {
    await originalLoadTask4();
    setTimeout(() => {
        document.querySelectorAll('#monitoringContainerDashboard .monitor-item-dashboard').forEach(item => {
            const name = item.getAttribute('data-creator-name') || '';
            item.setAttribute('data-searchable', name.toLowerCase());
        });
        initSearchTask('searchMonitoringDashboard', 'monitoringContainerDashboard', '.monitor-item-dashboard');
    }, 500);
};

// ========== IMPORT CREATOR FUNCTIONS ==========
let importFile = null;
let importBrandId = null;
let importBrandName = null;

document.getElementById('importCreatorBtnDashboard')?.addEventListener('click', () => {
    document.getElementById('importModalDashboard').classList.add('active');
    document.getElementById('importStep1').style.display = 'block';
    document.getElementById('importStep2').style.display = 'none';
    document.getElementById('importStep3').style.display = 'none';
    document.getElementById('importFileInput').value = '';
    
    const brandSelect = document.getElementById('importBrandSelect');
    if (brandSelect) brandSelect.value = '';
});

document.getElementById('previewImportBtn')?.addEventListener('click', async () => {
    const brandSelect = document.getElementById('importBrandSelect');
    const brandId = brandSelect?.value;
    const brandName = brandSelect?.options[brandSelect.selectedIndex]?.text;
    
    if (!brandId) {
        showToastGlobal('Pilih brand terlebih dahulu', 'error');
        return;
    }
    
    const fileInput = document.getElementById('importFileInput');
    if (!fileInput.files || !fileInput.files[0]) {
        showToastGlobal('Pilih file terlebih dahulu', 'error');
        return;
    }
    
    importBrandId = brandId;
    importBrandName = brandName;
    
    const file = fileInput.files[0];
    const formData = new FormData();
    formData.append('import_file', file);
    formData.append('action', 'preview');
    formData.append('brand_id', brandId);
    formData.append('col_username', document.getElementById('colMappingUsername')?.value || 1);
    formData.append('col_fullname', document.getElementById('colMappingFullname')?.value || 0);
    formData.append('col_category', document.getElementById('colMappingCategory')?.value || 2);
    formData.append('col_phone', document.getElementById('colMappingPhone')?.value || -1);
    
    const previewBtn = document.getElementById('previewImportBtn');
    previewBtn.disabled = true;
    previewBtn.innerHTML = '<i class="fas fa-spinner fa-pulse"></i> Loading...';
    
    try {
        const response = await fetch(baseUrlIS + 'is/import_creators', {
            method: 'POST',
            body: formData
        });
        const result = await response.json();
        
        if (result.success) {
            document.getElementById('previewBrandInfo').innerHTML = `
                <div style="display: flex; align-items: center; gap: 12px;">
                    <i class="fas fa-store" style="color: #4ade80; font-size: 24px;"></i>
                    <div>
                        <div style="color: #e2f0e8; font-weight: 600;">Brand: ${escapeHtml(result.brand_info.name)}</div>
                        <div style="color: #9aaebe; font-size: 11px;">Shop: ${escapeHtml(result.brand_info.shop_name || '-')}</div>
                    </div>
                </div>
            `;
            
            const statsHtml = `
                <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 12px; text-align: center;">
                    <div>
                        <div style="color: #4ade80; font-size: 24px; font-weight: bold;">${result.total_rows}</div>
                        <div style="color: #9aaebe; font-size: 11px;">Total Data</div>
                    </div>
                    <div>
                        <div style="color: #fbbf24; font-size: 24px; font-weight: bold;">${result.new_count}</div>
                        <div style="color: #9aaebe; font-size: 11px;">Creator Baru</div>
                    </div>
                    <div>
                        <div style="color: #9aaebe; font-size: 24px; font-weight: bold;">${result.exists_count}</div>
                        <div style="color: #9aaebe; font-size: 11px;">Sudah Ada</div>
                    </div>
                </div>
            `;
            document.getElementById('previewStats').innerHTML = statsHtml;
            
            if (result.errors && result.errors.length > 0) {
                const errorsHtml = `<strong><i class="fas fa-exclamation-triangle"></i> Error pada data:</strong><br>
                    ${result.errors.map(e => `<div style="font-size: 11px;"> ${escapeHtml(e)}</div>`).join('')}`;
                document.getElementById('previewErrors').innerHTML = errorsHtml;
                document.getElementById('previewErrors').style.display = 'block';
            } else {
                document.getElementById('previewErrors').style.display = 'none';
            }
            
            let tableHtml = '<table style="width:100%; font-size:11px; border-collapse:collapse;">';
            tableHtml += '<thead><tr style="border-bottom:1px solid #2a3346;">';
            tableHtml += '<th style="padding:6px;">Username</th>';
            tableHtml += '<th style="padding:6px;">Nama</th>';
            tableHtml += '<th style="padding:6px;">Kategori</th>';
            tableHtml += '<th style="padding:6px;">GMV (28 Hari)</th>';
            tableHtml += '<th style="padding:6px;">Status</th>';
            tableHtml += '</tr></thead><tbody>';
            
            result.preview.forEach(creator => {
                const statusBadge = creator.status === 'NEW' 
                    ? '<span style="color:#4ade80;"> Baru</span>' 
                    : `<span style="color:#fbbf24;"> Sudah Ada (${creator.existing_status || '-'})</span>`;
                
               const gmvValue = creator.gmv_28days || 0;
                const gmvIdr = Math.round(gmvValue * 16000);  //  KONVERSI KE IDR
                const gmvDisplay = gmvValue > 0 ? 'Rp ' + formatNumber(gmvIdr) : '-';
                const gmvColor = gmvValue > 100000 ? '#fbbf24' : (gmvValue > 0 ? '#4ade80' : '#9aaebe');

               
                
                tableHtml += `<tr style="border-bottom:1px solid #2a3346;">
                    <td style="padding:6px;">@${escapeHtml(creator.username)}</td>
                    <td style="padding:6px;">${escapeHtml(creator.full_name || '-')}</td>
                    <td style="padding:6px;">${escapeHtml(creator.category || '-')}</td>
                    <td style="padding:6px; color:${gmvColor}; font-weight:${gmvValue > 0 ? '600' : 'normal'};">${gmvDisplay}</td>
                    <td style="padding:6px;">${statusBadge}</td>
                </tr>`;
            });
            
            tableHtml += '</tbody></table>';
            document.getElementById('previewTable').innerHTML = tableHtml;
            
            importFile = file;
            
            document.getElementById('importStep1').style.display = 'none';
            document.getElementById('importStep2').style.display = 'block';
            
        } else {
            showToastGlobal(result.message || 'Gagal preview file', 'error');
        }
    } catch (error) {
        showToastGlobal('Error: ' + error.message, 'error');
    } finally {
        previewBtn.disabled = false;
        previewBtn.innerHTML = '<i class="fas fa-eye"></i> Preview Data';
    }
});

document.getElementById('confirmImportBtn')?.addEventListener('click', async () => {
    if (!importFile || !importBrandId) {
        showToastGlobal('Tidak ada file atau brand untuk diimport', 'error');
        return;
    }
    
    const duplicateAction = document.querySelector('input[name="duplicate_action"]:checked')?.value || 'skip';
    const formData = new FormData();
    formData.append('import_file', importFile);
    formData.append('action', 'process');
    formData.append('brand_id', importBrandId);
    formData.append('skip_existing', duplicateAction === 'skip' ? 'true' : 'false');
    formData.append('col_username', document.getElementById('colMappingUsername')?.value || 1);
    formData.append('col_fullname', document.getElementById('colMappingFullname')?.value || 0);
    formData.append('col_category', document.getElementById('colMappingCategory')?.value || 2);
    formData.append('col_phone', document.getElementById('colMappingPhone')?.value || -1);
    
    const confirmBtn = document.getElementById('confirmImportBtn');
    confirmBtn.disabled = true;
    confirmBtn.innerHTML = '<i class="fas fa-spinner fa-pulse"></i> Importing...';
    
    try {
        const response = await fetch(baseUrlIS + 'is/import_creators', {
            method: 'POST',
            body: formData
        });
        const result = await response.json();
        
        if (result.success) {
            const resultHtml = `
                <div style="background: rgba(74,222,128,0.1); border-radius: 14px; padding: 20px;">
                    <i class="fas fa-check-circle" style="font-size: 48px; color: #4ade80;"></i>
                    <h3 style="margin: 16px 0; color: #e2f0e8;">Import Selesai!</h3>
                    <div style="text-align: left; max-width: 300px; margin: 0 auto;">
                        <div style="display: flex; justify-content: space-between; padding: 5px 0;">
                            <span> Brand:</span><span style="color:#4ade80;">${escapeHtml(result.brand_name)}</span>
                        </div>
                        <div style="display: flex; justify-content: space-between; padding: 5px 0;">
                            <span> Creator baru:</span><span style="color:#4ade80;">${result.inserted}</span>
                        </div>
                        <div style="display: flex; justify-content: space-between; padding: 5px 0;">
                            <span> Dilewati:</span><span style="color:#fbbf24;">${result.skipped}</span>
                        </div>
                        <div style="display: flex; justify-content: space-between; padding: 5px 0;">
                            <span> Gagal:</span><span style="color:#ef4444;">${result.failed}</span>
                        </div>
                    </div>
                    <p style="margin-top: 16px; color: #9aaebe;">${result.message}</p>
                </div>
            `;
            document.getElementById('importResult').innerHTML = resultHtml;
            
            document.getElementById('importStep2').style.display = 'none';
            document.getElementById('importStep3').style.display = 'block';
            
            setTimeout(() => {
                location.reload();
            }, 3000);
        } else {
            showToastGlobal(result.message || 'Gagal import', 'error');
            confirmBtn.disabled = false;
            confirmBtn.innerHTML = '<i class="fas fa-save"></i> Konfirmasi Import';
        }
    } catch (error) {
        showToastGlobal('Error: ' + error.message, 'error');
        confirmBtn.disabled = false;
        confirmBtn.innerHTML = '<i class="fas fa-save"></i> Konfirmasi Import';
    }
});

// ========== CREATOR STATUS TAB SWITCHING ==========
document.querySelectorAll('.creator-tab-btn').forEach(btn => {
    btn.addEventListener('click', () => {
        const tabId = btn.getAttribute('data-creator-tab');
        
        document.querySelectorAll('.creator-tab-btn').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        
        if (tabId === 'active') {
            document.getElementById('activeCreatorsList').style.display = 'block';
            document.getElementById('pendingCreatorsList').style.display = 'none';
        } else {
            document.getElementById('activeCreatorsList').style.display = 'none';
            document.getElementById('pendingCreatorsList').style.display = 'block';
        }
    });
});

document.querySelectorAll('.view-creator-detail').forEach(btn => {
    btn.addEventListener('click', () => {
        const creatorId = btn.getAttribute('data-creator-id');
        showCreatorDetailIS(creatorId);
    });
});

// ========== TOP CREATOR PERIOD FILTER ==========
document.querySelectorAll('.period-btn').forEach(btn => {
    btn.addEventListener('click', async () => {
        const period = btn.getAttribute('data-period');
        
        document.querySelectorAll('.period-btn').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        
        const gmvContainer = document.getElementById('topGmvCreatorsList');
        const engagementContainer = document.getElementById('topEngagementCreatorsList');
        
        gmvContainer.innerHTML = '<div style="text-align: center; padding: 40px;"><i class="fas fa-spinner fa-pulse"></i> Loading...</div>';
        engagementContainer.innerHTML = '<div style="text-align: center; padding: 40px;"><i class="fas fa-spinner fa-pulse"></i> Loading...</div>';
        
        try {
            const response = await fetch(baseUrlIS + 'is/get_top_creators?period=' + period);
            const result = await response.json();
            
            if (result.success) {
                renderTopCreators(gmvContainer, result.top_gmv, 'gmv');
                renderTopCreators(engagementContainer, result.top_engagement, 'engagement');
            } else {
                gmvContainer.innerHTML = '<div style="text-align: center; padding: 40px; color: #ef4444;">Gagal memuat data</div>';
                engagementContainer.innerHTML = '<div style="text-align: center; padding: 40px; color: #ef4444;">Gagal memuat data</div>';
            }
        } catch (error) {
            console.error('Error:', error);
            gmvContainer.innerHTML = '<div style="text-align: center; padding: 40px; color: #ef4444;">Error loading data</div>';
            engagementContainer.innerHTML = '<div style="text-align: center; padding: 40px; color: #ef4444;">Error loading data</div>';
        }
    });
});

function renderTopCreators(container, creators, type) {
    if (!creators || creators.length === 0) {
        container.innerHTML = '<div style="text-align: center; padding: 40px; color: var(--text-muted);"><i class="fas fa-chart-line" style="font-size: 48px; margin-bottom: 16px; display: block; opacity: 0.5;"></i><p>Belum ada data</p></div>';
        return;
    }
    
    let html = '';
    creators.forEach((creator, index) => {
        const rank = index + 1;
        const rankBadge = rank == 1 ? '' : (rank == 2 ? '' : (rank == 3 ? '' : rank));
        
        html += `
            <div class="leaderboard-item-dashboard" style="display: flex; align-items: center; gap: 12px; padding: 12px; border-bottom: 1px solid var(--border); transition: background 0.2s; border-radius: 12px;" onmouseover="this.style.background='rgba(139,92,246,0.1)'" onmouseout="this.style.background='transparent'">
                <div style="width: 36px; text-align: center;">
                    <span style="color: var(--text-muted); font-size: 14px; font-weight: 600;">${rankBadge}</span>
                </div>
                <div style="flex: 1;">
                    <strong style="color: var(--text-primary); font-size: 13px;">@${escapeHtml(creator.username)}</strong>
                    <div style="display: flex; gap: 16px; margin-top: 4px;">
                        <span style="font-size: 10px; color: var(--text-muted);"><i class="fas fa-tag"></i> ${escapeHtml(creator.category || '-')}</span>
                    </div>
                </div>
                <div style="text-align: right;">
                    <div style="color: ${type === 'gmv' ? '#4ade80' : '#8b5cf6'}; font-weight: 700; font-size: 14px;">
                        ${type === 'gmv' ? 'Rp ' + new Intl.NumberFormat('id-ID').format(creator.total_gmv) : (creator.engagement_rate || 0) + '%'}
                    </div>
                    <div style="font-size: 9px; color: var(--text-muted);">
                        ${type === 'gmv' ? (creator.total_orders || 0) + ' orders' : 'GMV: Rp ' + new Intl.NumberFormat('id-ID').format(creator.total_gmv || 0)}
                    </div>
                </div>
            </div>
        `;
    });
    
    container.innerHTML = html;
}
function attachMonitoringDetailEvents() {
    document.querySelectorAll('.view-monitoring-detail-btn').forEach(btn => {
        // Hapus event listener lama jika ada
        const newBtn = btn.cloneNode(true);
        btn.parentNode.replaceChild(newBtn, btn);
        
        newBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            const creatorId = newBtn.getAttribute('data-creator-id');
            console.log('Detail button clicked for creator:', creatorId);
            if (creatorId) {
                showMonitoringDetailModal(creatorId);
            } else {
                showToastGlobal('Creator ID tidak ditemukan', 'error');
            }
        });
    });
}


// ========== INITIALIZATION ==========
document.addEventListener('DOMContentLoaded', () => {
    console.log('IS Dashboard initialized');
    
    updateAddCreatorButtons();
    
    loadTask2CreatorsIS();
    loadTask3CreatorsIS();
    loadTask4CreatorsIS();
    
    initAllSearches();
    
    // �9�7 ATTACH RESYNC EVENTS (setelah data dimuat)
    setTimeout(() => {
        attachResyncEvents();
    }, 1500);
});

// �9�7 JUGA PANGGIL SAAT SEARCH / RELOAD TASK 1
const originalReloadTask1 = reloadTaskData;
reloadTaskData = async function(containerId) {
    if (containerId === 'scoutingContainerDashboard') {
        location.reload();
        return;
    }
    await originalReloadTask1(containerId);
    if (containerId === 'scoutingContainerDashboard') {
        setTimeout(attachResyncEvents, 500);
    }
};


// ========== SEARCH TASK DENGAN DATABASE ==========
function initDatabaseSearch(searchInputId, containerId, taskType) {
    const searchInput = document.getElementById(searchInputId);
    if (!searchInput) return;
    
    let debounceTimer = null;
    
    searchInput.addEventListener('keyup', function() {
        clearTimeout(debounceTimer);
        
        const keyword = this.value.trim();
        const container = document.getElementById(containerId);
        
        // Tampilkan loading
        if (keyword.length > 0) {
            container.innerHTML = `
                <div class="stage-item-dashboard" style="text-align:center; padding:20px;">
                    <i class="fas fa-spinner fa-pulse"></i> Mencari data...
                </div>
            `;
        }
        
        debounceTimer = setTimeout(() => {
            if (keyword.length >= 2) {
                // �9�7 KIRIM TASK TYPE KE SERVER
                searchCreatorsByTaskAjax(keyword, taskType, containerId);
            } else if (keyword.length === 0) {
                // Reload data jika search kosong
                reloadTaskData(containerId);
            } else {
                container.innerHTML = `
                    <div class="stage-item-dashboard" style="text-align:center; padding:20px; color:#9aaebe;">
                        <i class="fas fa-info-circle"></i> Minimal 2 karakter untuk mencari
                    </div>
                `;
            }
        }, 500);
    });
}

async function searchCreatorsByTaskAjax(keyword, taskType, containerId) {
    const container = document.getElementById(containerId);
    
    try {
        const response = await fetch(baseUrlIS + 'is/search_creators_by_task', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: new URLSearchParams({
                keyword: keyword,
                task: taskType,  // �9�7 KIRIM TASK TYPE
                limit: 30
            })
        });
        
        const result = await response.json();
        
        if (result.success && result.data.length > 0) {
            let html = '';
            updateTaskCount(containerId, result.data.length);
            
            // �9�7 RENDER SESUAI TASK TYPE
            result.data.forEach(creator => {
                html += renderTaskItem(creator, taskType);
            });
            
            container.innerHTML = html;
            attachTaskEvents(containerId);
            
        } else {
            container.innerHTML = `
                <div class="stage-item-dashboard" style="text-align:center; padding:20px; color:#fbbf24;">
                    <i class="fas fa-search"></i> Tidak ditemukan creator untuk keyword "${keyword}"
                </div>
            `;
            updateTaskCount(containerId, 0);
        }
        
    } catch (error) {
        console.error('Search error:', error);
        container.innerHTML = `
            <div class="stage-item-dashboard" style="text-align:center; padding:20px; color:#ef4444;">
                <i class="fas fa-exclamation-triangle"></i> Error: ${error.message}
            </div>
        `;
    }
}

function getTaskTypeFromContainer(containerId) {
    if (containerId === 'scoutingContainerDashboard') return 'scouting';
    if (containerId === 'linkSwappingContainerDashboard') return 'link_swapping';
    if (containerId === 'sendingSampleContainerDashboard') return 'sample';
    if (containerId === 'monitoringContainerDashboard') return 'monitoring';
    return 'default';
}

function updateTaskCount(containerId, count) {
    let countSpan = null;
    if (containerId === 'scoutingContainerDashboard') countSpan = document.getElementById('scoutingCountDashboard');
    else if (containerId === 'linkSwappingContainerDashboard') countSpan = document.getElementById('linkCountDashboard');
    else if (containerId === 'sendingSampleContainerDashboard') countSpan = document.getElementById('sampleCountDashboard');
    else if (containerId === 'monitoringContainerDashboard') countSpan = document.getElementById('monitoringCountDashboard');
    
    if (countSpan) countSpan.innerText = count;
}

async function reloadTaskData(containerId) {
    if (containerId === 'scoutingContainerDashboard') {
        location.reload();
        return;
    }
    
    if (containerId === 'linkSwappingContainerDashboard') {
        await loadTask2CreatorsIS();
    } else if (containerId === 'sendingSampleContainerDashboard') {
        await loadTask3CreatorsIS();
    } else if (containerId === 'monitoringContainerDashboard') {
        await loadTask4CreatorsIS();
    }
}
// ========== RESYNC WHATSAPP DI TASK 1 ==========
// Fungsi untuk resync kontak creator (memakai fetchCreatorContact yang sudah ada)
async function resyncCreatorContact(creatorId, creatorName) {
    console.log('�9�4 Resync contact for:', creatorName);
    
    // Tampilkan loading di tombol
    const btn = document.querySelector(`.resync-wa-btn[data-creator-id="${creatorId}"]`);
    if (btn) {
        const originalText = btn.innerHTML;
        btn.disabled = true;
        btn.innerHTML = '<i class="fas fa-spinner fa-pulse"></i>';
        btn.style.background = '#8b5cf6';
        btn.style.color = 'white';
    }
    
    try {
        // �9�7 PAKAI fetchCreatorContact YANG SUDAH ADA
        const contactResult = await fetchCreatorContact(creatorName);
        
        if (contactResult.success && contactResult.whatsapp) {
            // �7�3 KONTAK DITEMUKAN - UPDATE DATABASE
            const updateResponse = await fetch(baseUrlIS + 'is/update_creator_phone', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: new URLSearchParams({
                    creator_id: creatorId,
                    phone: contactResult.whatsapp
                })
            });
            
            const updateResult = await updateResponse.json();
            
            if (updateResult.success) {
                // �7�3 UPDATE TAMPILAN
                const phoneDisplay = document.getElementById(`phoneDisplay_${creatorId}`);
                if (phoneDisplay) {
                    phoneDisplay.innerHTML = `<i class="fab fa-whatsapp"></i> <span style="color: #4ade80;">${contactResult.whatsapp}</span>`;
                }
                
                // Sembunyikan tombol resync
                if (btn) {
                    btn.style.display = 'none';
                }
                
                showToastGlobal(`�7�3 WhatsApp @${creatorName} berhasil ditemukan: ${contactResult.whatsapp}`, 'success');
            } else {
                showToastGlobal('�7�4 Gagal update nomor WhatsApp', 'error');
            }
        } else {
            // �7�4 KONTAK TIDAK DITEMUKAN
            if (contactResult.status === 'LOADING') {
                showToastGlobal(`�7�7 Pencarian kontak @${creatorName} sedang diproses, coba lagi nanti`, 'warning');
            } else {
                showToastGlobal(`�7�4 Kontak @${creatorName} tidak ditemukan. Silakan isi manual.`, 'error');
            }
        }
    } catch (error) {
        console.error('Resync error:', error);
        showToastGlobal(`�7�4 Error: ${error.message}`, 'error');
    } finally {
        // Reset tombol
        if (btn) {
            btn.disabled = false;
            btn.innerHTML = '<i class="fas fa-sync-alt"></i> Resync WA';
            btn.style.background = '#fbbf24';
            btn.style.color = '#0a0e17';
        }
    }
}

// ========== ATTACH EVENT RESYNC ==========
function attachResyncEvents() {
    document.querySelectorAll('.resync-wa-btn').forEach(btn => {
        // Hapus event listener lama
        const newBtn = btn.cloneNode(true);
        btn.parentNode.replaceChild(newBtn, btn);
        
        newBtn.addEventListener('click', function(e) {
            e.stopPropagation(); // Jangan trigger click pada card
            const creatorId = this.getAttribute('data-creator-id');
            const creatorName = this.getAttribute('data-creator-name');
            resyncCreatorContact(creatorId, creatorName);
        });
    });
}
function renderTaskItem(creator, taskType) {
    const escapedUsername = escapeHtml(creator.username || '');
    const escapedCategory = escapeHtml(creator.category || '-');
    const escapedPhone = escapeHtml(creator.phone || '-');
    const escapedStatus = escapeHtml(creator.status || 'PENDING');
    
    const isName = creator.is_full_name || creator.is_username || '-';
    const isDisplay = isName !== '-' ? `<i class="fas fa-user-tie"></i> IS: ${escapeHtml(isName)}` : '';
    
    let additionalHtml = '';
    let badgeClass = 'badge-pending';
    let badgeIcon = 'fa-clock';
    let statusLabel = escapedStatus;
    
    // �9�7 BADGE BERDASARKAN STATUS (TAMBAHKAN LINK_SWAPPING)
    switch (creator.status) {
        case 'ACTIVE':
            badgeClass = 'badge-active';
            badgeIcon = 'fa-check-circle';
            statusLabel = 'ACTIVE';
            break;
        case 'LINK_SWAPPING':
            badgeClass = 'badge-approved';
            badgeIcon = 'fa-link';
            statusLabel = 'LINK_SWAPPING';
            break;
        case 'LINK_SENT':
            badgeClass = 'badge-pending';
            badgeIcon = 'fa-link';
            statusLabel = 'LINK_SENT';
            break;
        case 'SAMPLE_SENT':
            badgeClass = 'badge-pending';
            badgeIcon = 'fa-box';
            statusLabel = 'SAMPLE_SENT';
            break;
        case 'PENDING':
            badgeClass = 'badge-pending';
            badgeIcon = 'fa-clock';
            statusLabel = 'PENDING';
            break;
        default:
            badgeClass = 'badge-pending';
            badgeIcon = 'fa-clock';
            statusLabel = escapedStatus;
    }
    
    // �9�7 RENDER BERDASARKAN TASK TYPE
    switch (taskType) {
        case 'scouting':
            // TASK 1: SCOUTING
            additionalHtml = `
                <div class="item-details-dashboard" style="margin-top: 4px;">
                    ${isDisplay ? `<span style="color: #8b5cf6; font-size: 10px;">${isDisplay}</span>` : ''}
                    ${creator.brand_name ? `
                    <span class="brand-badge" style="background: rgba(74,222,128,0.15); padding: 2px 8px; border-radius: 20px;">
                        <i class="fas fa-store"></i> ${escapeHtml(creator.brand_name)}
                    </span>` : `
                    <span style="color: #9aaebe; font-size: 10px;">
                        <i class="fas fa-store"></i> Belum ada brand
                    </span>`}
                </div>
                <div class="item-details-dashboard">
                    <span><i class="fab fa-whatsapp"></i> ${escapedPhone}</span>
                    <span><i class="fas fa-tag"></i> ${escapedCategory}</span>
                </div>
                ${creator.imported_gmv > 0 ? `
                <div class="item-details-dashboard" style="margin-top: 4px;">
                    <span style="color: #fbbf24; font-size: 11px;">
                        <i class="fas fa-chart-line"></i> GMV 28H: Rp ${formatNumber(creator.imported_gmv)}
                    </span>
                </div>` : ''}
                <span class="badge-dashboard ${badgeClass}" style="margin-top: 6px;">
                    <i class="fas ${badgeIcon}"></i> ${statusLabel}
                </span>
            `;
            break;
            
        case 'link_swapping':
            // TASK 2: LINK SWAPPING
            additionalHtml = `
                <div class="item-details-dashboard">
                    ${isDisplay ? `<span style="color: #8b5cf6; font-size: 10px;">${isDisplay}</span>` : ''}
                    <span><i class="fab fa-whatsapp"></i> ${escapedPhone}</span>
                    <span><i class="fas fa-tag"></i> ${escapedCategory}</span>
                </div>
                <div class="item-details-dashboard">
                    <i class="fas fa-link"></i> Siap diberikan link afiliasi
                </div>
                <span class="badge-dashboard badge-active">
                    <i class="fas fa-check-circle"></i> ACTIVE
                </span>
            `;
            break;
            
        case 'sample':
            // TASK 3: KIRIM SAMPLE
            additionalHtml = `
                <div class="item-details-dashboard">
                    ${isDisplay ? `<span style="color: #8b5cf6; font-size: 10px;">${isDisplay}</span>` : ''}
                    <span><i class="fab fa-whatsapp"></i> ${escapedPhone}</span>
                    <span><i class="fas fa-tag"></i> ${escapedCategory}</span>
                </div>
                <div class="item-details-dashboard">
                    <i class="fas fa-box"></i> Menunggu konfirmasi sample
                </div>
                <span class="badge-dashboard badge-pending">
                    <i class="fas fa-clock"></i> ${statusLabel}
                </span>
            `;
            break;
            
        case 'monitoring':
            // TASK 4: MONITORING
            const gmv = creator.total_gmv || 0;
            const orders = creator.total_orders || 0;
            const commission = creator.total_estimated_commission || 0;
            const roas = (commission > 0) ? (gmv / commission).toFixed(1) : '0';
            
            additionalHtml = `
                <div class="item-details-dashboard">
                    ${isDisplay ? `<span style="color: #8b5cf6; font-size: 10px;">${isDisplay}</span>` : ''}
                    <span><i class="fas fa-money-bill-wave"></i> GMV: Rp ${formatNumber(gmv)}</span>
                    <span><i class="fas fa-chart-line"></i> ROAS: ${roas}x</span>
                    <span><i class="fas fa-shopping-cart"></i> Orders: ${formatNumber(orders)}</span>
                </div>
                <div class="item-details-dashboard">
                    <span><i class="fas fa-tag"></i> ${escapedCategory}</span>
                    <span><i class="fab fa-whatsapp"></i> ${escapedPhone}</span>
                </div>
                <span class="badge-dashboard badge-active">
                    <i class="fas fa-check-circle"></i> ACTIVE
                    ${creator.auto_activated_at ? `
                    <span class="auto-badge" style="background: #4ade80; color: #0a0e17; font-size: 8px; padding: 2px 6px; border-radius: 10px; margin-left: 6px;">
                        <i class="fas fa-robot"></i> Auto
                    </span>` : ''}
                </span>
            `;
            break;
    }
    
    return `
        <div class="stage-item-dashboard ${taskType}-item-dashboard" 
             data-creator-id="${creator.id}" 
             data-creator-name="${escapedUsername}"
             data-creator-category="${escapedCategory}"
             data-creator-phone="${escapedPhone}"
             data-searchable="${escapedUsername.toLowerCase()} ${(creator.brand_name || '').toLowerCase()}">
            <strong><i class="fab fa-tiktok"></i> ${escapedUsername}</strong>
            ${additionalHtml}
        </div>
    `;
}

window._assignData = null;
async function openAssignLinkModal(creatorId, creatorUsername) {
    const modalBody = document.getElementById('modalBodyDashboard');
    const modalTitle = document.getElementById('modalTitleDashboard');
    
    modalTitle.innerHTML = `<i class="fas fa-link"></i> Assign Link - @${creatorUsername}`;
    
    modalBody.innerHTML = `
        <div style="text-align:center; padding:40px;">
            <i class="fas fa-spinner fa-pulse fa-2x"></i>
            <p style="margin-top:12px;">Loading products...</p>
        </div>
    `;
    
    openModalIS();
    
    try {
        // �9�7 AMBIL PRODUK MATCH DARI CREATOR_PRODUCTS
        const response = await fetch(baseUrlIS + 'is/get_assign_products_by_creator', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: new URLSearchParams({ creator_id: creatorId })
        });
        
        const result = await response.json();
        console.log('Assign products result:', result);
        
        if (!result.success) {
            modalBody.innerHTML = `
                <div style="text-align:center; padding:40px; color:#ef4444;">
                    <i class="fas fa-exclamation-triangle fa-2x"></i>
                    <p>${result.message}</p>
                    <button onclick="closeModalIS()" style="margin-top:16px; background:#1e293b; color:#e2f0e8; border:1px solid #2a3346; padding:8px 20px; border-radius:8px; cursor:pointer;">Tutup</button>
                </div>
            `;
            return;
        }
        
        // �9�7 AMBIL CAMPAIGN LIST
        let campaignList = [];
        try {
            const campResponse = await fetch(baseUrlIS + 'is/get_active_campaigns', { method: 'GET' });
            const campResult = await campResponse.json();
            if (campResult.success) {
                campaignList = campResult.campaigns || [];
            }
        } catch (e) {
            console.log('Error fetching campaigns:', e);
        }
        
        // ========== RENDER MODAL LENGKAP ==========
        renderAssignModalFull(creatorId, creatorUsername, result, campaignList);
        
    } catch (error) {
        console.error('Error in openAssignLinkModal:', error);
        modalBody.innerHTML = `
            <div style="text-align:center; padding:40px; color:#ef4444;">
                <i class="fas fa-exclamation-triangle fa-2x"></i>
                <p>Error loading products: ${error.message}</p>
                <button onclick="closeModalIS()" style="margin-top:16px; background:#1e293b; color:#e2f0e8; border:1px solid #2a3346; padding:8px 20px; border-radius:8px; cursor:pointer;">Tutup</button>
            </div>
        `;
    }
}



// ========== RETRY FUNCTION ==========
function retryLoadCampaignProducts(campaignId) {
    const list = document.getElementById('campaignProductsList');
    if (list) {
        list.innerHTML = '<div style="text-align:center; padding:20px;"><i class="fas fa-spinner fa-pulse"></i> Loading products...</div>';
    }
    
    // Trigger change event pada select
    const select = document.getElementById('campaignSelectFilter');
    if (select) {
        select.value = campaignId;
        select.dispatchEvent(new Event('change'));
    }
}



// ========== RENDER MODAL ASSIGN LENGKAP ==========
function renderAssignModalFull(creatorId, creatorUsername, result, campaignList) {
    const modalBody = document.getElementById('modalBodyDashboard');
    const modalTitle = document.getElementById('modalTitleDashboard');
    
    modalTitle.innerHTML = `<i class="fas fa-link"></i> Assign Link - @${creatorUsername}`;
    
    // Simpan data global
    window.assignDataGlobal = {
        creatorId: creatorId,
        creatorUsername: creatorUsername,
        allProducts: result.products || [],
        stats: result.stats || {},
        creator: result.creator || {},
        campaigns: campaignList
    };
    
    // ========== 1. BUILD PRODUCT ROWS ==========
    function buildProductRows(products) {
        if (!products || products.length === 0) {
            return `
                <tr>
                    <td colspan="5" style="text-align:center; padding:40px; color:#6b7280;">
                        <i class="fas fa-box-open" style="font-size:32px; display:block; margin-bottom:12px;"></i>
                        No matching products found
                    </td>
                </tr>
            `;
        }
        
        let html = '';
        products.forEach((product) => {
            const hasLink = product.has_link;
            const isAssigned = product.is_assigned;
            const productName = product.product_name || 'Unknown';
            const shopName = product.shop_name || '';
            const campaignId = product.link_campaign_id || '';
            
            // �9�7 FIX: Parse commission dengan aman
            let commission = parseFloat(product.link_commission) || parseFloat(product.commission_rate) || parseFloat(product.open_commission_rate) || 0;
            const commissionDisplay = commission > 0 ? commission.toFixed(1) + '%' : '-';
            
            const sales = product.sales_from_creator || product.sales_count || 0;
            const linkCreator = product.link_created_by || '';
            const imageUrl = product.image_url || '';
            const linkUrl = product.affiliate_link || product.assigned_link || '';
            
            // Status badge
            let statusBadge = '';
            let actionHtml = '';
            
            if (isAssigned) {
                statusBadge = `<span style="background:rgba(139,92,246,0.15); color:#8b5cf6; padding:3px 10px; border-radius:20px; font-size:10px; font-weight:600;"><i class="fas fa-check-circle"></i> Assigned</span>`;
                actionHtml = `<button onclick="copyLink('${linkUrl}')" style="background:transparent; color:#4ade80; border:1px solid #4ade80; padding:4px 12px; border-radius:16px; cursor:pointer; font-size:10px;"><i class="fas fa-copy"></i> Copy</button>`;
            } else if (hasLink) {
                statusBadge = `<span style="background:rgba(74,222,128,0.15); color:#4ade80; padding:3px 10px; border-radius:20px; font-size:10px; font-weight:600;"><i class="fas fa-link"></i> Link Ready</span>`;
                actionHtml = `<button onclick="assignProduct('${product.product_id}', '${productName.replace(/'/g, "\\'")}', '${commission}', '${linkUrl}', '${campaignId}')" style="background:#8b5cf6; color:white; border:none; padding:4px 14px; border-radius:16px; cursor:pointer; font-size:10px; font-weight:600;"><i class="fas fa-link"></i> Assign</button>`;
            } else {
                statusBadge = `<span style="background:rgba(239,68,68,0.15); color:#ef4444; padding:3px 10px; border-radius:20px; font-size:10px; font-weight:600;"><i class="fas fa-exclamation-circle"></i> No Link</span>`;
                actionHtml = `<span style="color:#6b7280; font-size:10px;"><i class="fas fa-clock"></i> Ask BD</span>`;
            }
            
            const rowStyle = hasLink ? 'border-left:3px solid #4ade80;' : '';
            
            html += `
                <tr style="border-bottom:1px solid #1e293b; ${rowStyle}">
                    <td style="padding:8px 10px;">
                        <div style="display:flex; align-items:center; gap:10px;">
                            <div style="width:32px; height:32px; border-radius:6px; background:#1e293b; display:flex; align-items:center; justify-content:center; flex-shrink:0; overflow:hidden;">
                                ${imageUrl ? `<img src="${imageUrl}" style="width:100%; height:100%; object-fit:cover;" onerror="this.parentElement.innerHTML='<i class=\\'fas fa-box\\' style=\\'color:#6b7280;font-size:12px;\\'></i>'">` : '<i class="fas fa-box" style="color:#6b7280;font-size:12px;"></i>'}
                            </div>
                            <div style="min-width:0;">
                                <div style="font-weight:500; color:#e2f0e8; font-size:11px; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;" title="${productName}">
                                    ${productName.substring(0, 50)}${productName.length > 50 ? '...' : ''}
                                </div>
                                <div style="font-size:9px; color:#6b7280; margin-top:2px;">
                                    ${shopName ? `<span style="color:#8b5cf6;"><i class="fas fa-store"></i> ${shopName}</span>` : ''}
                                    ${campaignId ? `<span style="color:#4ade80;margin-left:6px;">Campaign: ${campaignId.substring(0,8)}</span>` : ''}
                                    ${linkCreator ? `<span style="color:#6b7280;margin-left:6px;">by ${linkCreator}</span>` : ''}
                                </div>
                            </div>
                        </div>
                    </td>
                    <td style="padding:8px 10px; text-align:center; font-size:11px; color:#9aaebe;">${sales > 0 ? formatNumber(sales) : '-'}</td>
                    <td style="padding:8px 10px; text-align:center; font-size:11px; color:#fbbf24; font-weight:600;">${commissionDisplay}</td>
                    <td style="padding:8px 10px; text-align:center;">${statusBadge}</td>
                    <td style="padding:8px 10px; text-align:center;">${actionHtml}</td>
                </tr>
            `;
        });
        return html;
    }
    
    // ========== 2. SUMMARY BAR ==========
    const products = result.products || [];
    const total = products.length;
    const withLink = products.filter(p => p.has_link).length;
    const assigned = products.filter(p => p.is_assigned).length;
    
    const summaryBar = `
        <div style="display:flex; gap:20px; padding:10px 14px; background:rgba(139,92,246,0.08); border-radius:8px; margin-bottom:12px; flex-wrap:wrap; border:1px solid rgba(139,92,246,0.1);">
            <span style="display:flex; align-items:center; gap:6px; font-size:11px; color:#9aaebe;">
                <i class="fas fa-box"></i> Total: <strong style="color:#e2f0e8;">${total}</strong>
            </span>
            <span style="display:flex; align-items:center; gap:6px; font-size:11px; color:#4ade80;">
                <i class="fas fa-link"></i> With Link: <strong>${withLink}</strong>
            </span>
            <span style="display:flex; align-items:center; gap:6px; font-size:11px; color:#8b5cf6;">
                <i class="fas fa-check-circle"></i> Assigned: <strong>${assigned}</strong>
            </span>
            <span style="display:flex; align-items:center; gap:6px; font-size:11px; color:#fbbf24;">
                <i class="fas fa-chart-line"></i> GMV: <strong>Rp ${formatNumber(result.stats?.total_gmv || 0)}</strong>
            </span>
            <span style="display:flex; align-items:center; gap:6px; font-size:11px; color:#6b7280;">
                <i class="fas fa-robot"></i> FastMoss: <strong>${result.stats?.total || 0}</strong>
            </span>
        </div>
    `;
    
    // ========== 3. PRODUCT TABLE ==========
    const productTable = `
        <div style="max-height:380px; overflow-y:auto; border-radius:8px; border:1px solid #1e293b;">
            <table style="width:100%; border-collapse:collapse; font-size:12px;">
                <thead>
                    <tr style="background:#1a1f2e; border-bottom:2px solid #2a3346; position:sticky; top:0; z-index:10;">
                        <th style="padding:10px 12px; text-align:left; font-size:10px; font-weight:700; text-transform:uppercase; color:#8b5cf6; width:40%;">Product</th>
                        <th style="padding:10px 12px; text-align:center; font-size:10px; font-weight:700; text-transform:uppercase; color:#8b5cf6; width:10%;">Sales</th>
                        <th style="padding:10px 12px; text-align:center; font-size:10px; font-weight:700; text-transform:uppercase; color:#8b5cf6; width:12%;">Commission</th>
                        <th style="padding:10px 12px; text-align:center; font-size:10px; font-weight:700; text-transform:uppercase; color:#8b5cf6; width:18%;">Status</th>
                        <th style="padding:10px 12px; text-align:center; font-size:10px; font-weight:700; text-transform:uppercase; color:#8b5cf6; width:20%;">Action</th>
                    </tr>
                </thead>
                <tbody>
                    ${buildProductRows(products)}
                </tbody>
            </table>
        </div>
    `;
    
    // ========== 4. CAMPAIGN DROPDOWN ==========
    let campaignHtml = '';
    if (campaignList && campaignList.length > 0) {
        campaignHtml = `
            <div style="margin-top:20px; padding-top:16px; border-top:2px solid #2a3346;">
                <label style="color:#e2f0e8; font-size:13px; font-weight:500; display:block; margin-bottom:6px;">
                    <i class="fas fa-bullhorn"></i> Pilih Campaign (Produk dari Campaign)
                </label>
                <select id="campaignSelectFilter" style="width:100%; padding:10px; background:#0f1420; border:1px solid #2a3346; border-radius:10px; color:#e2f0e8;">
                    <option value="">-- Pilih Campaign --</option>
                    ${campaignList.map(c => `<option value="${c.campaign_id}">${c.campaign_name || c.campaign_id}</option>`).join('')}
                </select>
                <div style="font-size:10px; color:#6b7280; margin-top:4px;">
                    <i class="fas fa-info-circle"></i> Pilih campaign untuk melihat produk yang tersedia
                </div>
            </div>
            <div id="campaignProductsContainer" style="margin-top:12px; display:none;">
                <div style="background:rgba(139,92,246,0.1); border-radius:8px; padding:10px; margin-bottom:10px;">
                    <span style="color:#8b5cf6; font-size:12px;">
                        <i class="fas fa-box"></i> Produk dari Campaign
                        <span id="campaignProductCount" style="margin-left:8px; font-weight:600;">0</span>
                    </span>
                </div>
                <div id="campaignProductsList" style="max-height:250px; overflow-y:auto; background:#0f1420; border-radius:8px; padding:8px;">
                    <div style="text-align:center; padding:20px; color:#9aaebe;">Pilih campaign untuk melihat produk</div>
                </div>
            </div>
        `;
    } else {
        campaignHtml = `
            <div style="margin-top:20px; padding-top:16px; border-top:2px solid #2a3346;">
                <div style="padding:10px; background:rgba(245,158,11,0.1); border-radius:8px; border-left:3px solid #f59e0b;">
                    <span style="color:#f59e0b; font-size:12px;">
                        <i class="fas fa-exclamation-triangle"></i> No active campaigns found.
                    </span>
                </div>
            </div>
        `;
    }
    
    // ========== 5. RENDER MODAL ==========
    modalBody.innerHTML = `
        <div style="background:rgba(139,92,246,0.1); border-radius:14px; padding:12px; margin-bottom:12px;">
            <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap;">
                <div>
                    <p style="color:#8b5cf6; font-size:12px; margin:0;">
                        <i class="fas fa-info-circle"></i> Products promoted by @${creatorUsername}
                    </p>
                </div>
                <div style="display:flex; gap:8px; align-items:center; font-size:10px; color:#6b7280;">
                    <span><i class="fas fa-store"></i> Brand ID: ${result.creator?.brand_id || 'No brand'}</span>
                </div>
            </div>
        </div>
        
        <!-- PRODUCT MATCH -->
        <div style="background:rgba(74,222,128,0.05); border-radius:10px; padding:12px; margin-bottom:8px;">
            <h4 style="color:#4ade80; margin:0 0 8px 0; font-size:13px;">
                <i class="fas fa-star"></i> Recommended Products (Match)
            </h4>
            ${summaryBar}
            ${productTable}
        </div>
        
        <!-- CAMPAIGN PRODUCTS -->
        ${campaignHtml}
        
        <div class="flex-buttons" style="margin-top:16px;">
            <button id="closeAssignLinkModal" style="background:#1e293b; color:#cbd5e6; flex:1; padding:12px; border-radius:40px; border:1px solid #2a3346; cursor:pointer;">Close</button>
        </div>
    `;
    
    // ========== 6. EVENT: LOAD CAMPAIGN PRODUCTS ==========
    const campaignSelect = document.getElementById('campaignSelectFilter');
    if (campaignSelect) {
        const newCampaignSelect = campaignSelect.cloneNode(true);
        campaignSelect.parentNode.replaceChild(newCampaignSelect, campaignSelect);
        
        newCampaignSelect.addEventListener('change', async function() {
            const campaignId = this.value;
            const container = document.getElementById('campaignProductsContainer');
            const list = document.getElementById('campaignProductsList');
            const countSpan = document.getElementById('campaignProductCount');
            
            if (!campaignId) {
                container.style.display = 'none';
                return;
            }
            
            container.style.display = 'block';
            list.innerHTML = '<div style="text-align:center; padding:20px;"><i class="fas fa-spinner fa-pulse"></i> Loading products...</div>';
            
            try {
                const response = await fetch(baseUrlIS + 'is/get_campaign_products_for_assign', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                    body: new URLSearchParams({ 
                        campaign_id: campaignId,
                        creator_category: result.creator?.category || ''
                    })
                });
                
                const data = await response.json();
                
                if (data.success && data.products && data.products.length > 0) {
                    if (countSpan) countSpan.textContent = data.products.length;
                    
                    let html = `
                        <table style="width:100%; border-collapse:collapse; font-size:11px;">
                            <thead>
                                <tr style="background:#1a1f2e; border-bottom:2px solid #2a3346; position:sticky; top:0; z-index:10;">
                                    <th style="padding:6px; text-align:left; width:40%; color:#8b5cf6; font-size:9px; text-transform:uppercase;">Product</th>
                                    <th style="padding:6px; text-align:center; width:12%; color:#8b5cf6; font-size:9px; text-transform:uppercase;">Price</th>
                                    <th style="padding:6px; text-align:center; width:12%; color:#8b5cf6; font-size:9px; text-transform:uppercase;">Commission</th>
                                    <th style="padding:6px; text-align:center; width:18%; color:#8b5cf6; font-size:9px; text-transform:uppercase;">Link</th>
                                    <th style="padding:6px; text-align:center; width:18%; color:#8b5cf6; font-size:9px; text-transform:uppercase;">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                    `;
                    
                    data.products.forEach((product) => {
                        const hasLink = product.has_link;
                        const link = product.affiliate_link || '';
                        let commission = parseFloat(product.commission_rate) || parseFloat(product.open_commission_rate) || 0;
                        const commissionDisplay = commission > 0 ? commission.toFixed(1) + '%' : '-';
                        const productName = product.product_name || 'Unknown';
                        const price = product.price || 0;
                        const imageUrl = product.image_url || '';
                        
                        html += `
                            <tr style="border-bottom:1px solid #1e293b; ${hasLink ? 'border-left:3px solid #4ade80;' : ''}">
                                <td style="padding:6px;">
                                    <div style="display:flex; align-items:center; gap:8px;">
                                        <div style="width:28px; height:28px; border-radius:6px; background:#1e293b; display:flex; align-items:center; justify-content:center; overflow:hidden; flex-shrink:0;">
                                            ${imageUrl ? `<img src="${imageUrl}" style="width:100%; height:100%; object-fit:cover;" onerror="this.parentElement.innerHTML='<i class=\\'fas fa-box\\' style=\\'color:#6b7280;font-size:10px;\\'></i>'">` : '<i class="fas fa-box" style="color:#6b7280;font-size:10px;"></i>'}
                                        </div>
                                        <div style="font-size:10px; color:#e2f0e8; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;" title="${productName}">
                                            ${productName.substring(0, 40)}${productName.length > 40 ? '...' : ''}
                                        </div>
                                    </div>
                                </td>
                                <td style="padding:6px; text-align:center; font-size:10px; color:#4ade80;">Rp ${formatNumber(price)}</td>
                                <td style="padding:6px; text-align:center; font-size:10px; color:#fbbf24; font-weight:600;">${commissionDisplay}</td>
                                <td style="padding:6px; text-align:center; font-size:10px;">
                                    ${hasLink ? 
                                        `<span style="color:#4ade80;"><i class="fas fa-check-circle"></i> Ready</span>` : 
                                        `<span style="color:#ef4444;"><i class="fas fa-times-circle"></i> No Link</span>`
                                    }
                                </td>
                                <td style="padding:6px; text-align:center;">
                                    ${hasLink ? 
                                        `<button onclick="copyLink('${link}')" style="background:transparent; color:#4ade80; border:1px solid #4ade80; padding:2px 10px; border-radius:12px; cursor:pointer; font-size:9px;"><i class="fas fa-copy"></i> Copy</button>` : 
                                        `<span style="color:#6b7280; font-size:9px;">No Link</span>`
                                    }
                                </td>
                            </tr>
                        `;
                    });
                    
                    html += `</tbody></table>`;
                    list.innerHTML = html;
                    
                } else {
                    if (countSpan) countSpan.textContent = '0';
                    list.innerHTML = `
                        <div style="text-align:center; padding:20px; color:#fbbf24;">
                            <i class="fas fa-info-circle"></i>
                            <p>${data.message || 'No products available in this campaign'}</p>
                        </div>
                    `;
                }
            } catch (error) {
                list.innerHTML = `
                    <div style="text-align:center; padding:20px; color:#ef4444;">
                        <i class="fas fa-exclamation-triangle"></i>
                        <p>Error: ${error.message}</p>
                    </div>
                `;
            }
        });
    }
    
    // ========== 7. CLOSE BUTTON ==========
    document.getElementById('closeAssignLinkModal')?.addEventListener('click', closeModalIS);
}
// ========== RENDER MODAL ASSIGN DENGAN FILTER CAMPAIGN ==========
function renderAssignModalWithFilter() {
    const data = window.assignDataGlobal;
    if (!data) return;
    
    const modalBody = document.getElementById('modalBodyDashboard');
    const modalTitle = document.getElementById('modalTitleDashboard');
    
    modalTitle.innerHTML = `<i class="fas fa-link"></i> Assign Link - @${data.creatorUsername}`;
    
    // ========== CAMPAIGN DROPDOWN ==========
    let campaignHtml = '';
    if (data.campaigns && data.campaigns.length > 0) {
        campaignHtml = `
            <div style="margin-bottom: 16px; margin-top: 16px; padding-top: 16px; border-top: 1px solid #2a3346;">
                <label style="color: #e2f0e8; font-size: 13px; font-weight: 500; display: block; margin-bottom: 6px;">
                    <i class="fas fa-bullhorn"></i> Pilih Campaign
                </label>
                <select id="campaignSelectFilter" style="width: 100%; padding: 10px; background: #0f1420; border: 1px solid #2a3346; border-radius: 10px; color: #e2f0e8;">
                    <option value="">-- Semua Campaign --</option>
                    ${data.campaigns.map(c => `
                        <option value="${c.campaign_id}">${c.campaign_name}</option>
                    `).join('')}
                </select>
                <div style="font-size: 10px; color: #6b7280; margin-top: 4px;">
                    <i class="fas fa-info-circle"></i> Pilih campaign untuk melihat produk yang memiliki link di campaign tersebut
                </div>
            </div>
        `;
    } else {
        campaignHtml = `
            <div style="margin-bottom: 16px; margin-top: 16px; padding: 10px; background: rgba(245,158,11,0.1); border-radius: 8px; border-left: 3px solid #f59e0b;">
                <span style="color: #f59e0b; font-size: 12px;">
                    <i class="fas fa-exclamation-triangle"></i> 
                    No active campaigns found. Please create a campaign first.
                </span>
            </div>
        `;
    }
    
    // ========== INFO ==========
    let infoHtml = '';
    if (data.allProducts && data.allProducts.length > 0) {
        infoHtml = `
            <div style="margin-bottom: 16px; padding: 12px; background: rgba(74,222,128,0.1); border-radius: 8px;">
                <div style="display: flex; justify-content: space-between; flex-wrap: wrap; gap: 8px;">
                    <span style="color: #4ade80;">
                        <i class="fas fa-check-circle"></i> 
                        ${data.allProducts.length} product(s) matched from creator's products
                    </span>
                    <span style="color: #6b7280; font-size: 11px;">
                        <i class="fas fa-robot"></i> Total in FastMoss: ${data.stats?.total || 0}
                    </span>
                </div>
                <div style="display: flex; gap: 16px; margin-top: 8px; font-size: 11px; color: #6b7280;">
                    <span>�7�3 Matched: ${data.stats?.matched || 0}</span>
                    <span>�7�7 Not Matched: ${data.stats?.not_matched || 0}</span>
                    <span>�9�0 GMV: Rp ${formatNumber(data.stats?.total_gmv || 0)}</span>
                </div>
            </div>
        `;
    } else {
        infoHtml = `
            <div style="margin-bottom: 16px; padding: 12px; background: rgba(245,158,11,0.1); border-radius: 8px;">
                <span style="color: #f59e0b;">
                    <i class="fas fa-info-circle"></i> 
                    No matching products found. Products from FastMoss: ${data.stats?.total || 0}
                </span>
            </div>
        `;
    }
    
    // ========== PRODUCT LIST ==========
    let productsHtml = '';
    if (!data.allProducts || data.allProducts.length === 0) {
        productsHtml = `
            <div style="text-align:center; padding:40px; color:#6b7280;">
                <i class="fas fa-box fa-2x"></i>
                <p>No matching products found in our database</p>
                <p style="font-size:11px; margin-top:8px;">
                    ${data.stats?.total > 0 ? 
                        `Found ${data.stats.total} products on FastMoss, but none match our database.` : 
                        'Creator may not have any promoted products yet.'
                    }
                </p>
            </div>
        `;
    } else {
        productsHtml = `
            <div id="productsContainer">
                <div style="max-height: 350px; overflow-y: auto; margin-top: 8px;">
                    <table style="width:100%; border-collapse: collapse; font-size: 12px;">
                        <thead>
                            <tr style="background: #1a1f2e; border-bottom: 1px solid #2a3346; position: sticky; top: 0; z-index: 10;">
                                <th style="padding: 8px; text-align: left; width: 30%;">Product</th>
                                <th style="padding: 8px; text-align: center; width: 8%;">Sales</th>
                                <th style="padding: 8px; text-align: center; width: 10%;">Commission</th>
                                <th style="padding: 8px; text-align: center; width: 20%;">Link Status</th>
                                <th style="padding: 8px; text-align: center; width: 32%;">Action</th>
                            </tr>
                        </thead>
                        <tbody id="productsTableBody">
                            ${renderProductRowsFilter(data.allProducts)}
                        </tbody>
                    </table>
                </div>
            </div>
        `;
    }
    
    modalBody.innerHTML = `
        <div style="background: rgba(139,92,246,0.1); border-radius: 14px; padding: 12px; margin-bottom: 16px;">
            <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap;">
                <div>
                    <p style="color: #8b5cf6; font-size: 12px; margin: 0;">
                        <i class="fas fa-info-circle"></i> 
                        Products promoted by @${data.creator?.username || data.creatorUsername}
                    </p>
                    <p style="color: #6b7280; font-size: 10px; margin-top: 4px;">
                        Select campaign to filter products with available links.
                    </p>
                </div>
                <div style="display: flex; gap: 8px; align-items: center; font-size: 10px; color: #6b7280;">
                    <span><i class="fas fa-store"></i> ${data.creator?.brand_id ? 'Brand ID: ' + data.creator.brand_id : 'No brand'}</span>
                </div>
            </div>
        </div>
        
        ${infoHtml}
        ${productsHtml}
        
        <!-- CAMPAIGN SELECTOR (DI BAWAH PRODUCT) -->
        ${campaignHtml}
        
        <div class="flex-buttons" style="margin-top: 16px;">
            <button id="closeAssignLinkModal" style="background: #1e293b; color: #cbd5e6; flex: 1; padding: 12px; border-radius: 40px; border: 1px solid #2a3346; cursor: pointer;">
                Close
            </button>
        </div>
    `;
    
    // ========== EVENT: FILTER PRODUK KETIKA CAMPAIGN DIPILIH ==========
    const campaignSelect = document.getElementById('campaignSelectFilter');
    if (campaignSelect) {
        // Hapus event listener lama jika ada
        const newCampaignSelect = campaignSelect.cloneNode(true);
        campaignSelect.parentNode.replaceChild(newCampaignSelect, campaignSelect);
        
        newCampaignSelect.addEventListener('change', function() {
            filterProductsByCampaign(this.value);
        });
    }
    
    // ========== ATTACH EVENTS ==========
    attachProductEventsFilter();
    
    document.getElementById('closeAssignLinkModal')?.addEventListener('click', closeModalIS);
}

function filterProductsByCampaign(campaignId) {
    console.log('Filtering products by campaign:', campaignId);
    
    const data = window.assignDataGlobal;
    if (!data) {
        console.error('No data found in window.assignDataGlobal');
        return;
    }
    
    const tbody = document.getElementById('productsTableBody');
    if (!tbody) {
        console.error('productsTableBody not found');
        return;
    }
    
    let filteredProducts = data.allProducts;
    
    // �9�7 FILTER: HANYA PRODUK YANG PUNYA LINK DI CAMPAIGN TERSEBUT
    if (campaignId) {
        filteredProducts = data.allProducts.filter(p => {
            // Cek apakah produk memiliki link di campaign ini
            return p.link_campaign_id === campaignId && p.has_link === true;
        });
        
        console.log('Filtered products count:', filteredProducts.length);
        
        // Tampilkan pesan jika tidak ada produk
        if (filteredProducts.length === 0) {
            const container = document.getElementById('productsContainer');
            if (container) {
                container.innerHTML = `
                    <div style="text-align:center; padding:30px; color:#fbbf24;">
                        <i class="fas fa-info-circle"></i>
                        <p>No products with links in this campaign.</p>
                        <p style="font-size:10px; color:#6b7280;">Try selecting another campaign.</p>
                    </div>
                `;
                return;
            }
        }
    }
    
    // Render ulang tabel
    tbody.innerHTML = renderProductRowsFilter(filteredProducts);
    attachProductEventsFilter();
}


// ========== LOAD CAMPAIGN PRODUCTS (TASK 2) ==========
async function loadCampaignProducts(campaignId, creatorCategory) {
    const productsContainer = document.getElementById('campaignProductsContainer');
    const loadingIndicator = document.getElementById('campaignProductsLoading');
    const productCountBadge = document.getElementById('selectedProductsCount');
    
    if (!campaignId) {
        if (productsContainer) {
            productsContainer.innerHTML = `
                <div class="empty-state" style="text-align:center; padding:30px; color:#9aaebe;">
                    <i class="fas fa-info-circle" style="font-size:24px; margin-bottom:12px; display:block;"></i>
                    <p>Pilih campaign untuk melihat produk yang tersedia</p>
                </div>
            `;
        }
        return;
    }
    
    // Tampilkan loading
    if (loadingIndicator) loadingIndicator.style.display = 'block';
    if (productsContainer) {
        productsContainer.innerHTML = `
            <div style="text-align:center; padding:20px; color:#9aaebe;">
                <i class="fas fa-spinner fa-pulse fa-2x"></i>
                <p style="margin-top:12px;">Memuat produk...</p>
            </div>
        `;
    }
    
    try {
        console.log('Loading products for campaign:', campaignId, 'category:', creatorCategory);
        
        const response = await fetch(baseUrlDashboard + 'is/get_campaign_products_for_assign', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: new URLSearchParams({
                campaign_id: campaignId,
                creator_category: creatorCategory || ''
            })
        });
        
        const result = await response.json();
        console.log('Campaign products:', result);
        
        // Sembunyikan loading
        if (loadingIndicator) loadingIndicator.style.display = 'none';
        
        if (!result.success) {
            if (productsContainer) {
                productsContainer.innerHTML = `
                    <div class="empty-state" style="text-align:center; padding:30px; color:#ef4444;">
                        <i class="fas fa-exclamation-triangle" style="font-size:24px; margin-bottom:12px; display:block;"></i>
                        <p>${result.message || 'Gagal memuat produk'}</p>
                    </div>
                `;
            }
            return;
        }
        
        const products = result.products || [];
        const total = result.total || 0;
        
        // Update badge
        if (productCountBadge) {
            productCountBadge.innerText = total;
        }
        
        if (products.length === 0) {
            if (productsContainer) {
                productsContainer.innerHTML = `
                    <div class="empty-state" style="text-align:center; padding:30px; color:#9aaebe;">
                        <i class="fas fa-box-open" style="font-size:32px; margin-bottom:12px; display:block; opacity:0.5;"></i>
                        <p>${result.message || 'Tidak ada produk yang tersedia di campaign ini'}</p>
                        <p style="font-size:11px; margin-top:8px;">Pastikan produk sudah di-APPROVE oleh BD terlebih dahulu.</p>
                    </div>
                `;
            }
            return;
        }
        
        // �9�7 RENDER PRODUK
        renderCampaignProducts(products);
        
    } catch (error) {
        console.error('Error loading campaign products:', error);
        if (loadingIndicator) loadingIndicator.style.display = 'none';
        
        if (productsContainer) {
            productsContainer.innerHTML = `
                <div class="empty-state" style="text-align:center; padding:30px; color:#ef4444;">
                    <i class="fas fa-exclamation-circle" style="font-size:24px; margin-bottom:12px; display:block;"></i>
                    <p>Error loading products: ${error.message}</p>
                    <button onclick="loadCampaignProducts('${campaignId}')" style="margin-top:12px; background:#8b5cf6; color:white; padding:6px 16px; border:none; border-radius:8px; cursor:pointer;">
                        <i class="fas fa-redo"></i> Coba Lagi
                    </button>
                </div>
            `;
        }
    }
}

// ========== RENDER CAMPAIGN PRODUCTS ==========
function renderCampaignProducts(products) {
    const container = document.getElementById('campaignProductsContainer');
    if (!container) return;
    
    // �9�7 CEGAH INFINITE LOOP - Gunakan flag
    if (container._rendering) return;
    container._rendering = true;
    
    try {
        let html = `
            <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(220px, 1fr)); gap: 12px; max-height: 400px; overflow-y: auto; padding: 4px;">
        `;
        
        products.forEach((product, index) => {
            const hasLink = product.has_link || false;
            const linkStatus = hasLink ? '�7�3 Ada Link' : '�7�2�1�5 Belum Ada Link';
            const linkColor = hasLink ? '#4ade80' : '#f59e0b';
            const priceFormatted = product.price ? 'Rp ' + Number(product.price).toLocaleString('id-ID') : '-';
            
            html += `
                <div class="product-item" data-product-id="${product.product_id}" 
                     style="background: #0f1420; border-radius: 12px; padding: 12px; border: 1px solid ${hasLink ? '#2a3346' : '#f59e0b'}; cursor: pointer; transition: all 0.2s;">
                    <div style="display: flex; gap: 10px; align-items: center;">
                        ${product.image_url ? 
                            `<img src="${product.image_url}" style="width: 50px; height: 50px; border-radius: 8px; object-fit: cover;" onerror="this.style.display='none'">` : 
                            `<div style="width: 50px; height: 50px; background: #1e293b; border-radius: 8px; display: flex; align-items: center; justify-content: center;">
                                <i class="fas fa-box" style="color: #8b5cf6;"></i>
                            </div>`
                        }
                        <div style="flex: 1; min-width: 0;">
                            <div style="font-size: 12px; font-weight: 500; color: #e2f0e8; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">
                                ${escapeHtml(product.product_name || 'Unknown Product')}
                            </div>
                            <div style="font-size: 10px; color: #9aaebe; margin-top: 2px;">
                                <span style="color: #4ade80;">${priceFormatted}</span>
                                <span style="margin-left: 8px;">| Komisi: ${product.open_commission_rate || 0}%</span>
                            </div>
                            <div style="margin-top: 4px;">
                                <span style="font-size: 9px; color: ${linkColor};">
                                    <i class="fas ${hasLink ? 'fa-check-circle' : 'fa-clock'}"></i> ${linkStatus}
                                </span>
                            </div>
                        </div>
                    </div>
                    ${hasLink ? `
                        <button class="assign-product-btn" data-product-id="${product.product_id}" 
                                data-product-name="${escapeHtml(product.product_name)}"
                                data-link="${product.affiliate_link || ''}"
                                data-commission="${product.commission_rate || 0}"
                                style="margin-top: 8px; width: 100%; background: #4ade80; color: #0a0e17; border: none; padding: 6px; border-radius: 8px; cursor: pointer; font-weight: 600; font-size: 11px;">
                            <i class="fas fa-link"></i> Assign Link ke Creator
                        </button>
                    ` : `
                        <div style="margin-top: 8px; padding: 6px; background: rgba(245,158,11,0.1); border-radius: 8px; text-align: center; font-size: 10px; color: #f59e0b;">
                            <i class="fas fa-info-circle"></i> Link belum tersedia, minta BD generate link
                        </div>
                    `}
                </div>
            `;
        });
        
        html += `</div>`;
        
        // Tambahkan info total
        html += `
            <div style="margin-top: 12px; padding: 8px 12px; background: rgba(139,92,246,0.1); border-radius: 8px; display: flex; justify-content: space-between; align-items: center;">
                <span style="color: #9aaebe; font-size: 11px;">
                    <i class="fas fa-box"></i> Total: <strong style="color: #e2f0e8;">${products.length}</strong> produk
                </span>
                <span style="color: #9aaebe; font-size: 11px;">
                    <i class="fas fa-link"></i> Dengan link: <strong style="color: #4ade80;">${products.filter(p => p.has_link).length}</strong>
                </span>
            </div>
        `;
        
        container.innerHTML = html;
        
        // �9�7 ATTACH EVENT LISTENER UNTUK TOMBOL ASSIGN
        document.querySelectorAll('.assign-product-btn').forEach(btn => {
            btn.addEventListener('click', function(e) {
                e.stopPropagation();
                const productId = this.getAttribute('data-product-id');
                const productName = this.getAttribute('data-product-name');
                const link = this.getAttribute('data-link');
                const commission = this.getAttribute('data-commission');
                
                // Panggil fungsi assign
                if (typeof assignProductToCreator === 'function') {
                    assignProductToCreator(productId, productName, link, commission);
                } else {
                    console.log('Assign product:', { productId, productName, link, commission });
                    showToastInModal('Fungsi assign belum siap', 'info');
                }
            });
        });
        
    } catch (error) {
        console.error('Error rendering products:', error);
        container.innerHTML = `
            <div style="text-align:center; padding:20px; color:#ef4444;">
                <i class="fas fa-exclamation-circle"></i>
                <p>Error rendering products: ${error.message}</p>
            </div>
        `;
    } finally {
        // Reset flag
        container._rendering = false;
    }
}

// ========== ASSIGN PRODUCT TO CREATOR ==========
async function assignProductToCreator(productId, productName, link, commission) {
    const creatorId = document.getElementById('selectedCreatorId')?.value;
    const creatorName = document.getElementById('selectedCreatorName')?.value;
    
    if (!creatorId) {
        showToastInModal('Pilih creator terlebih dahulu!', 'error');
        return;
    }
    
    if (!link) {
        showToastInModal('Link afiliasi belum tersedia untuk produk ini!', 'error');
        return;
    }
    
    try {
        const response = await fetch(baseUrlDashboard + 'is/assign_product_link', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: new URLSearchParams({
                creator_id: creatorId,
                product_id: productId,
                campaign_id: document.getElementById('campaignSelect')?.value || '',
                commission_rate: commission || 10,
                affiliate_link: link
            })
        });
        
        const result = await response.json();
        
        if (result.success) {
            showToastInModal(`�7�3 Link untuk "${productName}" berhasil di-assign ke @${creatorName}`, 'success');
            // Refresh list
            loadAssignedProducts(creatorId);
        } else {
            showToastInModal(result.message || 'Gagal assign link', 'error');
        }
    } catch (error) {
        console.error('Error assigning product:', error);
        showToastInModal('Error: ' + error.message, 'error');
    }
}

// ========== LOAD ASSIGNED PRODUCTS ==========
async function loadAssignedProducts(creatorId) {
    try {
        const response = await fetch(baseUrlDashboard + 'is/get_creator_affiliate_links', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: new URLSearchParams({ creator_id: creatorId })
        });
        
        const result = await response.json();
        
        if (result.success && result.links) {
            const container = document.getElementById('assignedProductsContainer');
            if (container) {
                if (result.links.length === 0) {
                    container.innerHTML = `
                        <div style="text-align:center; padding:20px; color:#9aaebe; font-size:12px;">
                            <i class="fas fa-info-circle"></i> Belum ada produk yang di-assign
                        </div>
                    `;
                } else {
                    let html = `<div style="max-height:200px; overflow-y:auto;">`;
                    result.links.forEach(link => {
                        html += `
                            <div style="padding:8px 12px; background:#0f1420; border-radius:8px; margin-bottom:6px; display:flex; justify-content:space-between; align-items:center;">
                                <div>
                                    <div style="font-size:12px; color:#e2f0e8;">${escapeHtml(link.product_name)}</div>
                                    <div style="font-size:10px; color:#4ade80;">Komisi: ${link.commission_rate}%</div>
                                </div>
                                <button onclick="copyToClipboard('${link.affiliate_link}')" 
                                        style="background:transparent; border:1px solid #4ade80; color:#4ade80; padding:4px 12px; border-radius:20px; cursor:pointer; font-size:10px;">
                                    <i class="fas fa-copy"></i> Copy
                                </button>
                            </div>
                        `;
                    });
                    html += `</div>`;
                    container.innerHTML = html;
                }
            }
        }
    } catch (error) {
        console.error('Error loading assigned products:', error);
    }
}
// ========== RENDER PRODUCT ROWS DENGAN FILTER ==========
function renderProductRowsFilter(products) {
    if (!products || products.length === 0) {
        return `
            <tr>
                <td colspan="5" style="text-align:center; padding:40px; color:#6b7280;">
                    <i class="fas fa-box-open" style="font-size:32px; display:block; margin-bottom:12px;"></i>
                    No products available
                </td>
            </tr>
        `;
    }
    
    let html = '';
    products.forEach((product) => {
        const hasLink = product.has_link;
        const isAssigned = product.is_assigned;
        const productName = product.product_name || 'Unknown';
        const shopName = product.shop_name || '';
        const campaignId = product.link_campaign_id || '';
        const commission = product.link_commission || product.commission_rate || product.open_commission_rate || 0;
        const commissionDisplay = commission > 0 ? commission.toFixed(1) + '%' : '-';
        const sales = product.sales_from_creator || product.sales_count || 0;
        const linkCreator = product.link_created_by || '';
        const imageUrl = product.image_url || '';
        const linkUrl = product.affiliate_link || product.assigned_link || '';
        
        // �7�3 Status Badge
        let statusBadge = '';
        if (isAssigned) {
            statusBadge = `<span class="status-badge assigned"><i class="fas fa-check-circle"></i> Assigned</span>`;
        } else if (hasLink) {
            statusBadge = `<span class="status-badge ready"><i class="fas fa-link"></i> Link Ready</span>`;
        } else {
            statusBadge = `<span class="status-badge nolink"><i class="fas fa-exclamation-circle"></i> No Link</span>`;
        }
        
        // �7�3 Action Button
        let actionHtml = '';
        if (isAssigned && linkUrl) {
            actionHtml = `
                <button class="btn-action copy" onclick="copyLink('${linkUrl}')">
                    <i class="fas fa-copy"></i> Copy
                </button>
            `;
        } else if (hasLink && linkUrl) {
            actionHtml = `
                <button class="btn-action assign" 
                        onclick="assignProduct('${product.product_id}', '${productName.replace(/'/g, "\\'")}', '${commission}', '${linkUrl}', '${campaignId}')">
                    <i class="fas fa-link"></i> Assign
                </button>
            `;
        } else {
            actionHtml = `
                <span class="btn-action ask-bd">
                    <i class="fas fa-clock"></i> Ask BD
                </span>
            `;
        }
        
        // �7�3 Row dengan border jika ada link
        const rowStyle = hasLink ? 'border-left: 3px solid #4ade80;' : '';
        
        html += `
            <tr style="border-bottom: 1px solid #1e293b; ${rowStyle}" data-product-id="${product.product_id}">
                <td>
                    <div class="product-cell">
                        <div class="product-thumb">
                            ${imageUrl ? 
                                `<img src="${imageUrl}" onerror="this.parentElement.innerHTML='<i class=\\'fas fa-box\\'></i>'">` : 
                                `<i class="fas fa-box"></i>`
                            }
                        </div>
                        <div class="product-info">
                            <div class="product-name" title="${productName}">
                                ${productName.substring(0, 50)}${productName.length > 50 ? '...' : ''}
                            </div>
                            <div class="product-meta">
                                ${shopName ? `<span class="shop-name"><i class="fas fa-store"></i> ${shopName}</span>` : ''}
                                ${campaignId ? `<span class="campaign-id"> | Campaign: ${campaignId.substring(0,8)}</span>` : ''}
                                ${linkCreator ? `<span style="color:#6b7280;"> | by ${linkCreator}</span>` : ''}
                            </div>
                        </div>
                    </div>
                </td>
                <td class="col-sales">
                    <span style="color:#9aaebe; font-size:11px;">${sales > 0 ? formatNumber(sales) : '-'}</span>
                </td>
                <td class="col-commission">
                    <span style="color:#fbbf24; font-weight:600; font-size:12px;">${commissionDisplay}</span>
                </td>
                <td class="col-status">
                    ${statusBadge}
                </td>
                <td class="col-action">
                    ${actionHtml}
                </td>
            </tr>
        `;
    });
    
    return html;
}


// ========== ATTACH PRODUCT EVENTS FILTER ==========
function attachProductEventsFilter() {
    // Assign Link
    document.querySelectorAll('.assign-link-btn').forEach(btn => {
        const newBtn = btn.cloneNode(true);
        btn.parentNode.replaceChild(newBtn, btn);
        
        newBtn.addEventListener('click', async function() {
            const data = window.assignDataGlobal;
            if (!data) return;
            
            const productId = this.getAttribute('data-product-id');
            const productName = this.getAttribute('data-product-name');
            const commission = parseFloat(this.getAttribute('data-commission')) || 10;
            const link = this.getAttribute('data-link');
            const linkCampaignId = this.getAttribute('data-campaign-id');
            
            const campaignSelect = document.getElementById('campaignSelectFilter');
            let campaignId = campaignSelect ? campaignSelect.value : null;
            
            if (!campaignId && linkCampaignId) {
                campaignId = linkCampaignId;
            }
            
            if (!campaignId) {
                showToastGlobal('Please select a campaign first!', 'error');
                return;
            }
            
            if (!link) {
                showToastGlobal('No affiliate link available!', 'error');
                return;
            }
            
            if (!confirm(`Assign link for "${productName}" to @${data.creatorUsername}?`)) return;
            
            this.disabled = true;
            this.innerHTML = '<i class="fas fa-spinner fa-pulse"></i>';
            
            try {
                const response = await fetch(baseUrlIS + 'is/assign_product_link', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                    body: new URLSearchParams({
                        creator_id: data.creatorId,
                        product_id: productId,
                        campaign_id: campaignId,
                        commission_rate: commission,
                        affiliate_link: link
                    })
                });
                
                const result = await response.json();
                
                if (result.success) {
                    showToastGlobal(result.message, 'success');
                    setTimeout(() => openAssignLinkModal(data.creatorId, data.creatorUsername), 1500);
                } else {
                    showToastGlobal(result.message, 'error');
                    this.disabled = false;
                    this.innerHTML = '<i class="fas fa-link"></i> Assign';
                }
            } catch (error) {
                showToastGlobal('Error: ' + error.message, 'error');
                this.disabled = false;
                this.innerHTML = '<i class="fas fa-link"></i> Assign';
            }
        });
    });
    
    // Copy Link
    document.querySelectorAll('.copy-link-btn').forEach(btn => {
        const newBtn = btn.cloneNode(true);
        btn.parentNode.replaceChild(newBtn, btn);
        
        newBtn.addEventListener('click', function() {
            const link = this.getAttribute('data-link');
            if (link) {
                navigator.clipboard.writeText(link).then(() => {
                    showToastGlobal('Link copied!', 'success');
                }).catch(() => {
                    const textarea = document.createElement('textarea');
                    textarea.value = link;
                    document.body.appendChild(textarea);
                    textarea.select();
                    document.execCommand('copy');
                    document.body.removeChild(textarea);
                    showToastGlobal('Link copied!', 'success');
                });
            }
        });
    });
}


// ========== GET ACTIVE CAMPAIGNS ==========
async function getActiveCampaigns() {
    try {
        const response = await fetch(baseUrlIS + 'is/get_active_campaigns', {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json'
            }
        });
        
        const result = await response.json();
        console.log('Active campaigns:', result);
        
        if (result.success) {
            return result.campaigns || [];
        }
        return [];
    } catch (error) {
        console.error('Error fetching campaigns:', error);
        return [];
    }
}
// ========== RENDER PRODUCT ROWS ==========
function renderProductRows(products, creatorId, creatorUsername) {
    if (!products || products.length === 0) {
        return `
            <tr>
                <td colspan="5" style="text-align:center; padding:30px; color:#6b7280;">
                    No products available
                </td>
            </tr>
        `;
    }
    
    let html = '';
    products.forEach((product) => {
        const hasLink = product.has_link;
        const isAssigned = product.is_assigned;
        const productName = product.product_name || 'Unknown';
        const shopName = product.shop_name || '';
        
        let statusBadge = '';
        let actionHtml = '';
        
        if (isAssigned) {
            statusBadge = `<span style="color:#4ade80;"><i class="fas fa-check-circle"></i> Assigned</span>`;
            actionHtml = `
                <div style="display: flex; flex-direction: column; align-items: center; gap: 4px;">
                    <button class="copy-link-btn" 
                            data-link="${product.assigned_link || ''}"
                            style="background: #1e293b; color: #4ade80; border: 1px solid #4ade80; padding: 4px 12px; border-radius: 12px; cursor: pointer; font-size: 10px;">
                        <i class="fas fa-copy"></i> Copy
                    </button>
                    ${product.link_campaign_id ? `<span style="font-size:8px; color:#6b7280;">Campaign: ${product.link_campaign_id.substring(0,8)}</span>` : ''}
                </div>
            `;
        } else if (hasLink) {
            statusBadge = `<span style="color:#fbbf24;"><i class="fas fa-link"></i> Link Ready</span>`;
            actionHtml = `
                <button class="assign-link-btn" 
                        data-product-id="${product.product_id}"
                        data-product-name="${productName}"
                        data-commission="${product.link_commission || product.open_commission_rate || 10}"
                        data-link="${product.affiliate_link || ''}"
                        data-campaign-id="${product.link_campaign_id || ''}"
                        style="background: #8b5cf6; color: white; border: none; padding: 6px 12px; border-radius: 20px; cursor: pointer; font-size: 11px; width: 100%;">
                    <i class="fas fa-link"></i> Assign
                </button>
                ${product.link_campaign_id ? `<span style="font-size:8px; color:#6b7280; display:block; margin-top:2px;">Campaign: ${product.link_campaign_id.substring(0,8)}</span>` : ''}
            `;
        } else {
            statusBadge = `<span style="color:#ef4444;"><i class="fas fa-exclamation-circle"></i> No Link</span>`;
            actionHtml = `
                <span style="color:#ef4444; font-size:10px;">
                    <i class="fas fa-clock"></i> No Link
                </span>
                <span style="font-size:8px; color:#6b7280; display:block; margin-top:2px;">Ask BD to generate</span>
            `;
        }
        
        const commission = product.link_commission || product.commission_rate || product.open_commission_rate || 0;
        const commissionDisplay = typeof commission === 'string' ? commission : commission + '%';
        
        html += `
            <tr style="border-bottom: 1px solid #2a3346;" data-product-id="${product.product_id}">
                <td style="padding: 8px;">
                    <div style="display: flex; align-items: center; gap: 10px;">
                        ${product.image_url ? 
                            `<img src="${product.image_url}" style="width: 35px; height: 35px; object-fit: cover; border-radius: 6px;" onerror="this.style.display='none'">` :
                            `<div style="width: 35px; height: 35px; background: #1e293b; border-radius: 6px; display: flex; align-items: center; justify-content: center;">
                                <i class="fas fa-box" style="color: #6b7280; font-size: 14px;"></i>
                            </div>`
                        }
                        <div>
                            <div style="font-weight: 500; color: #e2f0e8; font-size: 11px;">
                                ${productName.substring(0, 45)}${productName.length > 45 ? '...' : ''}
                            </div>
                            <div style="font-size: 9px; color: #6b7280;">
                                ${shopName || 'No shop'}
                            </div>
                        </div>
                    </div>
                </td>
                <td style="padding: 8px; text-align: center; font-size: 11px;">
                    ${product.sales_from_creator ? formatNumber(product.sales_from_creator) : (product.sales_count ? formatNumber(product.sales_count) : '-')}
                </td>
                <td style="padding: 8px; text-align: center; font-size: 11px; color: #fbbf24;">
                    ${commissionDisplay}
                </td>
                <td style="padding: 8px; text-align: center; font-size: 10px;">
                    ${statusBadge}
                </td>
                <td style="padding: 8px; text-align: center;">
                    ${actionHtml}
                </td>
            </tr>
        `;
    });
    
    return html;
}


function attachTaskEvents(containerId) {
    if (containerId === 'scoutingContainerDashboard') {
        document.querySelectorAll('.scouting-item-dashboard').forEach(item => {
            item.addEventListener('click', () => {
                const creatorId = item.getAttribute('data-creator-id');
                showCreatorDetailIS(creatorId);
            });
        });
    } else if (containerId === 'linkSwappingContainerDashboard') {
        document.querySelectorAll('.link-item-dashboard').forEach(item => {
    // Hapus event listener lama jika ada
    const newItem = item.cloneNode(true);
    item.parentNode.replaceChild(newItem, item);
    
    newItem.addEventListener('click', function(e) {
        // Jangan trigger jika klik tombol WA
        if (e.target.closest('.update-phone-quick-btn')) return;
        
        const creatorId = this.getAttribute('data-creator-id');
        const creatorName = this.getAttribute('data-creator-name');
        const creatorPhone = this.getAttribute('data-creator-phone') || '';
        
        console.log('�9�7�1�5 Task 2 clicked:', { creatorId, creatorName, creatorPhone });
        
        if (!creatorPhone || creatorPhone === '') {
            showToastGlobal(`Creator @${creatorName} belum memiliki nomor WhatsApp!`, 'error');
            return;
        }
        
        // �9�7 PANGGIL openAssignLinkModal (BUKAN showLinkAssignmentModal)
        openAssignLinkModal(creatorId, creatorName);
    });
});
    } else if (containerId === 'sendingSampleContainerDashboard') {
        document.querySelectorAll('.sample-item-dashboard').forEach(item => {
            item.addEventListener('click', () => {
                const creatorId = item.getAttribute('data-creator-id');
                const creatorName = item.getAttribute('data-creator-name');
                const creatorPhone = item.getAttribute('data-creator-phone');
                const creatorCategory = item.getAttribute('data-creator-category');
                showSampleRequestModalIS(creatorId, creatorName, creatorCategory, creatorPhone);
            });
        });
    } else if (containerId === 'monitoringContainerDashboard') {
        document.querySelectorAll('.monitor-item-dashboard').forEach(item => {
            item.addEventListener('click', () => {
                const creatorId = item.getAttribute('data-creator-id');
                showMonitoringDetailModal(creatorId);
            });
        });
    }
}

// ========== RE-ATTACH PRODUCT EVENTS ==========
function reattachProductEvents(creatorId, creatorUsername) {
    // Assign Link
    document.querySelectorAll('.assign-link-btn').forEach(btn => {
        const newBtn = btn.cloneNode(true);
        btn.parentNode.replaceChild(newBtn, btn);
        
        newBtn.addEventListener('click', async function() {
            const productId = this.getAttribute('data-product-id');
            const productName = this.getAttribute('data-product-name');
            const commission = parseFloat(this.getAttribute('data-commission')) || 10;
            const link = this.getAttribute('data-link');
            const linkCampaignId = this.getAttribute('data-campaign-id');
            
            const campaignSelect = document.getElementById('campaignSelect');
            let campaignId = campaignSelect ? campaignSelect.value : null;
            
            if (!campaignId && linkCampaignId) {
                campaignId = linkCampaignId;
            }
            
            if (!campaignId) {
                showToastInModal('Please select a campaign first!', 'error');
                return;
            }
            
            if (!link) {
                showToastInModal('No affiliate link available!', 'error');
                return;
            }
            
            if (!confirm(`Assign link for "${productName}" to @${creatorUsername}?`)) return;
            
            this.disabled = true;
            this.innerHTML = '<i class="fas fa-spinner fa-pulse"></i>';
            
            try {
                const response = await fetch(baseUrlIS + 'is/assign_product_link', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                    body: new URLSearchParams({
                        creator_id: creatorId,
                        product_id: productId,
                        campaign_id: campaignId,
                        commission_rate: commission,
                        affiliate_link: link
                    })
                });
                
                const result = await response.json();
                
                if (result.success) {
                    showToastInModal(result.message, 'success');
                    setTimeout(() => openAssignLinkModal(creatorId, creatorUsername), 1500);
                } else {
                    showToastInModal(result.message, 'error');
                    this.disabled = false;
                    this.innerHTML = '<i class="fas fa-link"></i> Assign';
                }
            } catch (error) {
                showToastInModal('Error: ' + error.message, 'error');
                this.disabled = false;
                this.innerHTML = '<i class="fas fa-link"></i> Assign';
            }
        });
    });
    
    // Copy Link
    document.querySelectorAll('.copy-link-btn').forEach(btn => {
        const newBtn = btn.cloneNode(true);
        btn.parentNode.replaceChild(newBtn, btn);
        
        newBtn.addEventListener('click', function() {
            const link = this.getAttribute('data-link');
            if (link) {
                navigator.clipboard.writeText(link).then(() => {
                    showToastInModal('Link copied!', 'success');
                }).catch(() => {
                    const textarea = document.createElement('textarea');
                    textarea.value = link;
                    document.body.appendChild(textarea);
                    textarea.select();
                    document.execCommand('copy');
                    document.body.removeChild(textarea);
                    showToastInModal('Link copied!', 'success');
                });
            }
        });
    });
}

</script>
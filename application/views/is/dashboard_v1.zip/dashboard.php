<!-- file: application/views/is/dashboard.php -->
<style>
    /* Dashboard IS styles - konsisten dengan tema ungu + biru + hitam */
    .dashboard-header {
        background: linear-gradient(135deg, #0f0f1a 0%, #13111f 100%);
        border-radius: 20px;
        padding: 16px 20px;
        margin-bottom: 20px;
        border: 1px solid var(--border);
        display: flex;
        justify-content: space-between;
        align-items: center;
        flex-wrap: wrap;
        gap: 16px;
    }
    
    .dashboard-title h1 { 
        font-size: 20px; 
        font-weight: 700; 
        background: linear-gradient(135deg, var(--purple), var(--cyan), var(--blue));
        -webkit-background-clip: text; 
        background-clip: text; 
        color: transparent;
    }
    
    .dashboard-title .sub { 
        font-size: 10px; 
        color: var(--text-secondary); 
        margin-top: 4px;
    }
    
    /* Desktop Menu */
    .desktop-menu {
        display: flex;
        gap: 12px;
        align-items: center;
        flex-wrap: wrap;
    }
    
    .desktop-menu a {
        color: var(--text-muted);
        text-decoration: none;
        font-size: 13px;
        font-weight: 500;
        padding: 6px 14px;
        border-radius: 40px;
        transition: var(--transition);
    }
    
    .desktop-menu a:hover, .desktop-menu a.active {
        background: var(--purple-glow);
        color: var(--purple);
    }
    
    .stat-cards-dashboard { 
        display: flex; 
        gap: 20px; 
        background: rgba(139, 92, 246, 0.1);
        padding: 6px 16px; 
        border-radius: 60px; 
        border: 1px solid var(--border);
    }
    
    .stat-item-dashboard { text-align: center; padding: 2px 6px; }
    .stat-label-dashboard { font-size: 9px; color: var(--text-muted); }
    .stat-value-dashboard { font-size: 18px; font-weight: 700; background: linear-gradient(135deg, var(--purple), var(--blue)); -webkit-background-clip: text; background-clip: text; color: transparent; }
    
    /* Tabs */
    .tabs-bar-dashboard { display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 12px; margin-bottom: 20px; border-bottom: 1px solid var(--border); padding-bottom: 10px; }
    .tabs-dashboard { display: flex; gap: 6px; flex-wrap: wrap; }
    .tab-btn-dashboard { background: transparent; border: none; padding: 6px 16px; font-size: 12px; font-weight: 600; color: var(--text-muted); cursor: pointer; border-radius: 40px; transition: var(--transition); }
    .tab-btn-dashboard.active { background: linear-gradient(135deg, var(--purple-glow), rgba(59, 130, 246, 0.1)); color: var(--purple); border: 1px solid rgba(139, 92, 246, 0.4); }
    .scout-btn-dashboard { background: linear-gradient(135deg, var(--purple-glow), rgba(6, 182, 212, 0.1)); border: 1px solid var(--purple); padding: 6px 16px; border-radius: 40px; color: var(--purple); font-weight: 600; cursor: pointer; font-size: 12px; transition: var(--transition); }
    .scout-btn-dashboard:hover { background: var(--purple); color: white; }
    
    .tab-content-dashboard { display: none; animation: fadeIn 0.3s ease; }
    .tab-content-dashboard.active { display: block; }
    
    /* Stages Container */
    .stages-scroll-dashboard { overflow-x: auto; overflow-y: visible; margin-bottom: 20px; padding-bottom: 12px; }
    .stages-container-dashboard { display: flex; flex-direction: row; gap: 16px; min-width: min-content; }
    
    /* Warna berbeda untuk setiap stage card */
    .stage-card-dashboard { border-radius: 20px; padding: 16px; width: 340px; flex-shrink: 0; transition: var(--transition); border: 1px solid var(--border); }
    .stage-card-dashboard[data-stage="1"] { background: linear-gradient(135deg, #1a1030, #13111f); border-top: 3px solid var(--purple); }
    .stage-card-dashboard[data-stage="2"] { background: linear-gradient(135deg, #0f1a2e, #13111f); border-top: 3px solid var(--blue); }
    .stage-card-dashboard[data-stage="3"] { background: linear-gradient(135deg, #0a1a1f, #13111f); border-top: 3px solid var(--cyan); }
    .stage-card-dashboard[data-stage="4"] { background: linear-gradient(135deg, #0a1f15, #13111f); border-top: 3px solid var(--green); }
    
    .stage-card-dashboard.completed { opacity: 0.7; }
    .stage-title-dashboard { font-weight: 700; font-size: 14px; margin-bottom: 14px; padding-bottom: 8px; border-bottom: 1px solid var(--border); display: flex; align-items: center; gap: 10px; flex-wrap: wrap; justify-content: space-between; color: var(--text-primary); }
    .stage-count-dashboard { background: var(--bg-elevated); padding: 2px 8px; border-radius: 40px; font-size: 10px; }
    
    /* Items */
    .stage-item-dashboard { background: var(--bg-elevated); border-radius: 14px; padding: 12px; margin-bottom: 10px; cursor: pointer; transition: var(--transition); border: 1px solid transparent; }
    .stage-item-dashboard:hover { border-color: var(--purple); transform: translateX(3px); }
    .stage-item-dashboard strong { display: flex; align-items: center; gap: 8px; margin-bottom: 6px; color: var(--text-primary); font-size: 13px; }
    .item-details-dashboard { display: flex; flex-wrap: wrap; gap: 10px; font-size: 10px; color: var(--text-secondary); margin-bottom: 6px; }
    .badge-dashboard { display: inline-flex; align-items: center; gap: 4px; padding: 2px 8px; border-radius: 20px; font-size: 9px; font-weight: 600; }
    .badge-pending { background: rgba(245, 158, 11, 0.15); color: #f59e0b; }
    .badge-active { background: rgba(16, 185, 129, 0.15); color: #10b981; }
    .badge-approved { background: rgba(139, 92, 246, 0.15); color: #8b5cf6; }
    
    .task-btn-dashboard { margin-top: 14px; width: 100%; padding: 8px; border-radius: 40px; border: none; background: var(--bg-elevated); color: var(--text-secondary); font-weight: 600; cursor: pointer; transition: var(--transition); font-size: 12px; }
    .task-btn-dashboard:hover:not(:disabled) { background: linear-gradient(135deg, var(--purple), var(--blue)); color: white; }
    .task-btn-dashboard:disabled { opacity: 0.5; cursor: not-allowed; }
    
    /* Product item */
    .product-item-dashboard { background: #0f1420; border-radius: 12px; padding: 10px; margin-top: 8px; display: flex; justify-content: space-between; align-items: center; border: 1px solid #2a3346; }
    .product-info-dashboard { flex: 1; }
    .product-name-dashboard { color: #ffffff; font-size: 12px; font-weight: 500; }
    .product-price-dashboard { color: #4ade80; font-size: 11px; margin-top: 3px; }
    .add-product-btn { background: #1e293b; border: 1px dashed #4ade80; border-radius: 12px; padding: 8px; text-align: center; color: #4ade80; cursor: pointer; margin-top: 8px; font-size: 12px; }
    
    /* Recent Orders */
    .recent-section-dashboard { background: var(--bg-card); border-radius: 20px; padding: 16px; border: 1px solid var(--border); overflow-x: auto; margin-top: 20px; }
    .recent-table-dashboard { width: 100%; min-width: 550px; border-collapse: collapse; }
    .recent-table-dashboard th, .recent-table-dashboard td { padding: 8px 6px; text-align: left; border-bottom: 1px solid var(--border); font-size: 11px; color: var(--text-secondary); }
    .recent-table-dashboard th { color: var(--purple); font-weight: 600; }
    
    /* Brands Grid */
    .brands-grid-dashboard { display: flex; flex-direction: column; gap: 16px; }
    .brand-card-dashboard { background: var(--bg-card); border-radius: 20px; padding: 16px; border: 1px solid var(--border); }
    .brand-item-row-dashboard { display: flex; justify-content: space-between; align-items: center; padding: 10px 0; border-bottom: 1px solid var(--border); flex-wrap: wrap; gap: 6px; }
    
    /* Modal */
    .modal-overlay-dashboard { position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.9); backdrop-filter: blur(8px); display: flex; align-items: center; justify-content: center; z-index: 2000; visibility: hidden; opacity: 0; transition: 0.2s; }
    .modal-overlay-dashboard.active { visibility: visible; opacity: 1; }
    .modal-glass-dashboard { background: #111827; border-radius: 28px; width: 95%; max-width: 550px; padding: 24px; border: 1px solid #4ade80; max-height: 85vh; overflow-y: auto; color: #e2f0e8; }
    .modal-header-dashboard { display: flex; justify-content: space-between; align-items: center; margin-bottom: 16px; border-bottom: 1px solid #2a3346; padding-bottom: 10px; }
    .modal-header-dashboard h3 { color: #e2f0e8; font-size: 18px; }
    .modal-close-dashboard { font-size: 26px; cursor: pointer; color: #9aaebe; }
    .modal-body label { color: #bdf2c0; font-weight: 500; display: block; margin-top: 14px; margin-bottom: 5px; font-size: 13px; }
    .modal-body input, .modal-body select, .modal-body textarea { width: 100%; padding: 10px 12px; background: #0f1420; border: 1px solid #2a3346; border-radius: 14px; color: #e2f0e8; font-size: 13px; }
    .modal-body button { background: #4ade80; color: #0a0e17; border: none; padding: 10px 18px; border-radius: 40px; font-weight: 600; cursor: pointer; transition: 0.2s; font-size: 13px; }
    .modal-body button:hover { background: #22c55e; }
    .flex-buttons { display: flex; gap: 10px; margin-top: 16px; }
    .flex-buttons button { flex: 1; }
    
    /* Leaderboard */
    .leaderboard-card-dashboard { background: var(--bg-card); border-radius: 20px; padding: 20px; border: 1px solid var(--border); }
    .leaderboard-item-dashboard { padding: 12px; border-bottom: 1px solid var(--border); display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 8px; }
    
    /* Mobile Bottom Nav */
    .mobile-bottom-nav-dashboard { display: none; position: fixed; bottom: 0; left: 0; right: 0; background: var(--bg-card); border-top: 1px solid var(--border); padding: 6px 12px; justify-content: space-around; z-index: 100; }
    .mobile-nav-item-dashboard { display: flex; flex-direction: column; align-items: center; gap: 2px; color: var(--text-muted); text-decoration: none; font-size: 9px; padding: 6px; border-radius: 40px; }
    .mobile-nav-item-dashboard i { font-size: 16px; }
    .mobile-nav-item-dashboard.active { color: var(--purple); background: var(--purple-glow); }
    
    .text-center { text-align: center; }
    .mt-2 { margin-top: 8px; }
    .mt-3 { margin-top: 12px; }
    .mb-2 { margin-bottom: 8px; }
    
    @media (min-width: 768px) {
        .mobile-bottom-nav-dashboard { display: none; }
        .desktop-menu { display: flex; }
        .stage-card-dashboard { width: 360px; }
    }
    
    @media (max-width: 767px) {
        .mobile-bottom-nav-dashboard { display: flex; }
        body { padding-bottom: 60px; }
        .dashboard-header { flex-direction: column; text-align: center; padding: 14px; }
        .stat-cards-dashboard { justify-content: center; flex-wrap: wrap; gap: 12px; }
        .desktop-menu { display: none; }
        .stage-card-dashboard { width: 300px; padding: 14px; }
        .modal-glass-dashboard { width: 95%; padding: 18px; }
        .dashboard-title h1 { font-size: 18px; }
    }
    /* Tambahkan CSS untuk selected product items */
.selected-product-item {
    transition: all 0.2s ease;
}

.selected-product-item:hover {
    border-color: #4ade80;
}

.commission-input {
    transition: all 0.2s ease;
}

.commission-input:focus {
    outline: none;
    border-color: #4ade80;
    box-shadow: 0 0 5px rgba(74, 222, 128, 0.3);
}

.generate-link-btn {
    transition: all 0.2s ease;
}

.generate-link-btn:hover {
    transform: translateY(-1px);
    box-shadow: 0 2px 8px rgba(74, 222, 128, 0.3);
}

.generated-link-container {
    animation: fadeIn 0.3s ease;
}

.copy-link-btn {
    transition: all 0.2s ease;
}

.copy-link-btn:hover {
    background: #4ade80 !important;
    color: #0a0e17 !important;
}

@keyframes fadeIn {
    from { opacity: 0; transform: translateY(-5px); }
    to { opacity: 1; transform: translateY(0); }
}

.order-status {
    display: inline-block;
    padding: 2px 6px;
    border-radius: 12px;
    font-size: 9px;
    font-weight: 500;
}

.order-status.completed {
    background: rgba(16, 185, 129, 0.15);
    color: #10b981;
}

.order-status.processing {
    background: rgba(245, 158, 11, 0.15);
    color: #f59e0b;
}

.order-status.cancelled {
    background: rgba(239, 68, 68, 0.15);
    color: #ef4444;
}
/* Brand badge style */
.brand-badge {
    background: rgba(74, 222, 128, 0.15);
    padding: 2px 8px;
    border-radius: 20px;
    font-size: 10px;
    color: #4ade80;
    display: inline-flex;
    align-items: center;
    gap: 4px;
}

.brand-badge i {
    font-size: 9px;
}

/* Source badge */
.source-badge-imported {
    color: #fbbf24;
    font-size: 9px;
}

.source-badge-manual {
    color: #4ade80;
    font-size: 9px;
}

/* Creator Status Tab Styles */
.creator-tab-btn.active {
    background: linear-gradient(135deg, var(--purple-glow), rgba(59, 130, 246, 0.1));
    color: var(--purple);
    border: 1px solid rgba(139, 92, 246, 0.4);
}

.creator-tab-btn:hover:not(.active) {
    background: rgba(139, 92, 246, 0.1);
    color: var(--purple);
}

.view-creator-detail:hover {
    background: var(--purple) !important;
    color: white !important;
}

/* Responsive untuk mobile */
@media (max-width: 767px) {
    .creator-list-container table,
    .creator-list-container thead,
    .creator-list-container tbody,
    .creator-list-container th,
    .creator-list-container td,
    .creator-list-container tr {
        display: block;
    }
    
    .creator-list-container thead {
        display: none;
    }
    
    .creator-list-container tr {
        margin-bottom: 12px;
        border: 1px solid var(--border);
        border-radius: 12px;
        padding: 12px;
    }
    
    .creator-list-container td {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 8px 0 !important;
        text-align: left !important;
    }
    
    .creator-list-container td:before {
        content: attr(data-label);
        font-weight: 600;
        color: #9aaebe;
        margin-right: 16px;
    }
}

/* Top Creator Tab Styles */
.leaderboard-card-dashboard {
    transition: transform 0.2s, box-shadow 0.2s;
}

.leaderboard-card-dashboard:hover {
    transform: translateY(-2px);
    box-shadow: 0 8px 25px rgba(0,0,0,0.3);
}

.period-btn.active {
    background: linear-gradient(135deg, var(--purple-glow), rgba(59, 130, 246, 0.1));
    color: var(--purple);
    border-color: rgba(139, 92, 246, 0.4);
}

.period-btn:hover:not(.active) {
    background: rgba(139, 92, 246, 0.1);
    border-color: var(--purple);
}

/* Responsive */
@media (max-width: 768px) {
    #tabLeaderboardDashboard > div:first-of-type {
        flex-direction: column;
        align-items: flex-start;
    }
    
    #tabLeaderboardDashboard > div:not(:first-of-type) {
        grid-template-columns: 1fr !important;
    }
    
    .leaderboard-item-dashboard {
        flex-wrap: wrap;
    }
    
    .leaderboard-item-dashboard > div:last-child {
        width: 100%;
        text-align: left;
        margin-top: 8px;
        padding-left: 48px;
    }
}

/* Icon SV dan LV styles */
.icon-sv {
    display: inline-flex;
    align-items: center;
    gap: 3px;
    background: linear-gradient(135deg, #8b5cf6, #a855f7);
    padding: 2px 8px;
    border-radius: 20px;
    font-size: 9px;
    font-weight: 600;
    color: white;
    box-shadow: 0 0 8px rgba(139, 92, 246, 0.5);
}

.icon-lv {
    display: inline-flex;
    align-items: center;
    gap: 3px;
    background: linear-gradient(135deg, #f97316, #ea580c);
    padding: 2px 8px;
    border-radius: 20px;
    font-size: 9px;
    font-weight: 600;
    color: white;
    box-shadow: 0 0 8px rgba(249, 115, 22, 0.5);
}

.icon-sv i, .icon-lv i {
    font-size: 8px;
}
</style>

<!-- Desktop Menu -->
<div class="desktop-menu">
    <a href="<?= base_url('is/dashboard') ?>" class="active"><i class="fas fa-tachometer-alt"></i> Dashboard</a>
    <a href="<?= base_url('is/creators') ?>"><i class="fas fa-users"></i> Creators</a>
    <a href="<?= base_url('is/performance') ?>"><i class="fas fa-chart-line"></i> Performance</a>
    <a href="<?= base_url('performance') ?>"><i class="fas fa-chart-line"></i> Performance Creator</a>
    <a href="<?= base_url('is/team_performance') ?>"><i class="fas fa-users"></i> Team Performance</a>
    <a href="<?= base_url('analytics/bd') ?>"><i class="fas fa-chart-line"></i> Analytics</a>
     <a href="<?= base_url($this->session->userdata('role') == 'IS' ? 'is/target_plan_dashboard' : 'bd/target_plan_dashboard') ?>" class="sidebar-link">
        <i class="fas fa-bullseye"></i>
        <span>Target Plan</span>
    </a>
</div>

<!-- Mobile Menu Bar -->
<div class="mobile-menu-bar">
    <a href="<?= base_url('is/dashboard') ?>" class="active"><i class="fas fa-tachometer-alt"></i> Dashboard</a>
    <a href="<?= base_url('is/creators') ?>"><i class="fas fa-users"></i> Creators</a>
    <a href="<?= base_url('is/performance') ?>"><i class="fas fa-chart-line"></i> Performance</a>
    <a href="<?= base_url('analytics/bd') ?>"><i class="fas fa-chart-line"></i> Analytics</a>
    
</div>

<div class="dashboard">
    <!-- Dashboard Header -->
   <div class="dashboard-header">
    <div class="dashboard-title">
        <h1>CA Dashboard</h1>
        <div class="sub"><i class="fas fa-users"></i> Managing <?= $total_creators ?? 0 ?> Creator Partners  Real-time API</div>
    </div>
    <div class="stat-cards-dashboard">
        <div class="stat-item-dashboard">
            <div class="stat-label-dashboard">TOTAL GMV</div>
            <div class="stat-value-dashboard">Rp <?= number_format($total_gmv ?? 0, 0, ',', '.') ?></div>
            <?php if (($gmv_growth ?? 0) != 0): ?>
            <div style="font-size: 8px; color: <?= ($gmv_growth ?? 0) >= 0 ? '#4ade80' : '#ef4444' ?>;">
                <?= ($gmv_growth ?? 0) >= 0 ? '��' : '��' ?> <?= abs($gmv_growth ?? 0) ?>% vs kemarin
            </div>
            <?php endif; ?>
        </div>
        <!--<div class="stat-item-dashboard">-->
        <!--    <div class="stat-label-dashboard">EST. COMMISSION</div>-->
        <!--    <div class="stat-value-dashboard">Rp <?= number_format($total_estimated_commission ?? 0, 0, ',', '.') ?></div>-->
        <!--</div>-->
        <div class="stat-item-dashboard">
            <div class="stat-label-dashboard">TOTAL ORDERS</div>
            <div class="stat-value-dashboard"><?= number_format($total_orders ?? 0) ?></div>
        </div>
        <div class="stat-item-dashboard">
            <div class="stat-label-dashboard">STATUS</div>
            <div class="stat-value-dashboard" style="font-size:14px;"><i class="fas fa-circle" style="color:#10b981; font-size:8px;"></i> LIVE</div>
        </div>
    </div>
</div>

    <!-- Tabs -->
    <div class="tabs-bar-dashboard">
        <div class="tabs-dashboard">
            <button class="tab-btn-dashboard active" data-tab="tabTaskDashboard"><i class="fas fa-clipboard-list"></i> Task</button>
            <button class="tab-btn-dashboard" data-tab="tabCreatorsDashboard"><i class="fas fa-users"></i> Creator Status</button>
            <button class="tab-btn-dashboard" data-tab="tabLeaderboardDashboard"><i class="fas fa-trophy"></i> Top Creator</button>
        </div>
        
        <button class="scout-btn-dashboard" id="addCreatorBtnDashboard"><i class="fas fa-plus-circle"></i> Tambah Creator</button>
    </div>

  
 <!-- TAB TASK - 4 STAGE dengan SCROLL dan SEARCH -->
<div id="tabTaskDashboard" class="tab-content-dashboard active">
    <div class="stages-scroll-dashboard">
        <div class="stages-container-dashboard">
           
           <!-- TASK 1: SCOUTING - UNGU -->
<div class="stage-card-dashboard" data-stage="1" style="display: flex; flex-direction: column; height: 500px;">
    <div class="stage-title-dashboard" style="flex-shrink: 0;">
        <span><i class="fas fa-search"></i> 1. SCOUTING (Cari Creator)</span>
        <span class="stage-count-dashboard" id="scoutingCountDashboard"><?= count($scouting_items ?? []) ?></span>
    </div>
    
    <!-- Search input -->
    <div style="flex-shrink: 0; padding: 8px 12px;">
        <input type="text" id="searchScoutingDashboard" placeholder="�9�3 Cari creator atau brand..." style="width: 100%; padding: 6px 10px; border: 1px solid #ddd; border-radius: 6px; font-size: 12px; background: #1a1f2e; color: white;">
    </div>
    
    <!-- Scrollable container -->
    <div id="scoutingContainerDashboard" style="flex: 1; overflow-y: auto; padding: 0 8px;">
        <?php if (!empty($scouting_items)): ?>
            <?php foreach ($scouting_items as $item): ?>
            <div class="stage-item-dashboard scouting-item-dashboard" 
                 data-creator-id="<?= $item->id ?>" 
                 data-creator-name="<?= htmlspecialchars($item->username) ?>"
                 data-searchable="<?= strtolower(htmlspecialchars($item->username . ' ' . ($item->shop_name ?? '') . ' ' . ($item->brand_name ?? ''))) ?>">
                
                <strong><i class="fab fa-tiktok"></i> <?= htmlspecialchars($item->username) ?></strong>
                
                <!-- �9�7 TAMPILAN SHOP/BRAND NAME -->
                <div class="item-details-dashboard" style="margin-top: 4px;">
                    <?php if ($is_supervisor && isset($item->is_username)): ?>
                    <span><i class="fas fa-user-tie"></i> IS: <?= htmlspecialchars($item->is_username) ?></span>
                    <?php endif; ?>
                    
                    <!-- �9�7 SHOP NAME / BRAND -->
                    <?php if (!empty($item->shop_name) || !empty($item->brand_name)): ?>
                    <span class="brand-badge" style="background: rgba(74,222,128,0.15); padding: 2px 8px; border-radius: 20px;">
                        <i class="fas fa-store"></i> <?= htmlspecialchars($item->shop_name ?: $item->brand_name) ?>
                    </span>
                    <?php else: ?>
                    <span style="color: #9aaebe; font-size: 10px;">
                        <i class="fas fa-store"></i> Belum ada brand
                    </span>
                    <?php endif; ?>
                </div>
                
                <div class="item-details-dashboard">
                    <span><i class="fab fa-whatsapp"></i> <?= $item->phone ?? '-' ?></span>
                    <span><i class="fas fa-tag"></i> <?= $item->category ?? '-' ?></span>
                </div>
                 <?php if (!empty($item->imported_gmv) && $item->imported_gmv > 0): ?>
                <div class="item-details-dashboard" style="margin-top: 4px;">
                    <span style="color: #fbbf24; font-size: 11px;">
                        <i class="fas fa-chart-line"></i> GMV 28H: Rp <?= number_format($item->imported_gmv, 0, ',', '.') ?>
                    </span>
                    <?php if (!empty($item->imported_products_count)): ?>
                    <span style="color: #9aaebe; font-size: 10px; margin-left: 8px;">
                        <i class="fas fa-box"></i> <?= $item->imported_products_count ?> produk
                    </span>
                    <?php endif; ?>
                </div>
                <?php endif; ?>
                <!-- �9�7 INFO SUMBER DATA (imported/manual) -->
                <div class="item-details-dashboard" style="font-size: 9px; margin-top: 4px;">
                    <?php if (isset($item->source) && $item->source == 'imported'): ?>
                    <span style="color: #fbbf24;">
                        <i class="fas fa-file-import"></i> Imported 
                        <?php if (!empty($item->created_at)): ?>
                        �� <?= date('d/m/Y', strtotime($item->created_at)) ?>
                        <?php endif; ?>
                    </span>
                    <?php else: ?>
                    <span style="color: #4ade80;">
                        <i class="fas fa-user-plus"></i> Manual input
                    </span>
                    <?php endif; ?>
                </div>
                
                <span class="badge-dashboard badge-pending" style="margin-top: 6px;">
                    <i class="fas fa-clock"></i> <?= $item->status ?>
                </span>
            </div>
            <?php endforeach; ?>
        <?php else: ?>
            <div class="stage-item-dashboard">
                <strong><i class="fas fa-info-circle"></i> Belum ada creator</strong>
                <div class="item-details-dashboard">Klik "Tambah Creator" atau "Import Excel" untuk mulai</div>
            </div>
        <?php endif; ?>
    </div>
    
    <!-- Button group -->
    <div style="flex-shrink: 0; display: flex; gap: 8px; margin-top: 8px;">
        <button class="task-btn-dashboard" id="addCreatorQuickBtnDashboard" style="flex: 1;">
            <i class="fas fa-plus-circle"></i> Tambah Creator
        </button>
        <button class="task-btn-dashboard" id="importCreatorBtnDashboard" style="flex: 1; background: linear-gradient(135deg, #8b5cf6, #3b82f6);">
            <i class="fas fa-file-upload"></i> Import Excel
        </button>
    </div>
</div>

            <!-- TASK 2: LINK SWAPPING - BIRU -->
            <div class="stage-card-dashboard" data-stage="2" style="display: flex; flex-direction: column; height: 500px;">
                <div class="stage-title-dashboard" style="flex-shrink: 0;">
                    <span><i class="fas fa-link"></i> 2. LINK SWAPPING</span>
                    <span class="stage-count-dashboard" id="linkCountDashboard">0</span>
                </div>
                
                <!-- Search input untuk Task 2 -->
                <div style="flex-shrink: 0; padding: 8px 12px;">
                    <input type="text" id="searchLinkSwappingDashboard" placeholder=" Cari creator..." style="width: 100%; padding: 6px 10px; border: 1px solid #ddd; border-radius: 6px; font-size: 12px; background: #1a1f2e; color: white;">
                </div>
                
                <!-- Scrollable container -->
                <div id="linkSwappingContainerDashboard" style="flex: 1; overflow-y: auto; padding: 0 8px;">
                    <div class="stage-item-dashboard"><strong>Loading...</strong><div class="item-details-dashboard">Memuat data creator</div></div>
                </div>
                
                <button class="task-btn-dashboard" id="refreshTask2BtnDashboard" style="flex-shrink: 0; margin-top: 8px;"><i class="fas fa-sync-alt"></i> Refresh</button>
            </div>

            <!-- TASK 3: SENDING SAMPLE - CYAN -->
            <div class="stage-card-dashboard" data-stage="3" style="display: flex; flex-direction: column; height: 500px;">
                <div class="stage-title-dashboard" style="flex-shrink: 0;">
                    <span><i class="fas fa-box"></i> 3. KIRIM SAMPLE</span>
                    <span class="stage-count-dashboard" id="sampleCountDashboard"><?= count($sending_sample_items) ?></span>
                </div>
                
                <!-- Search input untuk Task 3 -->
                <div style="flex-shrink: 0; padding: 8px 12px;">
                    <input type="text" id="searchSampleDashboard" placeholder=" Cari creator..." style="width: 100%; padding: 6px 10px; border: 1px solid #ddd; border-radius: 6px; font-size: 12px; background: #1a1f2e; color: white;">
                </div>
                
                <!-- Scrollable container -->
               <div id="sendingSampleContainerDashboard" style="flex: 1; overflow-y: auto; padding: 0 8px;">
    <?php if (!empty($sending_sample_items)): ?>
        <?php foreach ($sending_sample_items as $item): ?>
        <div class="stage-item-dashboard sample-item-dashboard" data-creator-id="<?= $item->id ?>" data-creator-name="<?= htmlspecialchars($item->username) ?>" data-creator-phone="<?= htmlspecialchars($item->phone ?? '') ?>" data-creator-category="<?= htmlspecialchars($item->category ?? '') ?>" data-searchable="<?= strtolower(htmlspecialchars($item->username)) ?>">
            <strong><i class="fab fa-tiktok"></i> <?= htmlspecialchars($item->username) ?></strong>
            <div class="item-details-dashboard">
                <?php if ($is_supervisor && isset($item->is_username)): ?>
                <span><i class="fas fa-user-tie"></i> IS: <?= htmlspecialchars($item->is_username) ?></span>
                <?php endif; ?>
                <span><i class="fab fa-whatsapp"></i> <?= $item->phone ?? '-' ?></span>
                <span><i class="fas fa-tag"></i> <?= $item->category ?? '-' ?></span>
            </div>
            <div class="item-details-dashboard"><i class="fas fa-box"></i> 
                <?php if ($item->status == 'LINK_SENT'): ?>
                Menunggu konfirmasi sample
                <?php else: ?>
                Sample sudah dikirim
                <?php endif; ?>
            </div>
            <span class="badge-dashboard badge-pending">
                <i class="fas fa-clock"></i> <?= $item->status ?>
            </span>
        </div>
        <?php endforeach; ?>
    <?php else: ?>
        <div class="stage-item-dashboard">
            <strong><i class="fas fa-info-circle"></i> Belum ada creator di tahap pengiriman sample</strong>
            <div class="item-details-dashboard">Creator akan auto-pindah ke monitoring jika ada order</div>
        </div>
    <?php endif; ?>
</div>
                
                <button class="task-btn-dashboard" data-action="sample" style="flex-shrink: 0; margin-top: 8px;"><i class="fas fa-truck"></i> Request & Lacak Sample</button>
            </div>

            <!-- TASK 4: MONITORING - Hijau -->
            <div class="stage-card-dashboard" data-stage="4" style="display: flex; flex-direction: column; height: 500px;">
                <div class="stage-title-dashboard" style="flex-shrink: 0;">
                    <span><i class="fas fa-chart-line"></i> 4. MONITORING</span>
                    <span class="stage-count-dashboard" id="monitoringCountDashboard"><?= count($monitoring_items) ?></span>
                </div>
                
                <!-- Search input untuk Task 4 -->
                <div style="flex-shrink: 0; padding: 8px 12px;">
                    <input type="text" id="searchMonitoringDashboard" placeholder=" Cari creator..." style="width: 100%; padding: 6px 10px; border: 1px solid #ddd; border-radius: 6px; font-size: 12px; background: #1a1f2e; color: white;">
                </div>
                
                <!-- Scrollable container -->
                <div id="monitoringContainerDashboard" style="flex: 1; overflow-y: auto; padding: 0 8px;">
    <?php if (!empty($monitoring_items)): ?>
        <?php foreach ($monitoring_items as $item): ?>
        <div class="stage-item-dashboard monitor-item-dashboard" data-creator-id="<?= $item->id ?>" data-creator-name="<?= htmlspecialchars($item->username) ?>" data-searchable="<?= strtolower(htmlspecialchars($item->username)) ?>">
            <strong><i class="fab fa-tiktok"></i> <?= htmlspecialchars($item->username) ?></strong>
            <div class="item-details-dashboard">
                <?php if ($is_supervisor && isset($item->is_username)): ?>
                <span><i class="fas fa-user-tie"></i> IS: <?= htmlspecialchars($item->is_username) ?></span>
                <?php endif; ?>
                <span><i class="fas fa-money-bill-wave"></i> GMV: Rp <?= number_format($item->total_gmv ?? 0, 0, ',', '.') ?></span>
                <span><i class="fas fa-chart-line"></i> ROAS: <?= $item->roas ?? 0 ?>x</span>
            </div>
            <div class="item-details-dashboard">
                <span><i class="fas fa-shopping-cart"></i> Orders: <?= number_format($item->total_orders ?? 0) ?></span>
                <span><i class="fas fa-tag"></i> <?= $item->category ?? '-' ?></span>
            </div>
            <span class="badge-dashboard badge-active">
                <i class="fas fa-check-circle"></i> ACTIVE
                <?php if ($item->auto_activated_at): ?>
                <span class="auto-badge" style="background: #4ade80; color: #0a0e17; font-size: 8px; padding: 2px 6px; border-radius: 10px; margin-left: 6px;">
                    <i class="fas fa-robot"></i> Auto
                </span>
                <?php endif; ?>
            </span>
        </div>
        <?php endforeach; ?>
        <!-- Summary card untuk monitoring -->
        <div style="margin-top: 12px; padding: 12px; background: #0f1420; border-radius: 14px;">
            <div style="display: flex; justify-content: space-between;">
                <span style="color: var(--text-muted); font-size:11px;">Total GMV (All Time):</span>
                <span style="color: #4ade80; font-size:12px;">Rp <?= number_format($monitoring_stats['total_gmv'] ?? 0, 0, ',', '.') ?></span>
            </div>
            <div style="display: flex; justify-content: space-between; margin-top: 6px;">
                <span style="color: var(--text-muted); font-size:11px;">Total Estimated Commission:</span>
                <span style="color: #fbbf24; font-size:12px;">Rp <?= number_format($monitoring_stats['total_estimated_commission'] ?? 0, 0, ',', '.') ?></span>
            </div>
        </div>
    <?php else: ?>
        <div class="stage-item-dashboard">
            <strong><i class="fas fa-info-circle"></i> Belum ada creator aktif</strong>
            <div class="item-details-dashboard">Creator akan muncul setelah sample dikirim atau auto-move karena order</div>
        </div>
    <?php endif; ?>
</div>
                <button class="task-btn-dashboard" data-action="monitor" style="flex-shrink: 0; margin-top: 8px;"><i class="fas fa-chart-simple"></i> Lihat Laporan</button>
            </div>
        </div>
    </div>
</div>
    <!-- TAB CREATOR STATUS -->
<div id="tabCreatorsDashboard" class="tab-content-dashboard">
    <!-- Summary Cards -->
    <div style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 16px; margin-bottom: 24px;">
        <div style="background: linear-gradient(135deg, #1a1030, #13111f); border-radius: 16px; padding: 16px; border: 1px solid var(--border);">
            <div style="display: flex; align-items: center; gap: 12px;">
                <div style="background: rgba(74,222,128,0.15); width: 48px; height: 48px; border-radius: 50%; display: flex; align-items: center; justify-content: center;">
                    <i class="fas fa-users" style="color: #4ade80; font-size: 24px;"></i>
                </div>
                <div>
                    <div style="color: #9aaebe; font-size: 11px;">TOTAL CREATOR</div>
                    <div style="color: #e2f0e8; font-size: 24px; font-weight: 700;"><?= $total_creators ?? 0 ?></div>
                </div>
            </div>
        </div>
        
        <div style="background: linear-gradient(135deg, #0f1a2e, #13111f); border-radius: 16px; padding: 16px; border: 1px solid var(--border);">
            <div style="display: flex; align-items: center; gap: 12px;">
                <div style="background: rgba(16,185,129,0.15); width: 48px; height: 48px; border-radius: 50%; display: flex; align-items: center; justify-content: center;">
                    <i class="fas fa-check-circle" style="color: #10b981; font-size: 24px;"></i>
                </div>
                <div>
                    <div style="color: #9aaebe; font-size: 11px;">CREATOR AKTIF</div>
                    <div style="color: #e2f0e8; font-size: 24px; font-weight: 700;"><?= count($active_creators ?? []) ?></div>
                </div>
            </div>
        </div>
        
        <div style="background: linear-gradient(135deg, #0a1a1f, #13111f); border-radius: 16px; padding: 16px; border: 1px solid var(--border);">
            <div style="display: flex; align-items: center; gap: 12px;">
                <div style="background: rgba(139,92,246,0.15); width: 48px; height: 48px; border-radius: 50%; display: flex; align-items: center; justify-content: center;">
                    <i class="fas fa-clock" style="color: #8b5cf6; font-size: 24px;"></i>
                </div>
                <div>
                    <div style="color: #9aaebe; font-size: 11px;">TOTAL GMV (HARI INI)</div>
                    <div style="color: #e2f0e8; font-size: 24px; font-weight: 700;">Rp <?= number_format($total_gmv ?? 0, 0, ',', '.') ?></div>
                </div>
            </div>
        </div>
        
        <div style="background: linear-gradient(135deg, #0a1f15, #13111f); border-radius: 16px; padding: 16px; border: 1px solid var(--border);">
            <div style="display: flex; align-items: center; gap: 12px;">
                <div style="background: rgba(245,158,11,0.15); width: 48px; height: 48px; border-radius: 50%; display: flex; align-items: center; justify-content: center;">
                    <i class="fas fa-chart-line" style="color: #f59e0b; font-size: 24px;"></i>
                </div>
                <!--<div>-->
                <!--    <div style="color: #9aaebe; font-size: 11px;">EST. COMMISSION</div>-->
                <!--    <div style="color: #e2f0e8; font-size: 24px; font-weight: 700;">Rp <?= number_format($total_estimated_commission ?? 0, 0, ',', '.') ?></div>-->
                <!--</div>-->
            </div>
        </div>
    </div>
    
    <!-- Tabs for Creator Categories -->
    <div style="display: flex; gap: 8px; margin-bottom: 20px; border-bottom: 1px solid var(--border); padding-bottom: 12px;">
        <button class="creator-tab-btn active" data-creator-tab="active" style="background: transparent; border: none; padding: 8px 20px; font-size: 13px; font-weight: 600; color: var(--text-muted); cursor: pointer; border-radius: 40px; transition: all 0.2s;">
            <i class="fas fa-check-circle"></i> Aktif
            <span style="background: rgba(16,185,129,0.2); padding: 2px 8px; border-radius: 20px; margin-left: 6px;"><?= count($active_creators ?? []) ?></span>
        </button>
        <button class="creator-tab-btn" data-creator-tab="pending" style="background: transparent; border: none; padding: 8px 20px; font-size: 13px; font-weight: 600; color: var(--text-muted); cursor: pointer; border-radius: 40px; transition: all 0.2s;">
            <i class="fas fa-clock"></i> Pending
            <span style="background: rgba(245,158,11,0.2); padding: 2px 8px; border-radius: 20px; margin-left: 6px;"><?= count($inactive_creators ?? []) ?></span>
        </button>
    </div>
    
    <!-- Active Creators List -->
    <div id="activeCreatorsList" class="creator-list-container" style="display: block;">
        <div style="background: var(--bg-card); border-radius: 20px; border: 1px solid var(--border); overflow: hidden;">
            <div style="background: linear-gradient(135deg, #1a1030, #13111f); padding: 12px 16px; border-bottom: 1px solid var(--border);">
                <h4 style="margin: 0; color: #4ade80; font-size: 14px;"><i class="fas fa-check-circle"></i> Daftar Creator Aktif</h4>
            </div>
            <?php if (!empty($active_creators)): ?>
                <div style="overflow-x: auto;">
                    <table style="width: 100%; border-collapse: collapse; font-size: 12px;">
                        <thead>
                            <tr style="background: #0f1420; border-bottom: 1px solid var(--border);">
                                <th style="padding: 12px 16px; text-align: left; color: #9aaebe;">Username</th>
                                <th style="padding: 12px 16px; text-align: left; color: #9aaebe;">Kategori</th>
                                <th style="padding: 12px 16px; text-align: right; color: #9aaebe;">GMV Today</th>
                                <th style="padding: 12px 16px; text-align: right; color: #9aaebe;">Status</th>
                                <th style="padding: 12px 16px; text-align: center; color: #9aaebe;">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($active_creators as $c): ?>
                            <tr style="border-bottom: 1px solid var(--border); transition: background 0.2s;" onmouseover="this.style.background='rgba(139,92,246,0.1)'" onmouseout="this.style.background='transparent'">
                                <td style="padding: 12px 16px;">
                                    <div style="display: flex; align-items: center; gap: 10px;">
                                        <i class="fab fa-tiktok" style="color: #4ade80; font-size: 16px;"></i>
                                        <strong style="color: var(--text-primary);">@<?= htmlspecialchars($c->username) ?></strong>
                                    </div>
                                </td>
                                <td style="padding: 12px 16px;">
                                    <span style="background: rgba(139,92,246,0.15); padding: 4px 12px; border-radius: 20px; font-size: 11px; color: #8b5cf6;">
                                        <?= htmlspecialchars($c->category ?? '-') ?>
                                    </span>
                                </td>
                                <td style="padding: 12px 16px; text-align: right;">
                                    <span style="color: #4ade80; font-weight: 600;">
                                        Rp <?= number_format($c->today_gmv ?? 0, 0, ',', '.') ?>
                                    </span>
                                </td>
                                <td style="padding: 12px 16px; text-align: right;">
                                    <span class="badge-dashboard badge-active">
                                        <i class="fas fa-check-circle"></i> AKTIF
                                    </span>
                                </td>
                                <td style="padding: 12px 16px; text-align: center;">
                                    <button class="view-creator-detail" data-creator-id="<?= $c->id ?>" style="background: #1e293b; border: none; padding: 4px 12px; border-radius: 20px; color: #9aaebe; cursor: pointer; font-size: 11px;">
                                        <i class="fas fa-eye"></i> Detail
                                    </button>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <div style="text-align: center; padding: 40px; color: #9aaebe;">
                    <i class="fas fa-users" style="font-size: 48px; margin-bottom: 16px; display: block; opacity: 0.5;"></i>
                    <p>Belum ada creator aktif</p>
                </div>
            <?php endif; ?>
        </div>
    </div>
    
    <!-- Pending Creators List -->
    <div id="pendingCreatorsList" class="creator-list-container" style="display: none;">
        <div style="background: var(--bg-card); border-radius: 20px; border: 1px solid var(--border); overflow: hidden;">
            <div style="background: linear-gradient(135deg, #0a1a1f, #13111f); padding: 12px 16px; border-bottom: 1px solid var(--border);">
                <h4 style="margin: 0; color: #f59e0b; font-size: 14px;"><i class="fas fa-clock"></i> Daftar Creator Pending</h4>
            </div>
            <?php if (!empty($inactive_creators)): ?>
                <div style="overflow-x: auto;">
                    <table style="width: 100%; border-collapse: collapse; font-size: 12px;">
                        <thead>
                            <tr style="background: #0f1420; border-bottom: 1px solid var(--border);">
                                <th style="padding: 12px 16px; text-align: left; color: #9aaebe;">Username</th>
                                <th style="padding: 12px 16px; text-align: left; color: #9aaebe;">Kategori</th>
                                <th style="padding: 12px 16px; text-align: left; color: #9aaebe;">WhatsApp</th>
                                <th style="padding: 12px 16px; text-align: left; color: #9aaebe;">Status</th>
                                <th style="padding: 12px 16px; text-align: center; color: #9aaebe;">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($inactive_creators as $c): ?>
                            <tr style="border-bottom: 1px solid var(--border); transition: background 0.2s;" onmouseover="this.style.background='rgba(139,92,246,0.1)'" onmouseout="this.style.background='transparent'">
                                <td style="padding: 12px 16px;">
                                    <div style="display: flex; align-items: center; gap: 10px;">
                                        <i class="fab fa-tiktok" style="color: #f59e0b; font-size: 16px;"></i>
                                        <strong style="color: var(--text-primary);">@<?= htmlspecialchars($c->username) ?></strong>
                                    </div>
                                </td>
                                <td style="padding: 12px 16px;">
                                    <span style="background: rgba(139,92,246,0.15); padding: 4px 12px; border-radius: 20px; font-size: 11px; color: #8b5cf6;">
                                        <?= htmlspecialchars($c->category ?? '-') ?>
                                    </span>
                                </td>
                                <td style="padding: 12px 16px;">
                                    <?php if (!empty($c->phone)): ?>
                                        <span style="color: #4ade80; font-size: 11px;">
                                            <i class="fab fa-whatsapp"></i> <?= htmlspecialchars($c->phone) ?>
                                        </span>
                                    <?php else: ?>
                                        <span style="color: #ef4444; font-size: 11px;">
                                            <i class="fas fa-times-circle"></i> Belum ada WA
                                        </span>
                                    <?php endif; ?>
                                </td>
                                <td style="padding: 12px 16px;">
                                    <span class="badge-dashboard badge-pending">
                                        <i class="fas fa-clock"></i> <?= $c->status ?? 'PENDING' ?>
                                    </span>
                                </td>
                                <td style="padding: 12px 16px; text-align: center;">
                                    <button class="view-creator-detail" data-creator-id="<?= $c->id ?>" style="background: #1e293b; border: none; padding: 4px 12px; border-radius: 20px; color: #9aaebe; cursor: pointer; font-size: 11px;">
                                        <i class="fas fa-eye"></i> Detail
                                    </button>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <div style="text-align: center; padding: 40px; color: #9aaebe;">
                    <i class="fas fa-check-circle" style="font-size: 48px; margin-bottom: 16px; display: block; opacity: 0.5; color: #4ade80;"></i>
                    <p>Semua creator sudah diapprove! �9�5</p>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>
    <!-- TAB TOP CREATOR LEADERBOARD -->
    <!-- TAB TOP CREATOR LEADERBOARD -->
<div id="tabLeaderboardDashboard" class="tab-content-dashboard">
    <!-- Filter Periode -->
    <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 16px; margin-bottom: 24px;">
        <h3 style="color: var(--text-primary); font-size: 16px; margin: 0;">
            <i class="fas fa-trophy" style="color: var(--purple);"></i> Top Performing Creators
        </h3>
        <div style="display: flex; gap: 8px;">
            <button class="period-btn active" data-period="today" style="background: transparent; border: 1px solid var(--border); padding: 6px 16px; border-radius: 40px; font-size: 12px; color: var(--text-muted); cursor: pointer; transition: all 0.2s;">
                <i class="fas fa-calendar-day"></i> Hari Ini
            </button>
            <button class="period-btn" data-period="week" style="background: transparent; border: 1px solid var(--border); padding: 6px 16px; border-radius: 40px; font-size: 12px; color: var(--text-muted); cursor: pointer; transition: all 0.2s;">
                <i class="fas fa-calendar-week"></i> 7 Hari
            </button>
            <button class="period-btn" data-period="month" style="background: transparent; border: 1px solid var(--border); padding: 6px 16px; border-radius: 40px; font-size: 12px; color: var(--text-muted); cursor: pointer; transition: all 0.2s;">
                <i class="fas fa-calendar-alt"></i> 30 Hari
            </button>
        </div>
    </div>
    
    <!-- Leaderboard Grid -->
    <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 20px;">
        <!-- Top Creator berdasarkan GMV -->
        <div class="leaderboard-card-dashboard" style="background: linear-gradient(135deg, #1a1030, #13111f); border-radius: 20px; padding: 20px; border: 1px solid var(--border);">
            <div style="display: flex; align-items: center; gap: 12px; margin-bottom: 20px; padding-bottom: 12px; border-bottom: 1px solid var(--border);">
                <div style="background: rgba(74,222,128,0.15); width: 40px; height: 40px; border-radius: 50%; display: flex; align-items: center; justify-content: center;">
                    <i class="fas fa-chart-line" style="color: #4ade80; font-size: 20px;"></i>
                </div>
                <div>
                    <h4 style="margin: 0; color: var(--text-primary); font-size: 14px;">Top GMV Creator</h4>
                    <p style="margin: 0; color: var(--text-muted); font-size: 10px;">Berdasarkan total GMV</p>
                </div>
            </div>
            
            <div id="topGmvCreatorsList">
                <?php if (!empty($top_creators)): ?>
                    <?php $rank = 1; foreach ($top_creators as $c): ?>
                    <div class="leaderboard-item-dashboard" style="display: flex; align-items: center; gap: 12px; padding: 12px; border-bottom: 1px solid var(--border); transition: background 0.2s; border-radius: 12px;" onmouseover="this.style.background='rgba(139,92,246,0.1)'" onmouseout="this.style.background='transparent'">
                        <div style="width: 36px; text-align: center;">
                            <?php if ($rank == 1): ?>
                                <span style="background: linear-gradient(135deg, #fbbf24, #f59e0b); color: #0a0e17; width: 28px; height: 28px; display: flex; align-items: center; justify-content: center; border-radius: 50%; font-weight: 700; font-size: 12px;">1</span>
                            <?php elseif ($rank == 2): ?>
                                <span style="background: linear-gradient(135deg, #94a3b8, #64748b); color: white; width: 28px; height: 28px; display: flex; align-items: center; justify-content: center; border-radius: 50%; font-weight: 700; font-size: 12px;">2</span>
                            <?php elseif ($rank == 3): ?>
                                <span style="background: linear-gradient(135deg, #cd7e56, #b45309); color: white; width: 28px; height: 28px; display: flex; align-items: center; justify-content: center; border-radius: 50%; font-weight: 700; font-size: 12px;">3</span>
                            <?php else: ?>
                                <span style="color: var(--text-muted); font-size: 12px; font-weight: 600;"><?= $rank ?></span>
                            <?php endif; ?>
                        </div>
                        <div style="flex: 1;">
                            <div style="display: flex; align-items: center; gap: 8px; flex-wrap: wrap;">
                                <strong style="color: var(--text-primary); font-size: 13px;">@<?= htmlspecialchars($c->creator_username ?? $c->username ?? '-') ?></strong>
                                <?php if ($is_supervisor && isset($c->is_username)): ?>
                                <span style="background: rgba(139,92,246,0.15); padding: 2px 8px; border-radius: 20px; font-size: 9px; color: #8b5cf6;">
                                    <i class="fas fa-user-tie"></i> <?= htmlspecialchars($c->is_username) ?>
                                </span>
                                <?php endif; ?>
                            </div>
                            <div style="display: flex; gap: 16px; margin-top: 4px; flex-wrap: wrap;">
                                <span style="font-size: 10px; color: var(--text-muted);">
                                    <i class="fas fa-tag"></i> <?= htmlspecialchars($c->category ?? '-') ?>
                                </span>
                                <span style="font-size: 10px; color: var(--text-muted);">
                                    <i class="fas fa-box"></i> <?= number_format($c->total_orders ?? 0) ?> orders
                                </span>
                            </div>
                        </div>
                        <div style="text-align: right;">
                            <div style="color: #4ade80; font-weight: 700; font-size: 14px;">
                                Rp <?= number_format($c->total_gmv ?? 0, 0, ',', '.') ?>
                            </div>
                            <div style="font-size: 9px; color: var(--text-muted);">
                                <?= $c->engagement_rate ?? 0 ?>% ER
                            </div>
                        </div>
                    </div>
                    <?php $rank++; endforeach; ?>
                <?php else: ?>
                    <div style="text-align: center; padding: 40px; color: var(--text-muted);">
                        <i class="fas fa-chart-line" style="font-size: 48px; margin-bottom: 16px; display: block; opacity: 0.5;"></i>
                        <p>Belum ada data creator</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
        
        <!-- Top Creator berdasarkan Engagement -->
        <div class="leaderboard-card-dashboard" style="background: linear-gradient(135deg, #0f1a2e, #13111f); border-radius: 20px; padding: 20px; border: 1px solid var(--border);">
            <div style="display: flex; align-items: center; gap: 12px; margin-bottom: 20px; padding-bottom: 12px; border-bottom: 1px solid var(--border);">
                <div style="background: rgba(139,92,246,0.15); width: 40px; height: 40px; border-radius: 50%; display: flex; align-items: center; justify-content: center;">
                    <i class="fas fa-heart" style="color: #8b5cf6; font-size: 20px;"></i>
                </div>
                <div>
                    <h4 style="margin: 0; color: var(--text-primary); font-size: 14px;">Top Engagement Creator</h4>
                    <p style="margin: 0; color: var(--text-muted); font-size: 10px;">Berdasarkan engagement rate</p>
                </div>
            </div>
            
            <div id="topEngagementCreatorsList">
                <?php 
                // Sort by engagement rate
                $sorted_by_engagement = $top_creators ?? [];
                usort($sorted_by_engagement, function($a, $b) {
                    return ($b->engagement_rate ?? 0) <=> ($a->engagement_rate ?? 0);
                });
                ?>
                <?php if (!empty($sorted_by_engagement)): ?>
                    <?php $rank = 1; foreach (array_slice($sorted_by_engagement, 0, 5) as $c): ?>
                    <div class="leaderboard-item-dashboard" style="display: flex; align-items: center; gap: 12px; padding: 12px; border-bottom: 1px solid var(--border); transition: background 0.2s; border-radius: 12px;" onmouseover="this.style.background='rgba(139,92,246,0.1)'" onmouseout="this.style.background='transparent'">
                        <div style="width: 36px; text-align: center;">
                            <?php if ($rank == 1): ?>
                                <span style="background: linear-gradient(135deg, #fbbf24, #f59e0b); color: #0a0e17; width: 28px; height: 28px; display: flex; align-items: center; justify-content: center; border-radius: 50%; font-weight: 700; font-size: 12px;">1</span>
                            <?php elseif ($rank == 2): ?>
                                <span style="background: linear-gradient(135deg, #94a3b8, #64748b); color: white; width: 28px; height: 28px; display: flex; align-items: center; justify-content: center; border-radius: 50%; font-weight: 700; font-size: 12px;">2</span>
                            <?php elseif ($rank == 3): ?>
                                <span style="background: linear-gradient(135deg, #cd7e56, #b45309); color: white; width: 28px; height: 28px; display: flex; align-items: center; justify-content: center; border-radius: 50%; font-weight: 700; font-size: 12px;">3</span>
                            <?php else: ?>
                                <span style="color: var(--text-muted); font-size: 12px; font-weight: 600;"><?= $rank ?></span>
                            <?php endif; ?>
                        </div>
                        <div style="flex: 1;">
                            <strong style="color: var(--text-primary); font-size: 13px;">@<?= htmlspecialchars($c->creator_username ?? $c->username ?? '-') ?></strong>
                            <div style="display: flex; gap: 16px; margin-top: 4px;">
                                <span style="font-size: 10px; color: var(--text-muted);">
                                    <i class="fas fa-tag"></i> <?= htmlspecialchars($c->category ?? '-') ?>
                                </span>
                            </div>
                        </div>
                        <div style="text-align: right;">
                            <div style="color: #8b5cf6; font-weight: 700; font-size: 14px;">
                                <?= number_format($c->engagement_rate ?? 0, 1) ?>%
                            </div>
                            <div style="font-size: 9px; color: var(--text-muted);">
                                GMV: Rp <?= number_format($c->total_gmv ?? 0, 0, ',', '.') ?>
                            </div>
                        </div>
                    </div>
                    <?php $rank++; endforeach; ?>
                <?php else: ?>
                    <div style="text-align: center; padding: 40px; color: var(--text-muted);">
                        <i class="fas fa-heart" style="font-size: 48px; margin-bottom: 16px; display: block; opacity: 0.5;"></i>
                        <p>Belum ada data engagement</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <!-- Recent Activity -->
    <div style="margin-top: 20px; background: var(--bg-card); border-radius: 20px; padding: 20px; border: 1px solid var(--border);">
        <div style="display: flex; align-items: center; gap: 12px; margin-bottom: 20px; padding-bottom: 12px; border-bottom: 1px solid var(--border);">
            <div style="background: rgba(245,158,11,0.15); width: 40px; height: 40px; border-radius: 50%; display: flex; align-items: center; justify-content: center;">
                <i class="fas fa-clock" style="color: #f59e0b; font-size: 20px;"></i>
            </div>
            <div>
                <h4 style="margin: 0; color: var(--text-primary); font-size: 14px;">Recent Activity</h4>
                <p style="margin: 0; color: var(--text-muted); font-size: 10px;">Top creator terbaru minggu ini</p>
            </div>
        </div>
        
        <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap: 12px;">
            <?php if (!empty($top_creators)): ?>
                <?php foreach (array_slice($top_creators, 0, 4) as $c): ?>
                <div style="display: flex; align-items: center; gap: 12px; padding: 10px; background: #0f1420; border-radius: 12px;">
                                    <div style="width: 40px; height: 40px; background: linear-gradient(135deg, var(--purple), var(--blue)); border-radius: 50%; display: flex; align-items: center; justify-content: center;">
                        <i class="fab fa-tiktok" style="color: white; font-size: 18px;"></i>
                    </div>
                    <div style="flex: 1;">
                        <div style="color: var(--text-primary); font-size: 13px; font-weight: 500;">@<?= htmlspecialchars($c->creator_username ?? $c->username ?? '-') ?></div>
                        <div style="font-size: 10px; color: var(--text-muted);"><?= htmlspecialchars($c->category ?? '-') ?></div>
                    </div>
                    <div style="text-align: right;">
                        <div style="color: #4ade80; font-size: 12px; font-weight: 600;">
                            Rp <?= number_format($c->total_gmv ?? 0, 0, ',', '.') ?>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            <?php else: ?>
                <div style="text-align: center; padding: 30px; color: var(--text-muted); grid-column: 1 / -1;">
                    <p>Belum ada aktivitas</p>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>



</div>

<!-- Modal -->
<div id="taskModalDashboard" class="modal-overlay-dashboard">
    <div class="modal-glass-dashboard">
        <div class="modal-header-dashboard">
            <h3 id="modalTitleDashboard"><i class="fas fa-tasks"></i> Task</h3>
            <span class="modal-close-dashboard" id="closeTaskModalDashboard">&times;</span>
        </div>
        <div class="modal-body" id="modalBodyDashboard"></div>
    </div>
</div>


<!-- Modal Import Creator -->
<div id="importModalDashboard" class="modal-overlay-dashboard">
    <div class="modal-glass-dashboard" style="max-width: 900px;">
        <div class="modal-header-dashboard">
            <h3 id="importModalTitle"><i class="fas fa-file-upload"></i> Import Creator dari Excel</h3>
            <span class="modal-close-dashboard" id="closeImportModal">&times;</span>
        </div>
        <div class="modal-body" id="importModalBody">
            <!-- Step 1: Pilih Brand & Upload File -->
            <div id="importStep1">
                <div style="background: rgba(74,222,128,0.1); border-radius: 14px; padding: 12px; margin-bottom: 16px;">
                    <p style="color: #4ade80; font-size: 12px;"><i class="fas fa-info-circle"></i> Support file: Excel (.xlsx, .xls) atau CSV</p>
                    <p style="color: #9aaebe; font-size: 11px;">Format yang didukung: FastMoss atau Kalodata export</p>
                </div>
                
                <!-- �9�7 Pilihan Brand -->
                <label><i class="fas fa-store"></i> Pilih Brand <span style="color:#ef4444;">*</span></label>
                <select id="importBrandSelect" style="width: 100%; padding: 10px; background: #0f1420; border: 1px solid #2a3346; border-radius: 12px; color: #e2f0e8; margin-bottom: 16px;">
                    <option value="">-- Pilih Brand --</option>
                    <?php 
                    // Ambil brand dari database
                    $brands = $this->db->select('id, name, shop_name')->where('status', 'ACTIVE')->order_by('name', 'ASC')->get('brands')->result();
                    foreach ($brands as $brand): 
                    ?>
                    <option value="<?= $brand->id ?>" data-shop-name="<?= htmlspecialchars($brand->shop_name ?: $brand->name) ?>">
                        <?= htmlspecialchars($brand->name) ?> <?= $brand->shop_name ? '(Shop: ' . htmlspecialchars($brand->shop_name) . ')' : '' ?>
                    </option>
                    <?php endforeach; ?>
                </select>
                
                <label><i class="fas fa-file-excel"></i> Pilih File</label>
                <input type="file" id="importFileInput" accept=".xlsx,.xls,.csv" style="width: 100%; padding: 10px; background: #0f1420; border: 1px solid #2a3346; border-radius: 12px; color: #e2f0e8;">
                
                <!-- �9�7 Mapping Kolom (Opsional) -->
                <div style="margin-top: 16px;">
                    <label><i class="fas fa-columns"></i> Mapping Kolom (Opsional)</label>
                    <div style="background: #0f1420; border-radius: 12px; padding: 12px; margin-top: 8px;">
                        <p style="color: #9aaebe; font-size: 11px; margin-bottom: 8px;">Jika file memiliki struktur berbeda, sesuaikan mapping berikut:</p>
                     
<div style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px;">
    <div>
        <select id="colMappingUsername" style="width:100%; padding:6px; background:#1e293b; border-radius:8px; color:#e2f0e8;">
            <option value="1">Handle</option>
            <option value="0">Kolom 0</option>
            <option value="1">Kolom 1</option>
            <option value="2">Kolom 2</option>
            <option value="3">Kolom 3</option>
            <option value="4">Kolom 4</option>
            <option value="5">Kolom 5</option>
            <option value="6">Kolom 6</option>
            <option value="7">Kolom 7</option>
        </select>
        <span style="font-size:10px; color:#9aaebe;">Kolom Username</span>
    </div>
    <div>
        <select id="colMappingFullname" style="width:100%; padding:6px; background:#1e293b; border-radius:8px; color:#e2f0e8;">
            <option value="0">Nickname</option>
            <option value="0">Kolom 0</option>
            <option value="1">Kolom 1</option>
            <option value="2">Kolom 2</option>
        </select>
        <span style="font-size:10px; color:#9aaebe;">Kolom Nama</span>
    </div>
    <div>
        <select id="colMappingCategory" style="width:100%; padding:6px; background:#1e293b; border-radius:8px; color:#e2f0e8;">
            <option value="3">Kategori (FastMoss kolom3)</option>
            <option value="-1">Tidak Ada</option>
            <option value="0">Kolom 0</option>
            <option value="1">Kolom 1</option>
            <option value="2">Kolom 2</option>
            <option value="3">Kolom 3</option>
        </select>
        <span style="font-size:10px; color:#9aaebe;">Kolom Kategori</span>
    </div>
    <div>
        <select id="colMappingGmv" style="width:100%; padding:6px; background:#1e293b; border-radius:8px; color:#e2f0e8;">
            <option value="8">Revenue(Rp)</option>
            <option value="-1">Tidak Ada</option>
            <option value="4">Kolom 4</option>
            <option value="5">Kolom 5</option>
            <option value="8">Kolom 8</option>
        </select>
        <span style="font-size:10px; color:#9aaebe;">Kolom GMV</span>
    </div>
    <div>
        <select id="colMappingFollowers" style="width:100%; padding:6px; background:#1e293b; border-radius:8px; color:#e2f0e8;">
            <option value="6">Followers</option>
            <option value="-1">Tidak Ada</option>
            <option value="3">Kolom 3</option>
            <option value="6">Kolom 6</option>
        </select>
        <span style="font-size:10px; color:#9aaebe;">Kolom Followers</span>
    </div>
    <div>
        <select id="colMappingEmail" style="width:100%; padding:6px; background:#1e293b; border-radius:8px; color:#e2f0e8;">
            <option value="12">Email</option>
            <option value="-1">Tidak Ada</option>
            <option value="12">Kolom 12</option>
            <option value="18">Kolom 18</option>
        </select>
        <span style="font-size:10px; color:#9aaebe;">Kolom Email</span>
    </div>
    <div>
        <select id="colMappingPhone" style="width:100%; padding:6px; background:#1e293b; border-radius:8px; color:#e2f0e8;">
            <option value="13">whatsapp</option>
            <option value="-1">Tidak Ada</option>
            <option value="13">Kolom 13</option>
            <option value="23">Kolom 23</option>
        </select>
        <span style="font-size:10px; color:#9aaebe;">Kolom WhatsApp/Phone</span>
    </div>
</div>
                    </div>
                </div>
                
                <div style="margin-top: 16px;">
                    <label><i class="fas fa-check-circle"></i> Opsi Duplikat</label>
                    <div style="display: flex; gap: 16px; margin-top: 8px;">
                        <label style="display: flex; align-items: center; gap: 8px;">
                            <input type="radio" name="duplicate_action" value="skip" checked> Lewati creator yang sudah ada
                        </label>
                        <label style="display: flex; align-items: center; gap: 8px;">
                            <input type="radio" name="duplicate_action" value="update"> Update creator yang sudah ada
                        </label>
                    </div>
                </div>
                
                <div class="flex-buttons" style="margin-top: 20px;">
                    <button id="previewImportBtn" style="background: #4ade80; color: #0a0e17;"><i class="fas fa-eye"></i> Preview Data</button>
                    <button id="cancelImportBtn" style="background: #1e293b;">Batal</button>
                </div>
            </div>
            
            <!-- Step 2: Preview & Confirm -->
            <div id="importStep2" style="display: none;">
                <div id="previewBrandInfo" style="background: rgba(74,222,128,0.1); border-radius: 14px; padding: 12px; margin-bottom: 16px;"></div>
                <div id="previewStats" style="background: rgba(74,222,128,0.1); border-radius: 14px; padding: 12px; margin-bottom: 16px;"></div>
                <div id="previewErrors" style="background: rgba(239,68,68,0.1); border-radius: 14px; padding: 12px; margin-bottom: 16px; display: none; max-height: 150px; overflow-y: auto;"></div>
                <label><i class="fas fa-table"></i> Preview Data (10 baris pertama)</label>
                <div id="previewTable" style="max-height: 300px; overflow-y: auto; background: #0f1420; border-radius: 12px; padding: 8px; margin-bottom: 16px;"></div>
                <div class="flex-buttons">
                    <button id="confirmImportBtn" style="background: #4ade80; color: #0a0e17;"><i class="fas fa-save"></i> Konfirmasi Import</button>
                    <button id="backToUploadBtn" style="background: #1e293b;">Kembali</button>
                </div>
            </div>
            
            <!-- Step 3: Result -->
            <div id="importStep3" style="display: none;">
                <div id="importResult" style="text-align: center; padding: 20px;"></div>
                <div class="flex-buttons" style="margin-top: 20px;">
                    <button id="closeImportResultBtn" style="background: #4ade80; color: #0a0e17;">Tutup</button>
                </div>
            </div>
        </div>
    </div>
</div>


<!-- Mobile Bottom Navigation -->
<div class="mobile-bottom-nav-dashboard">
    <a href="#" class="mobile-nav-item-dashboard active" data-tab="tabTaskDashboard"><i class="fas fa-tasks"></i><span>Task</span></a>
    <a href="#" class="mobile-nav-item-dashboard" data-tab="tabCreatorsDashboard"><i class="fas fa-users"></i><span>Creators</span></a>
    <a href="#" class="mobile-nav-item-dashboard" data-tab="tabLeaderboardDashboard"><i class="fas fa-trophy"></i><span>Top</span></a>
</div>



<script>
// ========== DATA ==========
const baseUrlIS = '<?= base_url() ?>';

// ========== HELPER FUNCTIONS ==========
function escapeHtml(str) {
    if (!str) return '';
    return String(str).replace(/[&<>]/g, function(m) {
        if (m === '&') return '&amp;';
        if (m === '<') return '&lt;';
        if (m === '>') return '&gt;';
        return m;
    });
}

function formatNumber(num) {
    if (num === undefined || num === null) return '0';
    const n = parseFloat(num);
    return isNaN(n) ? '0' : n.toLocaleString('id-ID', { 
        minimumFractionDigits: 0,  // �9�7 TANPA DESIMAL
        maximumFractionDigits: 0   // �9�7 TANPA DESIMAL
    });
}

function formatNumberShort(num) {
    if (num === undefined || num === null) return '0';
    if (num >= 1000000) return (num / 1000000).toFixed(1) + 'M';
    if (num >= 1000) return (num / 1000).toFixed(1) + 'K';
    return num.toString();
}

function showToastGlobal(message, type = 'success') {
    let toast = document.getElementById('globalToast');
    if (!toast) {
        toast = document.createElement('div');
        toast.id = 'globalToast';
        toast.style.cssText = `
            position: fixed;
            bottom: 20px;
            right: 20px;
            background: ${type === 'success' ? '#10b981' : '#ef4444'};
            color: white;
            padding: 12px 20px;
            border-radius: 12px;
            font-size: 13px;
            z-index: 9999;
            animation: slideIn 0.3s ease;
            box-shadow: 0 4px 12px rgba(0,0,0,0.3);
        `;
        document.body.appendChild(toast);
        
        if (!document.querySelector('#toastStyle')) {
            const style = document.createElement('style');
            style.id = 'toastStyle';
            style.textContent = `
                @keyframes slideIn {
                    from { transform: translateX(100%); opacity: 0; }
                    to { transform: translateX(0); opacity: 1; }
                }
                @keyframes slideOut {
                    from { transform: translateX(0); opacity: 1; }
                    to { transform: translateX(100%); opacity: 0; }
                }
            `;
            document.head.appendChild(style);
        }
    }
    
    toast.textContent = message;
    toast.style.background = type === 'success' ? '#10b981' : (type === 'error' ? '#ef4444' : '#f59e0b');
    toast.style.display = 'block';
    
    setTimeout(() => {
        toast.style.animation = 'slideOut 0.3s ease';
        setTimeout(() => {
            toast.style.display = 'none';
            toast.style.animation = 'slideIn 0.3s ease';
        }, 300);
    }, 3000);
}

// ========== MODAL ==========
function closeModalIS() { 
    document.getElementById('taskModalDashboard')?.classList.remove('active'); 
}
function openModalIS() { 
    document.getElementById('taskModalDashboard')?.classList.add('active'); 
}

// ========== TAMBAH CREATOR (MANUAL - LAMA, TETAP DIKEEP) ==========
function showAddCreatorModalIS() {
    const modalTitle = document.getElementById('modalTitleDashboard');
    const modalBody = document.getElementById('modalBodyDashboard');
    modalTitle.innerHTML = '<i class="fas fa-user-plus"></i> Tambah Creator Baru';
    modalBody.innerHTML = `
        <div style="background:rgba(74,222,128,0.1); border-radius:14px; padding:12px; margin-bottom:16px;">
            <p style="color:#4ade80; font-size:12px;"><i class="fas fa-info-circle"></i> Masukkan data creator TikTok</p>
        </div>
        <label><i class="fab fa-tiktok"></i> Username TikTok *</label>
        <input type="text" id="creatorUsernameIS" placeholder="@username_tiktok">
        <label><i class="fas fa-user"></i> Nama Lengkap</label>
        <input type="text" id="creatorNameIS">
        <label><i class="fab fa-whatsapp"></i> WhatsApp</label>
        <input type="tel" id="creatorPhoneIS" placeholder="+62 812 3456 7890">
        <label><i class="fas fa-envelope"></i> Email</label>
        <input type="email" id="creatorEmailIS">
        <label><i class="fas fa-tag"></i> Kategori</label>
        <select id="creatorCategoryIS">
            <option value="Beauty">�9�6 Beauty</option>
            <option value="Fashion">�9�1 Fashion</option>
            <option value="Tech">�9�5 Tech</option>
            <option value="Lifestyle">�9�9 Lifestyle</option>
            <option value="Gaming">�9�2 Gaming</option>
            <option value="Food">�9�2 Food</option>
        </select>
        <button id="saveCreatorBtnIS" style="margin-top:16px; width:100%;"><i class="fas fa-save"></i> Simpan Creator</button>
    `;
    openModalIS();
    
    document.getElementById('saveCreatorBtnIS').addEventListener('click', async () => {
        const username = document.getElementById('creatorUsernameIS').value.trim();
        if (!username) { showToastGlobal('Username harus diisi', 'error'); return; }
        const btn = document.getElementById('saveCreatorBtnIS');
        btn.disabled = true; btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Menyimpan...';
        
        const response = await fetch(baseUrlIS + 'is/add_creator', { 
            method: 'POST', 
            body: new URLSearchParams({
                username: username.replace('@', ''),
                full_name: document.getElementById('creatorNameIS').value,
                phone: document.getElementById('creatorPhoneIS').value,
                email: document.getElementById('creatorEmailIS').value,
                category: document.getElementById('creatorCategoryIS').value
            })
        });
        const result = await response.json();
        if (result.success) {
            closeModalIS();
            showToastGlobal(`�7�3 Creator @${username} berhasil ditambahkan!`);
            setTimeout(() => location.reload(), 1500);
        } else {
            showToastGlobal(result.message || 'Gagal menambah creator', 'error');
            btn.disabled = false;
            btn.innerHTML = '<i class="fas fa-save"></i> Simpan Creator';
        }
    });
}

// ========== SEARCH CREATOR FROM API (FITUR BARU) ==========
let searchResults = [];
let searchPageToken = null;
let searchKeyword = '';
let isLoadingMore = false;

function showSearchCreatorModal() {
    const modalTitle = document.getElementById('modalTitleDashboard');
    const modalBody = document.getElementById('modalBodyDashboard');
    
    modalTitle.innerHTML = '<i class="fab fa-tiktok"></i> Cari Creator dari TikTok Shop';
    modalBody.innerHTML = `
        <div style="background:rgba(74,222,128,0.1); border-radius:14px; padding:12px; margin-bottom:16px;">
            <p style="color:#4ade80; font-size:12px;"><i class="fas fa-search"></i> Cari creator di TikTok Affiliate Marketplace</p>
            <p style="color:#9aaebe; font-size:10px;">Masukkan username TikTok untuk mencari data creator secara realtime</p>
        </div>
        
        <div style="display:flex; gap:10px; margin-bottom:16px;">
            <input type="text" id="searchCreatorKeyword" placeholder="Cari creator... (contoh: jefreestar, beautycreator)" 
                   style="flex:1; padding:12px; background:#0f1420; border:1px solid #2a3346; border-radius:12px; color:#e2f0e8;">
            <button id="searchCreatorBtn" style="background:#4ade80; color:#0a0e17; padding:0 20px; border-radius:12px;">
                <i class="fas fa-search"></i> Cari
            </button>
        </div>
        
        <div id="searchResultsContainer" style="max-height:400px; overflow-y:auto; background:#0f1420; border-radius:12px; padding:8px;">
            <div style="text-align:center; padding:40px; color:#9aaebe;">
                <i class="fas fa-search" style="font-size:32px; margin-bottom:12px; display:block;"></i>
                <p>Masukkan keyword dan klik Cari untuk mencari creator</p>
            </div>
        </div>
        
        <div id="searchPagination" style="display:none; margin-top:12px; text-align:center;">
            <button id="loadMoreResults" class="btn-secondary" style="background:#1e293b; color:#4ade80; border:1px solid #4ade80; padding:6px 16px; border-radius:20px; cursor:pointer;">
                <i class="fas fa-chevron-down"></i> Load More
            </button>
        </div>
        
        <div class="flex-buttons" style="margin-top:16px;">
            <button id="closeSearchModalBtn" style="background:#1e293b;">Tutup</button>
        </div>
    `;
    openModalIS();
    
    // Search button event
    const searchBtn = document.getElementById('searchCreatorBtn');
    if (searchBtn) {
        const newSearchBtn = searchBtn.cloneNode(true);
        searchBtn.parentNode.replaceChild(newSearchBtn, searchBtn);
        
        newSearchBtn.addEventListener('click', async () => {
            const keyword = document.getElementById('searchCreatorKeyword').value.trim();
            if (!keyword) {
                showToastGlobal('Masukkan keyword pencarian', 'error');
                return;
            }
            
            searchKeyword = keyword;
            searchPageToken = null;
            await performSearch();
        });
    }
    
    // Enter key event
    const searchInput = document.getElementById('searchCreatorKeyword');
    if (searchInput) {
        searchInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                document.getElementById('searchCreatorBtn')?.click();
            }
        });
    }
    
    // Close button
    const closeBtn = document.getElementById('closeSearchModalBtn');
    if (closeBtn) {
        const newCloseBtn = closeBtn.cloneNode(true);
        closeBtn.parentNode.replaceChild(newCloseBtn, closeBtn);
        newCloseBtn.addEventListener('click', closeModalIS);
    }
}

async function performSearch(append = false) {
    const keyword = searchKeyword;
    const container = document.getElementById('searchResultsContainer');
    const loadMoreContainer = document.getElementById('searchPagination');
    
    if (!append) {
        container.innerHTML = '<div style="text-align:center; padding:40px;"><i class="fas fa-spinner fa-pulse"></i> Searching creators...</div>';
    } else {
        isLoadingMore = true;
        const loadMoreBtn = document.getElementById('loadMoreResults');
        if (loadMoreBtn) {
            loadMoreBtn.innerHTML = '<i class="fas fa-spinner fa-pulse"></i> Loading...';
            loadMoreBtn.disabled = true;
        }
    }
    
    try {
        const response = await fetch(baseUrlIS + 'is/search_creators_by_is', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: new URLSearchParams({
                keyword: keyword,
                page_token: searchPageToken || ''
            })
        });
        
        const result = await response.json();
        console.log('Search result:', result);
        
        if (result.success && result.creators && result.creators.length > 0) {
            if (!append) {
                searchResults = [];
                container.innerHTML = '';
            }
            
            searchResults = [...searchResults, ...result.creators];
            
            // Render results
            result.creators.forEach(creator => {
                const followerFormatted = formatNumberShort(creator.follower_count);
                const gmvUsd = parseFloat(creator.gmv || 0);
                const gmvIdr = Math.round(gmvUsd * 16000);
                const gmvFormatted = gmvUsd > 0 
                    ? `Rp ${formatNumber(gmvIdr)}`
                    : (creator.gmv_formatted || 'Rp 0');
                const avatarHtml = creator.avatar_url && creator.avatar_url !== ''
                    ? `<img src="${escapeHtml(creator.avatar_url)}" style="width:100%; height:100%; object-fit:cover;" onerror="this.src=''; this.onerror=null; this.parentElement.innerHTML='<i class=\\'fab fa-tiktok\\' style=\\'font-size:28px; color:#4ade80;\\'></i>'">` 
                    : '<i class="fab fa-tiktok" style="font-size:28px; color:#4ade80;"></i>';
                
                // �9�7 Bangun icon SV/LV dengan class CSS
                let contentIconsHtml = '';
                const liveCount = creator.live_count || creator.avg_live_uv || 0;
                const videoCount = creator.video_count || creator.avg_video_views || 0;
                
                // SV untuk Live (Streaming Video) - NEON PURPLE, ICON PLAY
                if (liveCount > 0) {
                    contentIconsHtml += `<span class="icon-sv">
                        <i class="fas fa-play"></i> SV
                    </span>`;
                }
                // LV untuk Video - NEON ORANGE, ICON CAMERA DECODER
                if (videoCount > 0) {
                    contentIconsHtml += `<span class="icon-lv" style="margin-left:4px;">
                        <i class="fas fa-camera"></i> LV
                    </span>`;
                }
                
                // �9�7 BUAT CARD UNTUK SETIAP CREATOR
                const cardHtml = `
                <div class="search-result-item" style="background:#0f1420; border-radius:12px; padding:12px; margin-bottom:10px; border:1px solid #2a3346; transition:all 0.2s; cursor:pointer;" 
                     data-creator='${JSON.stringify(creator).replace(/'/g, "&#39;")}'
                     onmouseover="this.style.borderColor='#4ade80'" 
                     onmouseout="this.style.borderColor='#2a3346'">
                    <div style="display:flex; gap:12px;">
                        <div style="width:50px; height:50px; border-radius:50%; overflow:hidden; background:#1e293b; flex-shrink:0; display:flex; align-items:center; justify-content:center;">
                            ${avatarHtml}
                        </div>
                        <div style="flex:1;">
                            <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:6px;">
                                <div>
                                    <div style="display:flex; align-items:center; flex-wrap:wrap; gap:6px;">
                                        <strong style="color:#e2f0e8; font-size:13px;">${escapeHtml(creator.nickname || creator.username)}</strong>
                                        ${contentIconsHtml}
                                    </div>
                                    <div style="color:#9aaebe; font-size:10px; margin-top:2px;">@${escapeHtml(creator.username)}</div>
                                </div>
                                <div style="text-align:right;">
                                    <div style="color:#4ade80; font-size:12px; font-weight:600;">${gmvFormatted}</div>
                                    <div style="color:#9aaebe; font-size:9px;">GMV 28 hari</div>
                                </div>
                            </div>
                            <div style="display:flex; gap:12px; margin-top:6px; flex-wrap:wrap;">
                                <span style="color:#4ade80; font-size:10px;">
                                    <i class="fas fa-users"></i> ${followerFormatted}
                                </span>
                                <span style="color:#8b5cf6; font-size:10px;">
                                    <i class="fas fa-chart-line"></i> Avg View: ${formatNumberShort(creator.avg_video_views || 0)}
                                </span>
                                ${creator.avg_live_uv > 0 ? `
                                <span style="color:#f59e0b; font-size:10px;">
                                    <i class="fas fa-video"></i> Avg Live: ${formatNumberShort(creator.avg_live_uv)}
                                </span>
                                ` : ''}
                                <span style="color:#9aaebe; font-size:9px;">
                                    <i class="fas fa-tag"></i> ${escapeHtml(creator.category || 'Lifestyle')}
                                </span>
                            </div>
                        </div>
                        <div style="display:flex; flex-direction:column; gap:6px; flex-shrink:0;">
                            <button class="select-creator-btn" style="background:#4ade80; color:#0a0e17; border:none; padding:4px 12px; border-radius:16px; cursor:pointer; font-size:10px; font-weight:600; white-space:nowrap;">
                                <i class="fas fa-plus"></i> Pilih
                            </button>
                            <button class="detail-creator-btn" data-creator-open-id="${escapeHtml(creator.creator_open_id || '')}" 
                                    style="background:#1e293b; color:#8b5cf6; border:1px solid #8b5cf6; padding:4px 12px; border-radius:16px; cursor:pointer; font-size:10px; white-space:nowrap;">
                                <i class="fas fa-info-circle"></i> Detail
                            </button>
                        </div>
                    </div>
                </div>`;
                
                container.innerHTML += cardHtml;
            });
            
            // ... (rest of event listeners same as before)
            
            // �9�7 ATTACH EVENT LISTENER KE TOMBOL DETAIL
            document.querySelectorAll('.detail-creator-btn').forEach(btn => {
                const newBtn = btn.cloneNode(true);
                btn.parentNode.replaceChild(newBtn, btn);
                
                newBtn.addEventListener('click', (e) => {
                    e.stopPropagation();
                    const creatorOpenId = newBtn.getAttribute('data-creator-open-id');
                    console.log('Detail button clicked, creator_open_id:', creatorOpenId);
                    
                    if (creatorOpenId && creatorOpenId !== '') {
                        showCreatorPerformanceDetail(creatorOpenId);
                    } else {
                        showToastGlobal('Creator Open ID tidak tersedia untuk creator ini', 'warning');
                    }
                });
            });
            
            // �9�7 ATTACH EVENT LISTENER KE TOMBOL PILIH
            document.querySelectorAll('.select-creator-btn').forEach(btn => {
                const newBtn = btn.cloneNode(true);
                btn.parentNode.replaceChild(newBtn, btn);
                
                newBtn.addEventListener('click', (e) => {
                    e.stopPropagation();
                    const parent = newBtn.closest('.search-result-item');
                    const creatorData = JSON.parse(parent.getAttribute('data-creator'));
                    console.log('Select button clicked:', creatorData);
                    showAddCreatorFromSearchForm(creatorData);
                });
            });
            
            // Update pagination
            if (result.next_page_token) {
                searchPageToken = result.next_page_token;
                loadMoreContainer.style.display = 'block';
                
                let loadMoreBtn = document.getElementById('loadMoreResults');
                if (loadMoreBtn) {
                    const newLoadMoreBtn = loadMoreBtn.cloneNode(true);
                    loadMoreBtn.parentNode.replaceChild(newLoadMoreBtn, loadMoreBtn);
                    
                    newLoadMoreBtn.innerHTML = '<i class="fas fa-chevron-down"></i> Load More';
                    newLoadMoreBtn.disabled = false;
                    isLoadingMore = false;
                    
                    newLoadMoreBtn.addEventListener('click', async () => {
                        if (!isLoadingMore && searchPageToken) {
                            await performSearch(true);
                        }
                    });
                }
            } else {
                searchPageToken = null;
                if (searchResults.length > 0) {
                    loadMoreContainer.style.display = 'block';
                    let loadMoreBtn = document.getElementById('loadMoreResults');
                    if (loadMoreBtn) {
                        const newLoadMoreBtn = loadMoreBtn.cloneNode(true);
                        loadMoreBtn.parentNode.replaceChild(newLoadMoreBtn, loadMoreBtn);
                        newLoadMoreBtn.innerHTML = '<i class="fas fa-check"></i> No more results';
                        newLoadMoreBtn.disabled = true;
                    }
                } else {
                    loadMoreContainer.style.display = 'none';
                }
            }
            
        } else {
            container.innerHTML = `
                <div style="text-align:center; padding:40px; color:#ef4444;">
                    <i class="fas fa-exclamation-triangle" style="font-size:32px; margin-bottom:12px; display:block;"></i>
                    <p>${result.message || 'Tidak ditemukan creator'}</p>
                    <small style="color:#9aaebe;">Coba dengan keyword lain</small>
                </div>
            `;
            loadMoreContainer.style.display = 'none';
        }
        
    } catch (error) {
        console.error('Search error:', error);
        container.innerHTML = `
            <div style="text-align:center; padding:40px; color:#ef4444;">
                <i class="fas fa-exclamation-triangle" style="font-size:32px; margin-bottom:12px; display:block;"></i>
                <p>Error: ${error.message}</p>
                <button id="retrySearchBtn" class="btn-primary" style="margin-top:12px; background:#4ade80; color:#0a0e17; border:none; padding:8px 16px; border-radius:20px; cursor:pointer;">Coba Lagi</button>
            </div>
        `;
        const retryBtn = document.getElementById('retrySearchBtn');
        if (retryBtn) {
            retryBtn.addEventListener('click', () => performSearch());
        }
        loadMoreContainer.style.display = 'none';
    }
}
async function showAddCreatorFromSearchForm(creator) {
    console.log('Opening add creator form with data:', creator);
    
    const modalTitle = document.getElementById('modalTitleDashboard');
    const modalBody = document.getElementById('modalBodyDashboard');
    
    // Tampilkan loading
    modalTitle.innerHTML = '<i class="fas fa-spinner fa-pulse"></i> Memuat data kontak...';
    modalBody.innerHTML = `
        <div style="text-align:center; padding:40px;">
            <i class="fas fa-spinner fa-pulse fa-2x" style="color:#8b5cf6;"></i>
            <p style="margin-top:12px;">AI Toopai sedang mencari kontak WhatsApp & Email creator </p>
            <p style="font-size:11px; color:#9aaebe;">Mohon tunggu sebentar</p>
        </div>
    `;
    openModalIS();
    
    // �9�7 FETCH KONTAK DARI CRAWLER
    let contactData = { whatsapp: '', email: '', display_name: '' };
    let contactFound = false;
    
    try {
        const contactResult = await fetchCreatorContact(creator.username);
        if (contactResult.success && contactResult.whatsapp) {
            contactData.whatsapp = contactResult.whatsapp;
            contactData.email = contactResult.email || '';
            contactData.display_name = contactResult.display_name || creator.nickname;
            contactFound = true;
            console.log('Contact found via crawler:', contactData);
        } else {
            console.log('No contact found via crawler, using manual input');
        }
    } catch (error) {
        console.error('Error fetching contact:', error);
    }
    
    // Format data
    const followerFormatted = formatNumberShort(creator.follower_count);
    const followerRaw = creator.follower_count || 0;
    const gmvUsd = parseFloat(creator.gmv || 0);
    const gmvIdr = Math.round(gmvUsd * 16000);
    const gmvFormatted = 'Rp ' + formatNumber(gmvIdr);
    const gmvRaw = gmvIdr;
    
    // Avatar HTML
    const avatarHtml = creator.avatar_url && creator.avatar_url !== ''
        ? `<img src="${escapeHtml(creator.avatar_url)}" style="width:100%; height:100%; object-fit:cover;" onerror="this.src=''; this.onerror=null; this.parentElement.innerHTML='<i class=\\'fab fa-tiktok\\' style=\\'font-size:40px; color:#4ade80;\\'></i>'">` 
        : '<i class="fab fa-tiktok" style="font-size:40px; color:#4ade80;"></i>';
    
    // Tampilkan form dengan data yang sudah didapat
    modalTitle.innerHTML = '<i class="fas fa-user-plus"></i> Tambah Creator dari Hasil Pencarian';
    modalBody.innerHTML = `
        <div style="background:rgba(74,222,128,0.1); border-radius:14px; padding:12px; margin-bottom:16px;">
            <div style="display:flex; gap:16px; align-items:center;">
                <div style="width:70px; height:70px; border-radius:50%; overflow:hidden; background:#1e293b; display:flex; align-items:center; justify-content:center;">
                    ${avatarHtml}
                </div>
                <div>
                    <div style="color:#e2f0e8; font-weight:600; font-size:16px;">${escapeHtml(creator.nickname || creator.username)}</div>
                    <div style="color:#4ade80; font-size:12px;">@${escapeHtml(creator.username)}</div>
                    ${contactFound ? '<div style="color:#4ade80; font-size:10px; margin-top:4px;"><i class="fas fa-check-circle"></i> Kontak otomatis ditemukan!</div>' : '<div style="color:#fbbf24; font-size:10px; margin-top:4px;"><i class="fas fa-info-circle"></i> Kontak tidak ditemukan, silakan isi manual</div>'}
                </div>
            </div>
        </div>
        
        <div style="display:grid; grid-template-columns:1fr 1fr; gap:12px; margin-bottom:16px;">
            <div style="background:#0f1420; border-radius:10px; padding:8px; text-align:center;">
                <div style="color:#9aaebe; font-size:10px;"><i class="fas fa-users"></i> Followers</div>
                <div style="color:#4ade80; font-size:14px; font-weight:600;">${followerFormatted}</div>
            </div>
            <div style="background:#0f1420; border-radius:10px; padding:8px; text-align:center;">
                <div style="color:#9aaebe; font-size:10px;"><i class="fas fa-chart-line"></i> GMV 28 Hari</div>
                <div style="color:#fbbf24; font-size:14px; font-weight:600;">${gmvFormatted}</div>
            </div>
        </div>
        
        <label><i class="fab fa-tiktok"></i> Username *</label>
        <input type="text" id="creatorUsernameIS" value="${escapeHtml(creator.username)}" readonly style="background:#1a1f2e; color:#9aaebe; width:100%; padding:10px; border-radius:10px; border:1px solid #2a3346;">
        
        <label><i class="fas fa-user"></i> Nama Lengkap</label>
        <input type="text" id="creatorNameIS" value="${escapeHtml(contactData.display_name || creator.nickname || '')}" placeholder="Nama lengkap creator" style="width:100%; padding:10px; background:#0f1420; border:1px solid #2a3346; border-radius:10px; color:#e2f0e8;">
        
        <label><i class="fab fa-whatsapp"></i> WhatsApp <span id="whatsappStatus" style="font-size:10px; color:${contactData.whatsapp ? '#4ade80' : '#fbbf24'}; margin-left:8px;">${contactData.whatsapp ? '(Auto-ditemukan)' : '(Kosong - isi manual)'}</span></label>
        <div style="display:flex; gap:8px; align-items:center;">
            <input type="tel" id="creatorPhoneIS" value="${escapeHtml(contactData.whatsapp || '')}" placeholder="+62 812 3456 7890" style="flex:1; padding:10px; background:#0f1420; border:1px solid #2a3346; border-radius:10px; color:#e2f0e8;">
            <button type="button" id="refreshContactBtn" style="background:#8b5cf6; color:white; border:none; padding:8px 12px; border-radius:10px; cursor:pointer; font-size:11px;" title="Cari ulang kontak">
                <i class="fas fa-sync-alt"></i>
            </button>
        </div>
        
        <label><i class="fas fa-envelope"></i> Email <span id="emailStatus" style="font-size:10px; color:${contactData.email ? '#4ade80' : '#fbbf24'}; margin-left:8px;">${contactData.email ? '(Auto-ditemukan)' : '(Kosong - isi manual)'}</span></label>
        <input type="email" id="creatorEmailIS" value="${escapeHtml(contactData.email || '')}" placeholder="Email creator" style="width:100%; padding:10px; background:#0f1420; border:1px solid #2a3346; border-radius:10px; color:#e2f0e8;">
        
        <label><i class="fas fa-tag"></i> Kategori</label>
        <select id="creatorCategoryIS" style="width:100%; padding:10px; background:#0f1420; border:1px solid #2a3346; border-radius:10px; color:#e2f0e8;">
            <option value="Beauty" ${creator.category === 'Beauty' ? 'selected' : ''}> Beauty</option>
            <option value="Fashion" ${creator.category === 'Fashion' ? 'selected' : ''}> Fashion</option>
            <option value="Tech" ${creator.category === 'Tech' ? 'selected' : ''}> Tech</option>
            <option value="Lifestyle" ${creator.category === 'Lifestyle' ? 'selected' : ''}> Lifestyle</option>
            <option value="Gaming" ${creator.category === 'Gaming' ? 'selected' : ''}> Gaming</option>
            <option value="Food" ${creator.category === 'Food' ? 'selected' : ''}> Food</option>
            <option value="Sports" ${creator.category === 'Sports' ? 'selected' : ''}>Sports</option>
            <option value="Home & Living" ${creator.category === 'Home & Living' ? 'selected' : ''}> Home & Living</option>
            <option value="Health" ${creator.category === 'Health' ? 'selected' : ''}> Health</option>
            <option value="Skincare" ${creator.category === 'Skincare' ? 'selected' : ''}> Skincare</option>
            <option value="Makeup" ${creator.category === 'Makeup' ? 'selected' : ''}> Makeup</option>
        </select>
        
        <!-- Hidden fields untuk data API -->
        <input type="hidden" id="creatorAvatarUrl" value="${escapeHtml(creator.avatar_url || '')}">
        <input type="hidden" id="creatorFollowerCount" value="${followerRaw}">
        <input type="hidden" id="creatorGmv" value="${gmvRaw}">
        
        <div class="flex-buttons" style="margin-top:20px;">
            <button id="saveCreatorFromSearchBtn" style="background:#4ade80; color:#0a0e17; flex:1;"><i class="fas fa-save"></i> Simpan Creator</button>
            <button id="cancelCreatorFromSearchBtn" style="background:#1e293b; flex:1;">Batal</button>
        </div>
    `;
    
    // �9�7 EVENT: Refresh Contact Button
    document.getElementById('refreshContactBtn')?.addEventListener('click', async () => {
        const refreshBtn = document.getElementById('refreshContactBtn');
        const originalText = refreshBtn.innerHTML;
        refreshBtn.disabled = true;
        refreshBtn.innerHTML = '<i class="fas fa-spinner fa-pulse"></i>';
        
        showToastGlobal('Mencari ulang kontak creator...', 'info');
        
        try {
            const contactResult = await fetchCreatorContact(creator.username);
            
            if (contactResult.success && contactResult.whatsapp) {
                document.getElementById('creatorPhoneIS').value = contactResult.whatsapp;
                document.getElementById('creatorEmailIS').value = contactResult.email || '';
                document.getElementById('whatsappStatus').innerHTML = '(Auto-ditemukan)';
                document.getElementById('whatsappStatus').style.color = '#4ade80';
                document.getElementById('emailStatus').innerHTML = contactResult.email ? '(Auto-ditemukan)' : '(Kosong)';
                document.getElementById('emailStatus').style.color = contactResult.email ? '#4ade80' : '#fbbf24';
                
                if (!document.getElementById('creatorNameIS').value || document.getElementById('creatorNameIS').value === '') {
                    document.getElementById('creatorNameIS').value = contactResult.display_name || creator.nickname || '';
                }
                
                showToastGlobal(`Kontak ditemukan! WhatsApp: ${contactResult.whatsapp}`, 'success');
            } else {
                showToastGlobal('Kontak tidak ditemukan, silakan isi manual', 'warning');
                document.getElementById('whatsappStatus').innerHTML = '(Tidak ditemukan - isi manual)';
                document.getElementById('whatsappStatus').style.color = '#ef4444';
            }
        } catch (error) {
            showToastGlobal('Gagal mencari kontak: ' + error.message, 'error');
        } finally {
            refreshBtn.disabled = false;
            refreshBtn.innerHTML = originalText;
        }
    });
    
    // Save button event
    const saveBtn = document.getElementById('saveCreatorFromSearchBtn');
    if (saveBtn) {
        const newSaveBtn = saveBtn.cloneNode(true);
        saveBtn.parentNode.replaceChild(newSaveBtn, saveBtn);
        
        newSaveBtn.addEventListener('click', async () => {
            const username = document.getElementById('creatorUsernameIS').value.trim();
            if (!username) { 
                showToastGlobal('Username harus diisi', 'error'); 
                return; 
            }
            
            const btn = newSaveBtn;
            btn.disabled = true; 
            btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Menyimpan...';
            
            const formData = new URLSearchParams({
                username: username.replace('@', ''),
                full_name: document.getElementById('creatorNameIS').value,
                phone: document.getElementById('creatorPhoneIS').value,
                email: document.getElementById('creatorEmailIS').value,
                category: document.getElementById('creatorCategoryIS').value,
                avatar_url: document.getElementById('creatorAvatarUrl').value,
                follower_count: document.getElementById('creatorFollowerCount').value,
                gmv: document.getElementById('creatorGmv').value
            });
            
            try {
                const response = await fetch(baseUrlIS + 'is/add_creator', { 
                    method: 'POST', 
                    body: formData
                });
                const result = await response.json();
                
                if (result.success) {
                    closeModalIS();
                    showToastGlobal(`�7�3 Creator @${username} berhasil ditambahkan!`);
                    setTimeout(() => location.reload(), 1500);
                } else {
                    showToastGlobal(result.message || 'Gagal menambah creator', 'error');
                    btn.disabled = false;
                    btn.innerHTML = '<i class="fas fa-save"></i> Simpan Creator';
                }
            } catch (error) {
                console.error('Save error:', error);
                showToastGlobal('Error: ' + error.message, 'error');
                btn.disabled = false;
                btn.innerHTML = '<i class="fas fa-save"></i> Simpan Creator';
            }
        });
    }
    
    // Cancel button event
    const cancelBtn = document.getElementById('cancelCreatorFromSearchBtn');
    if (cancelBtn) {
        const newCancelBtn = cancelBtn.cloneNode(true);
        cancelBtn.parentNode.replaceChild(newCancelBtn, cancelBtn);
        newCancelBtn.addEventListener('click', closeModalIS);
    }
}

// ========== CEK KONTAK CREATOR DARI CRAWLER ==========
async function fetchCreatorContact(username) {
    try {
        console.log('Fetching contact for username:', username);
        
        const response = await fetch(baseUrlIS + 'creator_crawler/cek/' + encodeURIComponent(username), {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json'
            }
        });
        
        const result = await response.json();
        console.log('Contact result:', result);
        
        if (result.success && result.status === 'FOUND') {
            return {
                success: true,
                whatsapp: result.whatsapp || '',
                email: result.email || '',
                display_name: result.display_name || '',
                status: result.status
            };
        } else {
            return {
                success: false,
                whatsapp: '',
                email: '',
                display_name: '',
                status: result.status || 'NOT_FOUND',
                message: result.message || 'Kontak tidak ditemukan'
            };
        }
    } catch (error) {
        console.error('Error fetching contact:', error);
        return {
            success: false,
            whatsapp: '',
            email: '',
            display_name: '',
            error: error.message
        };
    }
}
// ========== UPDATE BUTTON TAMBAH CREATOR (GABUNGAN) ==========
function updateAddCreatorButtons() {
    // Tombol di tab - BUKA SEARCH MODAL
    const addBtn = document.getElementById('addCreatorBtnDashboard');
    if (addBtn) {
        const newAddBtn = addBtn.cloneNode(true);
        addBtn.parentNode.replaceChild(newAddBtn, addBtn);
        newAddBtn.addEventListener('click', function(e) {
            e.preventDefault();
            e.stopPropagation();
            console.log('Add Creator button clicked - opening search modal');
            showSearchCreatorModal();
        });
    }
    
    // Tombol quick di Task 1 - BUKA SEARCH MODAL
    const quickBtn = document.getElementById('addCreatorQuickBtnDashboard');
    if (quickBtn) {
        const newQuickBtn = quickBtn.cloneNode(true);
        quickBtn.parentNode.replaceChild(newQuickBtn, quickBtn);
        newQuickBtn.addEventListener('click', function(e) {
            e.preventDefault();
            e.stopPropagation();
            console.log('Quick Add Creator button clicked - opening search modal');
            showSearchCreatorModal();
        });
    }
}

// ========== TASK 1: KLIK BOX SCOUTING ==========
async function showCreatorDetailIS(creatorId) {
    console.log('Fetching creator detail for ID:', creatorId);
    
    document.getElementById('modalTitleDashboard').innerHTML = `<i class="fab fa-tiktok"></i> Loading...`;
    document.getElementById('modalBodyDashboard').innerHTML = `
        <div style="text-align:center; padding:40px;">
            <i class="fas fa-spinner fa-pulse fa-2x" style="color:#4ade80;"></i>
            <p style="margin-top:12px;">Memuat data creator...</p>
        </div>
    `;
    openModalIS();
    
    try {
        const response = await fetch(baseUrlIS + 'is/get_creator_detail', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: new URLSearchParams({ creator_id: creatorId })
        });
        
        const result = await response.json();
        console.log('API Response:', result);
        
        if (!result.success) {
            document.getElementById('modalBodyDashboard').innerHTML = `
                <div style="text-align:center; padding:40px;">
                    <i class="fas fa-exclamation-triangle fa-2x" style="color:#ef4444;"></i>
                    <p style="margin-top:12px;">${result.message || 'Gagal mengambil detail creator'}</p>
                    <button class="btn-submit" onclick="closeModalIS()" style="margin-top:16px;">Tutup</button>
                </div>
            `;
            return;
        }
        
        const creator = result.data;
        const createdDate = creator.created_at ? new Date(creator.created_at).toLocaleDateString('id-ID') : '-';
        const approvedDate = creator.approved_at ? new Date(creator.approved_at).toLocaleDateString('id-ID') : 'Belum';
        const hasPhone = creator.phone && creator.phone !== '' && creator.phone !== '-';
        
        let statusBadge = '';
        if (creator.status === 'ACTIVE') {
            statusBadge = '<span class="badge-dashboard badge-active"><i class="fas fa-check-circle"></i> ACTIVE</span>';
        } else if (creator.status === 'PENDING') {
            statusBadge = '<span class="badge-dashboard badge-pending"><i class="fas fa-clock"></i> PENDING</span>';
        } else if (creator.status === 'REJECTED') {
            statusBadge = '<span class="badge-dashboard" style="background:rgba(239,68,68,0.15); color:#ef4444;"><i class="fas fa-times-circle"></i> REJECTED</span>';
        } else {
            statusBadge = `<span class="badge-dashboard badge-pending"><i class="fas fa-clock"></i> ${creator.status}</span>`;
        }
        
        const phoneWarning = !hasPhone && creator.status === 'PENDING' ? `
            <div style="background: rgba(239,68,68,0.15); border-radius: 12px; padding: 10px; margin-bottom: 16px; border-left: 3px solid #ef4444;">
                <div style="color: #fbbf24; font-size: 12px; font-weight: 500; margin-bottom: 5px;">
                    <i class="fas fa-exclamation-triangle"></i> Nomor WhatsApp tidak tersedia!
                </div>
                <div style="color: #9aaebe; font-size: 11px;">
                    Silakan update nomor WhatsApp creator sebelum approve.
                </div>
            </div>
        ` : '';
        
        let campaignsHtml = '';
        if (creator.campaigns && creator.campaigns.length > 0) {
            campaignsHtml = `
                <div style="margin-top:16px;">
                    <label style="color:#9aaebe; font-size:12px; margin-bottom:8px; display:block;">
                        <i class="fas fa-bullhorn"></i> Campaign yang Diikuti
                    </label>
                    <div style="background:#0f1420; border-radius:12px; padding:8px; max-height:150px; overflow-y:auto;">
                        ${creator.campaigns.map(camp => `
                            <div style="display:flex; justify-content:space-between; padding:8px; border-bottom:1px solid #2a3346;">
                                <div style="color:#e2f0e8; font-size:12px;">${escapeHtml(camp.campaign_name || camp.campaign_id)}</div>
                                <div style="color:#fbbf24; font-size:11px;">${camp.commission_rate}%</div>
                            </div>
                        `).join('')}
                    </div>
                </div>
            `;
        }
        
        let whatsappHtml = '';
        if (creator.whatsapp_logs && creator.whatsapp_logs.length > 0) {
            whatsappHtml = `
                <div style="margin-top:16px;">
                    <label style="color:#9aaebe; font-size:12px; margin-bottom:8px; display:block;">
                        <i class="fab fa-whatsapp"></i> Riwayat WhatsApp
                    </label>
                    <div style="background:#0f1420; border-radius:12px; padding:8px; max-height:120px; overflow-y:auto;">
                        ${creator.whatsapp_logs.map(log => `
                            <div style="font-size:10px; color:#9aaebe; padding:4px 0; border-bottom:1px solid #2a3346;">
                                <i class="fas fa-paper-plane"></i> ${log.sent_at ? new Date(log.sent_at).toLocaleString() : '-'}
                                <div style="color:#e2f0e8; margin-top:2px;">${escapeHtml(log.message.substring(0, 100))}${log.message.length > 100 ? '...' : ''}</div>
                            </div>
                        `).join('')}
                    </div>
                </div>
            `;
        }
        
        document.getElementById('modalTitleDashboard').innerHTML = `<i class="fab fa-tiktok"></i> Detail Creator: @${escapeHtml(creator.username)}`;
        document.getElementById('modalBodyDashboard').innerHTML = `
            <div style="background:rgba(74,222,128,0.1); border-radius:14px; padding:14px; margin-bottom:16px;">
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 12px;">
                    <div>
                        <div style="color:#9aaebe; font-size:11px;">Username</div>
                        <div style="color:#ffffff; font-size:14px; font-weight:500; display: flex; align-items: center; gap: 8px;">
                            @${escapeHtml(creator.username)}
                            <button id="checkTiktokBtnIS" style="background: transparent; border: 1px solid #4ade80; border-radius: 20px; padding: 2px 10px; font-size: 10px; color: #4ade80; cursor: pointer;">
                                <i class="fab fa-tiktok"></i> Cek Profil
                            </button>
                        </div>
                    </div>
                    <div>
                        <div style="color:#9aaebe; font-size:11px;">Nama Lengkap</div>
                        <div style="color:#ffffff; font-size:14px;">${escapeHtml(creator.full_name || '-')}</div>
                    </div>
                    <div>
                        <div style="color:#9aaebe; font-size:11px;">Kategori</div>
                        <div style="color:#ffffff; font-size:14px;">${escapeHtml(creator.category || '-')}</div>
                    </div>
                    <div>
                        <div style="color:#9aaebe; font-size:11px;">Status</div>
                        <div>${statusBadge}</div>
                    </div>
                    <div>
                        <div style="color:#9aaebe; font-size:11px;"><i class="fab fa-whatsapp"></i> WhatsApp</div>
                        <div style="color:${hasPhone ? '#4ade80' : '#ef4444'}; font-size:14px;">
                            ${hasPhone ? escapeHtml(creator.phone) : '<i class="fas fa-times-circle"></i> Tidak tersedia'}
                        </div>
                    </div>
                    <div>
                        <div style="color:#9aaebe; font-size:11px;"><i class="fas fa-envelope"></i> Email</div>
                        <div style="color:#ffffff; font-size:14px;">${escapeHtml(creator.email || '-')}</div>
                    </div>
                    <div>
                        <div style="color:#9aaebe; font-size:11px;">Tanggal Daftar</div>
                        <div style="color:#ffffff; font-size:12px;">${createdDate}</div>
                    </div>
                    <div>
                        <div style="color:#9aaebe; font-size:11px;">Tanggal Approve</div>
                        <div style="color:#ffffff; font-size:12px;">${approvedDate}</div>
                    </div>
                </div>
            </div>
            
            ${phoneWarning}
            ${campaignsHtml}
            ${whatsappHtml}
            
            <div class="flex-buttons" style="margin-top:20px;">
                ${creator.status === 'PENDING' ? `
                 <button id="editCreatorBtnIS" style="background:#8b5cf6; color:white;">
            <i class="fas fa-edit"></i> Edit Data
        </button>
                    <button id="approveCreatorBtnIS" style="background:#4ade80; color:#0a0e17;">
                        <i class="fas fa-check-circle"></i> Approve Creator
                    </button>
                    <button id="updatePhoneBtnIS" style="background:#fbbf24; color:#0a0e17;">
                        <i class="fab fa-whatsapp"></i> Update WhatsApp
                    </button>
                    <button id="rejectCreatorBtnIS" style="background:#1e293b; border:1px solid #ef4444; color:#ef4444;">
                        <i class="fas fa-times-circle"></i> Tolak
                    </button>
                ` : ''}
                <button id="closeDetailBtnIS" style="background:#1e293b;">Tutup</button>
            </div>
        `;
        const editBtn = document.getElementById('editCreatorBtnIS');
if (editBtn) {
    editBtn.addEventListener('click', () => {
        showEditCreatorModalIS(creatorId, creator);
    });
}

        const checkTiktokBtn = document.getElementById('checkTiktokBtnIS');
        if (checkTiktokBtn) {
            checkTiktokBtn.addEventListener('click', (e) => {
                e.preventDefault();
                e.stopPropagation();
                window.open(`https://www.tiktok.com/@${creator.username}`, '_blank');
            });
        }
        
        const updatePhoneBtn = document.getElementById('updatePhoneBtnIS');
        if (updatePhoneBtn) {
            updatePhoneBtn.addEventListener('click', () => {
                showUpdatePhoneModalIS(creatorId, creator.username, creator.phone);
            });
        }
        
        const approveBtn = document.getElementById('approveCreatorBtnIS');
        if (approveBtn) {
            approveBtn.addEventListener('click', async () => {
                if (!hasPhone) {
                    showToastGlobal('Silakan update nomor WhatsApp creator terlebih dahulu sebelum approve!', 'error');
                    showUpdatePhoneModalIS(creatorId, creator.username, null);
                    return;
                }
                
                const btn = approveBtn;
                btn.disabled = true;
                btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Approving...';
                
                const approveRes = await fetch(baseUrlIS + 'is/approve_creator', {
                    method: 'POST',
                    body: new URLSearchParams({ creator_id: creatorId })
                });
                const approveResult = await approveRes.json();
                
                if (approveResult.success) {
                    closeModalIS();
                    showToastGlobal(`�7�3 @${creator.username} approved! Kini dapat diassign campaign di Task 2.`, 'success');
                    setTimeout(() => location.reload(), 1500);
                } else {
                    showToastGlobal(approveResult.message || 'Gagal approve', 'error');
                    btn.disabled = false;
                    btn.innerHTML = '<i class="fas fa-check-circle"></i> Approve Creator';
                }
            });
        }
        
        const rejectBtn = document.getElementById('rejectCreatorBtnIS');
        if (rejectBtn) {
            rejectBtn.addEventListener('click', async () => {
                if (confirm(`Tolak creator @${creator.username}?`)) {
                    await fetch(baseUrlIS + 'is/update_creator_status', {
                        method: 'POST',
                        body: new URLSearchParams({ creator_id: creatorId, status: 'REJECTED' })
                    });
                    closeModalIS();
                    showToastGlobal(`@${creator.username} ditolak`, 'warning');
                    setTimeout(() => location.reload(), 1500);
                }
            });
        }
        
        document.getElementById('closeDetailBtnIS')?.addEventListener('click', closeModalIS);
        
    } catch (error) {
        console.error('Error:', error);
        document.getElementById('modalBodyDashboard').innerHTML = `
            <div style="text-align:center; padding:40px;">
                <i class="fas fa-exclamation-triangle fa-2x" style="color:#ef4444;"></i>
                <p style="margin-top:12px;">Network error: ${error.message}</p>
                <button class="btn-submit" onclick="closeModalIS()" style="margin-top:16px;">Tutup</button>
            </div>
        `;
    }
}

function showUpdatePhoneModalIS(creatorId, creatorUsername, currentPhone) {
    const modalTitle = document.getElementById('modalTitleDashboard');
    const modalBody = document.getElementById('modalBodyDashboard');
    
    modalTitle.innerHTML = `<i class="fab fa-whatsapp"></i> Update WhatsApp - @${escapeHtml(creatorUsername)}`;
    modalBody.innerHTML = `
        <div style="background:rgba(74,222,128,0.1); border-radius:14px; padding:12px; margin-bottom:16px;">
            <p style="color:#4ade80; font-size:12px;"><i class="fas fa-info-circle"></i> Nomor WhatsApp diperlukan untuk mengirim link afiliasi dan sample</p>
        </div>
        
        <label><i class="fab fa-whatsapp"></i> Nomor WhatsApp</label>
        <input type="tel" id="updatePhoneNumber" placeholder="+62 812 3456 7890" value="${escapeHtml(currentPhone || '')}" style="width:100%; padding:10px; background:#0f1420; border:1px solid #2a3346; border-radius:12px; color:#e2f0e8; margin-bottom:16px;">
        <div style="font-size:11px; color:#9aaebe; margin-bottom:16px;">
            <i class="fas fa-info-circle"></i> Format: +628123456789 atau 08123456789
        </div>
        
        <div class="flex-buttons">
            <button id="savePhoneBtn" style="background:#4ade80; color:#0a0e17;"><i class="fas fa-save"></i> Simpan</button>
            <button id="cancelPhoneBtn" style="background:#1e293b;">Batal</button>
        </div>
    `;
    openModalIS();
    
    document.getElementById('savePhoneBtn').addEventListener('click', async () => {
        let phone = document.getElementById('updatePhoneNumber').value.trim();
        
        if (!phone) {
            showToastGlobal('Nomor WhatsApp tidak boleh kosong', 'error');
            return;
        }
        
        phone = phone.replace(/[^0-9+]/g, '');
        if (phone.startsWith('0')) {
            phone = '62' + phone.substring(1);
        } else if (phone.startsWith('+')) {
            phone = phone.substring(1);
        }
        
        if (phone.length < 10) {
            showToastGlobal('Nomor WhatsApp tidak valid (minimal 10 digit)', 'error');
            return;
        }
        
        const btn = document.getElementById('savePhoneBtn');
        btn.disabled = true;
        btn.innerHTML = '<i class="fas fa-spinner fa-pulse"></i> Menyimpan...';
        
        try {
            const response = await fetch(baseUrlIS + 'is/update_creator_phone', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: new URLSearchParams({
                    creator_id: creatorId,
                    phone: phone
                })
            });
            const result = await response.json();
            
            if (result.success) {
                showToastGlobal('Nomor WhatsApp berhasil diupdate!', 'success');
                closeModalIS();
                showCreatorDetailIS(creatorId);
            } else {
                showToastGlobal(result.message || 'Gagal update nomor', 'error');
                btn.disabled = false;
                btn.innerHTML = '<i class="fas fa-save"></i> Simpan';
            }
        } catch (error) {
            showToastGlobal('Error: ' + error.message, 'error');
            btn.disabled = false;
            btn.innerHTML = '<i class="fas fa-save"></i> Simpan';
        }
    });
    
    document.getElementById('cancelPhoneBtn').addEventListener('click', () => {
        closeModalIS();
        showCreatorDetailIS(creatorId);
    });
}
// ========== MODAL EDIT CREATOR (TASK 1) ==========
function showEditCreatorModalIS(creatorId, creatorData) {
    const modalTitle = document.getElementById('modalTitleDashboard');
    const modalBody = document.getElementById('modalBodyDashboard');
    
    modalTitle.innerHTML = `<i class="fas fa-edit"></i> Edit Creator: @${escapeHtml(creatorData.username)}`;
    modalBody.innerHTML = `
        <div style="background:rgba(139,92,246,0.1); border-radius:14px; padding:12px; margin-bottom:16px;">
            <p style="color:#8b5cf6; font-size:12px;"><i class="fas fa-info-circle"></i> Edit data creator. Field yang dikosongkan tidak akan diubah.</p>
        </div>
        
        <label><i class="fab fa-tiktok"></i> Username</label>
        <input type="text" value="@${escapeHtml(creatorData.username)}" readonly style="background:#1a1f2e; color:#9aaebe; width:100%; padding:10px; border-radius:10px; border:1px solid #2a3346;">
        
        <label><i class="fas fa-user"></i> Nama Lengkap</label>
        <input type="text" id="editFullName" value="${escapeHtml(creatorData.full_name || '')}" placeholder="Nama lengkap" style="width:100%; padding:10px; background:#0f1420; border:1px solid #2a3346; border-radius:10px; color:#e2f0e8;">
        
        <label><i class="fab fa-whatsapp"></i> WhatsApp</label>
        <input type="tel" id="editPhone" value="${escapeHtml(creatorData.phone || '')}" placeholder="+62 812 3456 7890" style="width:100%; padding:10px; background:#0f1420; border:1px solid #2a3346; border-radius:10px; color:#e2f0e8;">
        
        <label><i class="fas fa-envelope"></i> Email</label>
        <input type="email" id="editEmail" value="${escapeHtml(creatorData.email || '')}" placeholder="Email" style="width:100%; padding:10px; background:#0f1420; border:1px solid #2a3346; border-radius:10px; color:#e2f0e8;">
        
        <label><i class="fas fa-tag"></i> Kategori</label>
        <select id="editCategory" style="width:100%; padding:10px; background:#0f1420; border:1px solid #2a3346; border-radius:10px; color:#e2f0e8;">
            <option value="Beauty" ${creatorData.category === 'Beauty' ? 'selected' : ''}>�9�6 Beauty</option>
            <option value="Fashion" ${creatorData.category === 'Fashion' ? 'selected' : ''}>�9�1 Fashion</option>
            <option value="Tech" ${creatorData.category === 'Tech' ? 'selected' : ''}>�9�5 Tech</option>
            <option value="Lifestyle" ${creatorData.category === 'Lifestyle' ? 'selected' : ''}>�9�9 Lifestyle</option>
            <option value="Gaming" ${creatorData.category === 'Gaming' ? 'selected' : ''}>�9�2 Gaming</option>
            <option value="Food" ${creatorData.category === 'Food' ? 'selected' : ''}>�9�2 Food</option>
            <option value="Sports" ${creatorData.category === 'Sports' ? 'selected' : ''}>�7�1 Sports</option>
            <option value="Home & Living" ${creatorData.category === 'Home & Living' ? 'selected' : ''}>�9�2 Home & Living</option>
            <option value="Health" ${creatorData.category === 'Health' ? 'selected' : ''}>�9�2 Health</option>
            <option value="FnB" ${creatorData.category === 'FnB' ? 'selected' : ''}>�9�3 FnB</option>
            <option value="Skincare" ${creatorData.category === 'Skincare' ? 'selected' : ''}>�0�8 Skincare</option>
            <option value="Makeup" ${creatorData.category === 'Makeup' ? 'selected' : ''}>�9�3 Makeup</option>
        </select>
        
        <label><i class="fas fa-user-tag"></i> Nama Penerima Sample</label>
        <input type="text" id="editPenerima" value="${escapeHtml(creatorData.penerima || '')}" placeholder="Nama penerima" style="width:100%; padding:10px; background:#0f1420; border:1px solid #2a3346; border-radius:10px; color:#e2f0e8;">
        
        <label><i class="fas fa-map-marker-alt"></i> Alamat Pengiriman</label>
        <textarea id="editAlamat" rows="2" placeholder="Alamat lengkap..." style="width:100%; padding:10px; background:#0f1420; border:1px solid #2a3346; border-radius:10px; color:#e2f0e8;">${escapeHtml(creatorData.alamat || '')}</textarea>
        
        <label><i class="fas fa-sticky-note"></i> Catatan</label>
        <textarea id="editNotes" rows="2" placeholder="Catatan tentang creator ini..." style="width:100%; padding:10px; background:#0f1420; border:1px solid #2a3346; border-radius:10px; color:#e2f0e8;">${escapeHtml(creatorData.notes || '')}</textarea>
        
        <div style="background:#0f1420; border-radius:10px; padding:10px; margin-top:16px;">
            <div style="display:grid; grid-template-columns:1fr 1fr; gap:8px; font-size:10px; color:#9aaebe;">
                <div>Status: <span style="color:#fbbf24;">${escapeHtml(creatorData.status || '-')}</span></div>
                <div>Source: <span style="color:#8b5cf6;">${escapeHtml(creatorData.source || '-')}</span></div>
                <div>Created: ${new Date(creatorData.created_at).toLocaleDateString('id-ID')}</div>
                <div>Updated: ${new Date(creatorData.updated_at).toLocaleDateString('id-ID')}</div>
            </div>
        </div>
        
        <div class="flex-buttons" style="margin-top:20px;">
            <button id="saveEditBtn" style="background:#4ade80; color:#0a0e17; flex:1;"><i class="fas fa-save"></i> Simpan Perubahan</button>
            <button id="cancelEditBtn" style="background:#1e293b; flex:1;">Batal</button>
        </div>
    `;
    openModalIS();
    
    // Save button
    document.getElementById('saveEditBtn').addEventListener('click', async () => {
        const btn = document.getElementById('saveEditBtn');
        btn.disabled = true;
        btn.innerHTML = '<i class="fas fa-spinner fa-pulse"></i> Menyimpan...';
        
        const updateData = new URLSearchParams();
       const newUsername = document.getElementById('editUsername').value.trim().replace('@', '');
    const oldUsername = creatorData.username || '';
    
    // �9�7 KONFIRMASI KALAU USERNAME BERUBAH
    if (newUsername !== oldUsername && newUsername !== '') {
        if (!confirm(`�7�2�1�5 Username akan diubah dari @${oldUsername} menjadi @${newUsername}.\n\nData order, link, dan performa akan ikut terupdate.\n\nLanjutkan?`)) {
            return;
        }
    }
        
        const fullName = document.getElementById('editFullName').value.trim();
        const phone = document.getElementById('editPhone').value.trim();
        const email = document.getElementById('editEmail').value.trim();
        const category = document.getElementById('editCategory').value;
        const penerima = document.getElementById('editPenerima').value.trim();
        const alamat = document.getElementById('editAlamat').value.trim();
        const notes = document.getElementById('editNotes').value.trim();
        
        if (fullName !== (creatorData.full_name || '')) updateData.append('full_name', fullName);
        if (phone !== (creatorData.phone || '')) updateData.append('phone', phone);
        if (email !== (creatorData.email || '')) updateData.append('email', email);
        if (category !== (creatorData.category || '')) updateData.append('category', category);
        if (penerima !== (creatorData.penerima || '')) updateData.append('penerima', penerima);
        if (alamat !== (creatorData.alamat || '')) updateData.append('alamat', alamat);
        if (notes !== (creatorData.notes || '')) updateData.append('notes', notes);
        
        try {
            const response = await fetch(baseUrlIS + 'is/update_creator_data', {
                method: 'POST',
                body: updateData
            });
            const result = await response.json();
            
            if (result.success) {
                closeModalIS();
                showToastGlobal('Data creator berhasil diupdate!', 'success');
                setTimeout(() => location.reload(), 1500);
            } else {
                showToastGlobal(result.message || 'Gagal update', 'error');
                btn.disabled = false;
                btn.innerHTML = '<i class="fas fa-save"></i> Simpan Perubahan';
            }
        } catch (error) {
            showToastGlobal('Error: ' + error.message, 'error');
            btn.disabled = false;
            btn.innerHTML = '<i class="fas fa-save"></i> Simpan Perubahan';
        }
    });
    
    // Cancel button
    document.getElementById('cancelEditBtn').addEventListener('click', () => {
        closeModalIS();
        showCreatorDetailIS(creatorId);
    });
}
document.querySelectorAll('.scouting-item-dashboard').forEach(item => {
    item.addEventListener('click', () => {
        const creatorId = item.getAttribute('data-creator-id');
        showCreatorDetailIS(creatorId);
    });
});
/**
 * Extract phone number from bio text
 */
function extractPhoneFromBio(bio) {
    if (!bio) return '';
    
    // Pola nomor Indonesia
    const patterns = [
        /(\+?62[-\s]?8[1-9][0-9]{1,3}[-\s]?[0-9]{3,4}[-\s]?[0-9]{3,4})/i,  // +62 812-3456-7890
        /(08[1-9][0-9]{1,3}[-\s]?[0-9]{3,4}[-\s]?[0-9]{3,4})/i,             // 0812-3456-7890
        /(08[1-9][0-9]{8,11})/i,                                              // 081234567890
        /(\+62[0-9]{9,13})/i,                                                 // +6281234567890
    ];
    
    for (const pattern of patterns) {
        const match = bio.match(pattern);
        if (match) {
            // Bersihkan nomor
            let phone = match[1].replace(/[-\s]/g, '');
            return phone;
        }
    }
    
    return '';
}
// ========== SHOW CREATOR PERFORMANCE DETAIL ==========
async function showCreatorPerformanceDetail(creatorOpenId) {
    if (!creatorOpenId) {
        showToastGlobal('Creator Open ID tidak tersedia', 'error');
        return;
    }
    
    const modalTitle = document.getElementById('modalTitleDashboard');
    const modalBody = document.getElementById('modalBodyDashboard');
   
    modalTitle.innerHTML = '<i class="fas fa-chart-line"></i> Loading Performance...';
    modalBody.innerHTML = `
        <div style="text-align:center; padding:40px;">
            <i class="fas fa-spinner fa-pulse fa-2x" style="color:#8b5cf6;"></i>
            <p style="margin-top:12px; color:#e2f0e8;">Mengambil data performa creator...</p>
        </div>
    `;
    openModalIS();
    
    try {
        const response = await fetch(baseUrlIS + 'is/get_creator_performance_detail', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: new URLSearchParams({ creator_open_id: creatorOpenId })
        });
        
        const result = await response.json();
        
        if (!result.success) {
            modalBody.innerHTML = `
                <div style="text-align:center; padding:40px; color:#ef4444;">
                    <i class="fas fa-exclamation-triangle" style="font-size:48px; margin-bottom:16px; display:block;"></i>
                    <p style="font-size:14px;">${result.message || 'Gagal mengambil data performa'}</p>
                    <button onclick="closeModalIS()" style="margin-top:16px; background:#1e293b; color:#e2f0e8; border:1px solid #2a3346; padding:8px 20px; border-radius:8px; cursor:pointer;">Tutup</button>
                </div>
            `;
            return;
        }
        
        const c = result.data;
        
        // �9�7 Parse semua data dari API
        const nickname = c.nickname || c.username || 'Unknown';
        const username = c.username || '';
        const avatarUrl = c.avatar_url || '';
        const bio = c.bio || c.bio_description || '';
        const followerCount = c.follower_count || 0;
        const region = c.selection_region || '';
        
        // �9�7 AMBIL GMV DARI API (bukan GPM)
        
        // �9�7 AMBIL GMV DARI API (dalam USD) dan KONVERSI KE RUPIAH
        const gmvUsd = parseFloat(c.gmv || 0);
        // Kurs USD ke IDR (misal 1 USD = 16000 IDR)
        // Bisa disesuaikan dengan kurs realtime atau dari setting
        const exchangeRate = 16000;
        const gmvIdr = Math.round(gmvUsd * exchangeRate);
        const gmvFormatted = gmvUsd > 0 ? 'Rp ' + formatNumber(gmvIdr) : 'Rp 0';
        const gmvUsdFormatted = gmvUsd > 0 ? '$ ' + gmvUsd.toFixed(2) : '$ 0';
        
        // GMV Range (untuk tampilan alternatif)
        const gmvRange = c.gmv_range?.formatted_range || '';
        
        // Units Sold
        const unitsSold = c.units_sold || 0;
        
        // Content
        const liveCount = c.ec_live_count || 0;
        const videoCount = c.ec_video_count || 0;
        const avgLiveViews = c.avg_ec_live_view_count || 0;
        const avgVideoViews = c.avg_ec_video_play_count || 0;
        
        // Engagement
        const videoEngRate = parseFloat(c.ec_video_engagement_rate || 0) / 100;
        const liveEngRate = parseFloat(c.ec_live_engagement_rate || 0) / 100;
        const avgCommission = parseFloat(c.avg_commission_rate || 0) / 100;
        const postRate = c.post_rate || '0';
        const rating = c.rating || '0';
        const pps = c.pps || '0';
        
        // Live interaction
        const avgLiveLikes = c.avg_ec_live_like_count || 0;
        const avgLiveComments = c.avg_ec_live_comment_count || 0;
        const avgLiveShares = c.avg_ec_live_share_count || 0;
        
        // Promoted products
        const promotedProducts = c.promoted_product_num || 0;
        const brandCollab = c.brand_collaboration_count || 0;
        
        // Content distribution
        const contentDist = c.content_gmv_distribution || [];
        
        // Follower demographics
        const followerAge = c.follower_age || [];
        const followerGender = c.follower_gender || [];
        let contentIconsHtml = '';
        if (liveCount > 0) {
            contentIconsHtml += `<span style="display:inline-flex; align-items:center; gap:4px; background:rgba(139,92,246,0.15); padding:2px 8px; border-radius:20px; font-size:10px; color:#8b5cf6; margin-left:8px;">
                <i class="fas fa-play-circle"></i> LV
            </span>`;
        }
        if (videoCount > 0) {
             contentIconsHtml += `<span style="display:inline-flex; align-items:center; gap:4px; background:rgba(245,158,11,0.15); padding:2px 8px; border-radius:20px; font-size:10px; color:#f59e0b; margin-left:8px;">
                <i class="fas fa-video"></i> SV
            </span>`;
           
        }
       
      // �9�7 RENDER MODAL
        modalTitle.innerHTML = `<i class="fas fa-chart-line"></i> Performance: @${escapeHtml(username)}`;
        
        let html = '';
        
        // ========== HEADER dengan Icon SV/LV ==========
        html += `
        <div style="background:rgba(139,92,246,0.1); border-radius:14px; padding:14px; margin-bottom:16px; display:flex; gap:16px; align-items:center;">
            <div style="width:70px; height:70px; border-radius:50%; overflow:hidden; background:#1e293b; flex-shrink:0; display:flex; align-items:center; justify-content:center;">
                ${avatarUrl ? `<img src="${escapeHtml(avatarUrl)}" style="width:100%; height:100%; object-fit:cover;" onerror="this.style.display='none'; this.parentElement.innerHTML='<i class=\\'fas fa-user\\' style=\\'font-size:32px; color:#8b5cf6;\\'></i>'">` : '<i class="fas fa-user" style="font-size:32px; color:#8b5cf6;"></i>'}
            </div>
            <div>
                <div style="display:flex; align-items:center; flex-wrap:wrap; gap:4px;">
                    <div style="color:#e2f0e8; font-weight:600; font-size:16px;">${escapeHtml(nickname)}</div>
                    ${contentIconsHtml}
                </div>
                <div style="color:#8b5cf6; font-size:12px; margin-top:2px;">@${escapeHtml(username)}</div>
                <div style="color:#9aaebe; font-size:11px; margin-top:4px;">
                     ${escapeHtml(region || 'N/A')} |  ${formatNumberShort(followerCount)} followers
                </div>
                ${bio ? `<div style="color:#9aaebe; font-size:10px; margin-top:4px; max-height:40px; overflow:hidden;"> ${escapeHtml(bio.substring(0, 150))}</div>` : ''}
            </div>
        </div>`;
        
        // ========== GMV CARD (diganti dari GPM) ==========
        html += `
        <div style="background:rgba(74,222,128,0.1); border-radius:14px; padding:14px; margin-bottom:12px; text-align:center;">
            <div style="color:#9aaebe; font-size:11px; margin-bottom:4px;"> Est. GMV</div>
            <div style="color:#4ade80; font-size:28px; font-weight:700;">${gmvFormatted}</div>
            ${gmvRange ? `<div style="color:#9aaebe; font-size:10px; margin-top:4px;">Range: ${escapeHtml(gmvRange)}</div>` : ''}
        </div>`;
        
        // ========== CONTENT & ENGAGEMENT ==========
        html += `
        <div style="display:grid; grid-template-columns:1fr 1fr; gap:12px; margin-bottom:12px;">
            <!-- Content -->
            <div style="background:#0f1420; border-radius:14px; padding:14px;">
                <h4 style="color:#e2f0e8; margin:0 0 12px 0; font-size:14px;"> Content</h4>
                <div style="display:grid; gap:8px;">
                    <div style="display:flex; justify-content:space-between;"><span style="color:#9aaebe; font-size:12px;">Items Sold</span><span style="color:#fbbf24; font-size:12px; font-weight:600;">${formatNumberShort(unitsSold)}</span></div>
                    <div style="display:flex; justify-content:space-between;"><span style="color:#9aaebe; font-size:12px;">Live Count</span><span style="color:#f59e0b; font-size:12px; font-weight:600;">${liveCount}</span></div>
                    <div style="display:flex; justify-content:space-between;"><span style="color:#9aaebe; font-size:12px;">Video Count</span><span style="color:#ef4444; font-size:12px; font-weight:600;">${videoCount}</span></div>
                    <div style="display:flex; justify-content:space-between;"><span style="color:#9aaebe; font-size:12px;">Avg Live Views</span><span style="color:#e2f0e8; font-size:12px;">${formatNumberShort(avgLiveViews)}</span></div>
                    <div style="display:flex; justify-content:space-between;"><span style="color:#9aaebe; font-size:12px;">Avg Video Views</span><span style="color:#e2f0e8; font-size:12px;">${formatNumberShort(avgVideoViews)}</span></div>
                    <div style="display:flex; justify-content:space-between;"><span style="color:#9aaebe; font-size:12px;">Products Promoted</span><span style="color:#e2f0e8; font-size:12px;">${promotedProducts}</span></div>
                </div>
            </div>
            
            <!-- Engagement -->
            <div style="background:#0f1420; border-radius:14px; padding:14px;">
                <h4 style="color:#e2f0e8; margin:0 0 12px 0; font-size:14px;"> Engagement</h4>
                <div style="display:grid; gap:8px;">
                    <div style="display:flex; justify-content:space-between;"><span style="color:#9aaebe; font-size:12px;">Live Eng. Rate</span><span style="color:#4ade80; font-size:12px; font-weight:600;">${liveEngRate.toFixed(1)}%</span></div>
                    <div style="display:flex; justify-content:space-between;"><span style="color:#9aaebe; font-size:12px;">Video Eng. Rate</span><span style="color:#4ade80; font-size:12px; font-weight:600;">${videoEngRate.toFixed(1)}%</span></div>
                    <div style="display:flex; justify-content:space-between;"><span style="color:#9aaebe; font-size:12px;">Avg Commission</span><span style="color:#fbbf24; font-size:12px; font-weight:600;">${avgCommission.toFixed(1)}%</span></div>
                    <div style="display:flex; justify-content:space-between;"><span style="color:#9aaebe; font-size:12px;">Post Rate</span><span style="color:#e2f0e8; font-size:12px;">${postRate}%</span></div>
                    <div style="display:flex; justify-content:space-between;"><span style="color:#9aaebe; font-size:12px;">Rating / PPS</span><span style="color:#fbbf24; font-size:12px;"> ${rating} / ${pps}</span></div>
                </div>
            </div>
        </div>`;
        
        // ========== LIVE INTERACTION ==========
        if (avgLiveLikes > 0 || avgLiveComments > 0) {
            html += `
            <div style="background:#0f1420; border-radius:14px; padding:14px; margin-bottom:12px;">
                <h4 style="color:#e2f0e8; margin:0 0 12px 0; font-size:14px;"> Live Interaction (Avg)</h4>
                <div style="display:grid; grid-template-columns:repeat(3,1fr); gap:10px; text-align:center;">
                    <div style="background:#1e293b; border-radius:10px; padding:10px;">
                        <div style="color:#ef4444; font-size:16px; font-weight:700;">${formatNumberShort(avgLiveLikes)}</div>
                        <div style="color:#9aaebe; font-size:10px;"> Likes</div>
                    </div>
                    <div style="background:#1e293b; border-radius:10px; padding:10px;">
                        <div style="color:#4ade80; font-size:16px; font-weight:700;">${formatNumberShort(avgLiveComments)}</div>
                        <div style="color:#9aaebe; font-size:10px;"> Comments</div>
                    </div>
                    <div style="background:#1e293b; border-radius:10px; padding:10px;">
                        <div style="color:#f59e0b; font-size:16px; font-weight:700;">${formatNumberShort(avgLiveShares)}</div>
                        <div style="color:#9aaebe; font-size:10px;"> Shares</div>
                    </div>
                </div>
            </div>`;
        }
        
        // ========== BRAND COLLABORATION ==========
        html += `
        <div style="background:#0f1420; border-radius:14px; padding:14px; margin-bottom:12px;">
            <h4 style="color:#e2f0e8; margin:0 0 12px 0; font-size:14px;"> Brand Collaboration</h4>
            <div style="display:flex; gap:20px; justify-content:center;">
                <div style="text-align:center;">
                    <div style="color:#8b5cf6; font-size:24px; font-weight:700;">${brandCollab}</div>
                    <div style="color:#9aaebe; font-size:10px;">Brands</div>
                </div>
                <div style="text-align:center;">
                    <div style="color:#4ade80; font-size:24px; font-weight:700;">${promotedProducts}</div>
                    <div style="color:#9aaebe; font-size:10px;">Products</div>
                </div>
                <div style="text-align:center;">
                    <div style="color:#fbbf24; font-size:24px; font-weight:700;">${formatNumberShort(unitsSold)}</div>
                    <div style="color:#9aaebe; font-size:10px;">Units Sold</div>
                </div>
            </div>
        </div>`;
        
        // ========== GMV DISTRIBUTION ==========
        if (contentDist.length > 0) {
            html += `
            <div style="background:#0f1420; border-radius:14px; padding:14px; margin-bottom:12px;">
                <h4 style="color:#e2f0e8; margin:0 0 8px 0; font-size:14px;"> GMV Distribution</h4>
                <div style="display:flex; gap:8px; flex-wrap:wrap;">
                    ${contentDist.map(d => {
                        const pct = (parseFloat(d.value) * 100).toFixed(1);
                        const typeLabel = d.content_type === 'live_gmv' ? ' Live' : (d.content_type === 'video_gmv' ? ' Video' : ' Showcase');
                        const barColor = d.content_type === 'live_gmv' ? '#f59e0b' : (d.content_type === 'video_gmv' ? '#ef4444' : '#4ade80');
                        return `<div style="flex:1; min-width:100px; text-align:center;">
                            <div style="color:#9aaebe; font-size:10px;">${typeLabel}</div>
                            <div style="background:#1e293b; border-radius:6px; height:6px; margin:4px 0; overflow:hidden;">
                                <div style="background:${barColor}; height:100%; width:${pct}%;"></div>
                            </div>
                            <div style="color:#e2f0e8; font-size:12px; font-weight:600;">${pct}%</div>
                        </div>`;
                    }).join('')}
                </div>
            </div>`;
        }
        
        // ========== FOLLOWER DEMOGRAPHICS ==========
        if (followerAge.length > 0 || followerGender.length > 0) {
            html += `
            <div style="background:#0f1420; border-radius:14px; padding:14px; margin-bottom:12px;">
                <h4 style="color:#e2f0e8; margin:0 0 8px 0; font-size:14px;"> Follower Demographics</h4>`;
            
            if (followerAge.length > 0) {
                html += `<div style="margin-bottom:8px;">
                    <span style="color:#9aaebe; font-size:11px;"> Age: </span>
                    ${followerAge.map(a => `<span style="background:#1e293b; padding:2px 8px; border-radius:10px; font-size:10px; color:#e2f0e8;">${a.key}: ${(parseFloat(a.value)*100).toFixed(1)}%</span>`).join(' ')}
                </div>`;
            }
            
            if (followerGender.length > 0) {
                html += `<div>
                    <span style="color:#9aaebe; font-size:11px;"> Gender: </span>
                    ${followerGender.map(g => `<span style="background:#1e293b; padding:2px 8px; border-radius:10px; font-size:10px; color:#e2f0e8;">${g.key}: ${(parseFloat(g.value)*100).toFixed(1)}%</span>`).join(' ')}
                </div>`;
            }
            
            html += `</div>`;
        }
        
        // ========== BUTTONS ==========
        html += `
        <div class="flex-buttons" style="margin-top:16px; gap:12px;">
            <button id="selectFromPerfBtn" style="background:#4ade80; color:#0a0e17; flex:1; padding:12px; border:none; border-radius:12px; cursor:pointer; font-weight:600; font-size:13px;">
                <i class="fas fa-plus"></i> Pilih Creator Ini
            </button>
            <button id="backToSearchBtn" style="background:#1e293b; color:#e2f0e8; flex:1; padding:12px; border:1px solid #2a3346; border-radius:12px; cursor:pointer; font-size:13px;">
                <i class="fas fa-arrow-left"></i> Kembali ke Pencarian
            </button>
        </div>`;
        
        modalBody.innerHTML = html;
        
        // ========== EVENT LISTENERS ==========
        document.getElementById('selectFromPerfBtn')?.addEventListener('click', () => {
            const c = result.data;
            const bio = c.bio || c.bio_description || '';
            const extractedPhone = extractPhoneFromBio(bio);

            const creatorData = {
                username: username,
                nickname: nickname,
                avatar_url: avatarUrl,
                follower_count: followerCount,
                gmv: gmvValue,
                gmv_formatted: gmvFormatted,
                category: 'Lifestyle',
                avg_video_views: avgVideoViews,
                avg_live_uv: avgLiveViews,
                creator_open_id: creatorOpenId,
                phone: extractedPhone, 
                email: ''   
            };
            closeModalIS();
            showAddCreatorFromSearchForm(creatorData);
        });
        
        document.getElementById('backToSearchBtn')?.addEventListener('click', () => {
            closeModalIS();
            setTimeout(() => {
                showSearchCreatorModal();
                const searchInput = document.getElementById('searchCreatorKeyword');
                if (searchInput && searchKeyword) {
                    searchInput.value = searchKeyword;
                }
                if (searchResults.length > 0) {
                    const container = document.getElementById('searchResultsContainer');
                    if (container) {
                        renderSearchResults(searchResults);
                    }
                }
            }, 300);
        });
        
    } catch (error) {
        console.error('Error in showCreatorPerformanceDetail:', error);
        modalBody.innerHTML = `
            <div style="text-align:center; padding:40px; color:#ef4444;">
                <i class="fas fa-exclamation-triangle" style="font-size:48px; margin-bottom:16px; display:block;"></i>
                <p style="font-size:14px;">Error: ${error.message}</p>
                <button onclick="closeModalIS()" style="margin-top:16px; background:#1e293b; color:#e2f0e8; border:1px solid #2a3346; padding:8px 20px; border-radius:8px; cursor:pointer;">Tutup</button>
            </div>
        `;
    }
}


function renderSearchResults(results) {
    const container = document.getElementById('searchResultsContainer');
    if (!container) return;
    
    container.innerHTML = '';
    
    results.forEach(creator => {
        const followerFormatted = formatNumberShort(creator.follower_count);
       const gmvUsd = parseFloat(creator.gmv || 0);
const gmvIdr = Math.round(gmvUsd * 16000);
const gmvFormatted = gmvUsd > 0 
    ? `Rp ${formatNumber(gmvIdr)}`
    : (creator.gmv_formatted || 'Rp 0');
        const avatarHtml = creator.avatar_url && creator.avatar_url !== ''
            ? `<img src="${escapeHtml(creator.avatar_url)}" style="width:100%; height:100%; object-fit:cover;" onerror="this.onerror=null; this.parentElement.innerHTML='<i class=\\'fab fa-tiktok\\' style=\\'font-size:28px; color:#4ade80;\\'></i>'">` 
            : '<i class="fab fa-tiktok" style="font-size:28px; color:#4ade80;"></i>';
        
        const cardHtml = `
            <div class="search-result-item" style="background:#0f1420; border-radius:12px; padding:12px; margin-bottom:10px; border:1px solid #2a3346; transition:all 0.2s; cursor:pointer;" 
                 data-creator='${JSON.stringify(creator).replace(/'/g, "&#39;")}'
                 onmouseover="this.style.borderColor='#4ade80'" 
                 onmouseout="this.style.borderColor='#2a3346'">
                <div style="display:flex; gap:12px;">
                    <div style="width:60px; height:60px; border-radius:50%; overflow:hidden; background:#1e293b; flex-shrink:0; display:flex; align-items:center; justify-content:center;">
                        ${avatarHtml}
                    </div>
                    <div style="flex:1;">
                        <div style="display:flex; justify-content:space-between;">
                            <div>
                                <strong>${escapeHtml(creator.nickname || creator.username)}</strong>
                                <div style="color:#9aaebe; font-size:11px;">@${escapeHtml(creator.username)}</div>
                            </div>
                            <div style="text-align:right;">
                                <div style="color:#fbbf24;">${gmvFormatted}</div>
                                <div style="font-size:10px;">GMV 28 hari</div>
                            </div>
                        </div>
                        <div style="display:flex; gap:16px; margin-top:8px;">
                            <span><i class="fas fa-users"></i> ${followerFormatted}</span>
                            <span>${escapeHtml(creator.category || 'Lifestyle')}</span>
                        </div>
                    </div>
                    <div style="display:flex; flex-direction:column; gap:6px;">
                        <button class="select-creator-btn" style="background:#4ade80; color:#0a0e17; border:none; padding:6px 16px; border-radius:20px; cursor:pointer; font-size:11px;">
                            <i class="fas fa-plus"></i> Pilih
                        </button>
                        <button class="detail-creator-btn" data-creator-open-id="${escapeHtml(creator.creator_open_id || '')}" 
                                style="background:#1e293b; color:#8b5cf6; border:1px solid #8b5cf6; padding:6px 16px; border-radius:20px; cursor:pointer; font-size:11px;">
                            <i class="fas fa-info-circle"></i> Detail
                        </button>
                    </div>
                </div>
            </div>
        `;
        container.innerHTML += cardHtml;
    });
    
    // Re-attach event listeners
    document.querySelectorAll('.select-creator-btn').forEach(btn => {
        btn.addEventListener('click', (e) => {
            e.stopPropagation();
            const parent = btn.closest('.search-result-item');
            const creatorData = JSON.parse(parent.getAttribute('data-creator'));
            showAddCreatorFromSearchForm(creatorData);
        });
    });
    
    document.querySelectorAll('.detail-creator-btn').forEach(btn => {
        btn.addEventListener('click', (e) => {
            e.stopPropagation();
            const creatorOpenId = btn.getAttribute('data-creator-open-id');
            if (creatorOpenId) showCreatorPerformanceDetail(creatorOpenId);
        });
    });
}
// ========== TASK 2: LINK SWAPPING ==========
let selectedProductsIS = [];
let currentCreatorId = null;
let currentCreatorName = null;
let currentCreatorCategory = null;
let currentCreatorPhone = null;
let currentCampaignId = null;

// ========== TASK 2: LINK SWAPPING (REWRITE) ==========
async function loadTask2CreatorsIS() {
    const response = await fetch(baseUrlIS + 'is/get_creators_by_status', {
        method: 'POST', 
        body: new URLSearchParams({ status: 'ACTIVE' })
    });
    const result = await response.json();
    const container = document.getElementById('linkSwappingContainerDashboard');
    const countSpan = document.getElementById('linkCountDashboard');
    
    if (result.success && result.data.length > 0) {
        if (countSpan) countSpan.innerText = result.data.length;
        let html = '';
        result.data.forEach(creator => {
            const phoneDisplay = creator.phone 
                ? `<span style="color:#4ade80;"><i class="fab fa-whatsapp"></i> ${creator.phone}</span>` 
                : '<span style="color:#ef4444;"><i class="fab fa-whatsapp"></i> No WA</span>';
            
            html += `
            <div class="stage-item-dashboard link-item-dashboard" 
                 data-creator-id="${creator.id}" 
                 data-creator-name="${escapeHtml(creator.username)}"
                 data-creator-phone="${escapeHtml(creator.phone || '')}"
                 data-creator-category="${escapeHtml(creator.category || '')}">
                <div style="display:flex; justify-content:space-between; align-items:center;">
                    <strong><i class="fab fa-tiktok"></i> ${escapeHtml(creator.username)}</strong>
                    <div style="display:flex; gap:6px;">
                        ${!creator.phone ? `
                        <button class="update-phone-quick-btn" data-creator-id="${creator.id}" 
                            style="background:#fbbf24; color:#0a0e17; border:none; padding:2px 8px; border-radius:10px; cursor:pointer; font-size:9px;">
                            <i class="fas fa-edit"></i> WA
                        </button>` : ''}
                        <span class="badge-dashboard badge-active"><i class="fas fa-check-circle"></i> ACTIVE</span>
                    </div>
                </div>
                <div class="item-details-dashboard">
                    ${phoneDisplay}
                    <span><i class="fas fa-tag"></i> ${escapeHtml(creator.category || '-')}</span>
                </div>
                <div class="item-details-dashboard">
                    <i class="fas fa-link"></i> Siap diberikan link afiliasi
                    <span style="font-size:9px; color:#9aaebe;">Click untuk assign</span>
                </div>
            </div>`;
        });
        container.innerHTML = html;
        
        // Event: Update WA
        document.querySelectorAll('.update-phone-quick-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                e.stopPropagation();
                const cid = btn.getAttribute('data-creator-id');
                const cname = btn.closest('.link-item-dashboard')?.getAttribute('data-creator-name');
                showQuickEditPhoneModal(cid, cname, '');
            });
        });
        
        // Event: Buka Assign Modal
        document.querySelectorAll('.link-item-dashboard').forEach(item => {
            item.addEventListener('click', () => {
                const creatorId = item.getAttribute('data-creator-id');
                const creatorName = item.getAttribute('data-creator-name');
                const creatorCategory = item.getAttribute('data-creator-category') || '';
                const creatorPhone = item.getAttribute('data-creator-phone') || '';
                
                if (!creatorPhone || creatorPhone === '') {
                    showToastGlobal(`Creator @${creatorName} belum memiliki nomor WhatsApp!`, 'error');
                    return;
                }
                
                currentCreatorId = creatorId;
                currentCreatorName = creatorName;
                currentCreatorCategory = creatorCategory;
                currentCreatorPhone = creatorPhone;
                
                showLinkAssignmentModal(creatorId, creatorName, creatorCategory, creatorPhone);
            });
        });
    } else {
        if (countSpan) countSpan.innerText = '0';
        container.innerHTML = '<div class="stage-item-dashboard"><strong><i class="fas fa-info-circle"></i> Belum ada creator aktif</strong></div>';
    }
}

// ========== MODAL ASSIGN LINK ==========
async function showLinkAssignmentModal(creatorId, creatorName, creatorCategory, creatorPhone) {
    selectedProductsIS = [];
    currentCreatorId = creatorId;
    currentCreatorName = creatorName;
    currentCreatorCategory = creatorCategory;
    currentCreatorPhone = creatorPhone;
    currentCampaignId = null;
    
    document.getElementById('modalTitleDashboard').innerHTML = `<i class="fas fa-link"></i> Assign Link - @${escapeHtml(creatorName)}`;
    document.getElementById('modalBodyDashboard').innerHTML = `
        <div style="background:rgba(74,222,128,0.1); border-radius:14px; padding:12px; margin-bottom:16px;">
            <div style="display:grid; grid-template-columns:1fr 1fr; gap:8px;">
                <div>
                    <span style="color:#9aaebe; font-size:10px;">Creator</span><br>
                    <span style="color:#e2f0e8; font-size:13px; font-weight:600;">@${escapeHtml(creatorName)}</span>
                </div>
                <div>
                    <span style="color:#9aaebe; font-size:10px;">Kategori</span><br>
                    <span style="color:#e2f0e8; font-size:13px;">${escapeHtml(creatorCategory || 'Semua')}</span>
                </div>
                <div>
                    <span style="color:#9aaebe; font-size:10px;"><i class="fab fa-whatsapp"></i> WA</span><br>
                    <span style="color:#4ade80; font-size:13px;">${escapeHtml(creatorPhone)}</span>
                    <button id="editPhoneInModal" style="background:transparent; border:none; color:#fbbf24; cursor:pointer; font-size:9px; margin-left:4px;">
                        <i class="fas fa-edit"></i>
                    </button>
                </div>
                <div>
                    <span style="color:#9aaebe; font-size:10px;">Handler</span><br>
                    <span style="color:#8b5cf6; font-size:13px; font-weight:500;">
                        <i class="fas fa-user"></i> <?= $this->session->userdata('full_name') ?? 'IS User' ?>
                    </span>
                </div>
            </div>
        </div>
        
        <!-- STEP 1: Pilih Campaign -->
        <div id="step1Container">
            <label style="color:#e2f0e8; font-weight:500;"><i class="fas fa-bullhorn"></i> Pilih Campaign</label>
            <select id="campaignSelectIS" style="width:100%; padding:10px; background:#0f1420; border:1px solid #2a3346; border-radius:12px; color:#e2f0e8; margin-bottom:12px;">
                <option value="">-- Pilih Campaign --</option>
                <?php foreach ($campaigns as $camp): ?>
                <option value="<?= $camp->campaign_id ?>"><?= htmlspecialchars($camp->campaign_name) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        
        <!-- STEP 2: Pilih Produk -->
        <div id="step2Container" style="display:none;">
            <label style="color:#e2f0e8; font-weight:500;"><i class="fas fa-search"></i> Cari Produk</label>
            <input type="text" id="productSearchInput" placeholder="Ketik nama produk..." 
                style="width:100%; padding:10px; background:#0f1420; border:1px solid #2a3346; border-radius:12px; color:#e2f0e8; margin-bottom:12px;">
            
            <div id="campaignProductsList" style="max-height:300px; overflow-y:auto; background:#0f1420; border-radius:12px; padding:8px;">
                <div style="text-align:center; padding:20px; color:#9aaebe;">Pilih campaign terlebih dahulu</div>
            </div>
        </div>
        
        <!-- STEP 3: Review & Kirim -->
        <div id="step3Container" style="display:none; margin-top:12px;">
            <div style="background:#0f1420; border-radius:12px; padding:12px; margin-bottom:12px;">
                <div style="display:flex; justify-content:space-between; margin-bottom:8px;">
                    <span style="color:#9aaebe; font-size:11px;">Produk Dipilih</span>
                    <span id="selectedCount" style="color:#4ade80; font-size:11px; font-weight:600;">0</span>
                </div>
                <div id="selectedProductsPreview" style="max-height:150px; overflow-y:auto;"></div>
            </div>
            
            <!-- Tampilkan link yang akan diambil dari database -->
            <div id="linksPreviewContainer" style="background:rgba(74,222,128,0.1); border-radius:12px; padding:10px; margin-bottom:12px; display:none;">
                <p style="color:#4ade80; font-size:11px; margin-bottom:8px;">
                    <i class="fas fa-database"></i> Link dari Database (BD Affiliate Links):
                </p>
                <div id="linksPreviewList" style="max-height:200px; overflow-y:auto;"></div>
            </div>
            
            <div style="background:rgba(74,222,128,0.1); border-radius:12px; padding:10px; margin-bottom:12px;">
                <p style="color:#4ade80; font-size:11px;">
                    <i class="fas fa-info-circle"></i> Link akan dikirim via WhatsApp ke: <b>${creatorPhone}</b>
                </p>
                <p style="color:#9aaebe; font-size:10px;">
                    <i class="fas fa-user"></i> Handler: <b><?= $this->session->userdata('full_name') ?? 'IS User' ?></b>
                </p>
            </div>
            
            <button id="confirmAndSendBtn" style="width:100%; background:#25D366; color:white; border:none; padding:12px; border-radius:12px; cursor:pointer; font-weight:600; font-size:13px;">
                <i class="fab fa-whatsapp"></i> Konfirmasi & Kirim WA
            </button>
        </div>
        
        <div class="flex-buttons" style="margin-top:12px;">
            <button id="cancelLinkBtn" style="background:#1e293b; flex:1;">Batal</button>
        </div>
    `;
    openModalIS();
    
    // STEP 1 �� STEP 2
    document.getElementById('campaignSelectIS').addEventListener('change', async (e) => {
        currentCampaignId = e.target.value;
        if (!currentCampaignId) {
            document.getElementById('step2Container').style.display = 'none';
            document.getElementById('step3Container').style.display = 'none';
            return;
        }
        document.getElementById('step2Container').style.display = 'block';
        document.getElementById('step3Container').style.display = 'none';
        selectedProductsIS = [];
        await loadProductsForLink(currentCampaignId, currentCreatorCategory);
    });
    
    // Search produk
    document.getElementById('productSearchInput').addEventListener('keyup', (e) => {
        const search = e.target.value.toLowerCase();
        document.querySelectorAll('#campaignProductsList .product-item-card').forEach(item => {
            const name = item.getAttribute('data-product-name')?.toLowerCase() || '';
            item.style.display = name.includes(search) ? '' : 'none';
        });
    });
    
    // Edit phone
    document.getElementById('editPhoneInModal')?.addEventListener('click', () => {
        showQuickEditPhoneModal(creatorId, creatorName, creatorPhone);
    });
    
    // CONFIRM & SEND
    document.getElementById('confirmAndSendBtn')?.addEventListener('click', async () => {
        if (selectedProductsIS.length === 0) {
            showToastGlobal('Pilih minimal 1 produk', 'error');
            return;
        }
        
        const btn = document.getElementById('confirmAndSendBtn');
        btn.disabled = true;
        btn.innerHTML = '<i class="fas fa-spinner fa-pulse"></i> Mengirim...';
        
        // Simpan link
        const saveRes = await fetch(baseUrlIS + 'is/send_affiliate_links_bulk', {
            method: 'POST',
            body: new URLSearchParams({
                creator_id: creatorId,
                campaign_id: currentCampaignId,
                products: JSON.stringify(selectedProductsIS)
            })
        });
        const saveData = await saveRes.json();
        
        // Kirim WhatsApp
        if (saveData.success && saveData.generated.length > 0 && currentCreatorPhone) {
            const campaignName = document.getElementById('campaignSelectIS')?.selectedOptions[0]?.text || 'Campaign';
            let message = `Halo @${currentCreatorName}! �9�9\n\n`;
            message += `Link afiliasi untuk campaign *${campaignName}*:\n\n`;
            
            saveData.generated.forEach((p, i) => {
                message += `${i+1}. *${p.product_name}*\n`;
                message += `   Komisi: ${p.commission_rate}%\n`;
                message += `   Link: ${p.link}\n\n`;
            });
            
            message += `\n�7�8 Selamat berpromosi! �0�4\n\n`;
            message += `Dikirim oleh: ${saveData.generated[0]?.created_by || 'Toopai Team'}`;
            
            let phone = currentCreatorPhone.replace(/[^0-9+]/g, '');
            if (phone.startsWith('0')) phone = '62' + phone.substring(1);
            else if (phone.startsWith('+')) phone = phone.substring(1);
            
            window.open(`https://wa.me/${phone}?text=${encodeURIComponent(message)}`, '_blank');
        }
        
        let statusMsg = saveData.message || 'Link berhasil dikirim!';
        if (saveData.failed && saveData.failed.length > 0) {
            statusMsg += ` �7�2�1�5 Link untuk: ${saveData.failed.join(', ')} belum tersedia.`;
        }
        showToastGlobal(statusMsg, saveData.failed.length > 0 ? 'warning' : 'success');
        setTimeout(() => { closeModalIS(); location.reload(); }, 2000);
    });
    
    document.getElementById('cancelLinkBtn').addEventListener('click', closeModalIS);
}


// ========== LOAD PRODUCTS FOR LINK ==========
async function loadProductsForLink(campaignId, creatorCategory) {
    const container = document.getElementById('campaignProductsList');
    container.innerHTML = '<div style="text-align:center; padding:20px;"><i class="fas fa-spinner fa-pulse"></i> Loading...</div>';
    
    try {
        // Ambil produk dari campaign via API (untuk daftar produk yang tersedia)
        const response = await fetch(baseUrlIS + 'is/get_campaign_products', {
            method: 'POST',
            body: new URLSearchParams({ campaign_id: campaignId, creator_category: creatorCategory || '' })
        });
        const data = await response.json();
        
        if (data.success && data.products) {
            let html = '';
            
            for (const product of data.products) {
                // �9�7 CEK APAKAH LINK SUDAH ADA DI bd_affiliate_links
                const linkCheck = await fetch(baseUrlIS + 'is/get_bd_affiliate_link', {
                    method: 'POST',
                    body: new URLSearchParams({
                        product_id: product.product_id,
                        campaign_id: campaignId
                    })
                });
                const linkData = await linkCheck.json();
                const hasLink = linkData.has_link;
                const bdLink = linkData.link || '';
                const bdCommission = linkData.commission_rate || (product.commission_rate / 100) + 2;
                
                const isSelected = selectedProductsIS.some(p => p.product_id === product.product_id);
                const productImage = product.image_url || '';
                const hasImage = productImage && productImage !== '';
                
                html += `
                <div class="product-item-card" data-product-id="${product.product_id}" 
                     data-product-name="${escapeHtml(product.product_name || '')}"
                     style="display:flex; justify-content:space-between; align-items:center; padding:10px; border-bottom:1px solid #2a3346; background:${isSelected ? '#0a2e1a' : '#0f1420'}; border-radius:8px; margin-bottom:6px;">
                    <div style="display:flex; gap:10px; flex:1;">
                        <div style="width:50px; height:50px; background:#1e293b; border-radius:8px; display:flex; align-items:center; justify-content:center; overflow:hidden; flex-shrink:0;">
                            ${hasImage ? `<img src="${escapeHtml(productImage)}" style="width:100%; height:100%; object-fit:cover;" onerror="this.src=''; this.onerror=null; this.parentElement.innerHTML='<i class=\\'fas fa-box\\' style=\\'color:#4ade80;\\'></i>'">` : '<i class="fas fa-box" style="color:#4ade80;"></i>'}
                        </div>
                        <div style="flex:1;">
                            <div style="color:#e2f0e8; font-size:12px;">${escapeHtml((product.product_name || '').substring(0, 60))}</div>
                            <div style="display:flex; gap:8px; margin-top:4px; flex-wrap:wrap;">
                                <span style="color:#4ade80; font-size:10px;">Rp ${formatNumber(product.price)}</span>
                                <span style="color:#fbbf24; font-size:10px;">Open Plan: ${product.commission_rate / 100}%</span>
                                ${hasLink ? `<span style="color:#4ade80; font-size:10px;"><i class="fas fa-check-circle"></i> Link tersedia (${bdCommission}%)</span>` : `<span style="color:#ef4444; font-size:10px;"><i class="fas fa-times-circle"></i> Link belum tersedia</span>`}
                            </div>
                            ${product.shop_name ? `<div style="color:#9aaebe; font-size:9px; margin-top:2px;"><i class="fas fa-store"></i> ${escapeHtml(product.shop_name)}</div>` : ''}
                            ${hasLink ? `<div style="color:#8b5cf6; font-size:9px; margin-top:2px; word-break:break-all;"><i class="fas fa-link"></i> ${escapeHtml(bdLink.substring(0, 50))}...</div>` : ''}
                        </div>
                    </div>
                    <div>
                        ${hasLink ? `
                        <button class="copy-link-quick-btn" data-link="${escapeHtml(bdLink)}" 
                                style="background:#1e293b; color:#4ade80; border:1px solid #4ade80; padding:4px 10px; border-radius:20px; cursor:pointer; font-size:10px; margin-right:6px;">
                            <i class="fas fa-copy"></i> Copy
                        </button>
                        ` : ''}
                        <button class="toggle-product-btn" data-product='${JSON.stringify({
                            product_id: product.product_id,
                            product_name: product.product_name,
                            commission_rate: bdCommission,
                            affiliate_link: bdLink,
                            has_link: hasLink
                        })}'
                        style="background:${isSelected ? '#ef4444' : (hasLink ? '#4ade80' : '#1e293b')}; color:white; border:none; padding:6px 12px; border-radius:20px; cursor:pointer; font-size:10px;">
                            ${isSelected ? '�7�9 Hapus' : (hasLink ? '+ Pilih' : 'Link Tidak Tersedia')}
                        </button>
                    </div>
                </div>`;
            }
            
            container.innerHTML = html || '<div style="text-align:center; padding:20px; color:#9aaebe;">Tidak ada produk</div>';
            
            // Toggle product
            document.querySelectorAll('.toggle-product-btn').forEach(btn => {
                btn.addEventListener('click', () => {
                    const productData = JSON.parse(btn.getAttribute('data-product'));
                    if (!productData.has_link) {
                        showToastGlobal(`Link untuk "${productData.product_name}" belum tersedia. Silakan minta BA/BD generate link.`, 'warning');
                        return;
                    }
                    
                    const idx = selectedProductsIS.findIndex(p => p.product_id === productData.product_id);
                    
                    if (idx !== -1) {
                        selectedProductsIS.splice(idx, 1);
                    } else {
                        selectedProductsIS.push({
                            product_id: productData.product_id,
                            product_name: productData.product_name,
                            commission_rate: productData.commission_rate,
                            affiliate_link: productData.affiliate_link
                        });
                    }
                    updateSelectedPreview();
                    loadProductsForLink(campaignId, creatorCategory);
                });
            });
            
            // Copy link button
            document.querySelectorAll('.copy-link-quick-btn').forEach(btn => {
                btn.addEventListener('click', (e) => {
                    e.stopPropagation();
                    const link = btn.getAttribute('data-link');
                    navigator.clipboard.writeText(link);
                    showToastGlobal('Link copied!', 'success');
                });
            });
        }
    } catch (error) {
        container.innerHTML = '<div style="text-align:center; padding:20px; color:#ef4444;">Error loading products</div>';
    }
}

function updateSelectedPreview() {
    const countSpan = document.getElementById('selectedCount');
    const preview = document.getElementById('selectedProductsPreview');
    const step3 = document.getElementById('step3Container');
    const linksPreviewContainer = document.getElementById('linksPreviewContainer');
    const linksPreviewList = document.getElementById('linksPreviewList');
    
    if (countSpan) countSpan.innerText = selectedProductsIS.length;
    if (step3) step3.style.display = selectedProductsIS.length > 0 ? 'block' : 'none';
    
    // Preview produk yang dipilih
    if (preview) {
        preview.innerHTML = selectedProductsIS.map((p, i) => `
            <div style="display:flex; justify-content:space-between; align-items:center; padding:6px 0; border-bottom:1px solid #2a3346; font-size:10px;">
                <span style="color:#e2f0e8;">${i+1}. ${escapeHtml(p.product_name || '').substring(0, 40)}</span>
                <div>
                    <span style="color:#fbbf24;">${p.commission_rate}%</span>
                    <button class="copy-single-link-btn" data-link="${escapeHtml(p.affiliate_link)}" data-product="${escapeHtml(p.product_name)}"
                            style="background:#1e293b; color:#4ade80; border:1px solid #4ade80; padding:2px 8px; border-radius:12px; cursor:pointer; font-size:9px; margin-left:8px;">
                        <i class="fas fa-copy"></i> Copy Link
                    </button>
                </div>
            </div>
        `).join('');
        
        // Event copy single link
        document.querySelectorAll('.copy-single-link-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                e.stopPropagation();
                const link = btn.getAttribute('data-link');
                const product = btn.getAttribute('data-product');
                navigator.clipboard.writeText(link);
                showToastGlobal(`Link untuk "${product}" dicopy!`, 'success');
            });
        });
    }
    
    // Tampilkan semua link yang akan dikirim
    if (linksPreviewList && selectedProductsIS.length > 0) {
        linksPreviewContainer.style.display = 'block';
        linksPreviewList.innerHTML = selectedProductsIS.map((p, i) => `
            <div style="display:flex; justify-content:space-between; align-items:center; padding:6px; border-bottom:1px solid #2a3346;">
                <div style="flex:1;">
                    <span style="color:#e2f0e8; font-size:11px;">${i+1}. ${escapeHtml(p.product_name)}</span>
                    <div style="color:#9aaebe; font-size:9px; word-break:break-all;">${escapeHtml(p.affiliate_link)}</div>
                </div>
                <button class="copy-link-preview-btn" data-link="${escapeHtml(p.affiliate_link)}" 
                        style="background:#1e293b; color:#4ade80; border:1px solid #4ade80; padding:4px 10px; border-radius:20px; cursor:pointer; font-size:9px; margin-left:8px;">
                    <i class="fas fa-copy"></i> Copy
                </button>
            </div>
        `).join('');
        
        document.querySelectorAll('.copy-link-preview-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                e.stopPropagation();
                const link = btn.getAttribute('data-link');
                navigator.clipboard.writeText(link);
                showToastGlobal('Link dicopy!', 'success');
            });
        });
    } else if (linksPreviewContainer) {
        linksPreviewContainer.style.display = 'none';
    }
}

async function showCampaignSelectionModalIS(creatorId, creatorName, creatorCategory, creatorPhone) {
    currentCreatorId = creatorId;
    currentCreatorName = creatorName;
    currentCreatorCategory = creatorCategory;
    currentCreatorPhone = creatorPhone;
    selectedProductsIS = [];
    
    document.getElementById('modalTitleDashboard').innerHTML = `<i class="fas fa-bullhorn"></i> Assign Campaign - ${creatorName}`;
    document.getElementById('modalBodyDashboard').innerHTML = `
        <div style="background:rgba(74,222,128,0.1); border-radius:14px; padding:12px; margin-bottom:16px;">
            <p style="color:#4ade80;"><i class="fas fa-info-circle"></i> Kategori Creator: ${creatorCategory || 'Semua'}</p>
            <p style="color:#4ade80;"><i class="fab fa-whatsapp"></i> WhatsApp: ${creatorPhone}</p>
            <p style="color:#9aaebe; font-size:11px;">Pilih campaign, pilih produk, atur komisi, lalu generate link</p>
        </div>
        
        <div id="step1Container">
            <label>Pilih Campaign</label>
            <select id="campaignSelectIS" style="width:100%; padding:10px; background:#0f1420; border:1px solid #2a3346; border-radius:12px; color:#e2f0e8;">
                <option value="">-- Pilih Campaign --</option>
                <?php foreach ($campaigns as $camp): ?>
                <option value="<?= $camp->campaign_id ?>"><?= htmlspecialchars($camp->campaign_name) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        
        <div id="step2Container" style="display:none; margin-top:16px;">
            <label><i class="fas fa-box"></i> Pilih Produk</label>
            <div id="campaignProductsList" style="max-height:300px; overflow-y:auto; background:#0f1420; border-radius:12px; padding:8px;">
                <div class="loading">Pilih campaign terlebih dahulu...</div>
            </div>
        </div>
        
        <div id="step3Container" style="display:none; margin-top:16px;">
            <label><i class="fas fa-sliders-h"></i> Atur Komisi & Generate Link</label>
            <div id="selectedProductsWithCommission" style="background:#0f1420; border-radius:12px; padding:8px; max-height:350px; overflow-y:auto;"></div>
        </div>
        
        <div id="step4Container" style="display:none; margin-top:16px;">
            <div style="background:rgba(74,222,128,0.1); border-radius:12px; padding:12px; margin-bottom:12px;">
                <p style="color:#4ade80; font-size:12px;"><i class="fas fa-check-circle"></i> 
                    <span id="generatedCount">0</span> dari <span id="totalProductsCount">0</span> link telah digenerate
                </p>
                <p style="color:#25D366; font-size:11px; margin-top:8px;">
                    <i class="fab fa-whatsapp"></i> Akan dikirim ke: ${creatorPhone}
                </p>
            </div>
            <div class="flex-buttons">
                <button id="saveAndSendWABtn" style="background:#25D366; color:white;"><i class="fab fa-whatsapp"></i> Save & Kirim WA</button>
                <button id="backToEditBtn" style="background:#1e293b;">Kembali Edit</button>
            </div>
        </div>
        
        <div class="flex-buttons" style="margin-top:16px;">
            <button id="cancelStepBtnIS" style="background:#1e293b;">Batal</button>
        </div>
    `;
    openModalIS();
    
    const campaignSelect = document.getElementById('campaignSelectIS');
    const step2Container = document.getElementById('step2Container');
    const step3Container = document.getElementById('step3Container');
    const step4Container = document.getElementById('step4Container');
    
    campaignSelect.addEventListener('change', async () => {
        currentCampaignId = campaignSelect.value;
        if (!currentCampaignId) {
            step2Container.style.display = 'none';
            step3Container.style.display = 'none';
            step4Container.style.display = 'none';
            return;
        }
        
        step2Container.style.display = 'block';
        step3Container.style.display = 'none';
        step4Container.style.display = 'none';
        selectedProductsIS = [];
        
        await loadAvailableProducts(currentCampaignId, currentCreatorCategory);
    });
    
    document.getElementById('backToEditBtn')?.addEventListener('click', () => {
        step3Container.style.display = 'block';
        step4Container.style.display = 'none';
    });
    
    document.getElementById('saveAndSendWABtn')?.addEventListener('click', async () => {
        const notGenerated = selectedProductsIS.filter(p => p.status !== 'generated');
        if (notGenerated.length > 0) {
            showToastGlobal(`Generate link terlebih dahulu untuk: ${notGenerated.map(p => p.product_name).join(', ')}`, 'error');
            return;
        }
        
        let phone = currentCreatorPhone || '';
        if (!phone || phone === '') {
            showToastGlobal('Creator tidak memiliki nomor WhatsApp!', 'error');
            return;
        }
        
        const saveBtn = document.getElementById('saveAndSendWABtn');
        saveBtn.disabled = true;
        saveBtn.innerHTML = '<i class="fas fa-spinner fa-pulse"></i> Menyimpan & Mengirim WA...';
        
        await fetch(baseUrlIS + 'is/update_creator_status', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: new URLSearchParams({ creator_id: currentCreatorId, status: 'LINK_SENT' })
        });
        
        const campaignName = campaignSelect.options[campaignSelect.selectedIndex]?.text || 'Campaign';
        
        let message = `Halo @${currentCreatorName}! �9�9\n\n`;
        message += `Terima kasih telah bergabung dengan Toopai. Berikut adalah link afiliasi untuk campaign yang sudah kita sepakati:\n\n`;
        message += `�9�0 *Campaign:* ${campaignName}\n\n`;
        message += `*�9�3 Link Afiliasi:*\n`;
        
        selectedProductsIS.forEach((product, idx) => {
            message += `${idx + 1}. *${product.product_name}* (Komisi: ${product.custom_commission}%)\n`;
            message += `   ${product.generated_link}\n\n`;
        });
        
        message += `\n�7�8 *Tips Sukses:*\n`;
        message += `�6�1 Promosikan produk dengan konten yang menarik\n`;
        message += `�6�1 Gunakan hashtag yang relevan\n`;
        message += `�6�1 Pantau performa link di dashboard Anda\n\n`;
        message += `Semangat berpromosi! �0�4\n\nBest regards,\nToopai Team �9�0`;
        
        phone = phone.replace(/[^0-9+]/g, '');
        if (phone.startsWith('0')) phone = '62' + phone.substring(1);
        else if (phone.startsWith('+')) phone = phone.substring(1);
        
        const whatsappUrl = `https://wa.me/${phone}?text=${encodeURIComponent(message)}`;
        window.open(whatsappUrl, '_blank');
        
        showToastGlobal('Link berhasil disimpan! WhatsApp akan terbuka.', 'success');
        
        saveBtn.disabled = false;
        saveBtn.innerHTML = '<i class="fab fa-whatsapp"></i> Save & Kirim WA';
        
        setTimeout(() => {
            closeModalIS();
            location.reload();
        }, 3000);
    });
    
    document.getElementById('cancelStepBtnIS').addEventListener('click', closeModalIS);
}

async function loadAvailableProducts(campaignId, creatorCategory) {
    const container = document.getElementById('campaignProductsList');
    if (!container) return;
    
    container.innerHTML = '<div class="loading"><i class="fas fa-spinner fa-pulse"></i> Loading products...</div>';
    
    try {
        const response = await fetch(baseUrlIS + 'is/get_campaign_products', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: new URLSearchParams({ 
                campaign_id: campaignId,
                creator_category: creatorCategory || ''
            })
        });
        const data = await response.json();
        
        console.log('API Response:', data);
        
        if (data.success && data.products && data.products.length > 0) {
            let html = '';
            data.products.forEach(product => {
                const isSelected = selectedProductsIS.some(p => p.product_id === product.product_id);
                const recommendedCommission = (product.commission_rate / 100) + 2;
                const productImage = product.image_url || '';
                const hasImage = productImage && productImage !== '';
                
                html += `
                    <div class="product-item-dashboard" data-product-id="${product.product_id}" style="display:flex; justify-content:space-between; align-items:center; padding:12px; border-bottom:1px solid #2a3346; background:#0f1420; margin-bottom:8px; border-radius:12px; transition:all 0.2s;">
                        <div style="width:60px; height:60px; background:#1e293b; border-radius:10px; display:flex; align-items:center; justify-content:center; overflow:hidden; flex-shrink:0;">
                            ${hasImage ? `<img src="${escapeHtml(productImage)}" alt="${escapeHtml(product.product_name)}" style="width:100%; height:100%; object-fit:cover;" onerror="this.src=''; this.onerror=null; this.parentElement.innerHTML='<i class=\\'fas fa-box fa-2x\\' style=\\'color:#4ade80;\\'></i>'">` : '<i class="fas fa-box fa-2x" style="color:#4ade80;"></i>'}
                        </div>
                        <div style="flex:1; margin-left:12px;">
                            <div style="color:#e2f0e8; font-size:13px; font-weight:500; margin-bottom:4px;">${escapeHtml(product.product_name || 'No Name')}</div>
                            <div style="display:flex; gap:16px; flex-wrap:wrap; margin-bottom:4px;">
                                <span style="color:#4ade80; font-size:12px;"> Rp ${formatNumber(product.price)}</span>
                                <span style="color:#fbbf24; font-size:11px;"> Open Plan: ${product.commission_rate / 100}%</span>
                                <span style="color:#9aaebe; font-size:10px;"> Rekomendasi: ${recommendedCommission}% (+2%)</span>
                            </div>
                            ${product.shop_name ? `<div style="color:#9aaebe; font-size:10px;"><i class="fas fa-store"></i> Shop: ${escapeHtml(product.shop_name)}</div>` : ''}
                        </div>
                        <button class="select-product-btn" 
                                data-product='${JSON.stringify({
                                    product_id: product.product_id,
                                    product_name: product.product_name,
                                    product_image: productImage,
                                    open_commission: product.commission_rate,
                                    recommended_commission: recommendedCommission
                                })}'
                                style="background:${isSelected ? '#4ade80' : '#1e293b'}; border:none; color:white; padding:8px 16px; border-radius:20px; cursor:pointer; font-size:12px; font-weight:500; transition:all 0.2s;">
                            ${isSelected ? '�7�7 Terpilih' : '+ Pilih'}
                        </button>
                    </div>
                `;
            });
            container.innerHTML = html;
            
            document.querySelectorAll('.select-product-btn').forEach(btn => {
                btn.addEventListener('click', () => {
                    const productData = JSON.parse(btn.getAttribute('data-product'));
                    const existingIndex = selectedProductsIS.findIndex(p => p.product_id === productData.product_id);
                    
                    if (existingIndex !== -1) {
                        selectedProductsIS.splice(existingIndex, 1);
                        btn.innerHTML = '+ Pilih';
                        btn.style.background = '#1e293b';
                        showToastGlobal(`Produk "${productData.product_name}" dihapus`, 'info');
                    } else {
                        selectedProductsIS.push({
                            product_id: productData.product_id,
                            product_name: productData.product_name,
                            product_image: productData.product_image,
                            open_commission: productData.open_commission,
                            custom_commission: productData.recommended_commission,
                            status: 'pending',
                            generated_link: null
                        });
                        btn.innerHTML = '�7�7 Terpilih';
                        btn.style.background = '#4ade80';
                        showToastGlobal(`Produk "${productData.product_name}" ditambahkan`, 'success');
                    }
                    renderSelectedProductsWithCommission();
                });
            });
        } else {
            container.innerHTML = `<div style="text-align:center; padding:40px; color:#9aaebe;">
                <i class="fas fa-box-open" style="font-size:48px; margin-bottom:16px; display:block;"></i>
                <p>Tidak ada produk yang tersedia untuk campaign ini.</p>
                <small style="font-size:11px;">Coba pilih campaign lain atau tunggu produk ditambahkan.</small>
            </div>`;
        }
    } catch (error) {
        console.error('Error:', error);
        container.innerHTML = `<div style="text-align:center; padding:40px; color:#ef4444;">
            <i class="fas fa-exclamation-triangle" style="font-size:48px; margin-bottom:16px; display:block;"></i>
            <p>Error loading products: ${error.message}</p>
            <button class="btn-retry" onclick="loadAvailableProducts('${campaignId}', '${creatorCategory}')" style="margin-top:12px;">Coba Lagi</button>
        </div>`;
    }
}

function renderSelectedProductsWithCommission() {
    const container = document.getElementById('selectedProductsWithCommission');
    const step3Container = document.getElementById('step3Container');
    const step4Container = document.getElementById('step4Container');
    
    if (selectedProductsIS.length === 0) {
        if (step3Container) step3Container.style.display = 'none';
        if (step4Container) step4Container.style.display = 'none';
        return;
    }
    
    if (step3Container) step3Container.style.display = 'block';
    if (step4Container) step4Container.style.display = 'none';
    
    let html = '';
    selectedProductsIS.forEach((product, idx) => {
        const recommended = (product.open_commission / 100) + 2;
        const isGenerated = product.status === 'generated';
        const hasLinkFromBD = product.has_bd_link === true;
        let borderColor = '#2a3346';
        if (isGenerated) borderColor = '#4ade80';
        else if (hasLinkFromBD) borderColor = '#fbbf24';
        
        html += `
            <div class="selected-product-item" style="background:#0f1420; border-radius:10px; padding:12px; margin-bottom:10px; border:1px solid ${borderColor};">
                <div style="display:flex; justify-content:space-between; align-items:flex-start;">
                    <div style="flex:1;">
                        <div style="color:#e2f0e8; font-size:13px; font-weight:500;">${escapeHtml(product.product_name)}</div>
                        <div style="color:#fbbf24; font-size:11px; margin-top:4px;">Open Plan: ${product.open_commission / 100}%</div>
                        <div style="color:#9aaebe; font-size:10px;"> Rekomendasi: ${recommended}% (+2%)</div>
                        ${hasLinkFromBD && !isGenerated ? `<div style="color:#fbbf24; font-size:10px; margin-top:4px;"><i class="fas fa-database"></i> Link tersedia dari BD, klik "Ambil Link"</div>` : ''}
                    </div>
                    <button class="remove-product-btn" data-idx="${idx}" style="background:transparent; border:none; color:#ef4444; cursor:pointer; font-size:16px;">
                        <i class="fas fa-trash-alt"></i>
                    </button>
                </div>
                <div style="margin-top:10px;">
                    <label style="color:#9aaebe; font-size:11px;">Set Komisi Manual (%):</label>
                    <input type="number" class="commission-input" data-idx="${idx}" value="${product.custom_commission || recommended}" 
                           step="0.5" min="1" max="50" ${isGenerated ? 'disabled' : ''}
                           style="width:100%; margin-top:5px; padding:8px; background:#1e293b; border:1px solid ${borderColor}; border-radius:8px; color:#e2f0e8;">
                    <div class="commission-status" id="commissionStatus-${idx}" style="font-size:10px; margin-top:4px; color:${isGenerated ? '#4ade80' : (hasLinkFromBD ? '#fbbf24' : '#fbbf24')};">
                        ${isGenerated ? '�7�3 Link sudah digenerate' : (hasLinkFromBD ? '�9�4 Link tersedia dari BD, klik "Ambil Link"' : '�7�3 Belum digenerate')}
                    </div>
                </div>
                ${!isGenerated ? `
                <button class="generate-link-btn" data-idx="${idx}" style="width:100%; margin-top:10px; background:${hasLinkFromBD ? '#fbbf24' : '#4ade80'}; border:none; color:#0a0e17; padding:8px; border-radius:20px; cursor:pointer; font-weight:600; font-size:12px;">
                    <i class="fas fa-${hasLinkFromBD ? 'download' : 'link'}"></i> ${hasLinkFromBD ? 'Ambil Link dari BD' : 'Generate Link'}
                </button>
                ` : `
                <div style="margin-top:10px; background:#0a0e1a; padding:10px; border-radius:8px;">
                    <div style="font-size:11px; color:#4ade80; word-break:break-all;">
                        <strong>Link Afiliasi:</strong><br>
                        ${product.generated_link}
                    </div>
                    <button class="copy-link-btn" data-link="${product.generated_link}" style="margin-top:8px; background:#1e293b; border:none; color:#4ade80; padding:4px 12px; border-radius:12px; cursor:pointer; font-size:10px;">
                        <i class="fas fa-copy"></i> Copy Link
                    </button>
                </div>
                `}
            </div>
        `;
    });
    container.innerHTML = html;
    
    document.querySelectorAll('.remove-product-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            const idx = parseInt(btn.getAttribute('data-idx'));
            selectedProductsIS.splice(idx, 1);
            renderSelectedProductsWithCommission();
            if (currentCampaignId) {
                loadAvailableProducts(currentCampaignId, currentCreatorCategory);
            }
            updateStep4Visibility();
        });
    });
    
    document.querySelectorAll('.commission-input').forEach(input => {
        input.addEventListener('change', (e) => {
            const idx = parseInt(input.getAttribute('data-idx'));
            const newCommission = parseFloat(input.value);
            if (!isNaN(newCommission) && newCommission > 0) {
                selectedProductsIS[idx].custom_commission = newCommission;
                selectedProductsIS[idx].status = 'pending';
                selectedProductsIS[idx].generated_link = null;
                const statusDiv = document.getElementById(`commissionStatus-${idx}`);
                if (statusDiv) {
                    statusDiv.innerHTML = '�7�3 Komisi diubah, klik Generate/Ambil Link';
                    statusDiv.style.color = '#fbbf24';
                }
                renderSelectedProductsWithCommission();
            }
        });
    });
    
    document.querySelectorAll('.generate-link-btn').forEach(btn => {
        btn.addEventListener('click', async () => {
            const idx = parseInt(btn.getAttribute('data-idx'));
            const product = selectedProductsIS[idx];
            const commission = product.custom_commission;
            const statusDiv = document.getElementById(`commissionStatus-${idx}`);
            const genBtn = btn;
            
            if (!commission || commission <= 0) {
                showToastGlobal('Masukkan komisi terlebih dahulu', 'error');
                return;
            }
            
            genBtn.disabled = true;
            genBtn.innerHTML = '<i class="fas fa-spinner fa-pulse"></i> Checking...';
            if (statusDiv) {
                statusDiv.innerHTML = '�7�7 Mengecek ketersediaan link...';
                statusDiv.style.color = '#4ade80';
            }
            
            try {
                const checkResponse = await fetch(baseUrlIS + 'is/get_bd_affiliate_link', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                    body: new URLSearchParams({
                        product_id: product.product_id,
                        campaign_id: currentCampaignId
                    })
                });
                const checkData = await checkResponse.json();
                
                if (checkData.has_link) {
                    product.generated_link = checkData.link;
                    product.commission_rate = checkData.commission_rate;
                    product.status = 'generated';
                    product.has_bd_link = true;
                    
                    if (statusDiv) {
                        statusDiv.innerHTML = '�7�3 Link berhasil diambil dari BD!';
                        statusDiv.style.color = '#4ade80';
                    }
                    showToastGlobal(`Link untuk ${product.product_name} berhasil diambil dari BD!`, 'success');
                    
                    await fetch(baseUrlIS + 'is/save_bd_affiliate_link', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                        body: new URLSearchParams({
                            creator_id: currentCreatorId,
                            campaign_id: currentCampaignId,
                            product_id: product.product_id,
                            product_name: product.product_name,
                            affiliate_link: checkData.link,
                            commission_rate: checkData.commission_rate
                        })
                    });
                    
                    renderSelectedProductsWithCommission();
                    updateStep4Visibility();
                } else {
                    const canGenerate = await checkCanGenerateLink();
                    
                    if (canGenerate) {
                        if (statusDiv) statusDiv.innerHTML = '�7�7 Generating link...';
                        
                        const generateResponse = await fetch(baseUrlIS + 'is/generate_creator_affiliate_link', {
                            method: 'POST',
                            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                            body: new URLSearchParams({
                                creator_id: currentCreatorId,
                                campaign_id: currentCampaignId,
                                product_id: product.product_id,
                                product_name: product.product_name,
                                commission_rate: commission
                            })
                        });
                        const generateData = await generateResponse.json();
                        
                        if (generateData.success) {
                            product.generated_link = generateData.link;
                            product.status = 'generated';
                            if (statusDiv) {
                                statusDiv.innerHTML = '�7�3 Link berhasil digenerate!';
                                statusDiv.style.color = '#4ade80';
                            }
                            showToastGlobal(`Link untuk ${product.product_name} berhasil digenerate!`, 'success');
                            renderSelectedProductsWithCommission();
                            updateStep4Visibility();
                        } else {
                            if (statusDiv) {
                                statusDiv.innerHTML = `�7�4 Gagal: ${generateData.message}`;
                                statusDiv.style.color = '#ef4444';
                            }
                            showToastGlobal(generateData.message, 'error');
                            genBtn.disabled = false;
                            genBtn.innerHTML = '<i class="fas fa-link"></i> Generate Link';
                        }
                    } else {
                        if (statusDiv) {
                            statusDiv.innerHTML = '�7�4 Link belum tersedia. Silakan minta BD generate link terlebih dahulu.';
                            statusDiv.style.color = '#ef4444';
                        }
                        showToastGlobal(`Link untuk ${product.product_name} belum tersedia. Silakan minta BD generate link.`, 'error');
                        genBtn.disabled = false;
                        genBtn.innerHTML = '<i class="fas fa-link"></i> Generate Link (Butuh BD)';
                    }
                }
            } catch (error) {
                console.error('Error:', error);
                if (statusDiv) {
                    statusDiv.innerHTML = `�7�4 Error: ${error.message}`;
                    statusDiv.style.color = '#ef4444';
                }
                showToastGlobal('Network error', 'error');
                genBtn.disabled = false;
                genBtn.innerHTML = '<i class="fas fa-link"></i> Generate Link';
            }
        });
    });
    
    document.querySelectorAll('.copy-link-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            const link = btn.getAttribute('data-link');
            navigator.clipboard.writeText(link);
            showToastGlobal('Link copied!', 'success');
        });
    });
}

function updateStep4Visibility() {
    const step4Container = document.getElementById('step4Container');
    const generatedCountSpan = document.getElementById('generatedCount');
    const totalCountSpan = document.getElementById('totalProductsCount');
    
    if (!step4Container) return;
    
    const generatedCount = selectedProductsIS.filter(p => p.status === 'generated').length;
    const totalCount = selectedProductsIS.length;
    
    if (generatedCountSpan) generatedCountSpan.innerText = generatedCount;
    if (totalCountSpan) totalCountSpan.innerText = totalCount;
    
    if (totalCount > 0 && generatedCount === totalCount) {
        step4Container.style.display = 'block';
    } else {
        step4Container.style.display = 'none';
    }
}

async function checkCanGenerateLink() {
    const response = await fetch(baseUrlIS + 'is/can_generate_link');
    const data = await response.json();
    return data.can_generate;
}

async function showProductModalIS(creatorId, creatorName, campaignId, campaignName) {
    const canGenerate = await checkCanGenerateLink();
    
    document.getElementById('modalTitleDashboard').innerHTML = `<i class="fas fa-box"></i> Tambah Produk - ${creatorName}`;
    document.getElementById('modalBodyDashboard').innerHTML = `
        <div style="background:rgba(74,222,128,0.1); border-radius:14px; padding:12px; margin-bottom:16px;">
            <p style="color:#4ade80;"><i class="fas fa-bullhorn"></i> Campaign: ${escapeHtml(campaignName)}</p>
            ${!canGenerate ? '<p style="color:#fbbf24; font-size:11px; margin-top:6px;"><i class="fas fa-info-circle"></i> �7�2�1�5 Link afiliasi akan diambil dari database (digenerate oleh BA/BD). Jika link belum tersedia, silakan minta BA/BD generate link terlebih dahulu.</p>' : ''}
            <p style="color:#9aaebe; font-size:11px; margin-top:6px;"><i class="fab fa-whatsapp"></i> Nomor WhatsApp Creator: ${currentCreatorPhone || '-'}</p>
        </div>
        
        <label>Daftar Produk yang Dipilih</label>
        <div id="productsListIS" style="max-height:200px; overflow-y:auto; background:#0f1420; border-radius:12px; padding:8px; margin-bottom:12px;">
            <div class="loading">Belum ada produk dipilih</div>
        </div>
        
        <div class="add-product-btn" id="addProductBtnIS" style="text-align:center; padding:10px; background:#1e293b; border:1px dashed #4ade80; border-radius:12px; color:#4ade80; cursor:pointer;">
            <i class="fas fa-plus"></i> Tambah Produk
        </div>
        
        <label style="margin-top:16px;">Pesan WhatsApp untuk Creator</label>
        <textarea id="whatsappMessageIS" rows="4" style="width:100%; padding:10px; background:#0f1420; border:1px solid #2a3346; border-radius:12px; color:#e2f0e8; font-size:12px;">Halo! Terima kasih telah bergabung dengan Toopai. Berikut adalah link afiliasi untuk produk yang dapat Anda promosikan. Selamat bekerja sama! �0�4</textarea>
        
        <div class="flex-buttons" style="margin-top:16px;">
            <button id="generateAndSendBtnIS" style="background:#4ade80; color:#0a0e17; padding:12px;"><i class="fas fa-link"></i> ${canGenerate ? 'Generate Link & Kirim WA' : 'Ambil Link & Kirim WA'}</button>
            <button id="backToCampaignBtnIS" style="background:#1e293b; color:#cbd5e6; padding:12px;">Kembali</button>
        </div>
    `;
    openModalIS();
    
    renderProductsListIS();
    
    document.getElementById('addProductBtnIS').addEventListener('click', () => {
        showAddProductModalIS(creatorId, creatorName, campaignId, campaignName);
    });
    
    document.getElementById('generateAndSendBtnIS').addEventListener('click', async () => {
        if (selectedProductsIS.length === 0) { 
            showToastGlobal('Tambah minimal 1 produk', 'error'); 
            return; 
        }
        
        const btn = document.getElementById('generateAndSendBtnIS');
        btn.disabled = true;
        btn.innerHTML = '<i class="fas fa-spinner fa-pulse"></i> Processing...';
        
        const response = await fetch(baseUrlIS + 'is/send_affiliate_links_bulk', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: new URLSearchParams({
                creator_id: creatorId,
                campaign_id: campaignId,
                products: JSON.stringify(selectedProductsIS)
            })
        });
        
        const result = await response.json();
        
        if (result.success && result.generated.length > 0) {
            const message = document.getElementById('whatsappMessageIS').value;
            let phone = currentCreatorPhone || '';
            
            if (phone) {
                let linksText = '';
                result.generated.forEach(l => {
                    if (l.source === 'BD') {
                        linksText += `�9�4 *${l.product_name}* (Link dari ${l.created_by || 'BD'} - Komisi: ${l.commission_rate}%)\n   ${l.link}\n\n`;
                    } else {
                        linksText += `�9�3 *${l.product_name}* (Komisi: ${l.commission_rate}%)\n   ${l.link}\n\n`;
                    }
                });
                
                phone = phone.replace(/[^0-9+]/g, '');
                if (phone.startsWith('0')) phone = '62' + phone.substring(1);
                else if (phone.startsWith('+')) phone = phone.substring(1);
                
                const whatsappUrl = `https://wa.me/${phone}?text=${encodeURIComponent(message + '\n\n' + linksText)}`;
                window.open(whatsappUrl, '_blank');
            }
            
            if (!result.can_generate) {
                showToastGlobal(result.generated.length + ' link berhasil diambil dari BD! ' + (result.failed.length > 0 ? result.failed.length + ' produk gagal karena link belum tersedia.' : ''), result.failed.length > 0 ? 'warning' : 'success');
            } else {
                showToastGlobal(result.generated.length + ' link berhasil digenerate!', 'success');
            }
            
            closeModalIS();
            setTimeout(() => location.reload(), 2000);
        } else if (result.failed && result.failed.length > 0) {
            showToastGlobal('Link untuk produk berikut tidak tersedia: ' + result.failed.join(', ') + '. Silakan minta BA/BD generate link terlebih dahulu.', 'error');
            btn.disabled = false;
            btn.innerHTML = '<i class="fas fa-link"></i> Proses Link';
        } else {
            showToastGlobal(result.message || 'Gagal memproses link', 'error');
            btn.disabled = false;
            btn.innerHTML = '<i class="fas fa-link"></i> Proses Link';
        }
    });
    
    document.getElementById('backToCampaignBtnIS').addEventListener('click', () => {
        showCampaignSelectionModalIS(creatorId, creatorName, currentCreatorCategory, currentCreatorPhone);
    });
}

function renderProductsListIS() {
    const container = document.getElementById('productsListIS');
    if (!container) return;
    
    if (selectedProductsIS.length === 0) {
        container.innerHTML = '<div style="text-align:center; padding:20px; color:#9aaebe;">Belum ada produk dipilih. Klik "Tambah Produk" untuk memilih produk.</div>';
        return;
    }
    
    let html = '';
    selectedProductsIS.forEach((product, idx) => {
        html += `
            <div style="display:flex; justify-content:space-between; align-items:center; padding:10px; background:#0f1420; border-radius:8px; margin-bottom:8px; border:1px solid #2a3346;">
                <div style="flex:1;">
                    <div style="color:#e2f0e8; font-size:13px; font-weight:500;">${escapeHtml(product.product_name)}</div>
                    <div style="color:#fbbf24; font-size:11px;">Komisi: ${product.custom_commission || product.commission_rate || 10}%</div>
                </div>
                <button class="remove-product-item" data-idx="${idx}" style="background:transparent; border:none; color:#ef4444; cursor:pointer; font-size:16px;">
                    <i class="fas fa-trash-alt"></i>
                </button>
            </div>
        `;
    });
    container.innerHTML = html;
    
    document.querySelectorAll('.remove-product-item').forEach(btn => {
        btn.addEventListener('click', () => {
            const idx = parseInt(btn.getAttribute('data-idx'));
            selectedProductsIS.splice(idx, 1);
            renderProductsListIS();
            renderSelectedProductsWithCommission();
        });
    });
}

function showAddProductModalIS(creatorId, creatorName, campaignId, campaignName) {
    document.getElementById('modalTitleDashboard').innerHTML = `<i class="fas fa-plus"></i> Tambah Produk - ${creatorName}`;
    document.getElementById('modalBodyDashboard').innerHTML = `
        <div style="background:rgba(74,222,128,0.1); border-radius:14px; padding:12px; margin-bottom:16px;">
            <p style="color:#4ade80;"><i class="fas fa-info-circle"></i> Pilih produk dari campaign: ${escapeHtml(campaignName)}</p>
            <p style="color:#9aaebe; font-size:11px;">Pilih produk, komisi akan otomatis +2% dari open plan</p>
        </div>
        
        <label>Pilih Produk</label>
        <div id="addProductList" style="max-height:300px; overflow-y:auto; background:#0f1420; border-radius:12px; padding:8px;">
            <div class="loading"><i class="fas fa-spinner fa-pulse"></i> Loading products...</div>
        </div>
        
        <div class="flex-buttons" style="margin-top:16px;">
            <button id="backToProductBtnIS" style="background:#1e293b;">Kembali</button>
        </div>
    `;
    openModalIS();
    
    loadAvailableProductsForAdd(campaignId, creatorName, campaignName);
    
    document.getElementById('backToProductBtnIS').addEventListener('click', () => {
        showProductModalIS(creatorId, creatorName, campaignId, campaignName);
    });
}

async function loadAvailableProductsForAdd(campaignId, creatorName, campaignName) {
    const container = document.getElementById('addProductList');
    container.innerHTML = '<div class="loading"><i class="fas fa-spinner fa-pulse"></i> Loading products...</div>';
    
    try {
        const response = await fetch(baseUrlIS + 'is/get_campaign_products', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: new URLSearchParams({ 
                campaign_id: campaignId,
                creator_category: currentCreatorCategory || ''
            })
        });
        const data = await response.json();
        
        if (data.success && data.products && data.products.length > 0) {
            let html = '';
            data.products.forEach(product => {
                const isAlreadySelected = selectedProductsIS.some(p => p.product_id === product.product_id);
                if (isAlreadySelected) return;
                
                const recommendedCommission = (product.commission_rate / 100) + 2;
                
                html += `
                    <div style="display:flex; justify-content:space-between; align-items:center; padding:12px; border-bottom:1px solid #2a3346; background:#0f1420; margin-bottom:5px; border-radius:8px;">
                        <div style="flex:1;">
                            <div style="color:#e2f0e8; font-size:13px; font-weight:500;">${escapeHtml(product.product_name || 'No Name')}</div>
                            <div style="color:#4ade80; font-size:12px;">Rp ${formatNumber(product.price)}</div>
                            <div style="color:#fbbf24; font-size:11px;">Open Plan: ${product.commission_rate / 100}%</div>
                            <div style="color:#9aaebe; font-size:10px;">Rekomendasi: ${recommendedCommission}% (+2%)</div>
                        </div>
                        <button class="add-this-product-btn" 
                                data-product-id="${product.product_id}"
                                data-product-name="${escapeHtml(product.product_name)}"
                                data-open-commission="${product.commission_rate}"
                                data-recommended-commission="${recommendedCommission}"
                                style="background:#4ade80; border:none; color:#0a0e17; padding:6px 14px; border-radius:20px; cursor:pointer; font-size:11px; font-weight:500;">
                            + Tambah
                        </button>
                    </div>
                `;
            });
            container.innerHTML = html;
            
            document.querySelectorAll('.add-this-product-btn').forEach(btn => {
                btn.addEventListener('click', () => {
                    const productId = btn.getAttribute('data-product-id');
                    const productName = btn.getAttribute('data-product-name');
                    const openCommission = parseFloat(btn.getAttribute('data-open-commission'));
                    const recommendedCommission = parseFloat(btn.getAttribute('data-recommended-commission'));
                    
                    selectedProductsIS.push({
                        product_id: productId,
                        product_name: productName,
                        open_commission: openCommission,
                        custom_commission: recommendedCommission,
                        commission_rate: recommendedCommission,
                        status: 'pending',
                        generated_link: null
                    });
                    
                    showToastGlobal(`Produk "${productName}" ditambahkan!`, 'success');
                    showProductModalIS(creatorId, creatorName, campaignId, campaignName);
                });
            });
        } else {
            container.innerHTML = '<div style="text-align:center; padding:30px; color:#9aaebe;">Tidak ada produk yang tersedia untuk campaign ini.</div>';
        }
    } catch (error) {
        console.error('Error:', error);
        container.innerHTML = '<div style="text-align:center; padding:30px; color:#ef4444;">Error loading products</div>';
    }
}


// ========== TASK 3: LOAD CREATORS ==========
async function loadTask3CreatorsIS() {
    const response = await fetch(baseUrlIS + 'is/get_creators_by_status', {
        method: 'POST', 
        body: new URLSearchParams({ status: 'LINK_SENT' })
    });
    const result = await response.json();
    const container = document.getElementById('sendingSampleContainerDashboard');
    const countSpan = document.getElementById('sampleCountDashboard');
    
    if (result.success && result.data.length > 0) {
        const filteredCreators = result.data.filter(c => !c.auto_activated_at);
        
        if (countSpan) countSpan.innerText = filteredCreators.length;
        let html = '';
        filteredCreators.forEach(creator => {
            const hasPhone = creator.phone && creator.phone !== '' && creator.phone !== '-';
            const phoneDisplay = hasPhone 
                ? `<span style="color:#4ade80;"><i class="fab fa-whatsapp"></i> ${creator.phone}</span>` 
                : `<span style="color:#ef4444;"><i class="fab fa-whatsapp"></i> No WA</span>`;
            
            html += `
            <div class="stage-item-dashboard sample-item-dashboard" 
                 data-creator-id="${creator.id}" 
                 data-creator-name="${escapeHtml(creator.username)}"
                 data-creator-phone="${escapeHtml(creator.phone || '')}"
                 data-creator-category="${escapeHtml(creator.category || '')}">
                <div style="display:flex; justify-content:space-between; align-items:center;">
                    <strong><i class="fab fa-tiktok"></i> ${escapeHtml(creator.username)}</strong>
                    <span class="badge-dashboard badge-pending"><i class="fas fa-clock"></i> LINK_SENT</span>
                </div>
                <div class="item-details-dashboard">
                    ${phoneDisplay}
                    ${!hasPhone ? `
                    <button class="edit-wa-task3-btn" data-creator-id="${creator.id}" data-creator-name="${escapeHtml(creator.username)}"
                        style="background:#fbbf24; color:#0a0e17; border:none; padding:2px 8px; border-radius:10px; cursor:pointer; font-size:9px; margin-left:8px;">
                        <i class="fas fa-edit"></i> Tambah WA
                    </button>` : ''}
                    <span><i class="fas fa-tag"></i> ${escapeHtml(creator.category || '-')}</span>
                </div>
                <div class="item-details-dashboard"><i class="fas fa-box"></i> Menunggu konfirmasi sample</div>
            </div>`;
        });
        container.innerHTML = html || '<div class="stage-item-dashboard">Semua creator sudah naik ke monitoring</div>';
        
        // �9�7 Event: Edit WA di Task 3
        document.querySelectorAll('.edit-wa-task3-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                e.stopPropagation();
                const cid = btn.getAttribute('data-creator-id');
                const cname = btn.getAttribute('data-creator-name');
                showQuickEditPhoneModal(cid, cname, '');
            });
        });
        
        // Event: Buka Sample Modal
        document.querySelectorAll('.sample-item-dashboard').forEach(item => {
            item.addEventListener('click', () => {
                const creatorId = item.getAttribute('data-creator-id');
                const creatorName = item.getAttribute('data-creator-name');
                const creatorPhone = item.getAttribute('data-creator-phone');
                const creatorCategory = item.getAttribute('data-creator-category');
                showSampleRequestModalIS(creatorId, creatorName, creatorCategory, creatorPhone);
            });
        });
    } else {
        if (countSpan) countSpan.innerText = '0';
        container.innerHTML = '<div class="stage-item-dashboard"><strong><i class="fas fa-info-circle"></i> Belum ada creator di tahap pengiriman sample</strong></div>';
    }
}

// ========== TASK 3: SHOW SAMPLE REQUEST MODAL (REWRITE) ==========
async function showSampleRequestModalIS(creatorId, creatorName, creatorCategory, creatorPhone) {
    currentSampleCreatorId = creatorId;
    currentSampleCreatorName = creatorName;
    currentSampleCreatorCategory = creatorCategory;
    currentSampleCreatorPhone = creatorPhone;
    currentSelectedProducts = [];
    
    const modalTitle = document.getElementById('modalTitleDashboard');
    const modalBody = document.getElementById('modalBodyDashboard');
    
    modalTitle.innerHTML = `<i class="fas fa-box"></i> Kirim Sample - @${escapeHtml(creatorName)}`;
    modalBody.innerHTML = `
        <div style="background:rgba(74,222,128,0.1); border-radius:14px; padding:12px; margin-bottom:16px;">
            <div style="display:grid; grid-template-columns:1fr 1fr; gap:8px;">
                <div>
                    <span style="color:#9aaebe; font-size:10px;">Creator</span><br>
                    <span style="color:#e2f0e8; font-size:14px; font-weight:600;">@${escapeHtml(creatorName)}</span>
                </div>
                <div>
                    <span style="color:#9aaebe; font-size:10px;">Kategori</span><br>
                    <span style="color:#e2f0e8; font-size:13px;">${escapeHtml(creatorCategory || 'Semua')}</span>
                </div>
                <div>
                    <span style="color:#9aaebe; font-size:10px;"><i class="fab fa-whatsapp"></i> WhatsApp</span><br>
                    <span style="color:${creatorPhone ? '#4ade80' : '#ef4444'}; font-size:13px;">${escapeHtml(creatorPhone || 'Tidak ada')}</span>
                </div>
                <div>
                    <span style="color:#9aaebe; font-size:10px;">Status</span><br>
                    <span class="badge-dashboard badge-pending">LINK_SENT</span>
                </div>
            </div>
        </div>
        
        <!-- Pilihan Kirim Sample -->
        <div style="background:#0f1420; border-radius:14px; padding:14px; margin-bottom:16px;">
            <h4 style="color:#e2f0e8; margin:0 0 12px 0; font-size:13px;">
                <i class="fas fa-question-circle"></i> Apakah akan mengirim sample?
            </h4>
            <div style="display:flex; gap:16px;">
                <label style="display:flex; align-items:center; gap:8px; cursor:pointer;">
                    <input type="radio" name="send_sample" value="yes" checked style="width:18px; height:18px; accent-color:#4ade80;">
                    <span style="color:#e2f0e8;">Ya, Kirim Sample</span>
                </label>
                <label style="display:flex; align-items:center; gap:8px; cursor:pointer;">
                    <input type="radio" name="send_sample" value="no" style="width:18px; height:18px; accent-color:#ef4444;">
                    <span style="color:#e2f0e8;">Tidak, Langsung ke Monitoring</span>
                </label>
            </div>
            <p style="color:#9aaebe; font-size:10px; margin-top:8px;">
                <i class="fas fa-info-circle"></i> Jika pilih "Tidak", creator akan langsung pindah ke Task 4 (Monitoring)
            </p>
        </div>
        
        <!-- Container untuk Metode Request (ditampilkan jika pilih Ya) -->
        <div id="sampleMethodContainer" style="background:#0f1420; border-radius:14px; padding:14px; margin-bottom:16px;">
            <h4 style="color:#e2f0e8; margin:0 0 12px 0; font-size:13px;">
                <i class="fas fa-cog"></i> Metode Request Sample
            </h4>
            <select id="requestMethod" style="width:100%; padding:12px; background:#0f1420; border:1px solid #2a3346; border-radius:12px; color:#e2f0e8;">
                <option value="system_tiktok"> 
system tiktok (creator request by tiktok)</option>
                <option value="manual"> manual (CA input di gsheet brand)</option>
            </select>
            
            <!-- Field untuk Manual -->
            <div id="manualFields" style="display:none; margin-top:12px;">
                <label style="color:#9aaebe; font-size:11px; margin-bottom:5px; display:block;">
                    <i class="fas fa-map-marker-alt"></i> Alamat Pengiriman Sample
                </label>
                <textarea id="shippingAddress" rows="3" style="width:100%; padding:10px; background:#0f1420; border:1px solid #2a3346; border-radius:12px; color:#e2f0e8; font-size:12px;" 
                    placeholder="Nama penerima: ${escapeHtml(creatorName)}\nAlamat lengkap...\nKode Pos..."></textarea>
                
                <label style="color:#9aaebe; font-size:11px; margin-top:10px; margin-bottom:5px; display:block;">
                    <i class="fas fa-truck"></i> Pilih Kurir
                </label>
                <select id="courierSelect" style="width:100%; padding:10px; background:#0f1420; border:1px solid #2a3346; border-radius:12px; color:#e2f0e8;">
                    <option value="JNE"> JNE</option>
                    <option value="J&T"> J&T Express</option>
                    <option value="SiCepat"> SiCepat</option>
                    <option value="Pos Indonesia"> Pos Indonesia</option>
                    <option value="Grab Express"> Grab Express</option>
                    <option value="GoSend"> GoSend</option>
                </select>
            </div>
        </div>
        
        <!-- List Produk untuk Sample -->
        <div id="productsSampleList" style="background:#0f1420; border-radius:14px; padding:14px; margin-bottom:16px;">
            <h4 style="color:#e2f0e8; margin:0 0 12px 0; font-size:13px;">
                <i class="fas fa-box"></i> Pilih Produk untuk Sample
            </h4>
            <div id="sampleProductsContainer" style="max-height:250px; overflow-y:auto;">
                <div style="text-align:center; padding:20px;">
                    <i class="fas fa-spinner fa-pulse"></i> Loading produk...
                </div>
            </div>
        </div>
        
        <!-- Buttons -->
        <div class="flex-buttons" style="margin-top:16px; gap:12px;">
            <button id="confirmSampleBtn" style="background:#4ade80; color:#0a0e17; flex:1; padding:12px; border:none; border-radius:12px; cursor:pointer; font-weight:600;">
                <i class="fas fa-paper-plane"></i> Konfirmasi
            </button>
            <button id="cancelSampleBtn" style="background:#1e293b; color:#e2f0e8; flex:1; padding:12px; border:1px solid #2a3346; border-radius:12px; cursor:pointer;">
                Batal
            </button>
        </div>
    `;
    openModalIS();
    
    // �9�7 EVENT: Toggle metode request
    const requestMethod = document.getElementById('requestMethod');
    const manualFields = document.getElementById('manualFields');
    
    requestMethod?.addEventListener('change', (e) => {
        manualFields.style.display = e.target.value === 'manual' ? 'block' : 'none';
    });
    
    // �9�7 EVENT: Pilihan Ya/Tidak
    const radioYes = document.querySelector('input[value="yes"]');
    const radioNo = document.querySelector('input[value="no"]');
    const methodContainer = document.getElementById('sampleMethodContainer');
    const productsContainer = document.getElementById('productsSampleList');
    
    radioYes?.addEventListener('change', () => {
        methodContainer.style.display = 'block';
        productsContainer.style.display = 'block';
    });
    
    radioNo?.addEventListener('change', () => {
        methodContainer.style.display = 'none';
        productsContainer.style.display = 'none';
    });
    
    // �9�7 LOAD PRODUK
    await loadProductsForSample(creatorId, creatorCategory);
    
    // �9�7 BUTTON CANCEL
    document.getElementById('cancelSampleBtn')?.addEventListener('click', closeModalIS);
    
    // �9�7 BUTTON CONFIRM
    document.getElementById('confirmSampleBtn')?.addEventListener('click', async () => {
        const sendSample = document.querySelector('input[name="send_sample"]:checked')?.value;
        const selectedProducts = document.querySelectorAll('.sample-product-checkbox:checked');
        
        if (sendSample === 'yes') {
            if (selectedProducts.length === 0) {
                showToastGlobal('Pilih minimal 1 produk untuk sample', 'error');
                return;
            }
            
            const method = document.getElementById('requestMethod')?.value;
            const shippingAddress = document.getElementById('shippingAddress')?.value || '';
            const courier = document.getElementById('courierSelect')?.value || 'JNE';
            
            if (method === 'manual' && !shippingAddress) {
                showToastGlobal('Masukkan alamat pengiriman untuk metode manual', 'error');
                return;
            }
            
            const btn = document.getElementById('confirmSampleBtn');
            btn.disabled = true;
            btn.innerHTML = '<i class="fas fa-spinner fa-pulse"></i> Memproses...';
            
            // Proses request sample
            let successCount = 0;
            for (const cb of selectedProducts) {
                const productId = cb.getAttribute('data-product-id');
                const productName = cb.getAttribute('data-product-name');
                
                const response = await fetch(baseUrlIS + 'is/request_sample_from_seller', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                    body: new URLSearchParams({
                        creator_id: creatorId,
                        campaign_id: cb.getAttribute('data-campaign-id') || '',
                        product_id: productId,
                        quantity: 1,
                        shipping_address: shippingAddress,
                        courier: courier
                    })
                });
                const result = await response.json();
                if (result.success) successCount++;
            }
            
            if (successCount > 0) {
                showToastGlobal(`${successCount} sample request berhasil dikirim!`, 'success');
            } else {
                showToastGlobal('Gagal mengirim request sample', 'error');
                btn.disabled = false;
                btn.innerHTML = '<i class="fas fa-paper-plane"></i> Konfirmasi';
                return;
            }
        }
        
        // Update status creator ke SAMPLE_SENT atau langsung ACTIVE (monitoring)
        const newStatus = sendSample === 'yes' ? 'SAMPLE_SENT' : 'ACTIVE';
        await fetch(baseUrlIS + 'is/update_creator_status', {
            method: 'POST',
            body: new URLSearchParams({ creator_id: creatorId, status: newStatus })
        });
        
        showToastGlobal(`�7�3 Creator @${creatorName} ${sendSample === 'yes' ? 'dikirim sample' : 'langsung ke monitoring'}!`, 'success');
        setTimeout(() => { closeModalIS(); location.reload(); }, 2000);
    });
}

// �9�7 LOAD PRODUK UNTUK SAMPLE
async function loadProductsForSample(creatorId, creatorCategory) {
    const container = document.getElementById('sampleProductsContainer');
    if (!container) return;
    
    container.innerHTML = '<div style="text-align:center; padding:20px;"><i class="fas fa-spinner fa-pulse"></i> Loading produk...</div>';
    
    try {
        // Ambil affiliate links creator
        const linksRes = await fetch(baseUrlIS + 'is/get_creator_affiliate_links', {
            method: 'POST',
            body: new URLSearchParams({ creator_id: creatorId })
        });
        const linksResult = await linksRes.json();
        const links = linksResult.links || [];
        
        if (links.length === 0) {
            container.innerHTML = `
                <div style="text-align:center; padding:20px; color:#ef4444;">
                    <i class="fas fa-exclamation-triangle"></i>
                    <p>Belum ada link afiliasi untuk creator ini</p>
                    <p style="font-size:10px;">Silakan assign campaign terlebih dahulu di Task 2</p>
                </div>
            `;
            return;
        }
        
        let html = '';
        links.forEach(link => {
            const productName = link.product_name || `Product ID: ${link.product_id}`;
            html += `
                <label style="display:flex; align-items:center; gap:12px; padding:12px; background:#0f1420; border-radius:12px; margin-bottom:8px; cursor:pointer; border:1px solid #2a3346; transition:all 0.2s;"
                       onmouseover="this.style.borderColor='#4ade80'"
                       onmouseout="this.style.borderColor='#2a3346'">
                    <input type="checkbox" class="sample-product-checkbox" 
                           data-product-id="${link.product_id}"
                           data-product-name="${escapeHtml(productName)}"
                           data-campaign-id="${link.campaign_id}"
                           style="width:18px; height:18px; cursor:pointer; accent-color:#4ade80;">
                    <div style="flex:1;">
                        <div style="color:#e2f0e8; font-size:13px; font-weight:500;">
                            <i class="fas fa-box" style="color:#4ade80; margin-right:8px;"></i>
                            ${escapeHtml(productName.substring(0, 60))}
                        </div>
                        <div style="display:flex; gap:12px; margin-top:4px; flex-wrap:wrap;">
                            <span style="color:#fbbf24; font-size:10px;"><i class="fas fa-percent"></i> Komisi: ${link.commission_rate}%</span>
                            <span style="color:#8b5cf6; font-size:10px;"><i class="fas fa-bullhorn"></i> Campaign: ${escapeHtml(link.campaign_name || '-')}</span>
                        </div>
                    </div>
                    <div style="color:#4ade80;">
                        <i class="fas fa-chevron-right"></i>
                    </div>
                </label>
            `;
        });
        
        container.innerHTML = html;
        
    } catch (error) {
        console.error('Error loading products:', error);
        container.innerHTML = `
            <div style="text-align:center; padding:20px; color:#ef4444;">
                <i class="fas fa-exclamation-triangle"></i>
                <p>Error loading products: ${error.message}</p>
            </div>
        `;
    }
}

// ========== LOAD REKOMENDASI PRODUK ==========
async function loadRecommendedProducts(creatorCategory) {
    const container = document.getElementById('recommendedProducts');
    if (!container) return;
    
    try {
        // Ambil campaign yang aktif
        const response = await fetch(baseUrlIS + 'is/get_campaign_products', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: new URLSearchParams({ 
                campaign_id: '',  // Semua campaign
                creator_category: creatorCategory || ''
            })
        });
        const data = await response.json();
        
        if (data.success && data.products && data.products.length > 0) {
            let html = '';
            data.products.slice(0, 5).forEach(product => {
                html += `
                <div style="display:flex; justify-content:space-between; align-items:center; padding:10px; border-bottom:1px solid #2a3346;">
                    <div style="flex:1;">
                        <div style="color:#e2f0e8; font-size:12px;">${escapeHtml(product.product_name || 'Unknown').substring(0, 50)}</div>
                        <div style="display:flex; gap:8px; margin-top:4px;">
                            <span style="color:#4ade80; font-size:10px;">Rp ${formatNumber(product.price)}</span>
                            <span style="color:#fbbf24; font-size:10px;">${product.commission_rate / 100}%</span>
                        </div>
                    </div>
                    <button class="sample-recommend-btn" data-product-id="${product.product_id}" 
                        data-product-name="${escapeHtml(product.product_name || '')}"
                        style="background:#4ade80; color:#0a0e17; border:none; padding:6px 12px; border-radius:20px; cursor:pointer; font-size:10px; white-space:nowrap;">
                        <i class="fas fa-box"></i> Sample
                    </button>
                </div>`;
            });
            container.innerHTML = html;
            
            // Attach event listeners
            document.querySelectorAll('.sample-recommend-btn').forEach(btn => {
                btn.addEventListener('click', () => {
                    const productName = btn.getAttribute('data-product-name');
                    showToastGlobal(`Produk "${productName}" ditambahkan ke sample!`, 'success');
                    btn.style.background = '#fbbf24';
                    btn.innerHTML = '<i class="fas fa-check"></i> Dipilih';
                    btn.setAttribute('data-selected', 'true');
                });
            });
        } else {
            container.innerHTML = '<div style="text-align:center; padding:20px; color:#9aaebe;">Tidak ada produk tersedia</div>';
        }
    } catch (error) {
        container.innerHTML = '<div style="text-align:center; padding:20px; color:#ef4444;">Error loading produk</div>';
    }
}

function renderSampleProductsList(links) {
    if (!links || links.length === 0) {
        return '<div style="text-align:center; padding:20px; color:#9aaebe;"><i class="fas fa-box-open" style="font-size:32px; margin-bottom:10px; display:block;"></i>Belum ada link afiliasi yang digenerate untuk creator ini</div>';
    }
    
    let html = '';
    links.forEach((link) => {
        let productName = link.product_name || `Product ID: ${link.product_id}`;
        const commissionRate = parseFloat(link.commission_rate || 0).toFixed(2);
        const campaignName = link.campaign_name || '';
        
        html += `
            <label style="display:flex; align-items:center; gap:12px; padding:12px; background:#0f1420; border-radius:12px; margin-bottom:8px; cursor:pointer; border:1px solid #2a3346;" 
                   onmouseover="this.style.borderColor='#4ade80'" 
                   onmouseout="this.style.borderColor='#2a3346'">
                <input type="radio" name="sample_product" value="${link.product_id}" 
                       data-product-name="${escapeHtml(productName)}" 
                       data-commission="${commissionRate}"
                       style="width:18px; height:18px; cursor:pointer;">
                <div style="flex:1;">
                    <div style="color:#e2f0e8; font-size:13px; font-weight:500;">
                        <i class="fas fa-box" style="color:#4ade80; margin-right:8px;"></i>
                        ${escapeHtml(productName)}
                    </div>
                    <div style="display:flex; gap:16px; margin-top:6px; flex-wrap:wrap;">
                        <span style="color:#fbbf24; font-size:11px;"><i class="fas fa-percent"></i> Komisi: ${commissionRate}%</span>
                        ${campaignName ? `<span style="color:#9aaebe; font-size:11px;"><i class="fas fa-bullhorn"></i> ${escapeHtml(campaignName)}</span>` : ''}
                        <span style="color:#9aaebe; font-size:11px;"><i class="fas fa-calendar"></i> Dibuat: ${formatDate(link.created_at)}</span>
                    </div>
                </div>
                <div style="color:#4ade80;"><i class="fas fa-chevron-right"></i></div>
            </label>
        `;
    });
    return html;
}

function formatDate(dateString) {
    if (!dateString) return '-';
    const date = new Date(dateString);
    return date.toLocaleDateString('id-ID');
}



// ========== TASK 4: MONITORING (REWRITE) ==========
async function loadTask4CreatorsIS() {
    const response = await fetch(baseUrlIS + 'is/get_creators_by_status', {
        method: 'POST', 
        body: new URLSearchParams({ status: 'ACTIVE' })
    });
    const result = await response.json();
    const container = document.getElementById('monitoringContainerDashboard');
    const countSpan = document.getElementById('monitoringCountDashboard');
    
    if (result.success && result.data.length > 0) {
        // Filter yang punya order
        const monitoringCreators = [];
        
        for (const creator of result.data) {
            const perfRes = await fetch(baseUrlIS + 'is/get_creator_realtime_performance', {
                method: 'POST',
                body: new URLSearchParams({ creator_id: creator.id, days: 30 })
            });
            const perfData = await perfRes.json();
            
            if (perfData.success && perfData.summary.total_orders > 0) {
                monitoringCreators.push({
                    ...creator,
                    total_gmv: perfData.summary.total_gmv,
                    total_orders: perfData.summary.total_orders,
                    total_commission: perfData.summary.total_estimated_commission,
                    roas: perfData.summary.total_gmv > 0 && perfData.summary.total_estimated_commission > 0 
                        ? (perfData.summary.total_gmv / perfData.summary.total_estimated_commission).toFixed(1) 
                        : 0
                });
            }
        }
        
        // Sort by GMV
        monitoringCreators.sort((a, b) => b.total_gmv - a.total_gmv);
        
        if (countSpan) countSpan.innerText = monitoringCreators.length;
        let html = '';
        
        monitoringCreators.forEach((creator, index) => {
            const medal = index === 0 ? '' : (index === 1 ? '' : (index === 2 ? '' : ''));
        
            const hasPhone = creator.phone && creator.phone !== '' && creator.phone !== '-';
const phoneDisplay = hasPhone 
    ? `<span style="color:#4ade80;"><i class="fab fa-whatsapp"></i> ${creator.phone}</span>` 
    : `<span style="color:#ef4444;"><i class="fab fa-whatsapp"></i> No WA</span>`;
            html += `
<div class="stage-item-dashboard monitor-item-dashboard" 
     data-creator-id="${creator.id}" 
     data-creator-name="${escapeHtml(creator.username)}">
    <div style="display:flex; justify-content:space-between; align-items:center;">
        <strong>${medal} <i class="fab fa-tiktok"></i> ${escapeHtml(creator.username)}</strong>
        <span class="badge-dashboard badge-active"><i class="fas fa-check-circle"></i> ACTIVE</span>
    </div>
    <div class="item-details-dashboard">
        <span><i class="fas fa-money-bill-wave"></i> GMV: Rp ${formatNumber(creator.total_gmv)}</span>
        <span><i class="fas fa-chart-line"></i> ROAS: ${creator.roas}x</span>
        <span><i class="fas fa-shopping-cart"></i> Orders: ${creator.total_orders}</span>
    </div>
    <div class="item-details-dashboard">
        <span><i class="fas fa-tag"></i> ${escapeHtml(creator.category || '-')}</span>
        ${phoneDisplay}
        ${!hasPhone ? `
        <button class="edit-wa-task4-btn" data-creator-id="${creator.id}" data-creator-name="${escapeHtml(creator.username)}"
            style="background:#fbbf24; color:#0a0e17; border:none; padding:2px 8px; border-radius:10px; cursor:pointer; font-size:9px; margin-left:8px;">
            <i class="fas fa-edit"></i> Tambah WA
        </button>` : ''}
    </div>
    <div style="margin-top:8px; display:flex; gap:6px;">
        <button class="view-monitoring-detail-btn" data-creator-id="${creator.id}"
            style="background:#8b5cf6; color:white; border:none; padding:4px 12px; border-radius:20px; cursor:pointer; font-size:10px;">
            <i class="fas fa-eye"></i> Detail
        </button>
        <button class="add-product-monitor-btn" data-creator-id="${creator.id}"
            data-creator-name="${escapeHtml(creator.username)}"
            data-creator-category="${escapeHtml(creator.category || '')}"
            data-creator-phone="${escapeHtml(creator.phone || '')}"
            style="background:#4ade80; color:#0a0e17; border:none; padding:4px 12px; border-radius:20px; cursor:pointer; font-size:10px;">
            <i class="fas fa-plus"></i> Tambah Product
        </button>
    </div>
</div>`;
        });
        
        container.innerHTML = html || '<div class="stage-item-dashboard">Belum ada creator dengan penjualan</div>';
        
        // Event: Detail Monitoring
      document.querySelectorAll('.view-monitoring-detail-btn').forEach(btn => {
    btn.addEventListener('click', (e) => {
        e.stopPropagation();
        const creatorId = btn.getAttribute('data-creator-id');
        showMonitoringDetailModal(creatorId);
    });
});

// Event: Edit WA
document.querySelectorAll('.edit-wa-task4-btn').forEach(btn => {
    btn.addEventListener('click', (e) => {
        e.stopPropagation();
        const cid = btn.getAttribute('data-creator-id');
        const cname = btn.getAttribute('data-creator-name');
        showQuickEditPhoneModal(cid, cname, '');
    });
});

        
        // Event: Tambah Product
        document.querySelectorAll('.add-product-monitor-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                e.stopPropagation();
                const creatorId = btn.getAttribute('data-creator-id');
                const creatorName = btn.getAttribute('data-creator-name');
                const creatorCategory = btn.getAttribute('data-creator-category');
                const creatorPhone = btn.getAttribute('data-creator-phone');
                
                currentCreatorId = creatorId;
                currentCreatorName = creatorName;
                currentCreatorCategory = creatorCategory;
                currentCreatorPhone = creatorPhone;
                
                showLinkAssignmentModal(creatorId, creatorName, creatorCategory, creatorPhone);
            });
        });
    } else {
        if (countSpan) countSpan.innerText = '0';
        container.innerHTML = '<div class="stage-item-dashboard"><strong><i class="fas fa-info-circle"></i> Belum ada creator aktif</strong></div>';
    }
}

// ========== MODAL MONITORING DETAIL ==========
async function showMonitoringDetailModal(creatorId) {
    document.getElementById('modalTitleDashboard').innerHTML = '<i class="fas fa-chart-line"></i> Loading...';
    document.getElementById('modalBodyDashboard').innerHTML = `
        <div style="text-align:center; padding:40px;">
            <i class="fas fa-spinner fa-pulse fa-2x" style="color:#8b5cf6;"></i>
        </div>
    `;
    openModalIS();
    
    try {
        const response = await fetch(baseUrlIS + 'is/get_monitoring_detail', {
            method: 'POST',
            body: new URLSearchParams({ creator_id: creatorId })
        });
        const result = await response.json();
        
        if (!result.success) {
            document.getElementById('modalBodyDashboard').innerHTML = `
                <div style="text-align:center; padding:40px; color:#ef4444;">
                    <p>${result.message || 'Gagal memuat data'}</p>
                    <button onclick="closeModalIS()" style="margin-top:12px; background:#1e293b; color:#e2f0e8; padding:8px 16px; border-radius:8px; border:1px solid #2a3346; cursor:pointer;">Tutup</button>
                </div>
            `;
            return;
        }
        
        const c = result.creator;
        const perf = result.performance;
        const links = result.links || [];
        const contents = result.contents || [];
        const daily = result.daily_performance || [];
        
        document.getElementById('modalTitleDashboard').innerHTML = `<i class="fas fa-chart-line"></i> Monitoring: @${escapeHtml(c.username)}`;
        
        let html = '';
        
        // ========== HEADER ==========
        html += `
        <div style="background:rgba(139,92,246,0.1); border-radius:14px; padding:14px; margin-bottom:16px;">
            <div style="display:grid; grid-template-columns:1fr 1fr; gap:12px;">
                <div>
                    <div style="color:#9aaebe; font-size:10px;">Creator</div>
                    <div style="color:#e2f0e8; font-size:15px; font-weight:600;">@${escapeHtml(c.username)}</div>
                </div>
                <div>
                    <div style="color:#9aaebe; font-size:10px;">Kategori</div>
                    <div style="color:#e2f0e8; font-size:13px;">${escapeHtml(c.category || '-')}</div>
                </div>
                <div>
                    <div style="color:#9aaebe; font-size:10px;">Status</div>
                    <span class="badge-dashboard badge-active">ACTIVE</span>
                </div>
                <div>
                    <div style="color:#9aaebe; font-size:10px;">WhatsApp</div>
                    <div style="color:${c.phone ? '#4ade80' : '#ef4444'}; font-size:13px;">${escapeHtml(c.phone || 'Tidak ada')}</div>
                </div>
            </div>
        </div>`;
        
        // ========== PERFORMANCE ==========
        html += `
        <div style="background:#0f1420; border-radius:14px; padding:14px; margin-bottom:12px;">
            <h4 style="color:#e2f0e8; margin:0 0 12px 0; font-size:13px;"><i class="fas fa-chart-bar"></i> Performance (30 Hari)</h4>
            <div style="display:grid; grid-template-columns:repeat(4,1fr); gap:8px; text-align:center;">
                <div style="background:#1e293b; border-radius:10px; padding:10px;">
                    <div style="color:#4ade80; font-size:16px; font-weight:700;">Rp ${formatNumber(perf.total_gmv)}</div>
                    <div style="color:#9aaebe; font-size:9px;">Total GMV</div>
                </div>
                <div style="background:#1e293b; border-radius:10px; padding:10px;">
                    <div style="color:#fbbf24; font-size:16px; font-weight:700;">${perf.total_orders}</div>
                    <div style="color:#9aaebe; font-size:9px;">Orders</div>
                </div>
                <div style="background:#1e293b; border-radius:10px; padding:10px;">
                    <div style="color:#8b5cf6; font-size:16px; font-weight:700;">${perf.roas}x</div>
                    <div style="color:#9aaebe; font-size:9px;">ROAS</div>
                </div>
                <div style="background:#1e293b; border-radius:10px; padding:10px;">
                    <div style="color:#f59e0b; font-size:16px; font-weight:700;">Rp ${formatNumber(perf.total_commission)}</div>
                    <div style="color:#9aaebe; font-size:9px;">Commission</div>
                </div>
            </div>
            ${perf.last_order ? `
            <div style="margin-top:8px; display:flex; justify-content:space-between; font-size:10px; color:#9aaebe;">
                <span>First Order: ${new Date(perf.first_order).toLocaleDateString('id-ID')}</span>
                <span>Last Order: ${new Date(perf.last_order).toLocaleDateString('id-ID')}</span>
            </div>` : ''}
        </div>`;
        
        // ========== VIDEOS / CONTENT ==========
        if (contents.length > 0) {
            html += `
            <div style="background:#0f1420; border-radius:14px; padding:14px; margin-bottom:12px;">
                <h4 style="color:#e2f0e8; margin:0 0 12px 0; font-size:13px;"><i class="fab fa-tiktok"></i> Konten Creator</h4>
                <div style="display:flex; gap:8px; overflow-x:auto; padding-bottom:8px;">`;
            
            contents.forEach(c => {
                const videoUrl = c.linked_tiktok_video || c.source_url || '#';
                html += `
                <a href="${videoUrl}" target="_blank" style="text-decoration:none; flex-shrink:0; width:140px;">
                    <div style="background:#1e293b; border-radius:10px; overflow:hidden; border:1px solid #2a3346;">
                        <div style="height:80px; background:#111827; display:flex; align-items:center; justify-content:center;">
                            ${c.cover_img_url 
                                ? `<img src="${escapeHtml(c.cover_img_url)}" style="width:100%; height:100%; object-fit:cover;" onerror="this.style.display='none'">`
                                : '<i class="fab fa-tiktok" style="font-size:32px; color:#8b5cf6;"></i>'}
                        </div>
                        <div style="padding:6px;">
                            <div style="color:#e2f0e8; font-size:10px;">�9�9 ${formatNumberShort(c.view_count)}</div>
                            <div style="color:#9aaebe; font-size:9px;">�7�8 ${formatNumberShort(c.like_count)} | �9�6 ${formatNumberShort(c.comment_count)}</div>
                            <div style="color:#4ade80; font-size:9px;">�0�6 ${c.paid_order_count} orders</div>
                        </div>
                    </div>
                </a>`;
            });
            
            html += `</div></div>`;
        }
        
        // ========== ACTIVE LINKS ==========
        if (links.length > 0) {
            html += `
            <div style="background:#0f1420; border-radius:14px; padding:14px; margin-bottom:12px;">
                <h4 style="color:#e2f0e8; margin:0 0 12px 0; font-size:13px;"><i class="fas fa-link"></i> Active Links (${links.length})</h4>
                <div style="max-height:200px; overflow-y:auto;">`;
            
            links.forEach(link => {
                html += `
                <div style="display:flex; justify-content:space-between; padding:8px; border-bottom:1px solid #2a3346; font-size:10px;">
                    <div style="flex:1;">
                        <div style="color:#e2f0e8;">${escapeHtml((link.product_name || '').substring(0, 40))}</div>
                        <div style="display:flex; gap:8px; margin-top:2px;">
                            <span style="color:#4ade80;">GMV: Rp ${formatNumber(link.link_gmv || 0)}</span>
                            <span style="color:#9aaebe;">Orders: ${link.link_orders || 0}</span>
                            <span style="color:#fbbf24;">${link.commission_rate}%</span>
                        </div>
                        ${link.handler_name ? `<div style="color:#8b5cf6; font-size:8px; margin-top:2px;"><i class="fas fa-user"></i> Handler: ${escapeHtml(link.handler_name)}</div>` : ''}
                    </div>
                    <a href="${link.affiliate_link || '#'}" target="_blank" style="color:#8b5cf6; font-size:9px;">
                        <i class="fas fa-external-link-alt"></i>
                    </a>
                </div>`;
            });
            
            html += `</div></div>`;
        }
        
        // ========== TAMBAH PRODUCT BUTTON ==========
        html += `
        <button id="addProductFromMonitoringBtn" style="width:100%; background:#4ade80; color:#0a0e17; border:none; padding:12px; border-radius:12px; cursor:pointer; font-weight:600; font-size:13px; margin-top:12px;">
            <i class="fas fa-plus"></i> Tambah Product Baru untuk Creator Ini
        </button>
        
        <button id="closeMonitoringBtn" style="width:100%; background:#1e293b; color:#e2f0e8; border:1px solid #2a3346; padding:10px; border-radius:12px; cursor:pointer; font-size:12px; margin-top:8px;">
            Tutup
        </button>`;
        
        document.getElementById('modalBodyDashboard').innerHTML = html;
        
        // Event: Tambah Product
        document.getElementById('addProductFromMonitoringBtn')?.addEventListener('click', () => {
            closeModalIS();
            // Buka modal assign link (Task 2 style)
            setTimeout(() => {
                currentCreatorId = c.id;
                currentCreatorName = c.username;
                currentCreatorCategory = c.category || '';
                currentCreatorPhone = c.phone || '';
                showLinkAssignmentModal(c.id, c.username, c.category || '', c.phone || '');
            }, 300);
        });
        
        document.getElementById('closeMonitoringBtn')?.addEventListener('click', closeModalIS);
        
    } catch (error) {
        document.getElementById('modalBodyDashboard').innerHTML = `
            <div style="text-align:center; padding:40px; color:#ef4444;">
                <p>Error: ${error.message}</p>
                <button onclick="closeModalIS()" style="margin-top:12px;">Tutup</button>
            </div>
        `;
    }
}

async function showCreatorPerformanceModalIS(creatorId, creatorName) {
    const response = await fetch(baseUrlIS + 'is/get_creator_realtime_performance', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: new URLSearchParams({ creator_id: creatorId, days: 30 })
    });
    const result = await response.json();
    
    if (!result.success) {
        showToastGlobal('Gagal mengambil data performa', 'error');
        return;
    }
    
    document.getElementById('modalTitleDashboard').innerHTML = `<i class="fas fa-chart-line"></i> Performance - ${creatorName}`;
    document.getElementById('modalBodyDashboard').innerHTML = `
        <div style="background:rgba(74,222,128,0.1); border-radius:14px; padding:14px; margin-bottom:16px;">
            <div style="display:grid; grid-template-columns:1fr 1fr; gap:12px;">
                <div><div style="color:#9aaebe; font-size:11px;">Total GMV</div><div style="color:#4ade80; font-size:18px; font-weight:700;">Rp ${formatNumber(result.summary.total_gmv)}</div></div>
                <div><div style="color:#9aaebe; font-size:11px;">Total Orders</div><div style="color:#4ade80; font-size:18px; font-weight:700;">${result.summary.total_orders}</div></div>
                <div><div style="color:#9aaebe; font-size:11px;">Estimated Commission</div><div style="color:#fbbf24; font-size:14px; font-weight:600;">Rp ${formatNumber(result.summary.total_estimated_commission)}</div></div>
                <div><div style="color:#9aaebe; font-size:11px;">Completed Orders</div><div style="color:#10b981; font-size:14px; font-weight:600;">${result.summary.completed_orders || 0}</div></div>
            </div>
        </div>
        <div style="margin-bottom:16px;">
            <label><i class="fas fa-chart-simple"></i> Campaign Breakdown</label>
            <div style="background:#0f1420; border-radius:12px; padding:8px;">${renderCampaignBreakdown(result.campaign_breakdown || [])}</div>
        </div>
        <div><label><i class="fas fa-history"></i> Recent Orders (30 hari)</label><div style="max-height:250px; overflow-y:auto; background:#0f1420; border-radius:12px; padding:8px;">${renderRecentOrders(result.recent_orders || [])}</div></div>
        <div class="flex-buttons" style="margin-top:16px;"><button id="closePerfBtn" style="background:#1e293b;">Tutup</button></div>
    `;
    openModalIS();
    document.getElementById('closePerfBtn').addEventListener('click', closeModalIS);
}

function renderCampaignBreakdown(campaigns) {
    if (!campaigns || campaigns.length === 0) return '<div style="text-align:center; padding:20px; color:#9aaebe;">Belum ada data campaign</div>';
    let html = '';
    campaigns.forEach(camp => {
        html += `<div style="display:flex; justify-content:space-between; padding:8px; border-bottom:1px solid #2a3346;"><div style="color:#e2f0e8; font-size:12px;">${escapeHtml(camp.campaign_name || camp.campaign_id)}</div><div style="color:#4ade80; font-size:12px;">Rp ${formatNumber(camp.gmv)}</div></div>`;
    });
    return html;
}

function renderRecentOrders(orders) {
    if (!orders || orders.length === 0) return '<div style="text-align:center; padding:20px; color:#9aaebe;">Belum ada pesanan</div>';
    let html = '<table style="width:100%; font-size:11px;"><thead><tr><th>Tanggal</th><th>Produk</th><th>GMV</th><th>Status</th></tr></thead><tbody>';
    orders.forEach(order => {
        html += `<tr style="border-bottom:1px solid #2a3346;"><td style="padding:6px;">${order.order_date || '-'}</td><td style="padding:6px;">${escapeHtml(order.product_name || '-').substring(0, 30)}</td><td style="padding:6px; color:#4ade80;">Rp ${formatNumber(order.gmv)}</td><td style="padding:6px;"><span class="order-status ${order.order_status?.toLowerCase()}">${order.order_status || '-'}</span></td></tr>`;
    });
    html += '</tbody></table>';
    return html;
}

// ========== TAB SWITCHING ==========
document.querySelectorAll('.tab-btn-dashboard').forEach(btn => {
    btn.addEventListener('click', () => {
        const tabId = btn.getAttribute('data-tab');
        document.querySelectorAll('.tab-content-dashboard').forEach(c => c.classList.remove('active'));
        document.querySelectorAll('.tab-btn-dashboard').forEach(b => b.classList.remove('active'));
        document.getElementById(tabId).classList.add('active');
        btn.classList.add('active');
        document.querySelectorAll('.mobile-nav-item-dashboard').forEach(nav => {
            if (nav.getAttribute('data-tab') === tabId) nav.classList.add('active');
            else nav.classList.remove('active');
        });
    });
});

document.querySelectorAll('.mobile-nav-item-dashboard').forEach(item => {
    item.addEventListener('click', (e) => {
        e.preventDefault();
        const tabId = item.getAttribute('data-tab');
        document.querySelector(`.tab-btn-dashboard[data-tab="${tabId}"]`)?.click();
    });
});

document.getElementById('closeTaskModalDashboard').addEventListener('click', closeModalIS);
document.getElementById('taskModalDashboard').addEventListener('click', (e) => {
    if (e.target === document.getElementById('taskModalDashboard')) closeModalIS();
});

// ========== FUNGSI SEARCH UNTUK SETIAP TASK ==========
function initSearchTask(searchInputId, containerId, itemClass) {
    const searchInput = document.getElementById(searchInputId);
    if (!searchInput) return;
    
    searchInput.addEventListener('keyup', function() {
        const searchTerm = this.value.toLowerCase();
        const container = document.getElementById(containerId);
        if (!container) return;
        
        const items = container.querySelectorAll(itemClass);
        let visibleCount = 0;
        
        items.forEach(function(item) {
            const searchable = item.getAttribute('data-searchable') || '';
            if (searchable.indexOf(searchTerm) > -1) {
                item.style.display = '';
                visibleCount++;
            } else {
                item.style.display = 'none';
            }
        });
        
        let countSpan = null;
        if (searchInputId === 'searchScoutingDashboard') countSpan = document.getElementById('scoutingCountDashboard');
        else if (searchInputId === 'searchLinkSwappingDashboard') countSpan = document.getElementById('linkCountDashboard');
        else if (searchInputId === 'searchSampleDashboard') countSpan = document.getElementById('sampleCountDashboard');
        else if (searchInputId === 'searchMonitoringDashboard') countSpan = document.getElementById('monitoringCountDashboard');
        
        if (countSpan) countSpan.innerText = visibleCount;
        
        const noResultDiv = container.querySelector('.no-search-result');
        if (visibleCount === 0 && searchTerm !== '') {
            if (!noResultDiv) {
                const noResult = document.createElement('div');
                noResult.className = 'stage-item-dashboard no-search-result';
                noResult.setAttribute('data-no-result', 'true');
                noResult.innerHTML = '<strong><i class="fas fa-search"></i> Tidak ada yang cocok</strong><div class="item-details-dashboard">Coba kata kunci lain (username atau brand)</div>';
                container.appendChild(noResult);
            }
        } else {
            if (noResultDiv) noResultDiv.remove();
        }
    });
}
// ========== QUICK EDIT PHONE MODAL ==========
function showQuickEditPhoneModal(creatorId, creatorName, currentPhone) {
    const modalTitle = document.getElementById('modalTitleDashboard');
    const modalBody = document.getElementById('modalBodyDashboard');
    
    modalTitle.innerHTML = `<i class="fab fa-whatsapp"></i> Update WhatsApp - @${escapeHtml(creatorName)}`;
    modalBody.innerHTML = `
        <div style="background:rgba(251,191,36,0.1); border-radius:14px; padding:12px; margin-bottom:16px; border-left:3px solid #fbbf24;">
            <p style="color:#fbbf24; font-size:12px;"><i class="fas fa-exclamation-triangle"></i> Nomor WhatsApp diperlukan untuk mengirim link & sample</p>
        </div>
        
        <label><i class="fab fa-whatsapp"></i> Nomor WhatsApp</label>
        <input type="tel" id="quickEditPhone" placeholder="+62 812 3456 7890" value="${escapeHtml(currentPhone || '')}" 
            style="width:100%; padding:12px; background:#0f1420; border:2px solid #fbbf24; border-radius:12px; color:#e2f0e8; font-size:14px; margin-bottom:12px;">
        <div style="font-size:11px; color:#9aaebe; margin-bottom:16px;">
            <i class="fas fa-info-circle"></i> Format: +628123456789 atau 08123456789
        </div>
        
        <div class="flex-buttons">
            <button id="saveQuickPhoneBtn" style="background:#4ade80; color:#0a0e17; flex:1; padding:12px; border:none; border-radius:12px; cursor:pointer; font-weight:600;">
                <i class="fas fa-save"></i> Simpan
            </button>
            <button id="cancelQuickPhoneBtn" style="background:#1e293b; flex:1; padding:12px; border:1px solid #2a3346; border-radius:12px; cursor:pointer;">
                Batal
            </button>
        </div>
    `;
    openModalIS();
    
    document.getElementById('saveQuickPhoneBtn').addEventListener('click', async () => {
        let phone = document.getElementById('quickEditPhone').value.trim();
        
        if (!phone) {
            showToastGlobal('Nomor WhatsApp tidak boleh kosong', 'error');
            return;
        }
        
        const btn = document.getElementById('saveQuickPhoneBtn');
        btn.disabled = true;
        btn.innerHTML = '<i class="fas fa-spinner fa-pulse"></i> Menyimpan...';
        
        try {
            const response = await fetch(baseUrlIS + 'is/update_creator_phone', {
                method: 'POST',
                body: new URLSearchParams({ creator_id: creatorId, phone: phone })
            });
            const result = await response.json();
            
            if (result.success) {
                closeModalIS();
                showToastGlobal(`WhatsApp @${creatorName} berhasil diupdate!`, 'success');
                setTimeout(() => location.reload(), 1500);
            } else {
                showToastGlobal(result.message || 'Gagal update', 'error');
                btn.disabled = false;
                btn.innerHTML = '<i class="fas fa-save"></i> Simpan';
            }
        } catch (error) {
            showToastGlobal('Error: ' + error.message, 'error');
            btn.disabled = false;
            btn.innerHTML = '<i class="fas fa-save"></i> Simpan';
        }
    });
    
    document.getElementById('cancelQuickPhoneBtn').addEventListener('click', closeModalIS);
}
function initAllSearches() {
    setTimeout(() => {
        initSearchTask('searchScoutingDashboard', 'scoutingContainerDashboard', '.scouting-item-dashboard');
        initSearchTask('searchLinkSwappingDashboard', 'linkSwappingContainerDashboard', '.link-item-dashboard');
        initSearchTask('searchSampleDashboard', 'sendingSampleContainerDashboard', '.sample-item-dashboard');
        initSearchTask('searchMonitoringDashboard', 'monitoringContainerDashboard', '.monitor-item-dashboard');
    }, 1000);
}

const originalLoadTask2 = loadTask2CreatorsIS;
loadTask2CreatorsIS = async function() {
    await originalLoadTask2();
    setTimeout(() => {
        document.querySelectorAll('#linkSwappingContainerDashboard .link-item-dashboard').forEach(item => {
            const name = item.getAttribute('data-creator-name') || '';
            item.setAttribute('data-searchable', name.toLowerCase());
        });
        initSearchTask('searchLinkSwappingDashboard', 'linkSwappingContainerDashboard', '.link-item-dashboard');
    }, 500);
};

const originalLoadTask3 = loadTask3CreatorsIS;
loadTask3CreatorsIS = async function() {
    await originalLoadTask3();
    setTimeout(() => {
        document.querySelectorAll('#sendingSampleContainerDashboard .sample-item-dashboard').forEach(item => {
            const name = item.getAttribute('data-creator-name') || '';
            item.setAttribute('data-searchable', name.toLowerCase());
        });
        initSearchTask('searchSampleDashboard', 'sendingSampleContainerDashboard', '.sample-item-dashboard');
    }, 500);
};

const originalLoadTask4 = loadTask4CreatorsIS;
loadTask4CreatorsIS = async function() {
    await originalLoadTask4();
    setTimeout(() => {
        document.querySelectorAll('#monitoringContainerDashboard .monitor-item-dashboard').forEach(item => {
            const name = item.getAttribute('data-creator-name') || '';
            item.setAttribute('data-searchable', name.toLowerCase());
        });
        initSearchTask('searchMonitoringDashboard', 'monitoringContainerDashboard', '.monitor-item-dashboard');
    }, 500);
};

// ========== IMPORT CREATOR FUNCTIONS ==========
let importFile = null;
let importBrandId = null;
let importBrandName = null;

document.getElementById('importCreatorBtnDashboard')?.addEventListener('click', () => {
    document.getElementById('importModalDashboard').classList.add('active');
    document.getElementById('importStep1').style.display = 'block';
    document.getElementById('importStep2').style.display = 'none';
    document.getElementById('importStep3').style.display = 'none';
    document.getElementById('importFileInput').value = '';
    
    const brandSelect = document.getElementById('importBrandSelect');
    if (brandSelect) brandSelect.value = '';
});

document.getElementById('previewImportBtn')?.addEventListener('click', async () => {
    const brandSelect = document.getElementById('importBrandSelect');
    const brandId = brandSelect?.value;
    const brandName = brandSelect?.options[brandSelect.selectedIndex]?.text;
    
    if (!brandId) {
        showToastGlobal('Pilih brand terlebih dahulu', 'error');
        return;
    }
    
    const fileInput = document.getElementById('importFileInput');
    if (!fileInput.files || !fileInput.files[0]) {
        showToastGlobal('Pilih file terlebih dahulu', 'error');
        return;
    }
    
    importBrandId = brandId;
    importBrandName = brandName;
    
    const file = fileInput.files[0];
    const formData = new FormData();
    formData.append('import_file', file);
    formData.append('action', 'preview');
    formData.append('brand_id', brandId);
    formData.append('col_username', document.getElementById('colMappingUsername')?.value || 1);
    formData.append('col_fullname', document.getElementById('colMappingFullname')?.value || 0);
    formData.append('col_category', document.getElementById('colMappingCategory')?.value || 2);
    formData.append('col_phone', document.getElementById('colMappingPhone')?.value || -1);
    
    const previewBtn = document.getElementById('previewImportBtn');
    previewBtn.disabled = true;
    previewBtn.innerHTML = '<i class="fas fa-spinner fa-pulse"></i> Loading...';
    
    try {
        const response = await fetch(baseUrlIS + 'is/import_creators', {
            method: 'POST',
            body: formData
        });
        const result = await response.json();
        
        if (result.success) {
            document.getElementById('previewBrandInfo').innerHTML = `
                <div style="display: flex; align-items: center; gap: 12px;">
                    <i class="fas fa-store" style="color: #4ade80; font-size: 24px;"></i>
                    <div>
                        <div style="color: #e2f0e8; font-weight: 600;">Brand: ${escapeHtml(result.brand_info.name)}</div>
                        <div style="color: #9aaebe; font-size: 11px;">Shop: ${escapeHtml(result.brand_info.shop_name || '-')}</div>
                    </div>
                </div>
            `;
            
            const statsHtml = `
                <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 12px; text-align: center;">
                    <div>
                        <div style="color: #4ade80; font-size: 24px; font-weight: bold;">${result.total_rows}</div>
                        <div style="color: #9aaebe; font-size: 11px;">Total Data</div>
                    </div>
                    <div>
                        <div style="color: #fbbf24; font-size: 24px; font-weight: bold;">${result.new_count}</div>
                        <div style="color: #9aaebe; font-size: 11px;">Creator Baru</div>
                    </div>
                    <div>
                        <div style="color: #9aaebe; font-size: 24px; font-weight: bold;">${result.exists_count}</div>
                        <div style="color: #9aaebe; font-size: 11px;">Sudah Ada</div>
                    </div>
                </div>
            `;
            document.getElementById('previewStats').innerHTML = statsHtml;
            
            if (result.errors && result.errors.length > 0) {
                const errorsHtml = `<strong><i class="fas fa-exclamation-triangle"></i> Error pada data:</strong><br>
                    ${result.errors.map(e => `<div style="font-size: 11px;">�6�1 ${escapeHtml(e)}</div>`).join('')}`;
                document.getElementById('previewErrors').innerHTML = errorsHtml;
                document.getElementById('previewErrors').style.display = 'block';
            } else {
                document.getElementById('previewErrors').style.display = 'none';
            }
            
            let tableHtml = '<table style="width:100%; font-size:11px; border-collapse:collapse;">';
            tableHtml += '<thead><tr style="border-bottom:1px solid #2a3346;">';
            tableHtml += '<th style="padding:6px;">Username</th>';
            tableHtml += '<th style="padding:6px;">Nama</th>';
            tableHtml += '<th style="padding:6px;">Kategori</th>';
            tableHtml += '<th style="padding:6px;">GMV (28 Hari)</th>';
            tableHtml += '<th style="padding:6px;">Status</th>';
            tableHtml += '</tr></thead><tbody>';
            
            result.preview.forEach(creator => {
                const statusBadge = creator.status === 'NEW' 
                    ? '<span style="color:#4ade80;">�9�5 Baru</span>' 
                    : `<span style="color:#fbbf24;">�7�2�1�5 Sudah Ada (${creator.existing_status || '-'})</span>`;
                
               const gmvValue = creator.gmv_28days || 0;
                const gmvIdr = Math.round(gmvValue * 16000);  // �9�7 KONVERSI KE IDR
                const gmvDisplay = gmvValue > 0 ? 'Rp ' + formatNumber(gmvIdr) : '-';
                const gmvColor = gmvValue > 100000 ? '#fbbf24' : (gmvValue > 0 ? '#4ade80' : '#9aaebe');

               
                
                tableHtml += `<tr style="border-bottom:1px solid #2a3346;">
                    <td style="padding:6px;">@${escapeHtml(creator.username)}</td>
                    <td style="padding:6px;">${escapeHtml(creator.full_name || '-')}</td>
                    <td style="padding:6px;">${escapeHtml(creator.category || '-')}</td>
                    <td style="padding:6px; color:${gmvColor}; font-weight:${gmvValue > 0 ? '600' : 'normal'};">${gmvDisplay}</td>
                    <td style="padding:6px;">${statusBadge}</td>
                </tr>`;
            });
            
            tableHtml += '</tbody></table>';
            document.getElementById('previewTable').innerHTML = tableHtml;
            
            importFile = file;
            
            document.getElementById('importStep1').style.display = 'none';
            document.getElementById('importStep2').style.display = 'block';
            
        } else {
            showToastGlobal(result.message || 'Gagal preview file', 'error');
        }
    } catch (error) {
        showToastGlobal('Error: ' + error.message, 'error');
    } finally {
        previewBtn.disabled = false;
        previewBtn.innerHTML = '<i class="fas fa-eye"></i> Preview Data';
    }
});

document.getElementById('confirmImportBtn')?.addEventListener('click', async () => {
    if (!importFile || !importBrandId) {
        showToastGlobal('Tidak ada file atau brand untuk diimport', 'error');
        return;
    }
    
    const duplicateAction = document.querySelector('input[name="duplicate_action"]:checked')?.value || 'skip';
    const formData = new FormData();
    formData.append('import_file', importFile);
    formData.append('action', 'process');
    formData.append('brand_id', importBrandId);
    formData.append('skip_existing', duplicateAction === 'skip' ? 'true' : 'false');
    formData.append('col_username', document.getElementById('colMappingUsername')?.value || 1);
    formData.append('col_fullname', document.getElementById('colMappingFullname')?.value || 0);
    formData.append('col_category', document.getElementById('colMappingCategory')?.value || 2);
    formData.append('col_phone', document.getElementById('colMappingPhone')?.value || -1);
    
    const confirmBtn = document.getElementById('confirmImportBtn');
    confirmBtn.disabled = true;
    confirmBtn.innerHTML = '<i class="fas fa-spinner fa-pulse"></i> Importing...';
    
    try {
        const response = await fetch(baseUrlIS + 'is/import_creators', {
            method: 'POST',
            body: formData
        });
        const result = await response.json();
        
        if (result.success) {
            const resultHtml = `
                <div style="background: rgba(74,222,128,0.1); border-radius: 14px; padding: 20px;">
                    <i class="fas fa-check-circle" style="font-size: 48px; color: #4ade80;"></i>
                    <h3 style="margin: 16px 0; color: #e2f0e8;">Import Selesai!</h3>
                    <div style="text-align: left; max-width: 300px; margin: 0 auto;">
                        <div style="display: flex; justify-content: space-between; padding: 5px 0;">
                            <span>�9�2 Brand:</span><span style="color:#4ade80;">${escapeHtml(result.brand_name)}</span>
                        </div>
                        <div style="display: flex; justify-content: space-between; padding: 5px 0;">
                            <span>�7�3 Creator baru:</span><span style="color:#4ade80;">${result.inserted}</span>
                        </div>
                        <div style="display: flex; justify-content: space-between; padding: 5px 0;">
                            <span>�7�1�1�5 Dilewati:</span><span style="color:#fbbf24;">${result.skipped}</span>
                        </div>
                        <div style="display: flex; justify-content: space-between; padding: 5px 0;">
                            <span>�7�4 Gagal:</span><span style="color:#ef4444;">${result.failed}</span>
                        </div>
                    </div>
                    <p style="margin-top: 16px; color: #9aaebe;">${result.message}</p>
                </div>
            `;
            document.getElementById('importResult').innerHTML = resultHtml;
            
            document.getElementById('importStep2').style.display = 'none';
            document.getElementById('importStep3').style.display = 'block';
            
            setTimeout(() => {
                location.reload();
            }, 3000);
        } else {
            showToastGlobal(result.message || 'Gagal import', 'error');
            confirmBtn.disabled = false;
            confirmBtn.innerHTML = '<i class="fas fa-save"></i> Konfirmasi Import';
        }
    } catch (error) {
        showToastGlobal('Error: ' + error.message, 'error');
        confirmBtn.disabled = false;
        confirmBtn.innerHTML = '<i class="fas fa-save"></i> Konfirmasi Import';
    }
});

// ========== CREATOR STATUS TAB SWITCHING ==========
document.querySelectorAll('.creator-tab-btn').forEach(btn => {
    btn.addEventListener('click', () => {
        const tabId = btn.getAttribute('data-creator-tab');
        
        document.querySelectorAll('.creator-tab-btn').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        
        if (tabId === 'active') {
            document.getElementById('activeCreatorsList').style.display = 'block';
            document.getElementById('pendingCreatorsList').style.display = 'none';
        } else {
            document.getElementById('activeCreatorsList').style.display = 'none';
            document.getElementById('pendingCreatorsList').style.display = 'block';
        }
    });
});

document.querySelectorAll('.view-creator-detail').forEach(btn => {
    btn.addEventListener('click', () => {
        const creatorId = btn.getAttribute('data-creator-id');
        showCreatorDetailIS(creatorId);
    });
});

// ========== TOP CREATOR PERIOD FILTER ==========
document.querySelectorAll('.period-btn').forEach(btn => {
    btn.addEventListener('click', async () => {
        const period = btn.getAttribute('data-period');
        
        document.querySelectorAll('.period-btn').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        
        const gmvContainer = document.getElementById('topGmvCreatorsList');
        const engagementContainer = document.getElementById('topEngagementCreatorsList');
        
        gmvContainer.innerHTML = '<div style="text-align: center; padding: 40px;"><i class="fas fa-spinner fa-pulse"></i> Loading...</div>';
        engagementContainer.innerHTML = '<div style="text-align: center; padding: 40px;"><i class="fas fa-spinner fa-pulse"></i> Loading...</div>';
        
        try {
            const response = await fetch(baseUrlIS + 'is/get_top_creators?period=' + period);
            const result = await response.json();
            
            if (result.success) {
                renderTopCreators(gmvContainer, result.top_gmv, 'gmv');
                renderTopCreators(engagementContainer, result.top_engagement, 'engagement');
            } else {
                gmvContainer.innerHTML = '<div style="text-align: center; padding: 40px; color: #ef4444;">Gagal memuat data</div>';
                engagementContainer.innerHTML = '<div style="text-align: center; padding: 40px; color: #ef4444;">Gagal memuat data</div>';
            }
        } catch (error) {
            console.error('Error:', error);
            gmvContainer.innerHTML = '<div style="text-align: center; padding: 40px; color: #ef4444;">Error loading data</div>';
            engagementContainer.innerHTML = '<div style="text-align: center; padding: 40px; color: #ef4444;">Error loading data</div>';
        }
    });
});

function renderTopCreators(container, creators, type) {
    if (!creators || creators.length === 0) {
        container.innerHTML = '<div style="text-align: center; padding: 40px; color: var(--text-muted);"><i class="fas fa-chart-line" style="font-size: 48px; margin-bottom: 16px; display: block; opacity: 0.5;"></i><p>Belum ada data</p></div>';
        return;
    }
    
    let html = '';
    creators.forEach((creator, index) => {
        const rank = index + 1;
        const rankBadge = rank == 1 ? '' : (rank == 2 ? '' : (rank == 3 ? '' : rank));
        
        html += `
            <div class="leaderboard-item-dashboard" style="display: flex; align-items: center; gap: 12px; padding: 12px; border-bottom: 1px solid var(--border); transition: background 0.2s; border-radius: 12px;" onmouseover="this.style.background='rgba(139,92,246,0.1)'" onmouseout="this.style.background='transparent'">
                <div style="width: 36px; text-align: center;">
                    <span style="color: var(--text-muted); font-size: 14px; font-weight: 600;">${rankBadge}</span>
                </div>
                <div style="flex: 1;">
                    <strong style="color: var(--text-primary); font-size: 13px;">@${escapeHtml(creator.username)}</strong>
                    <div style="display: flex; gap: 16px; margin-top: 4px;">
                        <span style="font-size: 10px; color: var(--text-muted);"><i class="fas fa-tag"></i> ${escapeHtml(creator.category || '-')}</span>
                    </div>
                </div>
                <div style="text-align: right;">
                    <div style="color: ${type === 'gmv' ? '#4ade80' : '#8b5cf6'}; font-weight: 700; font-size: 14px;">
                        ${type === 'gmv' ? 'Rp ' + new Intl.NumberFormat('id-ID').format(creator.total_gmv) : (creator.engagement_rate || 0) + '%'}
                    </div>
                    <div style="font-size: 9px; color: var(--text-muted);">
                        ${type === 'gmv' ? (creator.total_orders || 0) + ' orders' : 'GMV: Rp ' + new Intl.NumberFormat('id-ID').format(creator.total_gmv || 0)}
                    </div>
                </div>
            </div>
        `;
    });
    
    container.innerHTML = html;
}
function attachMonitoringDetailEvents() {
    document.querySelectorAll('.view-monitoring-detail-btn').forEach(btn => {
        // Hapus event listener lama jika ada
        const newBtn = btn.cloneNode(true);
        btn.parentNode.replaceChild(newBtn, btn);
        
        newBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            const creatorId = newBtn.getAttribute('data-creator-id');
            console.log('Detail button clicked for creator:', creatorId);
            if (creatorId) {
                showMonitoringDetailModal(creatorId);
            } else {
                showToastGlobal('Creator ID tidak ditemukan', 'error');
            }
        });
    });
}


// ========== INITIALIZATION ==========
document.addEventListener('DOMContentLoaded', () => {
    console.log('IS Dashboard initialized');
    
    updateAddCreatorButtons();
    
    loadTask2CreatorsIS();
    loadTask3CreatorsIS();
    loadTask4CreatorsIS();
    
    initAllSearches();
});
</script>
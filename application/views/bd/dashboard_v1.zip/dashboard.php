<!-- file: application/views/bd/dashboard.php -->
<style>
    /* Dashboard styles */
    .dashboard-header {
        background: linear-gradient(135deg, #0f0f1a 0%, #13111f 100%);
        border-radius: 20px;
        padding: 16px 20px;
        margin-bottom: 20px;
        border: 1px solid var(--border);
        display: flex;
        justify-content: space-between;
        align-items: center;
        flex-wrap: wrap;
        gap: 16px;
    }
    
    .dashboard-title h1 { 
        font-size: 20px; 
        font-weight: 700; 
        background: linear-gradient(135deg, var(--purple), var(--cyan), var(--blue));
        -webkit-background-clip: text; 
        background-clip: text; 
        color: transparent;
    }
    
    .dashboard-title .sub { 
        font-size: 10px; 
        color: var(--text-secondary); 
        margin-top: 4px;
    }
    
    /* Desktop Menu */
    .desktop-menu {
        display: flex;
        gap: 12px;
        align-items: center;
        flex-wrap: wrap;
    }
    
    .desktop-menu a {
        color: var(--text-muted);
        text-decoration: none;
        font-size: 13px;
        font-weight: 500;
        padding: 6px 14px;
        border-radius: 40px;
        transition: var(--transition);
    }
    
    .desktop-menu a:hover, .desktop-menu a.active {
        background: var(--purple-glow);
        color: var(--purple);
    }
    
    .stat-cards-dashboard { 
        display: flex; 
        gap: 20px; 
        background: rgba(139, 92, 246, 0.1);
        padding: 6px 16px; 
        border-radius: 60px; 
        border: 1px solid var(--border);
    }
    
    .stat-item-dashboard { text-align: center; padding: 2px 6px; }
    .stat-label-dashboard { font-size: 9px; color: var(--text-muted); }
    .stat-value-dashboard { font-size: 18px; font-weight: 700; background: linear-gradient(135deg, var(--purple), var(--blue)); -webkit-background-clip: text; background-clip: text; color: transparent; }
    
    /* XP Bar */
    .xp-container-dashboard { 
        background: linear-gradient(135deg, var(--bg-card), var(--bg-elevated));
        border-radius: 60px; 
        padding: 8px 16px; 
        margin-bottom: 20px; 
        border: 1px solid var(--border);
    }
    
    .xp-header-dashboard { display: flex; justify-content: space-between; align-items: center; margin-bottom: 5px; }
    .xp-text-dashboard { font-size: 10px; color: var(--text-secondary); }
    .progress-bar-dashboard { height: 4px; background: var(--border); border-radius: 10px; overflow: hidden; }
    .progress-fill-dashboard { height: 100%; background: linear-gradient(90deg, var(--purple), var(--cyan)); border-radius: 10px; transition: width 0.5s ease; }
    
    /* Tabs */
    .tabs-bar-dashboard { display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 12px; margin-bottom: 20px; border-bottom: 1px solid var(--border); padding-bottom: 10px; }
    .tabs-dashboard { display: flex; gap: 6px; flex-wrap: wrap; }
    .tab-btn-dashboard { background: transparent; border: none; padding: 6px 16px; font-size: 12px; font-weight: 600; color: var(--text-muted); cursor: pointer; border-radius: 40px; transition: var(--transition); }
    .tab-btn-dashboard.active { background: linear-gradient(135deg, var(--purple-glow), rgba(59, 130, 246, 0.1)); color: var(--purple); border: 1px solid rgba(139, 92, 246, 0.4); }
    .scout-btn-dashboard { background: linear-gradient(135deg, var(--purple-glow), rgba(6, 182, 212, 0.1)); border: 1px solid var(--purple); padding: 6px 16px; border-radius: 40px; color: var(--purple); font-weight: 600; cursor: pointer; font-size: 12px; transition: var(--transition); }
    .scout-btn-dashboard:hover { background: var(--purple); color: white; }
    
    .tab-content-dashboard { display: none; animation: fadeIn 0.3s ease; }
    .tab-content-dashboard.active { display: block; }
    
    /* Stages Container - Scroll Horizontal */
    .stages-scroll-dashboard { 
    overflow-x: auto; 
    overflow-y: visible;
    margin-bottom: 20px; 
    padding-bottom: 12px;
}
.stages-container-dashboard { 
    display: flex; 
    flex-direction: row;
    gap: 20px; 
    min-width: min-content;
    justify-content: center;  /* Tengahkan jika muat */
}

/* Perlebar card untuk 3 task */
.stage-card-dashboard { 
    border-radius: 20px; 
    padding: 20px;  /* Tambah padding */
    width: 400px;   /* Lebar dari 340px jadi 400px */
    flex-shrink: 0;
    transition: var(--transition); 
    position: relative; 
    overflow: hidden;
    border: 1px solid var(--border);
}
    
    /* Task 1: Ungu */
    .stage-card-dashboard[data-stage="1"] { background: linear-gradient(135deg, #1a1030, #13111f); border-top: 3px solid var(--purple); }
    /* Task 2: Biru */
    .stage-card-dashboard[data-stage="2"] { background: linear-gradient(135deg, #0f1a2e, #13111f); border-top: 3px solid var(--blue); }
    /* Task 3: Cyan */
    .stage-card-dashboard[data-stage="3"] { background: linear-gradient(135deg, #0a1a1f, #13111f); border-top: 3px solid var(--cyan); }
    /* Task 4: Hijau */
    .stage-card-dashboard[data-stage="4"] { background: linear-gradient(135deg, #0a1f15, #13111f); border-top: 3px solid var(--green); }
    
    .stage-card-dashboard.completed { opacity: 0.7; }
    
    .stage-title-dashboard { 
        font-weight: 700; 
        font-size: 14px; 
        margin-bottom: 14px; 
        padding-bottom: 8px; 
        border-bottom: 1px solid var(--border); 
        display: flex; 
        align-items: center; 
        gap: 10px; 
        flex-wrap: wrap; 
        justify-content: space-between; 
        color: var(--text-primary);
    }
    
    .stage-count-dashboard { background: var(--bg-elevated); padding: 2px 8px; border-radius: 40px; font-size: 10px; }
    
    /* Brand Items */
    .stage-item-dashboard { 
        background: var(--bg-elevated); 
        border-radius: 14px; 
        padding: 12px; 
        margin-bottom: 10px; 
        cursor: pointer; 
        transition: var(--transition); 
        border: 1px solid transparent;
    }
    .stage-item-dashboard:hover { border-color: var(--purple); transform: translateX(3px); }
    .stage-item-dashboard strong { display: flex; align-items: center; gap: 8px; margin-bottom: 6px; color: var(--text-primary); font-size: 13px; }
    .brand-details-dashboard { display: flex; flex-wrap: wrap; gap: 10px; font-size: 10px; color: var(--text-secondary); margin-bottom: 6px; }
    .badge-dashboard { display: inline-flex; align-items: center; gap: 4px; padding: 2px 8px; border-radius: 20px; font-size: 9px; font-weight: 600; }
    .badge-pending { background: rgba(245, 158, 11, 0.15); color: #f59e0b; }
    .badge-negotiating { background: rgba(59, 130, 246, 0.15); color: #3b82f6; }
    .badge-deal { background: rgba(139, 92, 246, 0.15); color: #8b5cf6; }
    .badge-active { background: rgba(16, 185, 129, 0.15); color: #10b981; }
    
    .task-btn-dashboard { 
        margin-top: 14px; 
        width: 100%; 
        padding: 8px; 
        border-radius: 40px; 
        border: none; 
        background: var(--bg-elevated);
        color: var(--text-secondary); 
        font-weight: 600; 
        cursor: pointer; 
        transition: var(--transition); 
        font-size: 12px;
    }
    .task-btn-dashboard:hover:not(:disabled) { background: linear-gradient(135deg, var(--purple), var(--blue)); color: white; }
    .task-btn-dashboard:disabled { opacity: 0.5; cursor: not-allowed; }
    
    /* Modal */
    .modal-overlay-dashboard { position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.9); backdrop-filter: blur(8px); display: flex; align-items: center; justify-content: center; z-index: 2000; visibility: hidden; opacity: 0; transition: 0.2s; }
    .modal-overlay-dashboard.active { visibility: visible; opacity: 1; }
    .modal-glass-dashboard {
        background: #111827;
        border-radius: 28px;
        width: 95%;
        max-width: 550px;
        padding: 24px;
        border: 1px solid #4ade80;
        max-height: 85vh;
        overflow-y: auto;
        color: #e2f0e8;
    }
    .modal-header-dashboard { display: flex; justify-content: space-between; align-items: center; margin-bottom: 16px; border-bottom: 1px solid #2a3346; padding-bottom: 10px; }
    .modal-header-dashboard h3 { color: #e2f0e8; font-size: 18px; }
    .modal-close-dashboard { font-size: 26px; cursor: pointer; color: #9aaebe; }
    .modal-body label {
        color: #bdf2c0;
        font-weight: 500;
        display: block;
        margin-top: 14px;
        margin-bottom: 5px;
        font-size: 13px;
    }
    .modal-body input, .modal-body select, .modal-body textarea {
        width: 100%;
        padding: 10px 12px;
        background: #0f1420;
        border: 1px solid #2a3346;
        border-radius: 14px;
        color: #e2f0e8;
        font-size: 13px;
    }
    .modal-body input:focus, .modal-body select:focus {
        outline: none;
        border-color: #4ade80;
    }
    .modal-body button {
        background: #4ade80;
        color: #0a0e17;
        border: none;
        padding: 10px 18px;
        border-radius: 40px;
        font-weight: 600;
        cursor: pointer;
        transition: 0.2s;
        font-size: 13px;
    }
    .modal-body button:hover { background: #22c55e; }
    .flex-buttons { display: flex; gap: 10px; margin-top: 16px; }
    .flex-buttons button { flex: 1; }
    
    .product-item { background: #0f1420; border-radius: 12px; padding: 10px; margin-top: 8px; display: flex; justify-content: space-between; align-items: center; border: 1px solid #2a3346; }
    .product-info { flex: 1; }
    .product-name { color: #ffffff; font-size: 12px; font-weight: 500; }
    .product-price { color: #4ade80; font-size: 11px; margin-top: 3px; }
    
    /* Recent Orders */
    .recent-section-dashboard { background: var(--bg-card); border-radius: 20px; padding: 16px; border: 1px solid var(--border); overflow-x: auto; margin-top: 20px; }
    .recent-table-dashboard { width: 100%; min-width: 550px; border-collapse: collapse; }
    .recent-table-dashboard th, .recent-table-dashboard td { padding: 8px 6px; text-align: left; border-bottom: 1px solid var(--border); font-size: 11px; color: var(--text-secondary); }
    .recent-table-dashboard th { color: var(--purple); font-weight: 600; }
    .pagination-dashboard { display: flex; gap: 8px; justify-content: center; margin-top: 12px; }
    .pagination-dashboard button { background: var(--bg-elevated); border: 1px solid var(--border); color: var(--text-secondary); padding: 5px 14px; border-radius: 30px; cursor: pointer; font-size: 11px; }
    .pagination-dashboard button:hover:not(:disabled) { background: var(--purple); color: white; }
    .pagination-dashboard button:disabled { opacity: 0.5; cursor: not-allowed; }
    
    /* Brands Grid */
    .brands-grid-dashboard { display: flex; flex-direction: column; gap: 16px; }
    .brand-card-dashboard { background: var(--bg-card); border-radius: 20px; padding: 16px; border: 1px solid var(--border); }
    .brand-item-row-dashboard { display: flex; justify-content: space-between; align-items: center; padding: 10px 0; border-bottom: 1px solid var(--border); flex-wrap: wrap; gap: 6px; }
    
    /* Sidebar */
    .sidebar-dashboard { background: var(--bg-card); width: 350px; max-width: 85vw; height: 100%; position: fixed; right: 0; top: 0; padding: 20px; overflow-y: auto; transform: translateX(100%); transition: transform 0.3s ease; border-left: 1px solid var(--purple); z-index: 2100; }
    .sidebar-dashboard.active { transform: translateX(0); }
    .brand-card-popup-dashboard { background: var(--bg-elevated); border-radius: 14px; padding: 12px; margin-bottom: 12px; border: 1px solid var(--border-light); }
    
    /* Mobile Bottom Nav */
    .mobile-bottom-nav-dashboard { display: none; position: fixed; bottom: 0; left: 0; right: 0; background: var(--bg-card); border-top: 1px solid var(--border); padding: 6px 12px; justify-content: space-around; z-index: 100; }
    .mobile-nav-item-dashboard { display: flex; flex-direction: column; align-items: center; gap: 2px; color: var(--text-muted); text-decoration: none; font-size: 9px; padding: 6px; border-radius: 40px; }
    .mobile-nav-item-dashboard i { font-size: 16px; }
    .mobile-nav-item-dashboard.active { color: var(--purple); background: var(--purple-glow); }
    
    .mt-3 { margin-top: 8px; }
    .text-center { text-align: center; }
    .text-success { color: #10b981; }
    .text-warning { color: #f59e0b; }
    
    @media (min-width: 768px) {
        .mobile-bottom-nav-dashboard { display: none; }
        .desktop-menu { display: flex; }
        .stage-card-dashboard { width: 360px; }
    }
    
    @media (max-width: 767px) {
        .mobile-bottom-nav-dashboard { display: flex; }
        body { padding-bottom: 60px; }
        .dashboard-header { flex-direction: column; text-align: center; padding: 14px; }
        .stat-cards-dashboard { justify-content: center; flex-wrap: wrap; gap: 12px; }
        .desktop-menu { display: none; }
        .stage-card-dashboard { width: 300px; padding: 14px; }
        .modal-glass-dashboard { width: 95%; padding: 18px; }
        .dashboard-title h1 { font-size: 18px; }
    }
    
    @media (min-width: 769px) {
        .desktop-menu { display: flex; }
    }
    
    .auto-badge {
    background: #4ade80;
    color: #0a0e17;
    font-size: 8px;
    padding: 2px 6px;
    border-radius: 10px;
    margin-left: 6px;
    white-space: nowrap;
}

.text-success {
    color: #4ade80;
}

.text-warning {
    color: #f59e0b;
}
/* Styling untuk input komisi di modal */
input[type="number"] {
    transition: all 0.2s ease;
}

input[type="number"]:focus {
    border-color: #4ade80;
    outline: none;
    box-shadow: 0 0 5px rgba(74, 222, 128, 0.3);
}

/* Label styling */
label {
    font-size: 12px;
    font-weight: 500;
    margin-bottom: 6px;
    display: block;
}
.shop-option:hover {
    background: #1a1f2e !important;
    border-color: #4ade80 !important;
    transform: translateX(4px);
}
/* Leaderboard Table Styles */
.leaderboard-container-dashboard {
    animation: fadeIn 0.3s ease;
}

.leaderboard-table-dashboard th {
    color: var(--purple);
    font-size: 11px;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

.leaderboard-table-dashboard td {
    font-size: 12px;
}

.leaderboard-table-dashboard tbody tr {
    transition: background 0.2s ease;
}

.leaderboard-table-dashboard tbody tr:hover {
    background: rgba(139, 92, 246, 0.05);
}

/* Responsive */
@media (max-width: 768px) {
    .leaderboard-table-dashboard th,
    .leaderboard-table-dashboard td {
        padding: 8px 4px;
        font-size: 10px;
    }
    
    .leaderboard-table-dashboard th:first-child,
    .leaderboard-table-dashboard td:first-child {
        width: 50px;
    }
    
    .leaderboard-table-dashboard th:nth-child(3),
    .leaderboard-table-dashboard td:nth-child(3),
    .leaderboard-table-dashboard th:nth-child(5),
    .leaderboard-table-dashboard td:nth-child(5),
    .leaderboard-table-dashboard th:nth-child(6),
    .leaderboard-table-dashboard td:nth-child(6) {
        display: none;
    }
}
/* Animasi scrolling teks dari kanan ke kiri */
@keyframes scrollBDText {
    0% {
        transform: translateX(0);
    }
    100% {
        transform: translateX(-50%);
    }
}

.bd-scroll-wrapper {
    mask-image: linear-gradient(to right, transparent, black 10%, black 90%, transparent);
    -webkit-mask-image: linear-gradient(to right, transparent, black 10%, black 90%, transparent);
}

.bd-scroll-wrapper:hover .bd-scroll-content {
    animation-play-state: paused;
}

#globalToast {
    position: fixed;
    bottom: 20px;
    right: 20px;
    background: #10b981;
    color: white;
    padding: 12px 20px;
    border-radius: 12px;
    font-size: 13px;
    z-index: 9999;
    animation: slideIn 0.3s ease;
    box-shadow: 0 4px 12px rgba(0,0,0,0.3);
}

@keyframes slideIn {
    from { transform: translateX(100%); opacity: 0; }
    to { transform: translateX(0); opacity: 1; }
}

@keyframes slideOut {
    from { transform: translateX(0); opacity: 1; }
    to { transform: translateX(100%); opacity: 0; }
}

/* Toast di dalam modal */
.modal-toast {
    position: sticky;
    top: 10px;
    background: #10b981;
    color: white;
    padding: 12px 16px;
    border-radius: 12px;
    font-size: 13px;
    font-weight: 500;
    margin-bottom: 16px;
    animation: slideInDown 0.3s ease;
    z-index: 100;
    backdrop-filter: blur(4px);
    box-shadow: 0 4px 12px rgba(0,0,0,0.2);
    display: flex;
    align-items: center;
    gap: 10px;
}

.modal-toast.error {
    background: #ef4444;
}

.modal-toast.warning {
    background: #f59e0b;
}

.modal-toast.info {
    background: #3b82f6;
}

.modal-toast i {
    font-size: 16px;
}

@keyframes slideInDown {
    from {
        transform: translateY(-20px);
        opacity: 0;
    }
    to {
        transform: translateY(0);
        opacity: 1;
    }
}

@keyframes slideOutUp {
    from {
        transform: translateY(0);
        opacity: 1;
    }
    to {
        transform: translateY(-20px);
        opacity: 0;
    }
}

</style>
<!-- Desktop Menu - hanya muncul di desktop -->
<div class="desktop-menu">
    <a href="<?= base_url('bd/dashboard') ?>" class="active"><i class="fas fa-tachometer-alt"></i> Dashboard</a>
    <a href="<?= base_url('bd/brands') ?>"><i class="fas fa-building"></i> Brands</a>
    <a href="<?= base_url('bd/campaigns') ?>"><i class="fas fa-bullhorn"></i> Campaigns</a>
    <a href="<?= base_url('link_management') ?>" ><i class="fas fa-link"></i> Link Management</a>
    <a href="<?= base_url('bd/team_performance') ?>"><i class="fas fa-users"></i> Team Performance</a>
    <a href="<?= base_url('tts/status') ?>"><i class="fas fa-sync"></i> Sync API</a>
    <a href="<?= base_url('analytics/bd') ?>"><i class="fas fa-chart-line"></i> Analytics</a>
</div>

<!-- Mobile Menu Bar (horizontal scroll) -->
<div class="mobile-menu-bar">
    <a href="<?= base_url('bd/dashboard') ?>" class="active"><i class="fas fa-tachometer-alt"></i> Dashboard</a>
    <a href="<?= base_url('bd/brands') ?>"><i class="fas fa-building"></i> Brands</a>
    <a href="<?= base_url('bd/campaigns') ?>"><i class="fas fa-bullhorn"></i> Campaigns</a>
    <a href="<?= base_url('tts/status') ?>"><i class="fas fa-sync"></i> Sync API</a>
</div>

<div class="dashboard">
    <!-- Dashboard Header -->
    <div class="dashboard-header">
        <div class="dashboard-title">
            <h1>BA Dashboard</h1>
            <div class="sub"><i class="fas fa-users"></i> Managing <?= $total_brands ?> Brand Partners �� Real-time API</div>
            <input type="hidden" id="isSupervisorHidden" value="<?= $is_supervisor ? 'true' : 'false' ?>">
        </div>
        <div class="stat-cards-dashboard">
            <div class="stat-item-dashboard">
                <div class="stat-label-dashboard">GMV</div>
                <div class="stat-value-dashboard">Rp <?= number_format($total_gmv, 0, ',', '.') ?></div>
            </div>
            <div class="stat-item-dashboard">
                <div class="stat-label-dashboard">Bonus</div>
                <div class="stat-value-dashboard">Rp <?= number_format($deal_bonus_amount, 0, ',', '.') ?></div>
            </div>
            <div class="stat-item-dashboard">
                <div class="stat-label-dashboard">Status</div>
                <div class="stat-value-dashboard" style="font-size:14px;"><i class="fas fa-circle" style="color:#10b981; font-size:8px;"></i> LIVE</div>
            </div>
        </div>
    </div>
    
    <!-- Tabs -->
    <div class="tabs-bar-dashboard">
        <div class="tabs-dashboard">
            <button class="tab-btn-dashboard active" data-tab="tabTaskDashboard"><i class="fas fa-clipboard-list"></i> Task</button>
            <button class="tab-btn-dashboard" data-tab="tabBrandStatusDashboard"><i class="fas fa-tags"></i> Status Brand</button>
            <button class="tab-btn-dashboard" data-tab="tabLeaderboardDashboard"><i class="fas fa-trophy"></i> Leaderboard</button>
        </div>
        <!-- �9�7 LEADERBOARD BD BERJALAN -->
<div class="bd-leaderboard-mini" style="display: flex; align-items: center; gap: 8px; background: rgba(139, 92, 246, 0.08); padding: 4px 12px; border-radius: 40px; border: 1px solid rgba(139, 92, 246, 0.2); flex-shrink: 0;">
    <div style="display: flex; align-items: center; gap: 4px; flex-shrink: 0;">
        <i class="fas fa-trophy" style="color: #fbbf24; font-size: 11px;"></i>
        <span style="font-size: 9px; font-weight: 600; color: var(--purple);">BD TOP 3</span>
        <span style="font-size: 8px; color: var(--text-muted);">(7 hari)</span>
    </div>
    
    <div class="bd-scroll-wrapper" style="overflow: hidden; flex: 1; position: relative; min-width: 0;">
        <div class="bd-scroll-content" style="display: flex; gap: 16px; animation: scrollBDText 15s linear infinite; white-space: nowrap;">
            <?php foreach ($top_3_bd as $index => $bd): ?>
    <div style="display: inline-flex; align-items: center; gap: 6px; background: rgba(139, 92, 246, 0.1); padding: 4px 12px; border-radius: 30px;">
        <?php if ($index == 0): ?>
            <i class="fas fa-crown" style="color: #fbbf24; font-size: 10px;"></i>
        <?php elseif ($index == 1): ?>
            <i class="fas fa-medal" style="color: #c0c0c0; font-size: 10px;"></i>
        <?php else: ?>
            <i class="fas fa-medal" style="color: #cd7f32; font-size: 10px;"></i>
        <?php endif; ?>
        <span style="font-size: 10px; font-weight: 500; color: var(--text-primary);"><?= htmlspecialchars($bd->full_name ?: $bd->username) ?></span>
        <span style="font-size: 9px; color: #4ade80; font-weight: 600;">Rp <?= number_format($bd->total_gmv_7d, 0, ',', '.') ?></span>
    </div>
    <?php endforeach; ?>
        </div>
    </div>
</div>
        <button class="scout-btn-dashboard" id="scoutBtnDashboard"><i class="fas fa-search"></i> Cari Brand Baru</button>
    </div>
    
    <!-- ==================== TAB 1: TASK ==================== -->
    <div id="tabTaskDashboard" class="tab-content-dashboard active">
        <div class="stages-scroll-dashboard">
            <div class="stages-container-dashboard">
                <!-- TASK 1: HUNTING -->
                <div class="stage-card-dashboard" data-stage="1" style="display: flex; flex-direction: column; height: 500px;">
                    <div class="stage-title-dashboard" style="flex-shrink: 0;">
                        <span><i class="fas fa-search"></i> 1. HUNTING</span>
                        <span class="stage-count-dashboard" id="huntingCountDashboard"><?= count($hunting_items) ?></span>
                    </div>
                    <div style="flex-shrink: 0; padding: 8px 12px;">
                        <input type="text" id="searchHuntingDashboard" placeholder=" Cari brand..." style="width: 100%; padding: 6px 10px; border: 1px solid #ddd; border-radius: 6px; font-size: 12px;">
                    </div>
                    <div id="huntingItemsContainerDashboard" style="flex: 1; overflow-y: auto; padding: 0 8px;">
                        <?php if (!empty($hunting_items)): ?>
                            <?php foreach ($hunting_items as $item): ?>
                            <div class="stage-item-dashboard brand-item-dashboard" data-brand-id="<?= $item->id ?>" data-brand-name="<?= htmlspecialchars($item->name) ?>" data-stage="1">
                                <strong><i class="fas fa-building"></i> <?= htmlspecialchars($item->name) ?></strong>
                                <div class="brand-details-dashboard">
                                    <span><i class="fab fa-whatsapp"></i> <?= $item->whatsapp_number ?? '-' ?></span>
                                    <span><i class="fas fa-user"></i> Input: <?= $item->input_by ?? ($item->bd_username ?? '-') ?></span>
                                </div>
                                <span class="badge-dashboard badge-pending"><i class="fas fa-clock"></i> PENDING</span>
                                <div class="progress-bar-dashboard mt-3"><div class="progress-fill-dashboard" style="width: 33%"></div></div>
                            </div>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <div class="stage-item-dashboard"><strong><i class="fas fa-info-circle"></i> Belum ada brand</strong><div class="brand-details-dashboard">Klik "Cari Brand Baru"</div></div>
                        <?php endif; ?>
                    </div>
                    <button class="task-btn-dashboard" data-action="hunting" style="flex-shrink: 0; margin: 8px;"><i class="fas fa-plus-circle"></i> Input Brand Baru</button>
                </div>

                <!-- TASK 2: SETUP CAMPAIGN -->
              <div class="stage-card-dashboard" data-stage="3" style="display: flex; flex-direction: column; height: 500px;">
    <div class="stage-title-dashboard" style="flex-shrink: 0;">
        <span><i class="fas fa-rocket"></i> 2. SETUP CAMPAIGN</span>
        <span class="stage-count-dashboard" id="setupCountDashboard"><?= count($setup_items) ?></span>
    </div>
    <div style="flex-shrink: 0; padding: 8px 12px;">
        <input type="text" id="searchSetupDashboard" placeholder=" Cari brand..." style="width: 100%; padding: 6px 10px; border: 1px solid #ddd; border-radius: 6px; font-size: 12px;">
    </div>
    <div id="setupItemsContainerDashboard" style="flex: 1; overflow-y: auto; padding: 0 8px;">
        <?php if (!empty($setup_items)): ?>
            <?php foreach ($setup_items as $item): ?>
            <div class="stage-item-dashboard brand-item-dashboard" data-brand-id="<?= $item->id ?>" data-brand-name="<?= htmlspecialchars($item->name) ?>" data-stage="3">
                <strong><i class="fas fa-building"></i> <?= htmlspecialchars($item->name) ?></strong>
                <div class="brand-details-dashboard">
                    <span><i class="fab fa-whatsapp"></i> <?= $item->whatsapp_number ?? '-' ?></span>
                    <span><i class="fas fa-user"></i> Input: <?= $item->input_by ?? ($item->bd_username ?? '-') ?></span>
                    <span class="badge-dashboard" style="background: rgba(245, 158, 11, 0.15); color: #f59e0b;">
                        <i class="fas fa-clock"></i> <?= $item->pending_products_count ?? 0 ?> produk pending
                    </span>
                </div>
                <span class="badge-dashboard badge-deal"><i class="fas fa-cog"></i> MENUNGGU APPROVAL</span>
                <div class="progress-bar-dashboard mt-3"><div class="progress-fill-dashboard" style="width: 66%"></div></div>
            </div>
            <?php endforeach; ?>
        <?php else: ?>
            <div class="stage-item-dashboard"><strong><i class="fas fa-info-circle"></i> Belum ada brand di tahap setup</strong><div class="brand-details-dashboard">Brand akan muncul setelah deal dan memiliki produk pending review</div></div>
        <?php endif; ?>
    </div>
    <button class="task-btn-dashboard" data-action="setup" style="flex-shrink: 0; margin: 8px;"><i class="fas fa-plug"></i> Setup Campaign</button>
</div>

<!-- TASK 3: MONITORING -->
<div class="stage-card-dashboard" data-stage="4" style="display: flex; flex-direction: column; height: 500px;">
    <div class="stage-title-dashboard" style="flex-shrink: 0;">
        <span><i class="fas fa-chart-line"></i> 3. MONITORING</span>
        <span class="stage-count-dashboard" id="monitoringCountDashboard"><?= count($monitoring_items) ?></span>
    </div>
    <div style="flex-shrink: 0; padding: 8px 12px;">
        <input type="text" id="searchMonitoringDashboard" placeholder=" Cari brand..." style="width: 100%; padding: 6px 10px; border: 1px solid #ddd; border-radius: 6px; font-size: 12px;">
    </div>
    <div id="monitoringItemsContainerDashboard" style="flex: 1; overflow-y: auto; padding: 0 8px;">
        <?php if (!empty($monitoring_items)): ?>
            <?php foreach ($monitoring_items as $item): ?>
            <div class="stage-item-dashboard brand-item-dashboard" data-brand-id="<?= $item->id ?>" data-brand-name="<?= htmlspecialchars($item->name) ?>" data-stage="4">
                <strong><i class="fas fa-chart-line"></i> <?= htmlspecialchars($item->name) ?></strong>
                <div class="brand-details-dashboard">
                    <span><i class="fab fa-whatsapp"></i> <?= $item->whatsapp_number ?? '-' ?></span>
                    <span><i class="fas fa-user"></i> Input: <?= $item->input_by ?? ($item->bd_username ?? '-') ?></span>
                    <span><i class="fas fa-money-bill-wave"></i> GMV: Rp <?= number_format($item->total_gmv ?? 0, 0, ',', '.') ?></span>
                    <span><i class="fas fa-chart-line"></i> ROAS: <?= $item->roas ?? 0 ?>x</span>
                    <span class="badge-dashboard" style="background: rgba(16, 185, 129, 0.15); color: #10b981;">
                        <i class="fas fa-check-circle"></i> <?= $item->approved_products_count ?? 0 ?> produk approve
                    </span>
                </div>
                <span class="badge-dashboard badge-active">
                    <i class="fas fa-chart-simple"></i> AKTIF
                </span>
                <div class="progress-bar-dashboard mt-3"><div class="progress-fill-dashboard" style="width: 100%"></div></div>
            </div>
            <?php endforeach; ?>
        <?php else: ?>
            <div class="stage-item-dashboard"><strong><i class="fas fa-info-circle"></i> Belum ada brand aktif</strong><div class="brand-details-dashboard">Brand akan muncul saat memiliki produk approved</div></div>
        <?php endif; ?>
    </div>
    <button class="task-btn-dashboard" data-action="monitoring" style="flex-shrink: 0; margin: 8px;"><i class="fas fa-chart-simple"></i> Lihat Laporan</button>
</div>

            </div>
        </div>
        
        <!-- Recent Orders - HANYA DI DALAM TAB TASK -->
        <div class="recent-section-dashboard">
            <div style="display:flex; justify-content:space-between; margin-bottom:12px; flex-wrap:wrap; gap:6px;">
                <h3 style="color:var(--text-primary); font-size:13px;"><i class="fas fa-box"></i> <h3 style="color:var(--text-primary); font-size:13px;"><i class="fas fa-box"></i> Pesanan Hari Ini (<?= date('d/m/Y') ?>)</h3>
                <div style="color:var(--text-muted); font-size:11px;"><span id="orderRangeDashboard">1-10</span> / <span id="totalOrdersDashboard"><?= count($orders) ?></span></div>
            </div>
            <div style="overflow-x:auto">
                <table class="recent-table-dashboard">
                    <thead>
                        <tr>
                            <th>Tanggal</th>
                            <th>Produk</th>
                            <th>Creator</th>
                            <th>GMV</th>
                            <th>Komisi</th>
                        </tr>
                    </thead>
                    <tbody id="recentOrdersBodyDashboard"></tbody>
                </table>
            </div>
            <div class="pagination-dashboard">
                <button id="prevPageBtnDashboard" disabled><i class="fas fa-chevron-left"></i> Sebelumnya</button>
                <button id="nextPageBtnDashboard">Selanjutnya <i class="fas fa-chevron-right"></i></button>
            </div>
        </div>
    </div>
    
    <!-- ==================== TAB 2: STATUS BRAND ==================== -->
<!-- TAB STATUS BRAND -->
<div id="tabBrandStatusDashboard" class="tab-content-dashboard">
    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
        
        <!-- KOLOM KIRI: BRAND TIDAK AKTIF -->
        <div class="brand-card-dashboard" style="background: var(--bg-card); border-radius: 20px; padding: 16px; border: 1px solid var(--border);">
            <h3 style="color: var(--text-primary); margin-bottom: 16px; font-size: 14px; display: flex; align-items: center; gap: 8px;">
                <i class="fas fa-clock" style="color: #f59e0b;"></i> 
                Brand Tidak Aktif
                <span class="badge-dashboard" style="background: rgba(245, 158, 11, 0.15); color: #f59e0b; margin-left: 8px;">
                    <?= count($inactive_brands) ?>
                </span>
            </h3>
            <div style="max-height: 500px; overflow-y: auto;">
                <?php if (!empty($inactive_brands)): ?>
                    <?php foreach ($inactive_brands as $brand): ?>
                    <div class="brand-item-row-dashboard" style="display: flex; justify-content: space-between; align-items: center; padding: 12px 0; border-bottom: 1px solid var(--border);">
                        <div>
                            <strong style="color: var(--text-primary); font-size: 13px;"><?= htmlspecialchars($brand->name) ?></strong>
                            <div style="display: flex; gap: 10px; margin-top: 4px; flex-wrap: wrap;">
                                <span style="font-size: 10px; color: var(--text-muted);">
                                    <i class="fas fa-user"></i> Input: <?= $brand->input_by ?? ($brand->bd_username ?? '-') ?>
                                </span>
                                <span class="badge-dashboard" style="background: rgba(245, 158, 11, 0.15); color: #f59e0b; font-size: 9px;">
                                    <?= $brand->status ?>
                                </span>
                            </div>
                        </div>
                        <div>
                            <?php if ($brand->status == 'PENDING'): ?>
                                <span style="font-size: 11px; color: #f59e0b;"><i class="fas fa-hourglass-half"></i> Hunting</span>
                            <?php elseif ($brand->status == 'CAMPAIGN_READY'): ?>
                                <span style="font-size: 11px; color: #8b5cf6;"><i class="fas fa-rocket"></i> Setup</span>
                            <?php else: ?>
                                <span style="font-size: 11px; color: #6b7280;"><i class="fas fa-pause"></i> <?= $brand->status ?></span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <div class="text-center" style="color: var(--text-muted); padding: 40px;">
                        <i class="fas fa-check-circle" style="font-size: 32px; margin-bottom: 12px; display: block;"></i>
                        <p>Semua brand sudah aktif!</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
        
        <!-- KOLOM KANAN: BRAND AKTIF -->
        <div class="brand-card-dashboard" style="background: var(--bg-card); border-radius: 20px; padding: 16px; border: 1px solid var(--border);">
            <h3 style="color: var(--text-primary); margin-bottom: 16px; font-size: 14px; display: flex; align-items: center; gap: 8px;">
                <i class="fas fa-chart-line" style="color: #10b981;"></i> 
                Brand Aktif
                <span class="badge-dashboard" style="background: rgba(16, 185, 129, 0.15); color: #10b981; margin-left: 8px;">
                    <?= count($active_brands_list) ?>
                </span>
            </h3>
            <div style="max-height: 500px; overflow-y: auto;">
                <?php if (!empty($active_brands_list)): ?>
                    <?php foreach ($active_brands_list as $brand): ?>
                    <div class="brand-item-row-dashboard" style="display: flex; justify-content: space-between; align-items: center; padding: 12px 0; border-bottom: 1px solid var(--border);">
                        <div>
                            <strong style="color: var(--text-primary); font-size: 13px;"><?= htmlspecialchars($brand->name) ?></strong>

                            <div style="display: flex; gap: 10px; margin-top: 4px; flex-wrap: wrap;">
                                <span style="font-size: 10px; color: var(--text-muted);">
                                    <i class="fas fa-user"></i> Deal: <?= $brand->bd_name ?? $brand->bd_username ?? '-' ?>
                                </span>
                                <span style="font-size: 10px; color: #4ade80;">
                                    <i class="fas fa-chart-simple"></i> GMV: Rp <?= number_format($brand->total_gmv, 0, ',', '.') ?>
                                </span>
                            </div>
                        </div>
                        <div>
                            <span style="font-size: 11px; color: #10b981;">
                                <i class="fas fa-circle" style="font-size: 8px;"></i> ACTIVE
                            </span>
                        </div>
                    </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <div class="text-center" style="color: var(--text-muted); padding: 40px;">
                        <i class="fas fa-store" style="font-size: 32px; margin-bottom: 12px; display: block;"></i>
                        <p>Belum ada brand aktif</p>
                        <p style="font-size: 11px; margin-top: 8px;">Selesaikan deal dengan brand untuk menampilkannya di sini.</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
        
    </div>
</div>
    <!-- ==================== TAB 3: LEADERBOARD ==================== -->
    <div id="tabLeaderboardDashboard" class="tab-content-dashboard">
        <div class="leaderboard-container-dashboard" style="background: var(--bg-card); border-radius: 20px; padding: 20px; border: 1px solid var(--border);">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; flex-wrap: wrap; gap: 10px;">
                <div>
                    <h3 style="color: var(--text-primary); font-size: 16px; margin: 0;">
                        <i class="fas fa-trophy" style="color: var(--purple);"></i> Top 10 Brands by GMV
                    </h3>
                    <p style="font-size: 11px; color: var(--text-muted); margin-top: 5px;">
                        <i class="fas fa-calendar-alt"></i> Periode: <?= date('d/m/Y', strtotime('-7 days')) ?> - <?= date('d/m/Y') ?> (7 hari terakhir)
                    </p>
                </div>
                <button id="refreshLeaderboardBtn" class="btn-secondary" style="background: var(--bg-elevated); border: 1px solid var(--border); padding: 6px 14px; border-radius: 20px; cursor: pointer; font-size: 11px; color: var(--text-secondary);">
                    <i class="fas fa-sync-alt"></i> Refresh
                </button>
            </div>
            
            <div style="overflow-x: auto;">
                <table class="leaderboard-table-dashboard" style="width: 100%; border-collapse: collapse;">
                    <thead>
                        <tr style="border-bottom: 2px solid var(--border);">
                            <th style="padding: 12px 8px; text-align: center; width: 70px;">Rank</th>
                            <th style="padding: 12px 8px; text-align: left;">Brand</th>
                            <th style="padding: 12px 8px; text-align: left;">Kategori</th>
                            <th style="padding: 12px 8px; text-align: right;">GMV (7 hari)</th>
                            <th style="padding: 12px 8px; text-align: center;">Orders</th>
                            <th style="padding: 12px 8px; text-align: center;">Creators</th>
                            <th style="padding: 12px 8px; text-align: center;">ROAS</th>
                            <th style="padding: 12px 8px; text-align: left;">Deal oleh</th>
                        </tr>
                    </thead>
                    <tbody id="leaderboardBodyDashboard">
                        <?php if (!empty($leaderboard_brands)): ?>
                            <?php foreach ($leaderboard_brands as $brand): ?>
                            <tr style="border-bottom: 1px solid var(--border);">
                                <td style="padding: 12px 8px; text-align: center;">
                                    <?php if ($brand['rank'] == 1): ?>
                                        <i class="fas fa-crown" style="color: #fbbf24; font-size: 24px;"></i>
                                    <?php elseif ($brand['rank'] == 2): ?>
                                        <i class="fas fa-medal" style="color: #c0c0c0; font-size: 24px;"></i>
                                    <?php elseif ($brand['rank'] == 3): ?>
                                        <i class="fas fa-medal" style="color: #cd7f32; font-size: 24px;"></i>
                                    <?php else: ?>
                                        <span style="font-weight: 700; color: var(--purple); font-size: 16px;">#<?= $brand['rank'] ?></span>
                                    <?php endif; ?>
                                </td>
                                <td style="padding: 12px 8px; text-align: left;">
                                    <strong style="color: var(--text-primary); font-size: 14px;"><?= htmlspecialchars($brand['brand_name']) ?></strong>
                                </td>
                                <td style="padding: 12px 8px; text-align: left;">
                                    <span class="badge-dashboard" style="background: rgba(139, 92, 246, 0.15); color: #8b5cf6; font-size: 10px;">
                                        <?= htmlspecialchars($brand['category']) ?>
                                    </span>
                                </td>
                                <td style="padding: 12px 8px; text-align: right; color: #4ade80; font-weight: 600;">
                                    Rp <?= number_format($brand['total_gmv'], 0, ',', '.') ?>
                                </td>
                                <td style="padding: 12px 8px; text-align: center;">
                                    <?= number_format($brand['total_orders']) ?>
                                </td>
                                <td style="padding: 12px 8px; text-align: center;">
                                    <?= number_format($brand['total_creators']) ?>
                                </td>
                                <td style="padding: 12px 8px; text-align: center;">
                                    <span style="color: <?= $brand['roas'] >= 3 ? '#4ade80' : ($brand['roas'] >= 1 ? '#f59e0b' : '#ef4444') ?>; font-weight: 600;">
                                        <?= $brand['roas'] ?>x
                                    </span>
                                </td>
                                <td style="padding: 12px 8px; text-align: left;">
                                    <div style="display: flex; align-items: center; gap: 8px;">
                                        <div style="width: 28px; height: 28px; background: var(--purple-glow); border-radius: 50%; display: flex; align-items: center; justify-content: center;">
                                            <i class="fas fa-user" style="color: var(--purple); font-size: 12px;"></i>
                                        </div>
                                        <div>
                                            <div style="font-size: 13px; font-weight: 500; color: var(--text-primary);">
                                                <?= htmlspecialchars($brand['bd_name'] != '-' ? $brand['bd_name'] : $brand['bd_username']) ?>
                                            </div>
                                            <?php if ($brand['input_by'] && $brand['input_by'] != '-'): ?>
                                            <div style="font-size: 9px; color: var(--text-muted);">
                                                <i class="fas fa-user-plus"></i> Input: <?= htmlspecialchars($brand['input_by']) ?>
                                            </div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="8" style="padding: 60px 20px; text-align: center; color: var(--text-muted);">
                                    <i class="fas fa-chart-line" style="font-size: 48px; margin-bottom: 16px; display: block; opacity: 0.5;"></i>
                                    <p style="font-size: 14px;">Belum ada data transaksi dalam 7 hari terakhir</p>
                                    <p style="font-size: 11px; margin-top: 8px;">Segera deal dengan brand dan dapatkan transaksi untuk masuk leaderboard!</p>
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
            
            <?php if (!empty($leaderboard_brands)): ?>
            <div style="margin-top: 20px; padding-top: 16px; border-top: 1px solid var(--border); display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 10px;">
                <div style="font-size: 11px; color: var(--text-muted);">
                    <i class="fas fa-info-circle"></i> Berdasarkan data transaksi 7 hari terakhir (<?= date('d/m/Y', strtotime('-7 days')) ?> - <?= date('d/m/Y') ?>)
                    <span style="margin-left: 12px;">| Update: <?= date('d/m/Y H:i') ?></span>
                </div>
                <div style="display: flex; gap: 6px;">
                    <span style="font-size: 10px; display: inline-flex; align-items: center; gap: 4px;">
                        <span style="display: inline-block; width: 10px; height: 10px; background: #4ade80; border-radius: 2px;"></span> ROAS �� 3x
                    </span>
                    <span style="font-size: 10px; display: inline-flex; align-items: center; gap: 4px;">
                        <span style="display: inline-block; width: 10px; height: 10px; background: #f59e0b; border-radius: 2px;"></span> ROAS 1-3x
                    </span>
                    <span style="font-size: 10px; display: inline-flex; align-items: center; gap: 4px;">
                        <span style="display: inline-block; width: 10px; height: 10px; background: #ef4444; border-radius: 2px;"></span> ROAS &lt; 1x
                    </span>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Modal Task -->
<div id="taskModalDashboard" class="modal-overlay-dashboard">
    <div class="modal-glass-dashboard">
        <div class="modal-header-dashboard">
            <h3 id="modalTitleDashboard"><i class="fas fa-tasks"></i> Task</h3>
            <span class="modal-close-dashboard" id="closeTaskModalDashboard" onclick="document.getElementById('taskModalDashboard').classList.remove('active'); return false;" style="cursor: pointer; font-size: 26px;">&times;</span>
        </div>
        <div class="modal-body" id="modalBodyDashboard"></div>
    </div>
</div>

<!-- Mobile Bottom Navigation -->
<div class="mobile-bottom-nav-dashboard">
    <a href="#" class="mobile-nav-item-dashboard active" data-tab="tabTaskDashboard"><i class="fas fa-tasks"></i><span>Task</span></a>
    <a href="#" class="mobile-nav-item-dashboard" data-tab="tabBrandStatusDashboard"><i class="fas fa-building"></i><span>Brands</span></a>
    <a href="#" class="mobile-nav-item-dashboard" data-tab="tabLeaderboardDashboard"><i class="fas fa-trophy"></i><span>Top</span></a>
</div>

<script>

// ========== FUNGSI UTILITY ==========
function escapeHtml(str) {
    if (!str) return '';
    return String(str).replace(/[&<>]/g, function(m) {
        if (m === '&') return '&amp;';
        if (m === '<') return '&lt;';
        if (m === '>') return '&gt;';
        return m;
    });
}

function formatNumber(num) {
    if (num === undefined || num === null) return '0';
    return Number(num).toLocaleString('id-ID');
}

// �9�7 TAMBAHKAN FUNGSI COPY TO CLIPBOARD DI SINI
function copyToClipboard(text, productName, productId, buttonElement) {
    if (!text) return;
    
    // Buat teks lengkap untuk dicopy
    let copyText = '';
    if (productName && productId) {
        copyText = ` Product: ${productName}\n�9�4 Product ID: ${productId}\n�9�3 Link: ${text}`;
    } else {
        copyText = text;
    }
    
    navigator.clipboard.writeText(copyText).then(() => {
        // Tampilkan toast notifikasi
        showToastInModal(`Link untuk "${productName || 'produk'}" berhasil dicopy!`, 'success');
        
        // Feedback visual pada tombol yang diklik
        if (buttonElement) {
            const originalHtml = buttonElement.innerHTML;
            const originalBg = buttonElement.style.background;
            const originalColor = buttonElement.style.color;
            
            buttonElement.innerHTML = '<i class="fas fa-check"></i> Copied!';
            buttonElement.style.background = '#4ade80';
            buttonElement.style.color = '#0a0e17';
            
            setTimeout(() => {
                buttonElement.innerHTML = originalHtml;
                buttonElement.style.background = originalBg;
                buttonElement.style.color = originalColor;
            }, 2000);
        }
    }).catch(() => {
        // Fallback
        const textarea = document.createElement('textarea');
        textarea.value = copyText;
        document.body.appendChild(textarea);
        textarea.select();
        document.execCommand('copy');
        document.body.removeChild(textarea);
        showToastInModal(`�7�3 Link untuk "${productName || 'produk'}" berhasil dicopy!`, 'success');
        
        if (buttonElement) {
            const originalHtml = buttonElement.innerHTML;
            buttonElement.innerHTML = '<i class="fas fa-check"></i> Copied!';
            buttonElement.style.background = '#4ade80';
            buttonElement.style.color = '#0a0e17';
            setTimeout(() => {
                buttonElement.innerHTML = originalHtml;
                buttonElement.style.background = '#1e293b';
                buttonElement.style.color = '#4ade80';
            }, 2000);
        }
    });
}
const refreshLeaderboardBtn = document.getElementById('refreshLeaderboardBtn');
if (refreshLeaderboardBtn) {
    refreshLeaderboardBtn.addEventListener('click', function() {
        const btn = this;
        btn.innerHTML = '<i class="fas fa-spinner fa-pulse"></i> Refreshing...';
        btn.disabled = true;
        
        fetch(baseUrlDashboard + 'bd/refresh_leaderboard', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' }
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                showToastInModal('Leaderboard berhasil diperbarui!', 'success');
                setTimeout(() => location.reload(), 1000);
            } else {
                showToastInModal('Gagal refresh leaderboard', 'error');
                btn.innerHTML = '<i class="fas fa-sync-alt"></i> Refresh';
                btn.disabled = false;
            }
        })
        .catch(error => {
            console.error('Error:', error);
            showToastInModal('Gagal refresh leaderboard', 'error');
            btn.innerHTML = '<i class="fas fa-sync-alt"></i> Refresh';
            btn.disabled = false;
        });
    });
}
function showToastGlobal(message, type = 'success') {
    // Hapus toast yang sudah ada sebelumnya
    let existingToast = document.getElementById('globalToast');
    if (existingToast) {
        existingToast.remove();
    }
    
    // Buat toast baru
    const toast = document.createElement('div');
    toast.id = 'globalToast';
    
    // Set warna sesuai type
    let bgColor = '#10b981';
    if (type === 'error') bgColor = '#ef4444';
    if (type === 'warning') bgColor = '#f59e0b';
    
    toast.style.cssText = `
        position: fixed;
        bottom: 30px;
        right: 30px;
        background: ${bgColor};
        color: white;
        padding: 14px 24px;
        border-radius: 12px;
        font-size: 13px;
        font-weight: 500;
        z-index: 10001;
        animation: slideIn 0.3s ease;
        box-shadow: 0 8px 20px rgba(0,0,0,0.3);
        backdrop-filter: blur(4px);
        pointer-events: none;
        max-width: 350px;
        word-wrap: break-word;
    `;
    
    toast.textContent = message;
    document.body.appendChild(toast);
    
    // Auto remove setelah 3 detik
    setTimeout(() => {
        if (toast && toast.parentNode) {
            toast.style.animation = 'slideOut 0.3s ease';
            setTimeout(() => {
                if (toast && toast.parentNode) toast.remove();
            }, 300);
        }
    }, 3000);
}

function showToastInModal(message, type = 'success') {
    // Cari modal yang sedang aktif
    const activeModal = document.querySelector('#taskModalDashboard.active');
    if (!activeModal) {
        // Jika tidak ada modal aktif, fallback ke toast biasa
        showToastInModal(message, type);
        return;
    }
    
    // Cari modal body
    const modalBody = activeModal.querySelector('.modal-body');
    if (!modalBody) {
        showToastInModal(message, type);
        return;
    }
    
    // Hapus toast lama dalam modal ini
    const oldToast = modalBody.querySelector('.modal-toast');
    if (oldToast) {
        oldToast.remove();
    }
    
    // Buat toast baru
    const toast = document.createElement('div');
    toast.className = `modal-toast ${type}`;
    
    // Set ikon sesuai type
    let icon = 'fa-check-circle';
    if (type === 'error') icon = 'fa-exclamation-circle';
    if (type === 'warning') icon = 'fa-exclamation-triangle';
    if (type === 'info') icon = 'fa-info-circle';
    
    toast.innerHTML = `<i class="fas ${icon}"></i> ${message}`;
    
    // Insert di awal modal body
    if (modalBody.firstChild) {
        modalBody.insertBefore(toast, modalBody.firstChild);
    } else {
        modalBody.appendChild(toast);
    }
    
    // Auto remove setelah 3 detik
    setTimeout(() => {
        if (toast && toast.parentNode) {
            toast.style.animation = 'slideOutUp 0.3s ease';
            setTimeout(() => {
                if (toast && toast.parentNode) toast.remove();
            }, 300);
        }
    }, 3000);
}

function startConfetti() {
    if (typeof confetti === 'function') {
        confetti({ particleCount: 100, spread: 70, origin: { y: 0.6 } });
    } else {
        console.log('�9�5 Stage completed!');
    }
}

// ========== DATA ==========
const allOrdersDashboard = <?= json_encode(array_slice(array_reverse($orders), 0, 100)) ?>;
const isSupervisor = document.getElementById('isSupervisorHidden')?.value === 'true';

// ========== STAGE COMPLETION (3 TASK) ==========
let completedStagesDashboard = JSON.parse(localStorage.getItem('bd_completed_stages')) || [];

function saveCompletedStagesDashboard() { 
    localStorage.setItem('bd_completed_stages', JSON.stringify(completedStagesDashboard)); 
}

function isStageCompletedDashboard(stageNum) { 
    return completedStagesDashboard.includes(stageNum); 
}

function updateStageUIDashboard() {
    const stageOrder = [1, 3, 4];
    
    document.querySelectorAll('.stage-card-dashboard').forEach(card => {
        const stageNum = parseInt(card.getAttribute('data-stage'));
        const btns = card.querySelectorAll('.task-btn-dashboard');
        
        if (isStageCompletedDashboard(stageNum)) {
            card.classList.add('completed');
            btns.forEach(btn => { 
                btn.disabled = true; 
                btn.innerHTML = '<i class="fas fa-check-circle"></i> Completed'; 
            });
        } else {
            let previousStage = null;
            if (stageNum === 3) previousStage = 1;
            if (stageNum === 4) previousStage = 3;
            
            if (previousStage && !isStageCompletedDashboard(previousStage)) {
                btns.forEach(btn => { 
                    btn.disabled = true; 
                    btn.innerHTML = '<i class="fas fa-lock"></i> Selesaikan stage sebelumnya'; 
                });
            } else {
                card.classList.remove('completed');
                btns.forEach(btn => btn.disabled = false);
            }
        }
    });
}

// ========== XP SYSTEM ==========
let userXPDashboard = parseInt(localStorage.getItem('bd_user_xp')) || 0;
let userLevelDashboard = parseInt(localStorage.getItem('bd_user_level')) || 1;

function updateXPDashboard() {
    const xpNeeded = userLevelDashboard * 500;
    const xpPercent = Math.min(100, (userXPDashboard / xpNeeded) * 100);
    const xpFill = document.getElementById('xpFillDashboard');
    const xpText = document.getElementById('xpTextDashboard');
    if (xpFill) xpFill.style.width = `${xpPercent}%`;
    if (xpText) xpText.innerText = `Level ${userLevelDashboard} BD �� ${userXPDashboard}/${xpNeeded} XP`;
}

function addXPDashboard(amount) {
    userXPDashboard += amount;
    const xpNeeded = userLevelDashboard * 500;
    if (userXPDashboard >= xpNeeded) { 
        userLevelDashboard++; 
        userXPDashboard -= xpNeeded; 
        showToastInModal(`�9�5 LEVEL UP! Level ${userLevelDashboard} BD!`); 
        startConfetti(); 
    }
    localStorage.setItem('bd_user_xp', userXPDashboard); 
    localStorage.setItem('bd_user_level', userLevelDashboard);
    updateXPDashboard();
}
updateXPDashboard();

// ========== MODAL ==========
function closeModalDashboard() { 
    const modal = document.getElementById('taskModalDashboard');
    if (modal) {
        modal.classList.remove('active');
    }
    isLoadingProducts = false;
}

function openModalDashboard() {
    document.getElementById('taskModalDashboard').classList.add('active');
}
// �9�7 FUNGSI UNTUK MEMASTIKAN TOMBOL CLOSE BERFUNGSI (PANGGIL SETIAP MODAL DIBUKA)
function ensureCloseButtonWorks() {
    // Tombol X di header modal
    const headerCloseBtn = document.getElementById('closeTaskModalDashboard');
    if (headerCloseBtn) {
        // Hapus semua listener lama dengan clone
        const newHeaderCloseBtn = headerCloseBtn.cloneNode(true);
        headerCloseBtn.parentNode.replaceChild(newHeaderCloseBtn, headerCloseBtn);
        newHeaderCloseBtn.addEventListener('click', function(e) {
            e.preventDefault();
            e.stopPropagation();
            console.log('Header close button clicked');
            closeModalDashboard();
        });
    }
    
    // Overlay modal
    const modalOverlay = document.getElementById('taskModalDashboard');
    if (modalOverlay) {
        const newOverlay = modalOverlay.cloneNode(true);
        modalOverlay.parentNode.replaceChild(newOverlay, modalOverlay);
        newOverlay.addEventListener('click', function(e) {
            if (e.target === newOverlay) {
                console.log('Overlay clicked - closing modal');
                closeModalDashboard();
            }
        });
    }
}

// Panggil ensureCloseButtonWorks setiap kali modal dibuka
const originalOpenModal = openModalDashboard;
openModalDashboard = function() {
    originalOpenModal();
    ensureCloseButtonWorks();
};

// ========== WHATSAPP ==========
function sendWhatsAppDirectDashboard(brandId, phoneNumber, message, stage) {
    let phone = phoneNumber.replace(/[^0-9+]/g, '');
    if (phone.startsWith('0')) phone = '+62' + phone.substring(1);
    else if (!phone.startsWith('+')) phone = '+' + phone;
    const cleanPhone = phone.replace(/^\+/, '');
    const whatsappUrl = `https://wa.me/${cleanPhone}?text=${encodeURIComponent(message)}`;
    
    fetch(baseUrlDashboard + 'bd/send_whatsapp', { 
        method: 'POST', 
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, 
        body: new URLSearchParams({ brand_id: brandId, phone_number: phone, message: message, stage: stage }) 
    }).then(() => { 
        window.open(whatsappUrl, '_blank'); 
        if (stage == 1) showToastInModal('�7�3 Pesan terkirim! Brand pindah ke Task 2 (Setup Campaign)');
    }).catch(() => window.open(whatsappUrl, '_blank'));
}

// ========== GET BRAND DETAIL ==========
async function getBrandDetailDashboard(brandId) {
    const response = await fetch(baseUrlDashboard + 'bd/get_brand_detail', { 
        method: 'POST', 
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, 
        body: new URLSearchParams({ brand_id: brandId }) 
    });
    const result = await response.json();
    return result.success ? result.data : null;
}

// ========== COMPLETE STAGE ==========
async function completeStageDashboard(stageNum, brandId = null) {
    if (completedStagesDashboard.includes(stageNum)) return;
    startConfetti();
    await fetch(baseUrlDashboard + 'bd/complete_task', { 
        method: 'POST', 
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, 
        body: new URLSearchParams({ stage: stageNum, brand_id: brandId }) 
    });
    completedStagesDashboard.push(stageNum); 
    saveCompletedStagesDashboard(); 
    updateStageUIDashboard();
    addXPDashboard(100);
    const messages = { 1: '�9�3 Hunting selesai! Saatnya setup campaign!', 3: '�0�4 Campaign siap!', 4: '�9�6 Monitoring aktif!' };
    showToastInModal(messages[stageNum]);
}

// ========== UPDATE BRAND STATUS TO ACTIVE ==========
async function updateBrandStatusToActive(brandId) {
    try {
        const response = await fetch(baseUrlDashboard + 'bd/update_brand_status', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: new URLSearchParams({
                brand_id: brandId,
                status: 'ACTIVE'
            })
        });
        const result = await response.json();
        if (result.success) {
            showToastInModal(`�7�3 Brand berhasil dipindahkan ke Monitoring (Task 3)!`, 'success');
        }
        return result.success;
    } catch (error) {
        console.error('Error updating brand status:', error);
        return false;
    }
}

// ========== TASK 1: HUNTING DETAIL ==========
async function showTask1DetailDashboard(brandId, brandName) {
    const brand = await getBrandDetailDashboard(brandId);
    if (!brand) { showToastInModal('Gagal mengambil detail brand', 'error'); return; }
    
    const modalTitleElem = document.getElementById('modalTitleDashboard'); 
    const modalBodyElem = document.getElementById('modalBodyDashboard');
    
    // Template pesan biasa (tanpa deal)
    const defaultMessage = `Hi ${brand.name} Team,

Kami dari AI Media Nusantara, ingin menawarkan kerjasama affiliate untuk produk Anda.

Tertarik untuk diskusi lebih lanjut?

Best regards,
AI Media Nusantara`;
    
    modalTitleElem.innerHTML = `<i class="fas fa-building"></i> Detail Brand: ${brand.name}`;
    modalBodyElem.innerHTML = `
        <div style="display:grid; gap:10px; margin-bottom:16px;">
            <div style="display:flex; justify-content:space-between; padding:6px 0; border-bottom:1px solid #2a3346;">
                <span style="color:#9aaebe;">Kategori:</span>
                <span>${brand.category || '-'}</span>
            </div>
            <div style="display:flex; justify-content:space-between; padding:6px 0; border-bottom:1px solid #2a3346;">
                <span style="color:#9aaebe;">WhatsApp:</span>
                <span>${brand.whatsapp_number || '-'}</span>
            </div>
            <div style="display:flex; justify-content:space-between; padding:6px 0; border-bottom:1px solid #2a3346;">
                <span style="color:#9aaebe;">Input oleh:</span>
                <span><i class="fas fa-user"></i> ${brand.bd_username || brand.input_by || '-'}</span>
            </div>
            <div style="display:flex; justify-content:space-between; padding:6px 0;">
                <span style="color:#9aaebe;">Status:</span>
                <span class="badge-dashboard badge-pending">${brand.status}</span>
            </div>
        </div>
        
        <label>Pesan ke Brand</label>
        <textarea id="huntingMessageDashboard" rows="6">${defaultMessage}</textarea>
        
        <div style="display:flex; gap:10px; margin-top:16px; flex-wrap:wrap;">
            <button id="dealBtnDashboard" style="flex:1; background:#10b981; color:white; font-weight:600; padding:10px; border-radius:40px; border:none; cursor:pointer;">
                <i class="fas fa-handshake"></i> Deal & Lanjutkan
            </button>
            <button id="sendOnlyBtnDashboard" style="flex:1; background:#3b82f6; color:white; font-weight:600; padding:10px; border-radius:40px; border:none; cursor:pointer;">
                <i class="fab fa-whatsapp"></i> Kirim Pesan
            </button>
        </div>
        <div style="margin-top:8px; font-size:10px; color:#9aaebe; text-align:center;">
            <i class="fas fa-info-circle"></i> "Kirim Pesan" hanya mengirim WA, status tetap PENDING.<br>
            "Deal & Lanjutkan" akan mengirim WA deal dan memindahkan brand ke Setup Campaign.
        </div>
    `;
    
    // Buka modal
    openModalDashboard();
    
    // �9�7 PASTIKAN TOMBOL CLOSE BERFUNGSI (PANGGIL SETIAP KALI)
    ensureCloseButtonWorks();
    
    // Tombol Kirim Pesan SAJA (tanpa ubah status) - WARNA BIRU
    const sendOnlyBtn = document.getElementById('sendOnlyBtnDashboard');
    if (sendOnlyBtn) {
        // Hapus listener lama
        const newSendBtn = sendOnlyBtn.cloneNode(true);
        sendOnlyBtn.parentNode.replaceChild(newSendBtn, sendOnlyBtn);
        newSendBtn.addEventListener('click', async () => {
            const message = document.getElementById('huntingMessageDashboard').value;
            
            if (brand.whatsapp_number) {
                sendWhatsAppOnlyDashboard(brand.id, brand.whatsapp_number, message);
            }
            
            closeModalDashboard();
            showToastInModal('�7�3 Pesan terkirim! Status brand masih PENDING.', 'success');
        });
    }
    
    // Tombol Deal (kirim WA deal + update status ke CAMPAIGN_READY + hapus duplikat) - WARNA HIJAU
    const dealBtn = document.getElementById('dealBtnDashboard');
    if (dealBtn) {
        // Hapus listener lama
        const newDealBtn = dealBtn.cloneNode(true);
        dealBtn.parentNode.replaceChild(newDealBtn, dealBtn);
        newDealBtn.addEventListener('click', async () => {
            const message = document.getElementById('huntingMessageDashboard').value;
            
            if (!confirm(`Anda yakin ingin deal dengan ${brand.name}?\n\nBrand akan pindah ke Setup Campaign dan brand duplikat milik BD lain akan dihapus.`)) {
                return;
            }
            
            const response = await fetch(baseUrlDashboard + 'bd/update_brand_status', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: new URLSearchParams({
                    brand_id: brand.id,
                    status: 'CAMPAIGN_READY'
                })
            });
            const result = await response.json();
            
            if (result.success) {
                if (brand.whatsapp_number) {
                    sendWhatsAppDealDashboard(brand.id, brand.whatsapp_number, message);
                }
                
                closeModalDashboard();
                if (result.deleted_duplicates > 0) {
                    showToastInModal(`�7�3 Deal berhasil! ${result.deleted_duplicates} brand duplikat milik BD lain telah dihapus.`, 'success');
                } else {
                    showToastInModal('�7�3 Deal berhasil! Brand pindah ke Setup Campaign.', 'success');
                }
                setTimeout(() => location.reload(), 2000);
            } else {
                if (result.already_deal) {
                    showToastInModal(result.message, 'error');
                } else {
                    showToastInModal('Gagal melakukan deal: ' + (result.message || 'Unknown error'), 'error');
                }
            }
        });
    }
}

// Fungsi kirim WA saja (tanpa update status)
// Fungsi kirim WA saja (tanpa update status) - REUSE TAB YANG SAMA
function sendWhatsAppOnlyDashboard(brandId, phoneNumber, message) {
    let phone = phoneNumber.replace(/[^0-9+]/g, '');
    if (phone.startsWith('0')) phone = '+62' + phone.substring(1);
    else if (!phone.startsWith('+')) phone = '+' + phone;
    const cleanPhone = phone.replace(/^\+/, '');
    const whatsappUrl = `https://wa.me/${cleanPhone}?text=${encodeURIComponent(message)}`;
    
    fetch(baseUrlDashboard + 'bd/log_whatsapp_only', { 
        method: 'POST', 
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, 
        body: new URLSearchParams({ brand_id: brandId, phone_number: phone, message: message, stage: 1 }) 
    }).then(() => { 
        // Gunakan target 'whatsapp_tab' yang konsisten, bukan '_blank'
        window.open(whatsappUrl, 'whatsapp_tab');
    }).catch(() => {
        window.open(whatsappUrl, 'whatsapp_tab');
    });
}

// Fungsi kirim WA deal - REUSE TAB YANG SAMA
function sendWhatsAppDealDashboard(brandId, phoneNumber, message) {
    let phone = phoneNumber.replace(/[^0-9+]/g, '');
    if (phone.startsWith('0')) phone = '+62' + phone.substring(1);
    else if (!phone.startsWith('+')) phone = '+' + phone;
    const cleanPhone = phone.replace(/^\+/, '');
    const whatsappUrl = `https://wa.me/${cleanPhone}?text=${encodeURIComponent(message)}`;
    
    window.open(whatsappUrl, 'whatsapp_tab');
}

// Fungsi sendWhatsAppDirectDashboard (jika masih digunakan)
function sendWhatsAppDirectDashboard(brandId, phoneNumber, message, stage) {
    let phone = phoneNumber.replace(/[^0-9+]/g, '');
    if (phone.startsWith('0')) phone = '+62' + phone.substring(1);
    else if (!phone.startsWith('+')) phone = '+' + phone;
    const cleanPhone = phone.replace(/^\+/, '');
    const whatsappUrl = `https://wa.me/${cleanPhone}?text=${encodeURIComponent(message)}`;
    
    fetch(baseUrlDashboard + 'bd/send_whatsapp', { 
        method: 'POST', 
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, 
        body: new URLSearchParams({ brand_id: brandId, phone_number: phone, message: message, stage: stage }) 
    }).then(() => { 
        window.open(whatsappUrl, 'whatsapp_tab');
        if (stage == 1) showToastInModal('�7�3 Pesan terkirim! Brand pindah ke Task 2 (Setup Campaign)');
    }).catch(() => window.open(whatsappUrl, 'whatsapp_tab'));
}

// Fungsi kirim WA deal (update status sudah dilakukan di controller terpisah)
function sendWhatsAppDealDashboard(brandId, phoneNumber, message) {
    let phone = phoneNumber.replace(/[^0-9+]/g, '');
    if (phone.startsWith('0')) phone = '+62' + phone.substring(1);
    else if (!phone.startsWith('+')) phone = '+' + phone;
    const cleanPhone = phone.replace(/^\+/, '');
    const whatsappUrl = `https://wa.me/${cleanPhone}?text=${encodeURIComponent(message)}`;
    
    // Hanya buka WA, status sudah diupdate sebelumnya
    window.open(whatsappUrl, '_blank');
}

// ========== TASK 2: SETUP CAMPAIGN (SEKARANG TASK 2 DARI 3) ==========
let selectedProductsForReview = [];
let currentBrandIdForReview = null;
let currentBrandNameForReview = null;
let allPendingProducts = [];
let isLoadingProducts = false;

async function showTask3SetupModalDashboard(brandId, brandName) {
    const brand = await getBrandDetailDashboard(brandId);
    if (!brand) { 
        showToastInModal('Gagal mengambil detail brand', 'error'); 
        return; 
    }
    
    currentBrandIdForReview = brandId;
    currentBrandNameForReview = brandName;
    selectedProductsForReview = [];
    allPendingProducts = [];
    
    const modalTitleElem = document.getElementById('modalTitleDashboard'); 
    const modalBodyElem = document.getElementById('modalBodyDashboard');
    
    modalTitleElem.innerHTML = `<i class="fas fa-rocket"></i> Setup Campaign - ${brandName}`;
    
    modalBodyElem.innerHTML = `
        <div style="background:rgba(74,222,128,0.1); border-radius:14px; padding:12px; margin-bottom:16px;">
            <p style="color:#4ade80; font-size:12px;"><i class="fas fa-info-circle"></i> Review produk yang diajukan oleh seller</p>
            <p style="color:#10b981; font-size:10px;"><i class="fas fa-arrow-right"></i> <strong>Catatan:</strong> Brand akan otomatis pindah ke Monitoring (Task 3) jika <strong>SEMUA</strong> produk sudah diapprove!</p>
            ${!isSupervisor ? '<p style="color:#f59e0b; font-size:10px; margin-top:8px;"><i class="fas fa-lock"></i> <strong>Perhatian:</strong> Hanya Supervisor yang dapat approve produk. Anda hanya bisa melihat.</p>' : ''}
        </div>
        
        <div id="productsReviewContainer">
            <div id="productsReviewList" style="max-height:550px; overflow-y:auto; background:#0f1420; border-radius:12px; padding:8px;">
                <div class="loading" style="text-align:center; padding:40px;">
                    <i class="fas fa-spinner fa-pulse fa-2x"></i>
                    <p style="margin-top:12px; color:#9aaebe;">Memuat daftar produk pending review...</p>
                    <p style="margin-top:8px; font-size:11px; color:#6b7280;">Tombol Tutup tetap bisa digunakan</p>
                </div>
            </div>
        </div>
        
        <div class="flex-buttons" style="margin-top:16px;">
            <button id="closeReviewModalBtn" style="background:#1e293b; color:#cbd5e6; cursor:pointer;">
                <i class="fas fa-times"></i> Tutup
            </button>
        </div>
    `;
    openModalDashboard();
    
    // Pasang tombol close
    const closeBtn = document.getElementById('closeReviewModalBtn');
    if (closeBtn) {
        const newCloseBtn = closeBtn.cloneNode(true);
        closeBtn.parentNode.replaceChild(newCloseBtn, closeBtn);
        newCloseBtn.addEventListener('click', function(e) {
            e.preventDefault();
            e.stopPropagation();
            closeModalDashboard();
        });
    }
    
    // Pasang header close button
    const headerCloseBtn = document.getElementById('closeTaskModalDashboard');
    if (headerCloseBtn) {
        const newHeaderCloseBtn = headerCloseBtn.cloneNode(true);
        headerCloseBtn.parentNode.replaceChild(newHeaderCloseBtn, headerCloseBtn);
        newHeaderCloseBtn.addEventListener('click', function(e) {
            e.preventDefault();
            e.stopPropagation();
            closeModalDashboard();
        });
    }
    
    await loadAllPendingProducts();
}

async function loadAllPendingProducts() {
    if (isLoadingProducts) return;
    isLoadingProducts = true;
    
    const productsContainer = document.getElementById('productsReviewList');
    if (!productsContainer) {
        isLoadingProducts = false;
        return;
    }
    
    productsContainer.innerHTML = '<div class="loading" style="text-align:center; padding:40px;"><i class="fas fa-spinner fa-pulse fa-2x"></i><p style="margin-top:12px; color:#9aaebe;">Memuat produk pending review dari database...</p></div>';
    
    try {
        const response = await fetch(baseUrlDashboard + 'bd/get_pending_products_for_brand', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: new URLSearchParams({ 
                brand_id: currentBrandIdForReview,
                brand_name: currentBrandNameForReview
            })
        });
        
        const result = await response.json();
        
        if (!result.success) {
            productsContainer.innerHTML = `
                <div style="text-align:center; padding:40px; color:#f59e0b;">
                    <i class="fas fa-exclamation-triangle" style="font-size:48px; margin-bottom:16px; display:block;"></i>
                    <h3 style="color:#f59e0b;">Gagal Memuat Data</h3>
                    <p style="color:#9aaebe; margin-top:8px;">${escapeHtml(result.message || 'Terjadi kesalahan saat memuat data')}</p>
                    <button id="retryLoadBtn" class="btn-primary" style="margin-top:16px; background:#f59e0b;">
                        <i class="fas fa-sync-alt"></i> Coba Lagi
                    </button>
                </div>
            `;
            document.getElementById('retryLoadBtn')?.addEventListener('click', () => {
                loadAllPendingProducts();
            });
            isLoadingProducts = false;
            return;
        }
        
        const products = result.products || [];
        const hasProducts = products.length > 0;
        
        if (!hasProducts) {
            let statusMessage = '';
            let statusIcon = '';
            let statusColor = '';
            
            if (result.has_approved) {
                statusMessage = 'Semua produk untuk brand ini sudah diapprove!';
                statusIcon = 'fa-check-circle';
                statusColor = '#10b981';
            } else {
                statusMessage = 'Belum ada pengajuan produk dari brand ini';
                statusIcon = 'fa-clock';
                statusColor = '#f59e0b';
            }
            
            productsContainer.innerHTML = `
                <div style="text-align:center; padding:40px; color:${statusColor};">
                    <i class="fas ${statusIcon}" style="font-size:48px; margin-bottom:16px; display:block;"></i>
                    <h3 style="color:${statusColor};">${statusMessage}</h3>
                    <p style="color:#9aaebe; margin-top:8px;">
                        ${result.has_approved ? 'Brand siap dipindahkan ke Monitoring.' : 'Brand belum mengajukan produk untuk direview.'}
                    </p>
                    ${result.has_approved && isSupervisor ? `
                    <button id="moveToTask4DirectBtn" class="btn-primary" style="margin-top:16px; background:#10b981;">
                        <i class="fas fa-arrow-right"></i> Pindahkan ke Monitoring (Task 3)
                    </button>
                    ` : ''}
                </div>
            `;
            
            document.getElementById('moveToTask4DirectBtn')?.addEventListener('click', async () => {
                await updateBrandStatusToActive(currentBrandIdForReview);
                closeModalDashboard();
                location.reload();
            });
            
            isLoadingProducts = false;
            return;
        }
        
        allPendingProducts = products.map(p => ({
            product_id: p.product_id,
            campaign_id: p.campaign_id,
            campaign_name: p.campaign_name
        }));
        
        selectedProductsForReview = [];
        
        // �9�7 HITUNG DEFAULT KOMISI DARI PRODUK PERTAMA
        let defaultOpenCommission = 10;
        let defaultAffiliateCommission = 11;
        
       
if (products.length > 0 && products[0]?.open_commission_rate) {
    let rawOpenCommission = products[0].open_commission_rate;
    
    // Jika nilai rawOpenCommission adalah 0 atau null
    if (rawOpenCommission === 0 || rawOpenCommission === null) {
        defaultOpenCommission = 10;
        defaultAffiliateCommission = 11;
    } else {
        // Konversi dari cents ke persen (700 -> 7%)
        defaultOpenCommission = Math.round(rawOpenCommission / 100);
        if (defaultOpenCommission < 1) defaultOpenCommission = 5;
        if (defaultOpenCommission > 49) defaultOpenCommission = 49;
        defaultAffiliateCommission = defaultOpenCommission + 1;
        if (defaultAffiliateCommission > 50) defaultAffiliateCommission = 50;
    }
} else {
    // Jika tidak ada data open_commission_rate, gunakan default
    defaultOpenCommission = 10;
    defaultAffiliateCommission = 11;
}

        
        // �9�7 BUAT HTML
        let productsHtml = '';
        let warningHtml = '';
        if (products.length > 0 && products[0]?.open_commission_rate === 0) {
    warningHtml = `
        <div style="background:rgba(245,158,11,0.15); border-radius:8px; padding:8px; margin-bottom:12px; border-left:3px solid #f59e0b;">
            <i class="fas fa-exclamation-triangle" style="color:#f59e0b; font-size:11px;"></i>
            <span style="color:#f59e0b; font-size:10px; margin-left:8px;">
                Open Plan commission tidak tersedia (0%). Menggunakan default 10% untuk perhitungan komisi afiliasi.
            </span>
        </div>
    `;
}
        // Action Bar di ATAS
        if (isSupervisor && products.length > 0) {
    productsHtml += `
        <div id="actionBarContainer" style="margin-bottom:16px; padding:12px; background:#1a1f2e; border-radius:12px;">
            ${warningHtml}
            <!-- Baris 1: Open Plan Input -->
            <div style="display:flex; align-items: center; gap: 12px; margin-bottom: 12px; flex-wrap: wrap;">
               
                <div style="display: flex; align-items: center; gap: 8px;">
                    <input type="hidden" id="openCommissionInput" value="${defaultOpenCommission}" step="1" min="1" max="49" 
                           style="width: 80px; padding: 6px 8px; background: #0f1420; border: 1px solid #2a3346; border-radius: 8px; color: #e2f0e8; font-size: 12px;" >
                   
                </div>
                <div style="font-size: 10px; color: #6b7280;">
                    <i class="fas fa-info-circle"></i> ${products[0]?.open_commission_rate === 0 ? 'Default 10% (Open Plan tidak tersedia)' : 'Dari API TikTok'}
                </div>
            </div>
            
            
            
            <!-- Baris 3: Hasil Komisi Afiliasi -->
            <div style="display:flex; align-items: center; gap: 12px; margin-bottom: 12px; flex-wrap: wrap; padding: 8px 0; background: rgba(74,222,128,0.1); border-radius: 8px;">
                <div style="display: flex; align-items: center; gap: 8px;">
                    <i class="fas fa-link" style="color: #4ade80; font-size: 12px;"></i>
                    <span style="color: #e2f0e8; font-size: 12px; font-weight: 500;">Komisi Afiliasi:</span>
                </div>
                <div style="display: flex; align-items: center; gap: 8px;">
                    <span id="affiliateCommissionDisplay" style="background: #0f1420; padding: 6px 12px; border-radius: 8px; color: #4ade80; font-weight: 700; font-size: 16px;">${defaultAffiliateCommission}%</span>
                    <input type="hidden" id="affiliateCommissionValue" value="${defaultAffiliateCommission}">
                </div>
                <div id="formulaDisplay" style="font-size: 10px; color: #4ade80;">
                    <i class="fas fa-calculator"></i> = ${defaultOpenCommission}% + 1% = ${defaultAffiliateCommission}%
                </div>
            </div>
            
            <!-- Baris 4: Tombol Aksi -->
            <div style="display:flex; gap:12px; justify-content:space-between; align-items:center; flex-wrap: wrap; margin-top: 8px;">
                <div>
                    <span id="selectedCountBadge" style="background:#4ade80; color:#0a0e17; padding:4px 12px; border-radius:20px; font-size:12px; font-weight:600;">0</span>
                    <span style="margin-left:8px; color:#9aaebe;">produk dipilih</span>
                </div>
                <div style="display:flex; gap:8px;">
                    <button id="selectAllProductsBtn" class="btn-secondary" style="padding:6px 16px; font-size:12px; background:#1e293b; color:#cbd5e6; cursor:pointer;">
                        <i class="fas fa-check-double"></i> Pilih Semua
                    </button>
                    <button id="approveSelectedProductsBtn" class="btn-primary" style="padding:6px 16px; font-size:12px; background:#10b981; color:white; cursor:pointer;" disabled>
                        <i class="fas fa-check"></i> Approve & Generate Link
                    </button>
                </div>
            </div>
        </div>
    `;
}
        
        // Daftar Produk
        productsHtml += `<div id="productsListContainer">`;
        
        products.forEach(product => {
            const partnerCommission = product.partner_commission_rate || 0;
            const openCommission = product.open_commission_rate || 0;
            const totalCommission = product.total_commission_rate || 0;
            const shopAdsRate = product.shop_ads_rate || 0;
            const sampleQuota = product.sample_quota || 0;
            const isChecked = selectedProductsForReview.some(p => p.product_id === product.product_id && p.campaign_id === product.campaign_id);
            
            productsHtml += `
                <div class="product-review-item" data-product-id="${product.product_id}" data-campaign-id="${product.campaign_id}" style="background:#0f1420; border-radius:12px; padding:12px; margin-bottom:10px; border:1px solid ${isChecked ? '#4ade80' : '#2a3346'};">
                    <div style="display:flex; gap:12px;">
                        ${isSupervisor ? `
                        <div style="flex-shrink:0;">
                            <input type="checkbox" class="product-select-checkbox" 
                                   data-product-id="${product.product_id}" 
                                   data-campaign-id="${product.campaign_id}"
                                   ${isChecked ? 'checked' : ''}
                                   style="width:20px; height:20px; cursor:pointer; accent-color:#4ade80;">
                        </div>
                        ` : ''}
                        <div style="width:70px; height:70px; background:#1e293b; border-radius:10px; display:flex; align-items:center; justify-content:center; overflow:hidden; flex-shrink:0;">
                            ${product.image_url ? `<img src="${escapeHtml(product.image_url)}" style="width:100%; height:100%; object-fit:cover;">` : '<i class="fas fa-box fa-2x" style="color:#4ade80;"></i>'}
                        </div>
                        <div style="flex:1;">
                            <div style="color:#e2f0e8; font-size:14px; font-weight:600; margin-bottom:6px;">${escapeHtml(product.product_name)}</div>
                            <div style="color:#4ade80; font-size:13px; font-weight:600; margin-bottom:6px;">
                                Rp ${formatNumber(product.price)} 
                            </div>
                            <div style="color:#9aaebe; font-size:11px; margin-bottom:4px;">
                                �9�2 Shop: ${escapeHtml(product.shop_name || '-')}
                                <span style="margin-left:12px;">�9�7 Campaign: ${escapeHtml(product.campaign_name || '-')}</span>
                            </div>
                            <div style="color:#9aaebe; font-size:10px;">�9�4 Stock: ${formatNumber(product.inventory)} | Terjual: ${formatNumber(product.product_sales)}</div>
                        </div>
                    </div>
                    
                    <div style="display:grid; grid-template-columns: repeat(4, 1fr); gap:12px; margin-top:12px; padding-top:10px; border-top:1px solid #2a3346;">
                        <div style="text-align:center;"><div style="color:#fbbf24; font-size:10px;">Open Plan</div><div style="color:#e2f0e8; font-size:14px; font-weight:600;">${(openCommission / 100).toFixed(1)}%</div></div>
                        <div style="text-align:center;"><div style="color:#fbbf24; font-size:10px;">Partner Komisi</div><div style="color:#e2f0e8; font-size:14px; font-weight:600;">${(partnerCommission / 100).toFixed(1)}%</div></div>
                        <div style="text-align:center;"><div style="color:#fbbf24; font-size:10px;">Total Komisi</div><div style="color:#e2f0e8; font-size:14px; font-weight:600;">${(totalCommission / 100).toFixed(1)}%</div></div>
                        <div style="text-align:center;"><div style="color:#fbbf24; font-size:10px;">Shop Ads</div><div style="color:#4ade80; font-size:14px; font-weight:600;">${(shopAdsRate / 100).toFixed(1)}%</div></div>
                    </div>
                    
                    <div style="margin-top:8px; padding-top:6px; border-top:1px solid #2a3346; display:flex; justify-content:space-between;">
                        <span style="color:#9aaebe; font-size:10px;"><i class="fas fa-box"></i> Sample Quota: 
                            <span style="color:${sampleQuota > 0 ? '#4ade80' : '#9aaebe'};">
                                ${sampleQuota > 0 ? `${sampleQuota} pcs tersedia` : 'Tidak tersedia'}
                            </span>
                        </span>
                        <span style="color:#9aaebe; font-size:10px;"><i class="fas fa-tag"></i> Kategori: ${escapeHtml(product.category || '-')}</span>
                    </div>
                </div>
            `;
        });
        
        productsHtml += `</div>`;
        
        if (!isSupervisor && products.length > 0) {
            productsHtml += `
                <div style="margin-top:16px; padding:12px; background:#1a1f2e; border-radius:12px; text-align:center;">
                    <span style="color:#f59e0b;"><i class="fas fa-lock"></i> Hanya Supervisor yang dapat approve produk</span>
                </div>
            `;
        }
        
        productsContainer.innerHTML = productsHtml;
        
        if (isSupervisor) {
            // �9�7 UPDATE KOMISI DISPLAY SAAT INPUT BERUBAH
            const openCommissionInput = document.getElementById('openCommissionInput');
            const affiliateCommissionDisplay = document.getElementById('affiliateCommissionDisplay');
            const affiliateCommissionValue = document.getElementById('affiliateCommissionValue');
            const formulaDisplay = document.getElementById('formulaDisplay');
            
           if (openCommissionInput) {
    openCommissionInput.addEventListener('input', function() {
        let openCommission = parseInt(this.value);
        if (isNaN(openCommission)) openCommission = 10;
        if (openCommission < 1) openCommission = 1;
        if (openCommission > 49) openCommission = 49;
        
        let affiliateCommission = openCommission + 1;
        if (affiliateCommission > 50) affiliateCommission = 50;
        
        affiliateCommissionDisplay.innerText = affiliateCommission + '%';
        affiliateCommissionValue.value = affiliateCommission;
        
        if (formulaDisplay) {
            formulaDisplay.innerHTML = `<i class="fas fa-calculator"></i> = ${openCommission}% + 1% = ${affiliateCommission}%`;
        }
    });
}
            // �9�7 UPDATE SELECTED COUNT DISPLAY
            function updateSelectedCountDisplay() {
                const count = selectedProductsForReview.length;
                const countSpan = document.getElementById('selectedCountBadge');
                const approveBtn = document.getElementById('approveSelectedProductsBtn');
                if (countSpan) countSpan.innerText = count;
                if (approveBtn) {
                    approveBtn.disabled = count === 0;
                    approveBtn.innerHTML = `<i class="fas fa-check"></i> Approve & Generate Link (${count})`;
                }
            }
            
            // �9�7 CHECKBOX EVENTS
            document.querySelectorAll('.product-select-checkbox').forEach(checkbox => {
                checkbox.addEventListener('change', (e) => {
                    const productId = checkbox.getAttribute('data-product-id');
                    const campaignId = checkbox.getAttribute('data-campaign-id');
                    const index = selectedProductsForReview.findIndex(p => p.product_id === productId && p.campaign_id === campaignId);
                    
                    if (checkbox.checked) {
                        if (index === -1) {
                            selectedProductsForReview.push({ product_id: productId, campaign_id: campaignId });
                        }
                    } else {
                        if (index !== -1) {
                            selectedProductsForReview.splice(index, 1);
                        }
                    }
                    
                    updateSelectedCountDisplay();
                    
                    const parentDiv = checkbox.closest('.product-review-item');
                    if (parentDiv) {
                        parentDiv.style.borderColor = checkbox.checked ? '#4ade80' : '#2a3346';
                    }
                });
            });
            
            // �9�7 SELECT ALL BUTTON
            const selectAllBtn = document.getElementById('selectAllProductsBtn');
            if (selectAllBtn) {
                selectAllBtn.onclick = () => {
                    const allCheckboxes = document.querySelectorAll('.product-select-checkbox');
                    const isAllSelected = selectedProductsForReview.length === allCheckboxes.length;
                    
                    if (isAllSelected) {
                        selectedProductsForReview = [];
                        allCheckboxes.forEach(cb => {
                            cb.checked = false;
                            const parentDiv = cb.closest('.product-review-item');
                            if (parentDiv) parentDiv.style.borderColor = '#2a3346';
                        });
                    } else {
                        selectedProductsForReview = [];
                        allCheckboxes.forEach(cb => {
                            cb.checked = true;
                            selectedProductsForReview.push({
                                product_id: cb.getAttribute('data-product-id'),
                                campaign_id: cb.getAttribute('data-campaign-id')
                            });
                            const parentDiv = cb.closest('.product-review-item');
                            if (parentDiv) parentDiv.style.borderColor = '#4ade80';
                        });
                    }
                    updateSelectedCountDisplay();
                };
            }
            
            // �9�7 APPROVE BUTTON
            const approveBtn = document.getElementById('approveSelectedProductsBtn');
           if (approveBtn) {
    approveBtn.onclick = async () => {
         const canGenerateRes = await fetch(baseUrlDashboard + 'bd/can_generate_link');
        const canGenerateData = await canGenerateRes.json();
        
        if (!canGenerateData.can_generate) {
            showToastInModal(canGenerateData.message || 'Anda tidak memiliki akses untuk approve dan generate link. Hanya Tiffany yang dapat melakukan ini.', 'error');
            return;
        }
        if (selectedProductsForReview.length === 0) {
            showToastInModal('Pilih produk yang akan diapprove', 'error');
            return;
        }
        
        // �9�7 AMBIL NILAI OPEN PLAN (dari input)
        const openCommissionInput = document.getElementById('openCommissionInput');
        let openCommission = parseInt(openCommissionInput?.value || 10);
        
        // �9�7 AMBIL KOMISI AFILIASI YANG AKAN DIGUNAKAN
        const affiliateCommissionValue = document.getElementById('affiliateCommissionValue');
        let customCommission = parseInt(affiliateCommissionValue?.value || 11);
        
        if (isNaN(customCommission) || customCommission < 2) customCommission = 11;
        if (customCommission > 50) customCommission = 50;
        
        // �9�7 VALIDASI: KOMISI AFILIASI HARUS >= OPEN PLAN + 1
        const minRequiredCommission = openCommission + 1;
        
        if (customCommission < minRequiredCommission) {
            showToastInModal(`�7�4 Komisi afiliasi minimal ${minRequiredCommission}% (Open Plan ${openCommission}% + 1%)`, 'error');
            return;
        }
        
        if (!confirm(`Approve ${selectedProductsForReview.length} produk dengan komisi afiliasi ${customCommission}%?`)) return;
                    
                    approveBtn.disabled = true;
                    approveBtn.innerHTML = '<i class="fas fa-spinner fa-pulse"></i> Processing...';
                    
                    let successCount = 0;
                    let failCount = 0;
                    let generatedLinks = [];
                    
                    for (const item of selectedProductsForReview) {
    // �9�7 CARI PRODUCT_NAME DARI products ARRAY
    const productData = products.find(p => p.product_id === item.product_id);
    const productName = productData?.product_name || `Product ${item.product_id}`;
    
    console.log('Sending approve request:', {
        campaign_id: item.campaign_id,
        product_id: item.product_id,
        product_name: productName,
        commission_rate: customCommission
    });
    
    try {
        const response = await fetch(baseUrlDashboard + 'bd/approve_product_with_commission', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: new URLSearchParams({
                campaign_id: item.campaign_id,
                product_id: item.product_id,
                review_result: 'APPROVE',
                commission_rate: customCommission,
                product_name: productName  // �9�7 KIRIMKAN PRODUCT_NAME
            })
        });
        const data = await response.json();
        console.log('Response:', data);
        
        if (data.success) {
            successCount++;
            if (data.affiliate_link) {
                generatedLinks.push({
                    product_id: item.product_id,
                    product_name: data.product_name || productName,  // �9�7 PAKAI DARI RESPONSE
                    link: data.affiliate_link,
                    commission: customCommission
                });
            }
        } else {
            failCount++;
        }
    } catch (error) {
        failCount++;
        console.error('Error:', error);
    }
}
                    
                    showToastInModal(`�7�3 ${successCount} produk diapprove, ${failCount} gagal`, successCount > 0 ? 'success' : 'error');
                    
                    // Tampilkan modal dengan link
                   if (generatedLinks.length > 0) {
    let linksHtml = '<div style="background:rgba(74,222,128,0.1); border-radius:12px; padding:12px; margin-bottom:16px;">';
    linksHtml += `<p style="color:#4ade80; margin-bottom:12px;"><i class="fas fa-link"></i> Link Afiliasi Telah Digenerate (Komisi: ${customCommission}%):</p>`;
    linksHtml += '<div style="max-height:350px; overflow-y:auto;">';
    
  generatedLinks.forEach((link, index) => {
    // �9�7 CARI PRODUCT_NAME DARI products ARRAY
    const productData = products.find(p => p.product_id === link.product_id);
    const productName = productData?.product_name || link.product_name || `Product ${link.product_id}`;
    const productId = link.product_id;
    
    linksHtml += `
        <div style="background:#0f1420; border-radius:10px; padding:12px; margin-bottom:12px; border:1px solid #2a3346;">
            <div style="margin-bottom:10px; padding-bottom:8px; border-bottom:1px solid #2a3346;">
                <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:8px;">
                    <div style="display:flex; align-items:center; gap:8px;">
                        <i class="fas fa-box" style="color:#4ade80; font-size:12px;"></i>
                        <span style="color:#e2f0e8; font-size:12px; font-weight:600;">${escapeHtml(productName)}</span>
                    </div>
                    <span style="background:#1a1f2e; padding:2px 8px; border-radius:12px; font-size:10px; color:#9aaebe;">
                        #${index + 1}
                    </span>
                </div>
                <div style="margin-top:6px; font-size:10px; color:#9aaebe;">
                    <i class="fas fa-barcode"></i> Product ID: <span style="color:#4ade80; font-family:monospace;">${escapeHtml(productId)}</span>
                </div>
            </div>
        
        <!-- Link Section -->
        <div style="margin-bottom:8px;">
            <div style="font-size:10px; color:#9aaebe; margin-bottom:4px;">
                <i class="fas fa-link"></i> Affiliate Link:
            </div>
            <div style="display:flex; gap:8px; align-items:center; flex-wrap:wrap;">
                <code style="font-size:10px; background:#0a0e17; padding:8px 10px; border-radius:8px; word-break:break-all; flex:1; font-family:monospace;">${escapeHtml(link.link)}</code>
                <button class="copy-link-btn" 
                        data-link="${escapeHtml(link.link)}" 
                        data-product-name="${escapeHtml(productName.replace(/'/g, "\\'"))}" 
                        data-product-id="${escapeHtml(productId)}"
                        style="background:#1e293b; border:1px solid #4ade80; color:#4ade80; padding:6px 14px; border-radius:20px; cursor:pointer; font-size:11px; white-space:nowrap;">
                    <i class="fas fa-copy"></i> Copy
                </button>
            </div>
        </div>
        
        <!-- Commission Info -->
        <div style="margin-top:8px; font-size:10px; color:#6b7280; display:flex; gap:12px; flex-wrap:wrap;">
            <span><i class="fas fa-percent"></i> Komisi: <strong style="color:#4ade80;">${link.commission}%</strong></span>
            <span><i class="fas fa-calendar"></i> Generate: ${new Date().toLocaleString('id-ID')}</span>
        </div>
    </div>
`;
    });
    
    linksHtml += '</div>';
    linksHtml += `
        <div style="margin-top:12px; padding:10px; background:rgba(139,92,246,0.1); border-radius:8px;">
            <i class="fas fa-info-circle" style="color:#8b5cf6;"></i>
            <span style="font-size:11px; color:#cbd5e1;"> Komisi afiliasi = Open Plan + 1% = <strong>${customCommission}%</strong></span>
        </div>
    `;
    linksHtml += `
        <div style="margin-top:12px; padding:10px; background:rgba(16,185,129,0.1); border-radius:8px;">
            <i class="fas fa-check-circle" style="color:#10b981;"></i>
            <span style="font-size:11px; color:#cbd5e1;"> Link sudah siap digunakan. Klik Copy untuk menyalin link lengkap dengan nama produk dan ID produk.</span>
        </div>
    `;
    linksHtml += '</div>';
    
    const tempModal = document.createElement('div');
    tempModal.className = 'modal-overlay-dashboard';
    tempModal.style.cssText = 'visibility: visible; opacity: 1; z-index: 10001;';
    tempModal.innerHTML = `
        <div class="modal-glass-dashboard" style="max-width: 600px;">
            <div class="modal-header-dashboard">
                <h3><i class="fas fa-link"></i> Link Afiliasi</h3>
                <span class="modal-close-dashboard" onclick="this.closest('.modal-overlay-dashboard').remove()" style="cursor:pointer; font-size:24px;">&times;</span>
            </div>
            <div class="modal-body" style="max-height: 70vh; overflow-y: auto;">
                ${linksHtml}
                <div class="flex-buttons" style="margin-top:20px;">
                    <button onclick="this.closest('.modal-overlay-dashboard').remove()" style="flex:1; background:#1e293b; color:#cbd5e6; padding:10px; border-radius:40px; cursor:pointer;">Tutup</button>
                    <button id="copyAllLinksBtn" style="flex:1; background:#4ade80; color:#0a0e17; padding:10px; border-radius:40px; cursor:pointer; font-weight:600;">
                        <i class="fas fa-copy"></i> Copy Semua Link
                    </button>
                </div>
            </div>
        </div>
    `;
    document.body.appendChild(tempModal);
    
    // �9�7 TAMBAHKAN FUNGSI COPY SEMUA LINK
    document.getElementById('copyAllLinksBtn')?.addEventListener('click', () => {
        let allLinksText = '';
        generatedLinks.forEach((link, idx) => {
            const productData = products.find(p => p.product_id === link.product_id);
            const productName = link.product_name || productData?.product_name || `Product ${link.product_id}`;
            const productId = link.product_id;
            allLinksText += `�9�4 Product ${idx + 1}: ${productName}\n�9�4 Product ID: ${productId}\n�9�3 Link: ${link.link}\n\n`;
        });
        
        navigator.clipboard.writeText(allLinksText).then(() => {
            showToastInModal(`�7�3 ${generatedLinks.length} link berhasil dicopy semua!`, 'success');
        }).catch(() => {
            showToastInModal('Gagal copy link', 'error');
        });
    });
}
                    
                    if (successCount > 0) {
                        await loadAllPendingProducts();
                    } else {
                        approveBtn.disabled = false;
                        approveBtn.innerHTML = '<i class="fas fa-check"></i> Approve & Generate Link';
                    }
                };
            }
            
            // Initial update
            updateSelectedCountDisplay();
        }
        
    } catch (error) {
        console.error('Error loading products:', error);
        productsContainer.innerHTML = `
            <div style="text-align:center; padding:40px; color:#ef4444;">
                <i class="fas fa-exclamation-triangle" style="font-size:48px; margin-bottom:16px; display:block;"></i>
                <p>Error: ${error.message}</p>
                <button id="retryLoadProductsBtn" class="btn-primary" style="margin-top:16px;">Coba Lagi</button>
            </div>
        `;
        document.getElementById('retryLoadProductsBtn')?.addEventListener('click', () => {
            loadAllPendingProducts();
        });
    }
    
    isLoadingProducts = false;
}
function copyAllLinks(generatedLinks, products) {
    if (!generatedLinks || generatedLinks.length === 0) {
        showToastInModal('Tidak ada link untuk dicopy', 'error');
        return;
    }
    
    let allLinksText = '';
    let allLinksSimple = '';
    
    generatedLinks.forEach((link, idx) => {
        // Cari data produk dari products array
        const productData = products.find(p => p.product_id === link.product_id);
        const productName = link.product_name || productData?.product_name || `Product ${link.product_id}`;
        const productId = link.product_id;
        
        // Format teks untuk clipboard
        allLinksText += `�9�4 Product ${idx + 1}: ${productName}\n�9�4 Product ID: ${productId}\n�9�3 Link: ${link.link}\n\n`;
        allLinksSimple += `${link.link}\n`;
    });
    
    // Copy ke clipboard
    navigator.clipboard.writeText(allLinksText).then(() => {
        showToastInModal(`�7�3 ${generatedLinks.length} link berhasil dicopy semua!`, 'success');
    }).catch((err) => {
        console.error('Copy failed:', err);
        // Fallback
        const textarea = document.createElement('textarea');
        textarea.value = allLinksText;
        document.body.appendChild(textarea);
        textarea.select();
        document.execCommand('copy');
        document.body.removeChild(textarea);
        showToastInModal(`�7�3 ${generatedLinks.length} link berhasil dicopy semua!`, 'success');
    });
}


// ========== FUNGSI COPY SINGLE LINK ==========
function copySingleLink(link, productName, productId, buttonElement) {
    if (!link) return;
    
    // Buat teks lengkap untuk dicopy
    const copyText = `�9�4 Product: ${productName}\n�9�4 Product ID: ${productId}\n�9�3 Link: ${link}`;
    
    navigator.clipboard.writeText(copyText).then(() => {
        // Tampilkan toast notifikasi
        showToastInModal(`�7�3 Link untuk "${productName}" berhasil dicopy!`, 'success');
        
        // Feedback visual pada tombol
        if (buttonElement) {
            const originalHtml = buttonElement.innerHTML;
            buttonElement.innerHTML = '<i class="fas fa-check"></i> Copied!';
            buttonElement.style.background = '#4ade80';
            buttonElement.style.color = '#0a0e17';
            
            setTimeout(() => {
                buttonElement.innerHTML = originalHtml;
                buttonElement.style.background = '#1e293b';
                buttonElement.style.color = '#4ade80';
            }, 2000);
        }
    }).catch(() => {
        // Fallback
        const textarea = document.createElement('textarea');
        textarea.value = copyText;
        document.body.appendChild(textarea);
        textarea.select();
        document.execCommand('copy');
        document.body.removeChild(textarea);
        showToastInModal(`�7�3 Link untuk "${productName}" berhasil dicopy!`, 'success');
        
        if (buttonElement) {
            const originalHtml = buttonElement.innerHTML;
            buttonElement.innerHTML = '<i class="fas fa-check"></i> Copied!';
            buttonElement.style.background = '#4ade80';
            buttonElement.style.color = '#0a0e17';
            setTimeout(() => {
                buttonElement.innerHTML = originalHtml;
                buttonElement.style.background = '#1e293b';
                buttonElement.style.color = '#4ade80';
            }, 2000);
        }
    });
}
function updateSelectedCountDisplay() {
    const countSpan = document.getElementById('selectedCountBadge');
    const approveBtn = document.getElementById('approveSelectedProductsBtn');
    const selectedCount = selectedProductsForReview.length;
    if (countSpan) countSpan.innerText = selectedCount;
    if (approveBtn) {
        approveBtn.disabled = selectedCount === 0;
        approveBtn.innerHTML = `<i class="fas fa-check"></i> Approve Selected (${selectedCount})`;
    }
}



// ========== TASK 3: MONITORING ==========
async function showTask4MonitoringModalDashboard(brandId, brandName) {
    const today = new Date().toISOString().split('T')[0];
    let currentStartDate = today;
    let currentEndDate = today;
    
    const modalTitleElem = document.getElementById('modalTitleDashboard'); 
    const modalBodyElem = document.getElementById('modalBodyDashboard');
    
    async function loadPerformanceData(startDate, endDate) {
        modalBodyElem.innerHTML = `
            <div style="background:rgba(74,222,128,0.1); border-radius:14px; padding:12px; margin-bottom:16px;">
                <div class="filter-bar" style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 12px;">
                    <p style="color:#4ade80; font-size:12px; margin:0;"><i class="fas fa-chart-simple"></i> Performa Campaign - ${brandName}</p>
                    <div style="display: flex; gap: 8px; align-items: center;">
                        <input type="date" id="perfStartDate" class="date-input" value="${startDate}" style="background:#0f1420; border:1px solid #2a3346; border-radius:8px; padding:4px 8px; color:#e2f0e8;">
                        <span style="color:#9aaebe;">s/d</span>
                        <input type="date" id="perfEndDate" class="date-input" value="${endDate}" style="background:#0f1420; border:1px solid #2a3346; border-radius:8px; padding:4px 8px; color:#e2f0e8;">
                        <button id="applyPerfFilter" class="btn-filter" style="background:#1e293b; border:1px solid #4ade80; color:#4ade80; padding:4px 12px; border-radius:20px; cursor:pointer;">
                            <i class="fas fa-calendar-alt"></i> Filter
                        </button>
                        <button id="resetPerfFilter" class="btn-filter" style="background:#1e293b; border:1px solid #f59e0b; color:#f59e0b; padding:4px 12px; border-radius:20px; cursor:pointer;">
                            <i class="fas fa-undo-alt"></i> Hari Ini
                        </button>
                    </div>
                </div>
            </div>
            
            <div id="performanceContent">
                <div class="loading" style="text-align:center; padding:40px;">
                    <i class="fas fa-spinner fa-pulse fa-2x"></i>
                    <p>Loading performance data...</p>
                </div>
            </div>
            
            <div class="flex-buttons" style="margin-top:16px;">
                <button id="closeMonitoringBtnDashboard" style="background:#1e293b; color:#cbd5e6;">Tutup</button>
            </div>
        `;
        openModalDashboard();
        
        try {
            const response = await fetch(baseUrlDashboard + 'bd/get_brand_performance', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: new URLSearchParams({ 
                    brand_id: brandId,
                    start_date: startDate,
                    end_date: endDate
                })
            });
            const result = await response.json();
            
            if (result.success) {
                renderPerformanceContent(result.data);
            } else {
                document.getElementById('performanceContent').innerHTML = `
                    <div class="empty-state" style="text-align:center; padding:40px; color:#ef4444;">
                        <i class="fas fa-exclamation-triangle"></i>
                        <p>Error: ${result.message}</p>
                    </div>
                `;
            }
        } catch (error) {
            console.error('Error loading performance:', error);
            document.getElementById('performanceContent').innerHTML = `
                <div class="empty-state" style="text-align:center; padding:40px; color:#ef4444;">
                    <i class="fas fa-exclamation-triangle"></i>
                    <p>Error loading performance data: ${error.message}</p>
                </div>
            `;
        }
        
        document.getElementById('applyPerfFilter')?.addEventListener('click', () => {
            const newStart = document.getElementById('perfStartDate').value;
            const newEnd = document.getElementById('perfEndDate').value;
            if (newStart && newEnd) {
                loadPerformanceData(newStart, newEnd);
            }
        });
        
        document.getElementById('resetPerfFilter')?.addEventListener('click', () => {
            const todayDate = new Date().toISOString().split('T')[0];
            document.getElementById('perfStartDate').value = todayDate;
            document.getElementById('perfEndDate').value = todayDate;
            loadPerformanceData(todayDate, todayDate);
        });
        
        document.getElementById('closeMonitoringBtnDashboard')?.addEventListener('click', closeModalDashboard);
    }
    
    function renderPerformanceContent(data) {
        const contentDiv = document.getElementById('performanceContent');
        
        let productsHtml = '';
        if (data.products && data.products.length > 0) {
            data.products.forEach(p => {
                productsHtml += `
                    <div style="display:flex; justify-content:space-between; align-items:center; padding:10px; border-bottom:1px solid #2a3346;">
                        <div>
                            <div style="color:#e2f0e8; font-size:12px; font-weight:500;">${escapeHtml(p.product_name || 'Unknown')}</div>
                            <div style="color:#9aaebe; font-size:10px;">${p.sales_count || 0} sold �� Komisi: ${p.commission_rate || 0}%</div>
                        </div>
                        <div style="color:#4ade80; font-size:12px; font-weight:600;">Rp ${formatNumber(p.gmv)}</div>
                    </div>
                `;
            });
        } else {
            productsHtml = '<div class="text-center" style="color:#9aaebe; padding:20px;">Belum ada produk terjual</div>';
        }
        
        let creatorsHtml = '';
        if (data.creators && data.creators.length > 0) {
            data.creators.forEach(c => {
                creatorsHtml += `
                    <div style="display:flex; justify-content:space-between; align-items:center; padding:10px; border-bottom:1px solid #2a3346;">
                        <div>
                            <div style="color:#e2f0e8; font-size:12px;">@${escapeHtml(c.creator_username)}</div>
                            <div style="color:#9aaebe; font-size:10px;">${c.total_orders} orders</div>
                        </div>
                        <div style="color:#4ade80; font-size:12px;">Rp ${formatNumber(c.total_gmv)}</div>
                    </div>
                `;
            });
        } else {
            creatorsHtml = '<div class="text-center" style="color:#9aaebe; padding:20px;">Belum ada creator</div>';
        }
        
        contentDiv.innerHTML = `
            <div style="display:grid; grid-template-columns:1fr 1fr; gap:12px; margin-bottom:20px;">
                <div style="background:#0f1420; border-radius:12px; padding:12px; text-align:center;">
                    <div style="color:#4ade80; font-size:20px; font-weight:700;">Rp ${formatNumber(data.total_gmv)}</div>
                    <div style="color:#9aaebe; font-size:10px;">Total GMV</div>
                    <div style="font-size:9px; color:#4ade80;">Periode: ${data.period.start_date} - ${data.period.end_date}</div>
                </div>
                <div style="background:#0f1420; border-radius:12px; padding:12px; text-align:center;">
                    <div style="color:#4ade80; font-size:20px; font-weight:700;">${formatNumber(data.total_orders)}</div>
                    <div style="color:#9aaebe; font-size:10px;">Total Orders</div>
                </div>
                <div style="background:#0f1420; border-radius:12px; padding:12px; text-align:center;">
                    <div style="color:#fbbf24; font-size:20px; font-weight:700;">Rp ${formatNumber(data.total_commission)}</div>
                    <div style="color:#9aaebe; font-size:10px;">Commission</div>
                </div>
                <div style="background:#0f1420; border-radius:12px; padding:12px; text-align:center;">
                    <div style="color:#4ade80; font-size:20px; font-weight:700;">${data.roas}x</div>
                    <div style="color:#9aaebe; font-size:10px;">ROAS</div>
                </div>
            </div>
            
            <div style="margin-bottom:16px;">
                <label style="color:#e2f0e8; font-size:12px; margin-bottom:8px; display:block;"><i class="fas fa-box"></i> Top Products</label>
                <div style="max-height:200px; overflow-y:auto; background:#0f1420; border-radius:12px;">
                    ${productsHtml}
                </div>
            </div>
            
            <div>
                <label style="color:#e2f0e8; font-size:12px; margin-bottom:8px; display:block;"><i class="fas fa-users"></i> Top Creators</label>
                <div style="max-height:150px; overflow-y:auto; background:#0f1420; border-radius:12px;">
                    ${creatorsHtml}
                </div>
            </div>
        `;
    }
    
    loadPerformanceData(currentStartDate, currentEndDate);
}

// ========== CLICK BRAND ITEM ==========
document.querySelectorAll('.brand-item-dashboard').forEach(item => {
    item.addEventListener('click', async (e) => { 
        if (e.target.closest('.remove-existing-product-dashboard') || e.target.closest('.remove-new-product-dashboard')) return;
        const brandId = item.getAttribute('data-brand-id');
        const brandName = item.getAttribute('data-brand-name');
        const stage = parseInt(item.getAttribute('data-stage'));
        
        if (stage === 1) {
            showTask1DetailDashboard(brandId, brandName);
        } else if (stage === 3) {
            showTask3SetupModalDashboard(brandId, brandName);
        } else if (stage === 4) {
            showTask4MonitoringModalDashboard(brandId, brandName);
        }
    });
});

// ========== SHOW NEW BRAND MODAL ==========
function showNewBrandModal() {
    console.log('Opening new brand modal');
    const modalTitleElem = document.getElementById('modalTitleDashboard'); 
    const modalBodyElem = document.getElementById('modalBodyDashboard');
    
    modalTitleElem.innerHTML = '<i class="fas fa-search"></i> Cari Brand Baru';
    modalBodyElem.innerHTML = `
        <div style="background:rgba(74,222,128,0.1); border-radius:14px; padding:12px; margin-bottom:16px;">
            <p style="color:#4ade80; font-size:12px;"><i class="fas fa-robot"></i> Cari brand baru dari TikTok Shop</p>
            <p style="color:#9aaebe; font-size:10px;">Masukkan username TikTok Shop brand (contoh: @superregen atau superregen)</p>
        </div>
        <label>Shop Name *</label>
        <input type="text" id="brandNameDashboard" placeholder="Contoh: superregen, cimolbojot, wardahbeauty">
        <div style="font-size:10px; color:#9aaebe; margin-top:4px;">Masukkan username tanpa @ atau dengan @ sama saja</div>
        <label>Kategori</label>
        <select id="brandCategoryDashboard">
            <option value="BEAUTY">Beauty</option>
            <option value="ELECTRONICS">Elektronik</option>
            <option value="FASHION">Fashion</option>
            <option value="FOOD">Makanan</option>
            <option value="OTHER">Lainnya</option>
        </select>
        <label>Kontak WhatsApp</label>
        <input type="tel" id="brandWhatsappDashboard" placeholder="+62 812 3456 7890">
        <button id="saveNewBrandBtnDashboard" style="margin-top:16px; width:100%; background:#4ade80; color:#0a0e17; font-weight:600; padding:12px; border-radius:40px; border:none; cursor:pointer;">
            <i class="fas fa-save"></i> Simpan Brand
        </button>
    `;
    openModalDashboard();
    
    const saveBtn = document.getElementById('saveNewBrandBtnDashboard');
    if (saveBtn) {
        saveBtn.replaceWith(saveBtn.cloneNode(true));
        document.getElementById('saveNewBrandBtnDashboard')?.addEventListener('click', async () => {
            const brandName = document.getElementById('brandNameDashboard')?.value.trim();
            if (!brandName) { showToastInModal('Nama brand harus diisi!', 'error'); return; }
            
            const btn = document.getElementById('saveNewBrandBtnDashboard');
            btn.disabled = true; 
            btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Menyimpan...';
            
            try {
                const response = await fetch(baseUrlDashboard + 'bd/scout_match_brand', { 
                    method: 'POST', 
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, 
                    body: new URLSearchParams({ 
                        brand_name: brandName, 
                        category: document.getElementById('brandCategoryDashboard')?.value || 'OTHER', 
                        whatsapp_number: document.getElementById('brandWhatsappDashboard')?.value || '', 
                        commission: 0
                    }) 
                });
                
                const result = await response.json();
                
                if (result.success) { 
                    closeModalDashboard();
                    if (result.warning) {
                        // Tampilkan toast dengan peringatan
                        showToastInModal(result.message, 'warning');
                        // Tampilkan alert tambahan untuk peringatan kompetisi
                        setTimeout(() => {
                            alert(`�7�2�1�5 PERINGATAN!\n\n${result.message}\n\nSiapa yang deal duluan yang akan mendapatkan brand ini.`);
                        }, 500);
                    } else {
                        showToastInModal(result.message, 'success');
                    }
                    setTimeout(() => location.reload(), 2000);
                } else if (result.my_duplicate) {
                    // BD yang sama mencoba input brand yang sama
                    showToastInModal(result.message, 'error');
                    btn.disabled = false;
                    btn.innerHTML = '<i class="fas fa-save"></i> Simpan Brand';
                } else if (result.already_deal) {
                    showToastInModal(result.message, 'error');
                    btn.disabled = false;
                    btn.innerHTML = '<i class="fas fa-save"></i> Simpan Brand';
                } else { 
                    showToastInModal(result.message || 'Gagal menyimpan brand', 'error'); 
                    btn.disabled = false;
                    btn.innerHTML = '<i class="fas fa-save"></i> Simpan Brand';
                }
            } catch (err) {
                console.error('Error saving brand:', err);
                showToastInModal('Terjadi kesalahan jaringan: ' + err.message, 'error');
                btn.disabled = false;
                btn.innerHTML = '<i class="fas fa-save"></i> Simpan Brand';
            }
        });
    }
}

// ========== NEW GET BRAND IFO=======//

// ========== SEARCH BRAND VARIABLES ==========
let searchDebounceTimer = null;
let currentSearchKeyword = '';
let currentSearchResults = { shops: [], products: [] };
let currentSelectedShop = null;
let currentSelectedProduct = null;
let isSearchingBrand = false;

// �9�7 FUNGSI UNTUK MENCARI BRAND/PRODUK
async function searchBrandProducts(keyword) {
    if (!keyword || keyword.length < 2) {
        return { shops: [], products: [] };
    }
    
    try {
        const response = await fetch(baseUrlDashboard + 'brand_crawler/test_search?keyword=' + encodeURIComponent(keyword));
        const result = await response.json();
        
        console.log('Search API response:', result);
        
        // �9�7 STRUKTUR RESPONSE DARI ENDPOINT ANDA:
        // {
        //   success: true,
        //   keyword: "kime",
        //   shop_name: "Kime Skincare Shop",
        //   seller_id: "7494474196244400831",
        //   whatsapp: "085803943120",
        //   email: null
        // }
        
        if (result.success === true) {
            let shops = [];
            let products = [];
            
            // Buat shop dari data yang didapat
            if (result.seller_id && result.shop_name) {
                shops.push({
                    type: 'shop',
                    id: result.seller_id,
                    name: result.shop_name,
                    product_count: 0,
                    contact_info: {
                        whatsapp: result.whatsapp || '',
                        email: result.email || ''
                    }
                });
                
                // Tambahkan juga sebagai produk dummy (opsional)
                if (result.shop_name) {
                    products.push({
                        type: 'product',
                        id: 'product_' + result.seller_id,
                        name: 'Produk dari ' + result.shop_name,
                        shop_name: result.shop_name,
                        shop_id: result.seller_id,
                        price: 0,
                        price_formatted: 'Rp 0',
                        image_url: '',
                        sales: 0,
                        sales_formatted: '0',
                        commission_rate: 0,
                        contact_info: {
                            whatsapp: result.whatsapp || '',
                            email: result.email || ''
                        }
                    });
                }
            }
            
            console.log('Parsed shops:', shops.length, 'products:', products.length);
            
            return { shops, products };
        }
        
        return { shops: [], products: [] };
    } catch (error) {
        console.error('Error searching brand:', error);
        return { shops: [], products: [] };
    }
}
// �9�7 FUNGSI UNTUK MENGAMBIL KONTAK BRAND (WHATSAPP & EMAIL)
async function fetchBrandContact(sellerId, shopName) {
    if (!sellerId || sellerId === '' || sellerId === 'null' || sellerId === 'undefined') {
        console.log('No seller_id provided');
        return { success: false, whatsapp: '', email: '' };
    }
    
    console.log('Fetching contact for seller_id:', sellerId, 'shop:', shopName);
    
    try {
        const response = await fetch(baseUrlDashboard + 'brand_crawler/test_contact?seller_id=' + encodeURIComponent(sellerId));
        const result = await response.json();
        
        console.log('Contact API response:', result);
        
        if (result.http_code === 200) {
            let whatsapp = result.whatsapp || '';
            let email = result.email || '';
            
            // Bersihkan nomor WhatsApp (hilangkan masking seperti 0**********0)
            if (whatsapp && whatsapp.includes('*')) {
                console.log('WhatsApp has masking, ignoring');
                whatsapp = '';
            }
            
            return {
                success: true,
                whatsapp: whatsapp,
                email: email,
                raw: result
            };
        }
        
        return { success: false, whatsapp: '', email: '', message: result.error || 'Kontak tidak ditemukan' };
    } catch (error) {
        console.error('Error fetching contact:', error);
        return { success: false, whatsapp: '', email: '', error: error.message };
    }
}
// �9�7 MODAL SEARCH BRAND (GANTI showNewBrandModal)
function showNewBrandModal() {
    console.log('Opening new brand modal with search');
    const modalTitleElem = document.getElementById('modalTitleDashboard'); 
    const modalBodyElem = document.getElementById('modalBodyDashboard');
    
    // Reset variables
    if (searchDebounceTimer) clearTimeout(searchDebounceTimer);
    searchDebounceTimer = null;
    currentSearchKeyword = '';
    currentSearchResults = { shops: [], products: [] };
    currentSelectedShop = null;
    currentSelectedProduct = null;
    
    modalTitleElem.innerHTML = '<i class="fas fa-search"></i> Cari Brand Baru';
    modalBodyElem.innerHTML = `
        <div style="background:rgba(74,222,128,0.1); border-radius:14px; padding:12px; margin-bottom:16px;">
            <p style="color:#4ade80; font-size:12px;"><i class="fas fa-robot"></i> Cari brand dari TikTok Shop</p>
            <p style="color:#9aaebe; font-size:10px;">Masukkan nama produk atau shop untuk mencari</p>
        </div>
        
        <!-- Search Input -->
        <div style="position: relative;">
            <input type="text" id="brandSearchInput" placeholder="Cari produk atau shop... (contoh: hanasui, scarlett, somethinc)" 
                   style="width:100%; padding:12px; background:#0f1420; border:1px solid #2a3346; border-radius:12px; color:#e2f0e8; font-size:14px;">
            <div id="searchResultsDropdown" style="position: absolute; top:100%; left:0; right:0; background:#0f1420; border:1px solid #2a3346; border-radius:12px; margin-top:4px; max-height:300px; overflow-y:auto; z-index:1000; display:none;">
            </div>
        </div>
        
        <!-- Loading Indicator -->
        <div id="searchLoading" style="display:none; text-align:center; padding:20px;">
            <i class="fas fa-spinner fa-pulse"></i> Mencari...
        </div>
        
        <!-- Selected Item Display -->
        <div id="selectedItemDisplay" style="display:none; margin-top:16px; background:rgba(74,222,128,0.1); border-radius:12px; padding:12px;">
            <div style="display:flex; justify-content:space-between; align-items:center;">
                <div>
                    <span style="color:#9aaebe; font-size:10px;">Dipilih:</span>
                    <div id="selectedItemName" style="color:#e2f0e8; font-weight:600; margin-top:4px;"></div>
                    <div id="selectedItemType" style="font-size:10px; color:#8b5cf6; margin-top:2px;"></div>
                </div>
                <button id="clearSelectionBtn" style="background:#1e293b; color:#ef4444; border:1px solid #ef4444; padding:4px 12px; border-radius:20px; cursor:pointer; font-size:11px;">
                    <i class="fas fa-times"></i> Hapus
                </button>
            </div>
        </div>
        
        <!-- Form Input (otomatis terisi jika pilih dari search) -->
        <div style="margin-top:16px;">
            <label><i class="fas fa-store"></i> Nama Brand *</label>
            <input type="text" id="brandNameDashboard" placeholder="Nama brand akan otomatis terisi" style="width:100%; padding:10px; background:#0f1420; border:1px solid #2a3346; border-radius:10px; color:#e2f0e8;">
            
            <label><i class="fas fa-tag"></i> Kategori</label>
            <select id="brandCategoryDashboard" style="width:100%; padding:10px; background:#0f1420; border:1px solid #2a3346; border-radius:10px; color:#e2f0e8;">
                <option value="BEAUTY">Beauty</option>
                <option value="ELECTRONICS">Elektronik</option>
                <option value="FASHION">Fashion</option>
                <option value="FOOD">Makanan</option>
                <option value="OTHER">Lainnya</option>
            </select>
            
            <label><i class="fab fa-whatsapp"></i> WhatsApp <span id="whatsappStatus" style="font-size:10px; color:#fbbf24; margin-left:8px;"></span></label>
            <div style="display:flex; gap:8px; align-items:center;">
                <input type="tel" id="brandWhatsappDashboard" placeholder="+62 812 3456 7890" style="flex:1; padding:10px; background:#0f1420; border:1px solid #2a3346; border-radius:10px; color:#e2f0e8;">
                <button type="button" id="refreshContactBtn" style="background:#8b5cf6; color:white; border:none; padding:8px 12px; border-radius:10px; cursor:pointer; font-size:11px;" title="Cari ulang kontak">
                    <i class="fas fa-sync-alt"></i>
                </button>
            </div>
            
            <label><i class="fas fa-envelope"></i> Email</label>
            <input type="email" id="brandEmailDashboard" placeholder="Email brand (opsional)" style="width:100%; padding:10px; background:#0f1420; border:1px solid #2a3346; border-radius:10px; color:#e2f0e8;">
            
            <input type="hidden" id="sellerIdHidden" value="">
            <input type="hidden" id="selectedProductIdHidden" value="">
        </div>
        
        <div style="margin-top:16px; padding:10px; background:#1a1f2e; border-radius:10px; font-size:11px; color:#9aaebe;">
            <i class="fas fa-info-circle"></i> <strong>Tips:</strong>
            <ul style="margin:5px 0 0 20px; padding:0;">
                <li>Ketik nama produk atau shop untuk mencari</li>
                <li>Pilih dari hasil pencarian untuk auto-fill data brand</li>
                <li>Klik tombol refresh �9�4 untuk mencari kontak WhatsApp & Email</li>
            </ul>
        </div>
        
        <div class="flex-buttons" style="margin-top:20px;">
            <button id="saveNewBrandBtnDashboard" style="background:#4ade80; color:#0a0e17; flex:1; padding:12px; border-radius:40px; border:none; cursor:pointer; font-weight:600;">
                <i class="fas fa-save"></i> Simpan Brand
            </button>
            <button id="cancelSearchBrandBtn" style="background:#1e293b; color:#cbd5e6; flex:1; padding:12px; border-radius:40px; border:1px solid #2a3346; cursor:pointer;">
                Batal
            </button>
        </div>
    `;
    openModalDashboard();
    
    // ========== GET DOM ELEMENTS ==========
    const searchInput = document.getElementById('brandSearchInput');
    const dropdown = document.getElementById('searchResultsDropdown');
    const loadingDiv = document.getElementById('searchLoading');
    
    if (!searchInput) {
        console.error('searchInput not found');
        return;
    }
    
    // �9�7 SEARCH ON TYPING (DEBOUNCE)
    searchInput.addEventListener('input', (e) => {
        const keyword = e.target.value.trim();
        
        // Clear previous timer
        if (searchDebounceTimer) {
            clearTimeout(searchDebounceTimer);
        }
        
        if (keyword.length < 2) {
            if (dropdown) dropdown.style.display = 'none';
            return;
        }
        
        // Set new timer
        searchDebounceTimer = setTimeout(async () => {
            if (loadingDiv) loadingDiv.style.display = 'block';
            if (dropdown) {
                dropdown.style.display = 'block';
                dropdown.innerHTML = '<div style="text-align:center; padding:20px; color:#9aaebe;"><i class="fas fa-spinner fa-pulse"></i> Mencari...</div>';
            }
            
            const results = await searchBrandProducts(keyword);
            currentSearchResults = results;
            
            if (loadingDiv) loadingDiv.style.display = 'none';
            
            if ((!results.shops || results.shops.length === 0) && (!results.products || results.products.length === 0)) {
                if (dropdown) dropdown.innerHTML = '<div style="text-align:center; padding:20px; color:#ef4444;">Tidak ditemukan hasil</div>';
                return;
            }
            
            let html = '';
            
            // Tampilkan Shops
          if (results.shops && results.shops.length > 0) {
    html += `<div style="padding:8px 12px; background:#1a1f2e; color:#8b5cf6; font-size:11px; font-weight:600;"> TOKO (${results.shops.length})</div>`;
    results.shops.forEach(shop => {
        html += `
            <div class="search-result-item" data-type="shop" 
                 data-id="${shop.id}" 
                 data-name="${escapeHtml(shop.name)}" 
                 data-shop-id="${shop.id}"
                 data-shop-name="${escapeHtml(shop.name)}"
                 data-contact-info='${JSON.stringify(shop.contact_info || {})}'
                 style="padding:10px 12px; cursor:pointer; border-bottom:1px solid #2a3346; transition:background 0.2s;"
                 onmouseover="this.style.background='rgba(139,92,246,0.1)'" onmouseout="this.style.background='transparent'">
                <div style="display:flex; align-items:center; gap:8px;">
                    <i class="fas fa-store" style="color:#8b5cf6;"></i>
                    <div>
                        <div style="font-weight:500; color:#e2f0e8;"> ${escapeHtml(shop.name)}</div>
                        <div style="font-size:11px; color:#9aaebe;">ID: ${shop.id}</div>
                    </div>
                </div>
            </div>
        `;
    });
}
            
            // Tampilkan Products
            if (results.products && results.products.length > 0) {
    html += `<div style="padding:8px 12px; background:#1a1f2e; color:#4ade80; font-size:11px; font-weight:600;"> PRODUK (${results.products.length})</div>`;
    results.products.slice(0, 20).forEach(product => {
        const priceFormatted = product.price_formatted || `Rp ${formatNumber(product.price)}`;
        const shopDisplay = product.shop_name ? `${escapeHtml(product.shop_name)}` : '';
        
        html += `
            <div class="search-result-item" data-type="product" 
                 data-id="${product.id}" 
                 data-shop-id="${product.shop_id}" 
                 data-shop-name="${escapeHtml(product.shop_name)}" 
                 data-name="${escapeHtml(product.name)}"
                 data-price="${product.price}" 
                 data-price-formatted="${escapeHtml(priceFormatted)}"
                 data-image="${escapeHtml(product.image_url)}"
                 data-contact-info='${JSON.stringify(product.contact_info || {})}'
                 style="padding:10px 12px; cursor:pointer; border-bottom:1px solid #2a3346; transition:background 0.2s;"
                 onmouseover="this.style.background='rgba(139,92,246,0.1)'" onmouseout="this.style.background='transparent'">
                <div style="display:flex; gap:12px; align-items:center;">
                    ${product.image_url ? `<img src="${escapeHtml(product.image_url)}" style="width:40px; height:40px; object-fit:cover; border-radius:8px;" onerror="this.style.display='none'">` : '<div style="width:40px; height:40px; background:#1e293b; border-radius:8px; display:flex; align-items:center; justify-content:center;"><i class="fas fa-box"></i></div>'}
                    <div style="flex:1;">
                        <div style="font-weight:500; color:#e2f0e8; font-size:12px;">${escapeHtml(product.name.substring(0, 60))}${product.name.length > 60 ? '...' : ''}</div>
                        <div style="font-size:10px; color:#4ade80;">${shopDisplay}</div>
                        <div style="font-size:10px; color:#fbbf24;">${priceFormatted} | Terjual: ${escapeHtml(product.sales_formatted || '0')}</div>
                    </div>
                </div>
            </div>
        `;
    });
}
            
            if (dropdown) dropdown.innerHTML = html;
            
           
           // Attach click events to search results
document.querySelectorAll('.search-result-item').forEach(item => {
    item.addEventListener('click', async () => {
        const type = item.getAttribute('data-type');
        const name = item.getAttribute('data-name');
        const shopId = item.getAttribute('data-shop-id');  // �9�7 INI YANG PENTING
        const shopName = item.getAttribute('data-shop-name');
        const productId = item.getAttribute('data-id');
        const priceFormatted = item.getAttribute('data-price-formatted');
        const imageUrl = item.getAttribute('data-image');
        
        console.log('Selected item:', { type, name, shopId, shopName, productId });
        
        let contactInfo = {};
        try {
            const contactInfoStr = item.getAttribute('data-contact-info');
            if (contactInfoStr && contactInfoStr !== 'null' && contactInfoStr !== 'undefined') {
                contactInfo = JSON.parse(contactInfoStr);
            }
        } catch(e) {
            console.error('Parse contact info error:', e);
        }
        
        if (dropdown) dropdown.style.display = 'none';
        if (searchInput) searchInput.value = name;
        
        // Tampilkan selected item
        const selectedDisplay = document.getElementById('selectedItemDisplay');
        const selectedName = document.getElementById('selectedItemName');
        const selectedType = document.getElementById('selectedItemType');
        const brandNameInput = document.getElementById('brandNameDashboard');
        
        if (selectedDisplay) selectedDisplay.style.display = 'block';
        if (selectedName) selectedName.innerText = name;
        if (selectedType) selectedType.innerHTML = type === 'shop' ? ' Toko' : ' Produk';
        
        // Set brand name
        if (brandNameInput) {
            if (type === 'shop') {
                brandNameInput.value = shopName || name;
            } else if (shopName && shopName !== 'Unknown Shop') {
                brandNameInput.value = shopName;
            } else {
                brandNameInput.value = name;
            }
        }
        
        const sellerIdHidden = document.getElementById('sellerIdHidden');
        const productIdHidden = document.getElementById('selectedProductIdHidden');
        
        // �9�7 PASTIKAN SHOP ID TERSIMPAN
        if (sellerIdHidden) {
            if (shopId && shopId !== '' && shopId !== 'null' && shopId !== 'undefined') {
                sellerIdHidden.value = shopId;
                console.log('Seller ID saved:', shopId);
            } else {
                sellerIdHidden.value = '';
                console.log('No seller ID for this item');
            }
        }
        if (productIdHidden) productIdHidden.value = productId || '';
        
        currentSelectedShop = { id: shopId, name: type === 'shop' ? (shopName || name) : shopName, contact_info: contactInfo };
        currentSelectedProduct = type === 'product' ? { id: productId, name: name, price: priceFormatted, image: imageUrl } : null;
        
        // �9�7 AUTO FETCH KONTAK (gunakan seller_id)
        const whatsappStatus = document.getElementById('whatsappStatus');
        
        if (shopId && shopId !== '' && shopId !== 'null' && shopId !== 'undefined') {
            showToastInModal('�9�3 Mencari kontak brand...', 'info');
            
            // Cek apakah ada kontak dari data produk
            let whatsappNumber = contactInfo.whatsapp || '';
            let emailAddress = contactInfo.email || '';
            
            // Jika WhatsApp masking (0**********0) atau kosong, coba dari API
            if (!whatsappNumber || whatsappNumber.includes('*')) {
                const contactResult = await fetchBrandContact(shopId, shopName);
                if (contactResult.success && contactResult.whatsapp && !contactResult.whatsapp.includes('*')) {
                    whatsappNumber = contactResult.whatsapp;
                    emailAddress = contactResult.email || '';
                }
            }
            
            const whatsappInput = document.getElementById('brandWhatsappDashboard');
            const emailInput = document.getElementById('brandEmailDashboard');
            
            if (whatsappNumber && !whatsappNumber.includes('*')) {
                if (whatsappInput) whatsappInput.value = whatsappNumber;
                if (emailInput) emailInput.value = emailAddress;
                if (whatsappStatus) {
                    whatsappStatus.innerHTML = '(Auto-ditemukan)';
                    whatsappStatus.style.color = '#4ade80';
                }
                showToastInModal(`Kontak ditemukan! WhatsApp: ${whatsappNumber}`, 'success');
            } else {
                if (whatsappStatus) {
                    whatsappStatus.innerHTML = '(Tidak ditemukan - isi manual)';
                    whatsappStatus.style.color = '#fbbf24';
                }
                showToastInModal('Kontak tidak ditemukan, silakan isi manual', 'warning');
            }
        } else {
            if (whatsappStatus) {
                whatsappStatus.innerHTML = '(Tidak ada seller ID - isi manual)';
                whatsappStatus.style.color = '#ef4444';
            }
            showToastInModal('Seller ID tidak ditemukan, silakan isi manual', 'warning');
        }
    });
});
        }, 500);
    });
    
    // Hide dropdown when clicking outside
    document.addEventListener('click', (e) => {
        if (searchInput && dropdown && !searchInput.contains(e.target) && !dropdown.contains(e.target)) {
            dropdown.style.display = 'none';
        }
    });
    
    // Clear selection
    const clearBtn = document.getElementById('clearSelectionBtn');
    if (clearBtn) {
        clearBtn.addEventListener('click', () => {
            const selectedDisplay = document.getElementById('selectedItemDisplay');
            const brandNameInput = document.getElementById('brandNameDashboard');
            const sellerIdHidden = document.getElementById('sellerIdHidden');
            const productIdHidden = document.getElementById('selectedProductIdHidden');
            const whatsappInput = document.getElementById('brandWhatsappDashboard');
            const emailInput = document.getElementById('brandEmailDashboard');
            const whatsappStatus = document.getElementById('whatsappStatus');
            
            if (selectedDisplay) selectedDisplay.style.display = 'none';
            if (brandNameInput) brandNameInput.value = '';
            if (sellerIdHidden) sellerIdHidden.value = '';
            if (productIdHidden) productIdHidden.value = '';
            if (whatsappInput) whatsappInput.value = '';
            if (emailInput) emailInput.value = '';
            if (whatsappStatus) whatsappStatus.innerHTML = '';
            if (searchInput) searchInput.value = '';
            
            currentSelectedShop = null;
            currentSelectedProduct = null;
        });
    }
    
    // Refresh contact button
    const refreshBtn = document.getElementById('refreshContactBtn');
    if (refreshBtn) {
        refreshBtn.addEventListener('click', async () => {
            const sellerId = document.getElementById('sellerIdHidden')?.value;
            const brandName = document.getElementById('brandNameDashboard')?.value;
            
            if (!sellerId || sellerId === '') {
                showToastInModal('Pilih produk atau toko terlebih dahulu dari hasil pencarian', 'error');
                return;
            }
            
            refreshBtn.disabled = true;
            refreshBtn.innerHTML = '<i class="fas fa-spinner fa-pulse"></i>';
            
            showToastInModal('�9�3 Mencari ulang kontak brand...', 'info');
            
            const contactResult = await fetchBrandContact(sellerId, brandName);
            
            const whatsappInput = document.getElementById('brandWhatsappDashboard');
            const emailInput = document.getElementById('brandEmailDashboard');
            const whatsappStatus = document.getElementById('whatsappStatus');
            
            if (contactResult.success && contactResult.whatsapp) {
                if (whatsappInput) whatsappInput.value = contactResult.whatsapp;
                if (emailInput) emailInput.value = contactResult.email || '';
                if (whatsappStatus) {
                    whatsappStatus.innerHTML = '(Auto-ditemukan)';
                    whatsappStatus.style.color = '#4ade80';
                }
                showToastInModal(`Kontak ditemukan! WhatsApp: ${contactResult.whatsapp}`, 'success');
            } else {
                if (whatsappStatus) {
                    whatsappStatus.innerHTML = '(Tidak ditemukan - isi manual)';
                    whatsappStatus.style.color = '#fbbf24';
                }
                showToastInModal(' Kontak tidak ditemukan, silakan isi manual', 'warning');
            }
            
            refreshBtn.disabled = false;
            refreshBtn.innerHTML = '<i class="fas fa-sync-alt"></i>';
        });
    }
    
    // Save button
    const saveBtn = document.getElementById('saveNewBrandBtnDashboard');
    if (saveBtn) {
        const newSaveBtn = saveBtn.cloneNode(true);
        saveBtn.parentNode.replaceChild(newSaveBtn, saveBtn);
        
        newSaveBtn.addEventListener('click', async () => {
            const brandName = document.getElementById('brandNameDashboard')?.value.trim();
            if (!brandName) { 
                showToastInModal('Nama brand harus diisi!', 'error'); 
                return; 
            }
            
            const btn = newSaveBtn;
            btn.disabled = true; 
            btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Menyimpan...';
            
            try {
                const response = await fetch(baseUrlDashboard + 'bd/scout_match_brand', { 
                    method: 'POST', 
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, 
                    body: new URLSearchParams({ 
                        brand_name: brandName, 
                        category: document.getElementById('brandCategoryDashboard')?.value || 'OTHER', 
                        whatsapp_number: document.getElementById('brandWhatsappDashboard')?.value || '', 
                        email: document.getElementById('brandEmailDashboard')?.value || '',
                        seller_id: document.getElementById('sellerIdHidden')?.value || '',
                        product_id: document.getElementById('selectedProductIdHidden')?.value || '',
                        commission: 0
                    }) 
                });
                
                const result = await response.json();
                
                if (result.success) { 
                    closeModalDashboard();
                    if (result.warning) {
                        showToastInModal(result.message, 'warning');
                        setTimeout(() => {
                            alert(`�7�2�1�5 PERINGATAN!\n\n${result.message}\n\nSiapa yang deal duluan yang akan mendapatkan brand ini.`);
                        }, 500);
                    } else {
                        showToastInModal(result.message, 'success');
                    }
                    setTimeout(() => location.reload(), 2000);
                } else if (result.my_duplicate) {
                    showToastInModal(result.message, 'error');
                    btn.disabled = false;
                    btn.innerHTML = '<i class="fas fa-save"></i> Simpan Brand';
                } else if (result.already_deal) {
                    showToastInModal(result.message, 'error');
                    btn.disabled = false;
                    btn.innerHTML = '<i class="fas fa-save"></i> Simpan Brand';
                } else { 
                    showToastInModal(result.message || 'Gagal menyimpan brand', 'error'); 
                    btn.disabled = false;
                    btn.innerHTML = '<i class="fas fa-save"></i> Simpan Brand';
                }
            } catch (err) {
                console.error('Error saving brand:', err);
                showToastInModal('Terjadi kesalahan jaringan: ' + err.message, 'error');
                btn.disabled = false;
                btn.innerHTML = '<i class="fas fa-save"></i> Simpan Brand';
            }
        });
    }
    
    // Cancel button
    const cancelBtn = document.getElementById('cancelSearchBrandBtn');
    if (cancelBtn) {
        cancelBtn.addEventListener('click', closeModalDashboard);
    }
}
// ========== TASK BUTTONS ==========
// Task 1: Hunting
const huntingBtn = document.querySelector('.task-btn-dashboard[data-action="hunting"]');
if (huntingBtn) {
    const newHuntingBtn = huntingBtn.cloneNode(true);
    huntingBtn.parentNode.replaceChild(newHuntingBtn, huntingBtn);
    newHuntingBtn.addEventListener('click', function(e) {
        e.preventDefault();
        e.stopPropagation();
        showNewBrandModal();
    });
}

// Task 2: Setup Campaign (sekarang data-action="setup")
const setupBtn = document.querySelector('.task-btn-dashboard[data-action="setup"]');
if (setupBtn) {
    const newSetupBtn = setupBtn.cloneNode(true);
    setupBtn.parentNode.replaceChild(newSetupBtn, setupBtn);
    newSetupBtn.addEventListener('click', () => { 
        const firstItem = document.querySelector('#setupItemsContainerDashboard .brand-item-dashboard'); 
        if (firstItem) {
            showTask3SetupModalDashboard(firstItem.getAttribute('data-brand-id'), firstItem.getAttribute('data-brand-name'));
        } else showToastInModal('Tidak ada brand yang siap setup', 'error'); 
    });
}

// Task 3: Monitoring (sekarang data-action="monitoring")
const monitoringBtn = document.querySelector('.task-btn-dashboard[data-action="monitoring"]');
if (monitoringBtn) {
    const newMonitoringBtn = monitoringBtn.cloneNode(true);
    monitoringBtn.parentNode.replaceChild(newMonitoringBtn, monitoringBtn);
    newMonitoringBtn.addEventListener('click', () => { 
        const firstItem = document.querySelector('#monitoringItemsContainerDashboard .brand-item-dashboard'); 
        if (firstItem) {
            showTask4MonitoringModalDashboard(firstItem.getAttribute('data-brand-id'), firstItem.getAttribute('data-brand-name'));
        } else showToastInModal('Tidak ada campaign aktif', 'error'); 
    });
}

// ========== TAB SWITCHING ==========
document.querySelectorAll('.tab-btn-dashboard').forEach(btn => { 
    btn.addEventListener('click', () => { 
        const tabId = btn.getAttribute('data-tab'); 
        document.querySelectorAll('.tab-content-dashboard').forEach(c => c.classList.remove('active')); 
        document.querySelectorAll('.tab-btn-dashboard').forEach(b => b.classList.remove('active')); 
        document.getElementById(tabId).classList.add('active'); 
        btn.classList.add('active'); 
        document.querySelectorAll('.mobile-nav-item-dashboard').forEach(nav => { 
            if (nav.getAttribute('data-tab') === tabId) nav.classList.add('active'); 
            else nav.classList.remove('active'); 
        });
    }); 
});

// ========== SCOUT BTN ==========
const scoutBtn = document.getElementById('scoutBtnDashboard');
if (scoutBtn) {
    const newScoutBtn = scoutBtn.cloneNode(true);
    scoutBtn.parentNode.replaceChild(newScoutBtn, scoutBtn);
    newScoutBtn.addEventListener('click', function(e) {
        e.preventDefault();
        e.stopPropagation();
        showNewBrandModal();
    });
}

// ========== LEADERBOARD SIDEBAR ==========
const openLeaderboardBtn = document.getElementById('openLeaderboardBtnDashboard');
if (openLeaderboardBtn) {
    const newLeaderboardBtn = openLeaderboardBtn.cloneNode(true);
    openLeaderboardBtn.parentNode.replaceChild(newLeaderboardBtn, openLeaderboardBtn);
    newLeaderboardBtn.addEventListener('click', () => { 
        document.getElementById('leaderboardSidebarDashboard').classList.add('active'); 
    });
}

const closeSidebarBtn = document.getElementById('closeSidebarDashboard');
if (closeSidebarBtn) {
    closeSidebarBtn.addEventListener('click', () => { 
        document.getElementById('leaderboardSidebarDashboard').classList.remove('active'); 
    });
}

// ========== RECENT ORDERS PAGINATION ==========
let currentPageDashboard = 0, perPageDashboard = 10;

const tbodyDashboard = document.getElementById('recentOrdersBodyDashboard'), 
      prevBtnDashboard = document.getElementById('prevPageBtnDashboard'), 
      nextBtnDashboard = document.getElementById('nextPageBtnDashboard'), 
      orderRangeSpanDashboard = document.getElementById('orderRangeDashboard');

function renderOrdersDashboard() {
    if (!tbodyDashboard) return;
    const start = currentPageDashboard * perPageDashboard, 
          end = start + perPageDashboard, 
          pageOrders = allOrdersDashboard.slice(start, end);
    
    tbodyDashboard.innerHTML = '';
    pageOrders.forEach(order => { 
        const orderDate = order.order_date_local || (order.order_time ? new Date(order.order_time).toISOString().split('T')[0] : '-');
        tbodyDashboard.innerHTML += `
            <tr>
                <td>${orderDate}</td>
                <td>${escapeHtml(order.product_name?.substring(0, 45) || '-')}</td>
                <td>${escapeHtml(order.creator_username || 'Unknown')}</td>
                <td class="gmv-cell">Rp ${formatNumber(order.gmv)}</td>
                <td>Rp ${formatNumber(order.estimated_commission)}</td>
            </tr>
        `; 
    });
    
    if (orderRangeSpanDashboard) orderRangeSpanDashboard.innerText = `${start+1}-${Math.min(end, allOrdersDashboard.length)}`;
    if (prevBtnDashboard) prevBtnDashboard.disabled = currentPageDashboard === 0;
    if (nextBtnDashboard) nextBtnDashboard.disabled = end >= allOrdersDashboard.length;
}

if (prevBtnDashboard) {
    prevBtnDashboard.addEventListener('click', () => { 
        if (currentPageDashboard > 0) { 
            currentPageDashboard--; 
            renderOrdersDashboard(); 
        } 
    });
}

if (nextBtnDashboard) {
    nextBtnDashboard.addEventListener('click', () => { 
        if ((currentPageDashboard+1)*perPageDashboard < allOrdersDashboard.length) { 
            currentPageDashboard++; 
            renderOrdersDashboard(); 
        } 
    });
}
renderOrdersDashboard();

// ========== MOBILE BOTTOM NAV ==========
document.querySelectorAll('.mobile-nav-item-dashboard').forEach(item => { 
    item.addEventListener('click', (e) => { 
        e.preventDefault(); 
        const tabId = item.getAttribute('data-tab'); 
        const tabBtn = document.querySelector(`.tab-btn-dashboard[data-tab="${tabId}"]`);
        if (tabBtn) tabBtn.click();
    }); 
});

// ========== MODAL CLOSE ==========
// const closeModalBtn = document.getElementById('closeTaskModalDashboard');
// if (closeModalBtn) {
//     const newCloseBtn = closeModalBtn.cloneNode(true);
//     closeModalBtn.parentNode.replaceChild(newCloseBtn, closeModalBtn);
//     newCloseBtn.addEventListener('click', closeModalDashboard);
// }

// const modalOverlay = document.getElementById('taskModalDashboard');
// if (modalOverlay) {
//     const newOverlay = modalOverlay.cloneNode(true);
//     modalOverlay.parentNode.replaceChild(newOverlay, modalOverlay);
//     newOverlay.addEventListener('click', (e) => { 
//         if (e.target === newOverlay) closeModalDashboard(); 
//     });
// }
// Paksa pasang onclick ke tombol X
document.addEventListener('DOMContentLoaded', function() {
    const closeX = document.getElementById('closeTaskModalDashboard');
    if (closeX) {
        closeX.onclick = function() {
            console.log('X clicked via onclick');
            document.getElementById('taskModalDashboard').classList.remove('active');
            return false;
        };
    }
    
    const modalOverlay = document.getElementById('taskModalDashboard');
    if (modalOverlay) {
        modalOverlay.onclick = function(e) {
            if (e.target === modalOverlay) {
                modalOverlay.classList.remove('active');
            }
        };
    }
});
// ========== INITIALIZE ==========
document.addEventListener('DOMContentLoaded', () => { 
    updateStageUIDashboard(); 
    console.log('Dashboard initialized - 3 tasks (Hunting, Setup Campaign, Monitoring)');
});

// ========== SEARCH FUNCTIONS ==========
function initSearchTask(searchInputId, containerId) {
    const searchInput = document.getElementById(searchInputId);
    if (!searchInput) return;
    
    searchInput.addEventListener('keyup', function() {
        const searchTerm = this.value.toLowerCase();
        const items = document.querySelectorAll('#' + containerId + ' .brand-item-dashboard');
        let visibleCount = 0;
        
        items.forEach(function(item) {
            const brandName = item.getAttribute('data-brand-name') || '';
            if (brandName.toLowerCase().indexOf(searchTerm) > -1) {
                item.style.display = '';
                visibleCount++;
            } else {
                item.style.display = 'none';
            }
        });
        
        const countSpan = document.getElementById(searchInputId.replace('search', '').replace('Dashboard', 'CountDashboard'));
        if (countSpan) {
            countSpan.innerText = visibleCount;
        }
        
        const container = document.getElementById(containerId);
        const noResultDiv = container.querySelector('.no-search-result');
        
        if (visibleCount === 0 && searchTerm !== '') {
            if (!noResultDiv) {
                const noResult = document.createElement('div');
                noResult.className = 'stage-item-dashboard';
                noResult.setAttribute('data-no-result', 'true');
                noResult.innerHTML = '<strong><i class="fas fa-search"></i> Tidak ada brand yang cocok</strong><div class="brand-details-dashboard">Coba kata kunci lain</div>';
                container.appendChild(noResult);
            }
        } else {
            if (noResultDiv) {
                noResultDiv.remove();
            }
        }
    });
}

initSearchTask('searchHuntingDashboard', 'huntingItemsContainerDashboard');
initSearchTask('searchSetupDashboard', 'setupItemsContainerDashboard');
initSearchTask('searchMonitoringDashboard', 'monitoringItemsContainerDashboard');

function resetAllSearches() {
    const searchInputs = ['searchHuntingDashboard', 'searchSetupDashboard', 'searchMonitoringDashboard'];
    searchInputs.forEach(function(inputId) {
        const input = document.getElementById(inputId);
        if (input) {
            input.value = '';
            const event = new Event('keyup');
            input.dispatchEvent(event);
        }
    });
}
// ========== LEADERBOARD REFRESH ==========

// Jalankan di console browser untuk cek
console.log('closeTaskModalDashboard:', document.getElementById('closeTaskModalDashboard'));
console.log('taskModalDashboard:', document.getElementById('taskModalDashboard'));

// Coba paksa close
document.getElementById('taskModalDashboard').classList.remove('active');
</script>